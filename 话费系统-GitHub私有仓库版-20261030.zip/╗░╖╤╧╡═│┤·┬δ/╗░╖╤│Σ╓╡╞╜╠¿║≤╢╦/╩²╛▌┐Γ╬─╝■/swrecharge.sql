/*
Navicat MySQL Data Transfer

Source Server         : 120.25.74.61
Source Server Version : 50722
Source Host           : 120.25.74.61:3306
Source Database       : swrecharge

Target Server Type    : MYSQL
Target Server Version : 50722
File Encoding         : 65001

Date: 2024-07-14 16:44:07
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `gen_table`
-- ----------------------------
DROP TABLE IF EXISTS `gen_table`;
CREATE TABLE `gen_table` (
  `table_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `table_name` varchar(200) DEFAULT '' COMMENT '表名称',
  `table_comment` varchar(500) DEFAULT '' COMMENT '表描述',
  `sub_table_name` varchar(64) DEFAULT NULL COMMENT '关联子表的表名',
  `sub_table_fk_name` varchar(64) DEFAULT NULL COMMENT '子表关联的外键名',
  `class_name` varchar(100) DEFAULT '' COMMENT '实体类名称',
  `tpl_category` varchar(200) DEFAULT 'crud' COMMENT '使用的模板（crud单表操作 tree树表操作）',
  `package_name` varchar(100) DEFAULT NULL COMMENT '生成包路径',
  `module_name` varchar(30) DEFAULT NULL COMMENT '生成模块名',
  `business_name` varchar(30) DEFAULT NULL COMMENT '生成业务名',
  `function_name` varchar(50) DEFAULT NULL COMMENT '生成功能名',
  `function_author` varchar(50) DEFAULT NULL COMMENT '生成功能作者',
  `gen_type` char(1) DEFAULT '0' COMMENT '生成代码方式（0zip压缩包 1自定义路径）',
  `gen_path` varchar(200) DEFAULT '/' COMMENT '生成路径（不填默认项目路径）',
  `options` varchar(1000) DEFAULT NULL COMMENT '其它生成选项',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`table_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=163 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='代码生成业务表';

-- ----------------------------
-- Records of gen_table
-- ----------------------------

-- ----------------------------
-- Table structure for `gen_table_column`
-- ----------------------------
DROP TABLE IF EXISTS `gen_table_column`;
CREATE TABLE `gen_table_column` (
  `column_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `table_id` varchar(64) DEFAULT NULL COMMENT '归属表编号',
  `column_name` varchar(200) DEFAULT NULL COMMENT '列名称',
  `column_comment` varchar(500) DEFAULT NULL COMMENT '列描述',
  `column_type` varchar(100) DEFAULT NULL COMMENT '列类型',
  `java_type` varchar(500) DEFAULT NULL COMMENT 'JAVA类型',
  `java_field` varchar(200) DEFAULT NULL COMMENT 'JAVA字段名',
  `is_pk` char(1) DEFAULT NULL COMMENT '是否主键（1是）',
  `is_increment` char(1) DEFAULT NULL COMMENT '是否自增（1是）',
  `is_required` char(1) DEFAULT NULL COMMENT '是否必填（1是）',
  `is_insert` char(1) DEFAULT NULL COMMENT '是否为插入字段（1是）',
  `is_edit` char(1) DEFAULT NULL COMMENT '是否编辑字段（1是）',
  `is_list` char(1) DEFAULT NULL COMMENT '是否列表字段（1是）',
  `is_query` char(1) DEFAULT NULL COMMENT '是否查询字段（1是）',
  `query_type` varchar(200) DEFAULT 'EQ' COMMENT '查询方式（等于、不等于、大于、小于、范围）',
  `html_type` varchar(200) DEFAULT NULL COMMENT '显示类型（文本框、文本域、下拉框、复选框、单选框、日期控件）',
  `dict_type` varchar(200) DEFAULT '' COMMENT '字典类型',
  `sort` int(11) DEFAULT NULL COMMENT '排序',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`column_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2801 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='代码生成业务表字段';

-- ----------------------------
-- Records of gen_table_column
-- ----------------------------

-- ----------------------------
-- Table structure for `pub_file`
-- ----------------------------
DROP TABLE IF EXISTS `pub_file`;
CREATE TABLE `pub_file` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '文件id',
  `biz_id` bigint(20) DEFAULT NULL COMMENT '业务id',
  `biz_key` varchar(100) DEFAULT NULL COMMENT '业务类型',
  `file_name` varchar(200) DEFAULT NULL COMMENT '文件名',
  `file_url` varchar(1000) DEFAULT NULL COMMENT '文件存储路径',
  `file_type` varchar(50) DEFAULT NULL COMMENT '文件类型',
  `size` bigint(20) DEFAULT NULL COMMENT '文件大小',
  `other_file_url` varchar(1000) DEFAULT NULL COMMENT '补充文件路径',
  `is_need` char(1) DEFAULT 'F' COMMENT '是否必须，T-是 F-否',
  `agent_id` bigint(20) DEFAULT NULL COMMENT '代理商id',
  `audit_time` datetime DEFAULT NULL COMMENT '审核时间',
  `audit_remark` varchar(50) DEFAULT NULL COMMENT '审核意见',
  `status` tinyint(4) DEFAULT '0' COMMENT '状态',
  `auditor` varchar(50) DEFAULT NULL COMMENT '审核人',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `sort_num` int(11) DEFAULT '0' COMMENT '序号',
  `del_flag` char(1) DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='通用文件';

-- ----------------------------
-- Records of pub_file
-- ----------------------------

-- ----------------------------
-- Table structure for `pv_agent`
-- ----------------------------
DROP TABLE IF EXISTS `pv_agent`;
CREATE TABLE `pv_agent` (
  `agent_id` bigint(20) NOT NULL COMMENT '代理商ID，使用分布式id',
  `agent_name` varchar(100) NOT NULL COMMENT '单位名称',
  `credit_code` varchar(30) DEFAULT NULL COMMENT '统一社会信用代码',
  `legal_person` varchar(50) DEFAULT NULL COMMENT '法人',
  `contacts` varchar(50) DEFAULT NULL COMMENT '联络人',
  `phone` varchar(20) DEFAULT NULL COMMENT '联络人手机',
  `credit` int(11) DEFAULT NULL COMMENT '信用额（单位：元）',
  `dept_id` bigint(20) DEFAULT NULL COMMENT '对应部门id',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `status` tinyint(4) DEFAULT NULL COMMENT '状态',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `sort_num` int(11) DEFAULT '0' COMMENT '序号',
  `del_flag` char(1) DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  PRIMARY KEY (`agent_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='代理商';

-- ----------------------------
-- Records of pv_agent
-- ----------------------------

-- ----------------------------
-- Table structure for `pv_area`
-- ----------------------------
DROP TABLE IF EXISTS `pv_area`;
CREATE TABLE `pv_area` (
  `area_id` varchar(20) NOT NULL COMMENT '区域id',
  `parent_id` varchar(20) DEFAULT NULL COMMENT '上级区域id',
  `ancestors` varchar(100) DEFAULT '' COMMENT '祖级列表',
  `short_name` varchar(100) DEFAULT NULL COMMENT '省市区名称',
  `real_name` varchar(300) DEFAULT NULL COMMENT '省市区简称',
  `level` int(11) DEFAULT NULL COMMENT '显示层级',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`area_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='区域';

-- ----------------------------
-- Records of pv_area
-- ----------------------------

-- ----------------------------
-- Table structure for `pv_serial_number`
-- ----------------------------
DROP TABLE IF EXISTS `pv_serial_number`;
CREATE TABLE `pv_serial_number` (
  `id` bigint(20) NOT NULL COMMENT '主键id',
  `prefix` varchar(50) DEFAULT NULL COMMENT '编号前缀',
  `seq_no` int(11) DEFAULT NULL COMMENT '序列号',
  `serial_no` varchar(100) DEFAULT NULL COMMENT '生成的编号',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `del_flag` char(1) DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='编号生成记录表';

-- ----------------------------
-- Records of pv_serial_number
-- ----------------------------

-- ----------------------------
-- Table structure for `qrtz_blob_triggers`
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_blob_triggers`;
CREATE TABLE `qrtz_blob_triggers` (
  `sched_name` varchar(120) NOT NULL COMMENT '调度名称',
  `trigger_name` varchar(200) NOT NULL COMMENT 'qrtz_triggers表trigger_name的外键',
  `trigger_group` varchar(200) NOT NULL COMMENT 'qrtz_triggers表trigger_group的外键',
  `blob_data` blob COMMENT '存放持久化Trigger对象',
  PRIMARY KEY (`sched_name`,`trigger_name`,`trigger_group`) USING BTREE,
  CONSTRAINT `qrtz_blob_triggers_ibfk_1` FOREIGN KEY (`sched_name`, `trigger_name`, `trigger_group`) REFERENCES `qrtz_triggers` (`sched_name`, `trigger_name`, `trigger_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='Blob类型的触发器表';

-- ----------------------------
-- Records of qrtz_blob_triggers
-- ----------------------------

-- ----------------------------
-- Table structure for `qrtz_calendars`
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_calendars`;
CREATE TABLE `qrtz_calendars` (
  `sched_name` varchar(120) NOT NULL COMMENT '调度名称',
  `calendar_name` varchar(200) NOT NULL COMMENT '日历名称',
  `calendar` blob NOT NULL COMMENT '存放持久化calendar对象',
  PRIMARY KEY (`sched_name`,`calendar_name`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='日历信息表';

-- ----------------------------
-- Records of qrtz_calendars
-- ----------------------------

-- ----------------------------
-- Table structure for `qrtz_cron_triggers`
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_cron_triggers`;
CREATE TABLE `qrtz_cron_triggers` (
  `sched_name` varchar(120) NOT NULL COMMENT '调度名称',
  `trigger_name` varchar(200) NOT NULL COMMENT 'qrtz_triggers表trigger_name的外键',
  `trigger_group` varchar(200) NOT NULL COMMENT 'qrtz_triggers表trigger_group的外键',
  `cron_expression` varchar(200) NOT NULL COMMENT 'cron表达式',
  `time_zone_id` varchar(80) DEFAULT NULL COMMENT '时区',
  PRIMARY KEY (`sched_name`,`trigger_name`,`trigger_group`) USING BTREE,
  CONSTRAINT `qrtz_cron_triggers_ibfk_1` FOREIGN KEY (`sched_name`, `trigger_name`, `trigger_group`) REFERENCES `qrtz_triggers` (`sched_name`, `trigger_name`, `trigger_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='Cron类型的触发器表';

-- ----------------------------
-- Records of qrtz_cron_triggers
-- ----------------------------

-- ----------------------------
-- Table structure for `qrtz_fired_triggers`
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_fired_triggers`;
CREATE TABLE `qrtz_fired_triggers` (
  `sched_name` varchar(120) NOT NULL COMMENT '调度名称',
  `entry_id` varchar(95) NOT NULL COMMENT '调度器实例id',
  `trigger_name` varchar(200) NOT NULL COMMENT 'qrtz_triggers表trigger_name的外键',
  `trigger_group` varchar(200) NOT NULL COMMENT 'qrtz_triggers表trigger_group的外键',
  `instance_name` varchar(200) NOT NULL COMMENT '调度器实例名',
  `fired_time` bigint(20) NOT NULL COMMENT '触发的时间',
  `sched_time` bigint(20) NOT NULL COMMENT '定时器制定的时间',
  `priority` int(11) NOT NULL COMMENT '优先级',
  `state` varchar(16) NOT NULL COMMENT '状态',
  `job_name` varchar(200) DEFAULT NULL COMMENT '任务名称',
  `job_group` varchar(200) DEFAULT NULL COMMENT '任务组名',
  `is_nonconcurrent` varchar(1) DEFAULT NULL COMMENT '是否并发',
  `requests_recovery` varchar(1) DEFAULT NULL COMMENT '是否接受恢复执行',
  PRIMARY KEY (`sched_name`,`entry_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='已触发的触发器表';

-- ----------------------------
-- Records of qrtz_fired_triggers
-- ----------------------------

-- ----------------------------
-- Table structure for `qrtz_job_details`
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_job_details`;
CREATE TABLE `qrtz_job_details` (
  `sched_name` varchar(120) NOT NULL COMMENT '调度名称',
  `job_name` varchar(200) NOT NULL COMMENT '任务名称',
  `job_group` varchar(200) NOT NULL COMMENT '任务组名',
  `description` varchar(250) DEFAULT NULL COMMENT '相关介绍',
  `job_class_name` varchar(250) NOT NULL COMMENT '执行任务类名称',
  `is_durable` varchar(1) NOT NULL COMMENT '是否持久化',
  `is_nonconcurrent` varchar(1) NOT NULL COMMENT '是否并发',
  `is_update_data` varchar(1) NOT NULL COMMENT '是否更新数据',
  `requests_recovery` varchar(1) NOT NULL COMMENT '是否接受恢复执行',
  `job_data` blob COMMENT '存放持久化job对象',
  PRIMARY KEY (`sched_name`,`job_name`,`job_group`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='任务详细信息表';

-- ----------------------------
-- Records of qrtz_job_details
-- ----------------------------

-- ----------------------------
-- Table structure for `qrtz_locks`
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_locks`;
CREATE TABLE `qrtz_locks` (
  `sched_name` varchar(120) NOT NULL COMMENT '调度名称',
  `lock_name` varchar(40) NOT NULL COMMENT '悲观锁名称',
  PRIMARY KEY (`sched_name`,`lock_name`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='存储的悲观锁信息表';

-- ----------------------------
-- Records of qrtz_locks
-- ----------------------------

-- ----------------------------
-- Table structure for `qrtz_paused_trigger_grps`
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_paused_trigger_grps`;
CREATE TABLE `qrtz_paused_trigger_grps` (
  `sched_name` varchar(120) NOT NULL COMMENT '调度名称',
  `trigger_group` varchar(200) NOT NULL COMMENT 'qrtz_triggers表trigger_group的外键',
  PRIMARY KEY (`sched_name`,`trigger_group`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='暂停的触发器表';

-- ----------------------------
-- Records of qrtz_paused_trigger_grps
-- ----------------------------

-- ----------------------------
-- Table structure for `qrtz_scheduler_state`
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_scheduler_state`;
CREATE TABLE `qrtz_scheduler_state` (
  `sched_name` varchar(120) NOT NULL COMMENT '调度名称',
  `instance_name` varchar(200) NOT NULL COMMENT '实例名称',
  `last_checkin_time` bigint(20) NOT NULL COMMENT '上次检查时间',
  `checkin_interval` bigint(20) NOT NULL COMMENT '检查间隔时间',
  PRIMARY KEY (`sched_name`,`instance_name`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='调度器状态表';

-- ----------------------------
-- Records of qrtz_scheduler_state
-- ----------------------------

-- ----------------------------
-- Table structure for `qrtz_simple_triggers`
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_simple_triggers`;
CREATE TABLE `qrtz_simple_triggers` (
  `sched_name` varchar(120) NOT NULL COMMENT '调度名称',
  `trigger_name` varchar(200) NOT NULL COMMENT 'qrtz_triggers表trigger_name的外键',
  `trigger_group` varchar(200) NOT NULL COMMENT 'qrtz_triggers表trigger_group的外键',
  `repeat_count` bigint(20) NOT NULL COMMENT '重复的次数统计',
  `repeat_interval` bigint(20) NOT NULL COMMENT '重复的间隔时间',
  `times_triggered` bigint(20) NOT NULL COMMENT '已经触发的次数',
  PRIMARY KEY (`sched_name`,`trigger_name`,`trigger_group`) USING BTREE,
  CONSTRAINT `qrtz_simple_triggers_ibfk_1` FOREIGN KEY (`sched_name`, `trigger_name`, `trigger_group`) REFERENCES `qrtz_triggers` (`sched_name`, `trigger_name`, `trigger_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='简单触发器的信息表';

-- ----------------------------
-- Records of qrtz_simple_triggers
-- ----------------------------

-- ----------------------------
-- Table structure for `qrtz_simprop_triggers`
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_simprop_triggers`;
CREATE TABLE `qrtz_simprop_triggers` (
  `sched_name` varchar(120) NOT NULL COMMENT '调度名称',
  `trigger_name` varchar(200) NOT NULL COMMENT 'qrtz_triggers表trigger_name的外键',
  `trigger_group` varchar(200) NOT NULL COMMENT 'qrtz_triggers表trigger_group的外键',
  `str_prop_1` varchar(512) DEFAULT NULL COMMENT 'String类型的trigger的第一个参数',
  `str_prop_2` varchar(512) DEFAULT NULL COMMENT 'String类型的trigger的第二个参数',
  `str_prop_3` varchar(512) DEFAULT NULL COMMENT 'String类型的trigger的第三个参数',
  `int_prop_1` int(11) DEFAULT NULL COMMENT 'int类型的trigger的第一个参数',
  `int_prop_2` int(11) DEFAULT NULL COMMENT 'int类型的trigger的第二个参数',
  `long_prop_1` bigint(20) DEFAULT NULL COMMENT 'long类型的trigger的第一个参数',
  `long_prop_2` bigint(20) DEFAULT NULL COMMENT 'long类型的trigger的第二个参数',
  `dec_prop_1` decimal(13,4) DEFAULT NULL COMMENT 'decimal类型的trigger的第一个参数',
  `dec_prop_2` decimal(13,4) DEFAULT NULL COMMENT 'decimal类型的trigger的第二个参数',
  `bool_prop_1` varchar(1) DEFAULT NULL COMMENT 'Boolean类型的trigger的第一个参数',
  `bool_prop_2` varchar(1) DEFAULT NULL COMMENT 'Boolean类型的trigger的第二个参数',
  PRIMARY KEY (`sched_name`,`trigger_name`,`trigger_group`) USING BTREE,
  CONSTRAINT `qrtz_simprop_triggers_ibfk_1` FOREIGN KEY (`sched_name`, `trigger_name`, `trigger_group`) REFERENCES `qrtz_triggers` (`sched_name`, `trigger_name`, `trigger_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='同步机制的行锁表';

-- ----------------------------
-- Records of qrtz_simprop_triggers
-- ----------------------------

-- ----------------------------
-- Table structure for `qrtz_triggers`
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_triggers`;
CREATE TABLE `qrtz_triggers` (
  `sched_name` varchar(120) NOT NULL COMMENT '调度名称',
  `trigger_name` varchar(200) NOT NULL COMMENT '触发器的名字',
  `trigger_group` varchar(200) NOT NULL COMMENT '触发器所属组的名字',
  `job_name` varchar(200) NOT NULL COMMENT 'qrtz_job_details表job_name的外键',
  `job_group` varchar(200) NOT NULL COMMENT 'qrtz_job_details表job_group的外键',
  `description` varchar(250) DEFAULT NULL COMMENT '相关介绍',
  `next_fire_time` bigint(20) DEFAULT NULL COMMENT '上一次触发时间（毫秒）',
  `prev_fire_time` bigint(20) DEFAULT NULL COMMENT '下一次触发时间（默认为-1表示不触发）',
  `priority` int(11) DEFAULT NULL COMMENT '优先级',
  `trigger_state` varchar(16) NOT NULL COMMENT '触发器状态',
  `trigger_type` varchar(8) NOT NULL COMMENT '触发器的类型',
  `start_time` bigint(20) NOT NULL COMMENT '开始时间',
  `end_time` bigint(20) DEFAULT NULL COMMENT '结束时间',
  `calendar_name` varchar(200) DEFAULT NULL COMMENT '日程表名称',
  `misfire_instr` smallint(6) DEFAULT NULL COMMENT '补偿执行的策略',
  `job_data` blob COMMENT '存放持久化job对象',
  PRIMARY KEY (`sched_name`,`trigger_name`,`trigger_group`) USING BTREE,
  KEY `sched_name` (`sched_name`,`job_name`,`job_group`) USING BTREE,
  CONSTRAINT `qrtz_triggers_ibfk_1` FOREIGN KEY (`sched_name`, `job_name`, `job_group`) REFERENCES `qrtz_job_details` (`sched_name`, `job_name`, `job_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='触发器详细信息表';

-- ----------------------------
-- Records of qrtz_triggers
-- ----------------------------

-- ----------------------------
-- Table structure for `sys_config`
-- ----------------------------
DROP TABLE IF EXISTS `sys_config`;
CREATE TABLE `sys_config` (
  `config_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '参数主键',
  `config_name` varchar(100) DEFAULT '' COMMENT '参数名称',
  `config_key` varchar(100) DEFAULT '' COMMENT '参数键名',
  `config_value` varchar(500) DEFAULT '' COMMENT '参数键值',
  `config_type` char(1) DEFAULT 'N' COMMENT '系统内置（Y是 N否）',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`config_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='参数配置表';

-- ----------------------------
-- Records of sys_config
-- ----------------------------

-- ----------------------------
-- Table structure for `sys_dept`
-- ----------------------------
DROP TABLE IF EXISTS `sys_dept`;
CREATE TABLE `sys_dept` (
  `dept_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '部门id',
  `parent_id` bigint(20) DEFAULT '0' COMMENT '父部门id',
  `ancestors` varchar(50) DEFAULT '' COMMENT '祖级列表',
  `dept_name` varchar(30) DEFAULT '' COMMENT '部门名称',
  `order_num` int(11) DEFAULT '0' COMMENT '显示顺序',
  `leader` varchar(20) DEFAULT NULL COMMENT '负责人',
  `phone` varchar(11) DEFAULT NULL COMMENT '联系电话',
  `email` varchar(50) DEFAULT NULL COMMENT '邮箱',
  `status` char(1) DEFAULT '0' COMMENT '部门状态（0正常 1停用）',
  `del_flag` char(1) DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`dept_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=201 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='部门表';

-- ----------------------------
-- Records of sys_dept
-- ----------------------------

-- ----------------------------
-- Table structure for `sys_dict_data`
-- ----------------------------
DROP TABLE IF EXISTS `sys_dict_data`;
CREATE TABLE `sys_dict_data` (
  `dict_code` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '字典编码',
  `dict_sort` int(11) DEFAULT '0' COMMENT '字典排序',
  `dict_label` varchar(100) DEFAULT '' COMMENT '字典标签',
  `dict_value` varchar(100) DEFAULT '' COMMENT '字典键值',
  `dict_type` varchar(100) DEFAULT '' COMMENT '字典类型',
  `css_class` varchar(100) DEFAULT NULL COMMENT '样式属性（其他样式扩展）',
  `list_class` varchar(100) DEFAULT NULL COMMENT '表格回显样式',
  `is_default` char(1) DEFAULT 'N' COMMENT '是否默认（Y是 N否）',
  `status` char(1) DEFAULT '0' COMMENT '状态（0正常 1停用）',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`dict_code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='字典数据表';

-- ----------------------------
-- Records of sys_dict_data
-- ----------------------------

-- ----------------------------
-- Table structure for `sys_dict_type`
-- ----------------------------
DROP TABLE IF EXISTS `sys_dict_type`;
CREATE TABLE `sys_dict_type` (
  `dict_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '字典主键',
  `dict_name` varchar(100) DEFAULT '' COMMENT '字典名称',
  `dict_type` varchar(100) DEFAULT '' COMMENT '字典类型',
  `status` char(1) DEFAULT '0' COMMENT '状态（0正常 1停用）',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`dict_id`) USING BTREE,
  UNIQUE KEY `dict_type` (`dict_type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='字典类型表';

-- ----------------------------
-- Records of sys_dict_type
-- ----------------------------

-- ----------------------------
-- Table structure for `sys_job`
-- ----------------------------
DROP TABLE IF EXISTS `sys_job`;
CREATE TABLE `sys_job` (
  `job_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '任务ID',
  `job_name` varchar(64) NOT NULL DEFAULT '' COMMENT '任务名称',
  `job_group` varchar(64) NOT NULL DEFAULT 'DEFAULT' COMMENT '任务组名',
  `invoke_target` varchar(500) NOT NULL COMMENT '调用目标字符串',
  `cron_expression` varchar(255) DEFAULT '' COMMENT 'cron执行表达式',
  `misfire_policy` varchar(20) DEFAULT '3' COMMENT '计划执行错误策略（1立即执行 2执行一次 3放弃执行）',
  `concurrent` char(1) DEFAULT '1' COMMENT '是否并发执行（0允许 1禁止）',
  `status` char(1) DEFAULT '0' COMMENT '状态（0正常 1暂停）',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) DEFAULT '' COMMENT '备注信息',
  PRIMARY KEY (`job_id`,`job_name`,`job_group`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='定时任务调度表';

-- ----------------------------
-- Records of sys_job
-- ----------------------------

-- ----------------------------
-- Table structure for `sys_job_log`
-- ----------------------------
DROP TABLE IF EXISTS `sys_job_log`;
CREATE TABLE `sys_job_log` (
  `job_log_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '任务日志ID',
  `job_name` varchar(64) NOT NULL COMMENT '任务名称',
  `job_group` varchar(64) NOT NULL COMMENT '任务组名',
  `invoke_target` varchar(500) NOT NULL COMMENT '调用目标字符串',
  `job_message` varchar(500) DEFAULT NULL COMMENT '日志信息',
  `status` char(1) DEFAULT '0' COMMENT '执行状态（0正常 1失败）',
  `exception_info` varchar(2000) DEFAULT '' COMMENT '异常信息',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`job_log_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='定时任务调度日志表';

-- ----------------------------
-- Records of sys_job_log
-- ----------------------------

-- ----------------------------
-- Table structure for `sys_logininfor`
-- ----------------------------
DROP TABLE IF EXISTS `sys_logininfor`;
CREATE TABLE `sys_logininfor` (
  `info_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '访问ID',
  `user_name` varchar(50) DEFAULT '' COMMENT '用户账号',
  `ipaddr` varchar(128) DEFAULT '' COMMENT '登录IP地址',
  `login_location` varchar(255) DEFAULT '' COMMENT '登录地点',
  `browser` varchar(50) DEFAULT '' COMMENT '浏览器类型',
  `os` varchar(50) DEFAULT '' COMMENT '操作系统',
  `status` char(1) DEFAULT '0' COMMENT '登录状态（0成功 1失败）',
  `msg` varchar(255) DEFAULT '' COMMENT '提示消息',
  `login_time` datetime DEFAULT NULL COMMENT '访问时间',
  PRIMARY KEY (`info_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=13446 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='系统访问记录';

-- ----------------------------
-- Records of sys_logininfor
-- ----------------------------

-- ----------------------------
-- Table structure for `sys_menu`
-- ----------------------------
DROP TABLE IF EXISTS `sys_menu`;
CREATE TABLE `sys_menu` (
  `menu_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '菜单ID',
  `menu_name` varchar(50) NOT NULL COMMENT '菜单名称',
  `parent_id` bigint(20) DEFAULT '0' COMMENT '父菜单ID',
  `order_num` int(11) DEFAULT '0' COMMENT '显示顺序',
  `path` varchar(200) DEFAULT '' COMMENT '路由地址',
  `component` varchar(255) DEFAULT NULL COMMENT '组件路径',
  `query` varchar(255) DEFAULT NULL COMMENT '路由参数',
  `is_frame` int(11) DEFAULT '1' COMMENT '是否为外链（0是 1否）',
  `is_cache` int(11) DEFAULT '0' COMMENT '是否缓存（0缓存 1不缓存）',
  `menu_type` char(1) DEFAULT '' COMMENT '菜单类型（M目录 C菜单 F按钮）',
  `visible` char(1) DEFAULT '0' COMMENT '菜单状态（0显示 1隐藏）',
  `status` char(1) DEFAULT '0' COMMENT '菜单状态（0正常 1停用）',
  `perms` varchar(100) DEFAULT NULL COMMENT '权限标识',
  `icon` varchar(100) DEFAULT '#' COMMENT '菜单图标',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) DEFAULT '' COMMENT '备注',
  PRIMARY KEY (`menu_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2150 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='菜单权限表';

-- ----------------------------
-- Records of sys_menu
-- ----------------------------

-- ----------------------------
-- Table structure for `sys_notice`
-- ----------------------------
DROP TABLE IF EXISTS `sys_notice`;
CREATE TABLE `sys_notice` (
  `notice_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '公告ID',
  `notice_title` varchar(50) NOT NULL COMMENT '公告标题',
  `notice_type` char(1) NOT NULL COMMENT '公告类型（1通知 2公告）',
  `notice_content` longblob COMMENT '公告内容',
  `status` char(1) DEFAULT '0' COMMENT '公告状态（0正常 1关闭）',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`notice_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='通知公告表';

-- ----------------------------
-- Records of sys_notice
-- ----------------------------

-- ----------------------------
-- Table structure for `sys_oper_log`
-- ----------------------------
DROP TABLE IF EXISTS `sys_oper_log`;
CREATE TABLE `sys_oper_log` (
  `oper_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '日志主键',
  `title` varchar(50) DEFAULT '' COMMENT '模块标题',
  `business_type` int(11) DEFAULT '0' COMMENT '业务类型（0其它 1新增 2修改 3删除）',
  `method` varchar(100) DEFAULT '' COMMENT '方法名称',
  `request_method` varchar(10) DEFAULT '' COMMENT '请求方式',
  `operator_type` int(11) DEFAULT '0' COMMENT '操作类别（0其它 1后台用户 2手机端用户）',
  `oper_name` varchar(50) DEFAULT '' COMMENT '操作人员',
  `dept_name` varchar(50) DEFAULT '' COMMENT '部门名称',
  `oper_url` varchar(255) DEFAULT '' COMMENT '请求URL',
  `oper_ip` varchar(128) DEFAULT '' COMMENT '主机地址',
  `oper_location` varchar(255) DEFAULT '' COMMENT '操作地点',
  `oper_param` varchar(2000) DEFAULT '' COMMENT '请求参数',
  `json_result` varchar(2000) DEFAULT '' COMMENT '返回参数',
  `status` int(11) DEFAULT '0' COMMENT '操作状态（0正常 1异常）',
  `error_msg` varchar(2000) DEFAULT '' COMMENT '错误消息',
  `oper_time` datetime DEFAULT NULL COMMENT '操作时间',
  PRIMARY KEY (`oper_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=55025 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='操作日志记录';

-- ----------------------------
-- Records of sys_oper_log
-- ----------------------------

-- ----------------------------
-- Table structure for `sys_post`
-- ----------------------------
DROP TABLE IF EXISTS `sys_post`;
CREATE TABLE `sys_post` (
  `post_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '岗位ID',
  `post_code` varchar(64) NOT NULL COMMENT '岗位编码',
  `post_name` varchar(50) NOT NULL COMMENT '岗位名称',
  `post_sort` int(11) NOT NULL COMMENT '显示顺序',
  `status` char(1) NOT NULL COMMENT '状态（0正常 1停用）',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`post_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='岗位信息表';

-- ----------------------------
-- Records of sys_post
-- ----------------------------

-- ----------------------------
-- Table structure for `sys_role`
-- ----------------------------
DROP TABLE IF EXISTS `sys_role`;
CREATE TABLE `sys_role` (
  `role_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '角色ID',
  `role_name` varchar(30) NOT NULL COMMENT '角色名称',
  `role_key` varchar(100) NOT NULL COMMENT '角色权限字符串',
  `role_sort` int(11) NOT NULL COMMENT '显示顺序',
  `data_scope` char(1) DEFAULT '1' COMMENT '数据范围（1：全部数据权限 2：自定数据权限 3：本部门数据权限 4：本部门及以下数据权限）',
  `menu_check_strictly` tinyint(1) DEFAULT '1' COMMENT '菜单树选择项是否关联显示',
  `dept_check_strictly` tinyint(1) DEFAULT '1' COMMENT '部门树选择项是否关联显示',
  `status` char(1) NOT NULL COMMENT '角色状态（0正常 1停用）',
  `del_flag` char(1) DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`role_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='角色信息表';

-- ----------------------------
-- Records of sys_role
-- ----------------------------

-- ----------------------------
-- Table structure for `sys_role_dept`
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_dept`;
CREATE TABLE `sys_role_dept` (
  `role_id` bigint(20) NOT NULL COMMENT '角色ID',
  `dept_id` bigint(20) NOT NULL COMMENT '部门ID',
  PRIMARY KEY (`role_id`,`dept_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='角色和部门关联表';

-- ----------------------------
-- Records of sys_role_dept
-- ----------------------------

-- ----------------------------
-- Table structure for `sys_role_menu`
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_menu`;
CREATE TABLE `sys_role_menu` (
  `role_id` bigint(20) NOT NULL COMMENT '角色ID',
  `menu_id` bigint(20) NOT NULL COMMENT '菜单ID',
  PRIMARY KEY (`role_id`,`menu_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='角色和菜单关联表';

-- ----------------------------
-- Records of sys_role_menu
-- ----------------------------

-- ----------------------------
-- Table structure for `sys_user`
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user` (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `dept_id` bigint(20) DEFAULT NULL COMMENT '部门ID',
  `user_name` varchar(30) NOT NULL COMMENT '用户账号',
  `nick_name` varchar(30) NOT NULL COMMENT '用户昵称',
  `user_type` varchar(2) DEFAULT '00' COMMENT '用户类型（00系统用户）',
  `email` varchar(50) DEFAULT '' COMMENT '用户邮箱',
  `phonenumber` varchar(11) DEFAULT '' COMMENT '手机号码',
  `sex` char(1) DEFAULT '0' COMMENT '用户性别（0男 1女 2未知）',
  `avatar` varchar(100) DEFAULT '' COMMENT '头像地址',
  `password` varchar(100) DEFAULT '' COMMENT '密码',
  `status` char(1) DEFAULT '0' COMMENT '帐号状态（0正常 1停用）',
  `del_flag` char(1) DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `login_ip` varchar(128) DEFAULT '' COMMENT '最后登录IP',
  `login_date` datetime DEFAULT NULL COMMENT '最后登录时间',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='用户信息表';

-- ----------------------------
-- Records of sys_user
-- ----------------------------

-- ----------------------------
-- Table structure for `sys_user_post`
-- ----------------------------
DROP TABLE IF EXISTS `sys_user_post`;
CREATE TABLE `sys_user_post` (
  `user_id` bigint(20) NOT NULL COMMENT '用户ID',
  `post_id` bigint(20) NOT NULL COMMENT '岗位ID',
  PRIMARY KEY (`user_id`,`post_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='用户与岗位关联表';

-- ----------------------------
-- Records of sys_user_post
-- ----------------------------

-- ----------------------------
-- Table structure for `sys_user_role`
-- ----------------------------
DROP TABLE IF EXISTS `sys_user_role`;
CREATE TABLE `sys_user_role` (
  `user_id` bigint(20) NOT NULL COMMENT '用户ID',
  `role_id` bigint(20) NOT NULL COMMENT '角色ID',
  PRIMARY KEY (`user_id`,`role_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='用户和角色关联表';

-- ----------------------------
-- Records of sys_user_role
-- ----------------------------

-- ----------------------------
-- Table structure for `t_activity_product`
-- ----------------------------
DROP TABLE IF EXISTS `t_activity_product`;
CREATE TABLE `t_activity_product` (
  `id` varchar(64) NOT NULL COMMENT '主键id',
  `platform_infos_id` varchar(64) DEFAULT NULL COMMENT '第三放平台归属',
  `activityid` varchar(64) DEFAULT NULL COMMENT '业务id',
  `activity_name` varchar(100) DEFAULT NULL COMMENT '业务商品名城',
  `category` tinyint(4) DEFAULT NULL COMMENT '商品类型 1 话费商品 2 流量商品',
  `activity_describes` varchar(500) DEFAULT NULL COMMENT '业务商品描述',
  `province` int(20) DEFAULT NULL COMMENT '省份',
  `city` int(20) DEFAULT NULL COMMENT '城市',
  `handlelimit` int(11) DEFAULT NULL COMMENT '办理限制次数',
  `smscodenum` int(11) DEFAULT NULL COMMENT '短信接收次数',
  `paycost` decimal(11,2) DEFAULT NULL COMMENT '需要额外支付话费',
  `yys` tinyint(4) DEFAULT NULL COMMENT ' 运营商  1 、移动 2、联通 3、电信',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='第三方业务商品表';

-- ----------------------------
-- Records of t_activity_product
-- ----------------------------

-- ----------------------------
-- Table structure for `t_agent_menu`
-- ----------------------------
DROP TABLE IF EXISTS `t_agent_menu`;
CREATE TABLE `t_agent_menu` (
  `menu_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '菜单ID',
  `menu_name` varchar(50) NOT NULL COMMENT '菜单名称',
  `parent_id` bigint(20) DEFAULT '0' COMMENT '父菜单ID',
  `order_num` int(11) DEFAULT '0' COMMENT '显示顺序',
  `path` varchar(200) DEFAULT '' COMMENT '路由地址',
  `component` varchar(255) DEFAULT NULL COMMENT '组件路径',
  `query` varchar(255) DEFAULT NULL COMMENT '路由参数',
  `is_frame` int(11) DEFAULT '1' COMMENT '是否为外链（0是 1否）',
  `is_cache` int(11) DEFAULT '0' COMMENT '是否缓存（0缓存 1不缓存）',
  `menu_type` char(1) DEFAULT '' COMMENT '菜单类型（M目录 C菜单 F按钮）',
  `visible` char(1) DEFAULT '0' COMMENT '菜单状态（0显示 1隐藏）',
  `status` char(1) DEFAULT '0' COMMENT '菜单状态（0正常 1停用）',
  `perms` varchar(100) DEFAULT NULL COMMENT '权限标识',
  `icon` varchar(100) DEFAULT '#' COMMENT '菜单图标',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) DEFAULT '' COMMENT '备注',
  PRIMARY KEY (`menu_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2144 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='代理商菜单权限表';

-- ----------------------------
-- Records of t_agent_menu
-- ----------------------------

-- ----------------------------
-- Table structure for `t_agent_user`
-- ----------------------------
DROP TABLE IF EXISTS `t_agent_user`;
CREATE TABLE `t_agent_user` (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `user_name` varchar(30) NOT NULL COMMENT '用户账号',
  `nick_name` varchar(30) NOT NULL COMMENT '用户昵称',
  `supplier_id` varchar(64) NOT NULL COMMENT '代理商id',
  `email` varchar(50) DEFAULT '' COMMENT '用户邮箱',
  `phonenumber` varchar(11) DEFAULT '' COMMENT '手机号码',
  `sex` char(1) DEFAULT '0' COMMENT '用户性别（0男 1女 2未知）',
  `avatar` varchar(100) DEFAULT '' COMMENT '头像地址',
  `password` varchar(100) DEFAULT '' COMMENT '密码',
  `status` char(1) DEFAULT '0' COMMENT '帐号状态（0正常 1停用）',
  `del_flag` char(1) DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `login_ip` varchar(128) DEFAULT '' COMMENT '最后登录IP',
  `login_date` datetime DEFAULT NULL COMMENT '最后登录时间',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='代理商用户信息表';

-- ----------------------------
-- Records of t_agent_user
-- ----------------------------

-- ----------------------------
-- Table structure for `t_areas`
-- ----------------------------
DROP TABLE IF EXISTS `t_areas`;
CREATE TABLE `t_areas` (
  `areaId` int(20) NOT NULL AUTO_INCREMENT COMMENT '地区Id',
  `areaCode` varchar(50) NOT NULL COMMENT '地区编码',
  `areaName` varchar(20) NOT NULL COMMENT '地区名',
  `level` tinyint(4) DEFAULT '-1' COMMENT '地区级别（1:省份province,2:市city,3:区县district,4:街道street）',
  `cityCode` varchar(50) DEFAULT NULL COMMENT '城市编码',
  `center` varchar(50) DEFAULT NULL COMMENT '城市中心点（即：经纬度坐标）',
  `parentId` int(20) DEFAULT '-1' COMMENT '地区父节点',
  PRIMARY KEY (`areaId`),
  KEY `areaCode` (`areaCode`),
  KEY `parentId` (`parentId`),
  KEY `level` (`level`),
  KEY `areaName` (`areaName`)
) ENGINE=InnoDB AUTO_INCREMENT=3260 DEFAULT CHARSET=utf8 COMMENT='地区码表';

-- ----------------------------
-- Records of t_areas
-- ----------------------------

-- ----------------------------
-- Table structure for `t_flow_product`
-- ----------------------------
DROP TABLE IF EXISTS `t_flow_product`;
CREATE TABLE `t_flow_product` (
  `id` varchar(64) NOT NULL COMMENT '主键id',
  `product_name` varchar(200) DEFAULT NULL COMMENT '流量商品名称',
  `product_sname` varchar(200) DEFAULT NULL COMMENT '流量商品副名称',
  `price` decimal(10,2) DEFAULT NULL COMMENT '单价',
  `order_by` int(11) DEFAULT NULL COMMENT '排序号码',
  `product_title` varchar(200) DEFAULT NULL COMMENT '流量商品标签',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(50) DEFAULT NULL COMMENT '备注',
  `del_flag` int(11) DEFAULT NULL COMMENT '删除标识 0 未删除 1已删除',
  `status` int(11) DEFAULT NULL COMMENT '上架状态 0下架 1上架',
  `product_no` varchar(64) DEFAULT NULL COMMENT '项目编号',
  `sales_total` int(11) DEFAULT NULL COMMENT '初始销售数量',
  `yys` tinyint(4) DEFAULT NULL COMMENT '运营商类型1 、移动 2、联通 3、电信',
  `province` int(20) DEFAULT NULL COMMENT '省',
  `city` int(20) DEFAULT NULL COMMENT '市',
  `activity_describes` varchar(255) DEFAULT NULL COMMENT '产品描述',
  `activity_product_id` varchar(64) DEFAULT NULL COMMENT '绑定的业务商品id',
  `activityid` varchar(64) DEFAULT NULL COMMENT '绑定的业务id',
  `platform_product_id` varchar(64) DEFAULT NULL COMMENT '平台id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='流量商品表';

-- ----------------------------
-- Records of t_flow_product
-- ----------------------------

-- ----------------------------
-- Table structure for `t_generate_number`
-- ----------------------------
DROP TABLE IF EXISTS `t_generate_number`;
CREATE TABLE `t_generate_number` (
  `id` varchar(32) NOT NULL COMMENT 'ID',
  `type` int(20) NOT NULL COMMENT '编号的类型',
  `date` varchar(200) NOT NULL COMMENT '生成该编号的日期格式yyyy-MM-dd',
  `number` int(11) NOT NULL COMMENT '当天生成该类型编号流水的数量',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='生成编码表';

-- ----------------------------
-- Records of t_generate_number
-- ----------------------------

-- ----------------------------
-- Table structure for `t_home_banner`
-- ----------------------------
DROP TABLE IF EXISTS `t_home_banner`;
CREATE TABLE `t_home_banner` (
  `id` varchar(64) NOT NULL COMMENT '主键id',
  `file_name` varchar(64) DEFAULT NULL COMMENT '文件名称',
  `file_url` varchar(200) DEFAULT NULL COMMENT '文件访问地址',
  `remake` varchar(200) DEFAULT NULL COMMENT '备注',
  `order_by` int(11) DEFAULT NULL COMMENT '排序',
  `status` int(11) DEFAULT NULL COMMENT '状态 0未开启  1已开启',
  `del_flag` int(11) DEFAULT NULL COMMENT '是否删除标识 0未删除  1已删除',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='首页轮播图表';

-- ----------------------------
-- Records of t_home_banner
-- ----------------------------

-- ----------------------------
-- Table structure for `t_online_message`
-- ----------------------------
DROP TABLE IF EXISTS `t_online_message`;
CREATE TABLE `t_online_message` (
  `id` varchar(64) NOT NULL COMMENT '记录ID',
  `title` varchar(500) DEFAULT NULL COMMENT '标题',
  `image_text` text COMMENT '留言内容',
  `contacts` varchar(200) DEFAULT NULL COMMENT '联系人',
  `contact_number` varchar(11) DEFAULT NULL COMMENT '联系电话',
  `remarks` varchar(500) DEFAULT NULL COMMENT '备注',
  `check_remarks` tinyint(1) DEFAULT NULL COMMENT '是否已备注 0：未备注；1：已备注',
  `status` tinyint(1) DEFAULT NULL COMMENT '状态 0：正常、1：删除',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新人',
  `open_id` varchar(64) DEFAULT NULL COMMENT '绑定的用户openId',
  `order_no` varchar(64) DEFAULT NULL COMMENT '订单编号',
  `product_name` varchar(200) DEFAULT NULL COMMENT '产品名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='在线留言';

-- ----------------------------
-- Records of t_online_message
-- ----------------------------

-- ----------------------------
-- Table structure for `t_online_message_reply`
-- ----------------------------
DROP TABLE IF EXISTS `t_online_message_reply`;
CREATE TABLE `t_online_message_reply` (
  `id` varchar(64) NOT NULL COMMENT '主键id',
  `message_id` varchar(64) DEFAULT NULL COMMENT '回复的留言id',
  `reply_text` varchar(500) DEFAULT NULL,
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '回复时间',
  `del_flag` tinyint(4) DEFAULT NULL COMMENT '删除标识 0未删除 1已删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='留言回复表';

-- ----------------------------
-- Records of t_online_message_reply
-- ----------------------------

-- ----------------------------
-- Table structure for `t_order`
-- ----------------------------
DROP TABLE IF EXISTS `t_order`;
CREATE TABLE `t_order` (
  `order_id` varchar(64) NOT NULL COMMENT '订单ID',
  `order_no` varchar(32) NOT NULL COMMENT '订单编号',
  `open_id` varchar(255) NOT NULL COMMENT '微信的用户ID',
  `supplier_id` varchar(64) NOT NULL COMMENT '代理商ID',
  `mchid` varchar(255) DEFAULT NULL COMMENT '微信的用户ID',
  `remark_body` varchar(255) DEFAULT NULL COMMENT '订单title',
  `fee_type` varchar(32) DEFAULT NULL COMMENT '标价币种，默认人民币：CNY',
  `total_fee` decimal(11,2) NOT NULL COMMENT '订单金额',
  `pay_fee` decimal(11,2) NOT NULL COMMENT '应付金额',
  `trade_type` varchar(255) DEFAULT NULL COMMENT '交易类型JSAPI -JSAPI支付 NATIVE -Native支付 APP -APP支付',
  `pay_time` datetime DEFAULT NULL COMMENT '支付时间',
  `remark` varchar(255) DEFAULT '' COMMENT '订单备注',
  `address` varchar(255) DEFAULT NULL COMMENT '收货地址',
  `phone` varchar(22) NOT NULL COMMENT '联系电话',
  `order_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '订单状态 -1、删除 0、待付款 1、待发货 2、待收货 3、交易完成 4、交易关闭 5、退款 6、取消',
  `transaction_id` varchar(255) DEFAULT NULL COMMENT '微信返回的订单号',
  `pay_status` varchar(20) NOT NULL COMMENT '订单支付状态 SUCCESS—支付成功 NOTPAY—未支付 CLOSED—已关闭',
  `third_pay_status` varchar(20) NOT NULL COMMENT '第三方支付状态 SUCCESS—支付成功 REFUND—转入退款 NOTPAY—未支付 CLOSED—已关闭 REVOKED—已撤销（付款码支付） USERPAYING--用户支付中（付款码支付） PAYERROR--支付失败(其他原因，如银行返回失败)',
  `send_product` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否已经发货 0、未发货 1、已发货',
  `send_product_time` datetime DEFAULT NULL COMMENT '发货时间',
  `send_remark` varchar(255) DEFAULT '' COMMENT '发货备注',
  `confirm_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `cancel_time` datetime DEFAULT NULL COMMENT '取消时间',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `check_delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0、正常 1、删除',
  `update_time` datetime NOT NULL COMMENT '更新时间',
  `sys_version` int(11) NOT NULL COMMENT '版本号',
  `goods_type` tinyint(4) DEFAULT NULL COMMENT '商品类型 1 话费商品 2 流量商品',
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单信息';

-- ----------------------------
-- Records of t_order
-- ----------------------------

-- ----------------------------
-- Table structure for `t_order_detail`
-- ----------------------------
DROP TABLE IF EXISTS `t_order_detail`;
CREATE TABLE `t_order_detail` (
  `det_id` varchar(64) NOT NULL COMMENT '详情ID',
  `order_id` varchar(64) NOT NULL COMMENT '订单ID',
  `goods_id` varchar(64) NOT NULL COMMENT '商品ID',
  `goods_type` tinyint(4) NOT NULL COMMENT '商品类型 1 话费商品 2 流量商品 ',
  `goods_num` int(11) NOT NULL COMMENT '商品数量',
  `goods_price` decimal(11,2) NOT NULL COMMENT '单价',
  `total_price` decimal(11,2) NOT NULL COMMENT '总金额',
  `common_sn` varchar(64) NOT NULL COMMENT '商品编号',
  `common_name` varchar(200) NOT NULL COMMENT '商品名称',
  `common_des` varchar(200) NOT NULL COMMENT '商品副标题',
  `product_title` varchar(200) DEFAULT NULL COMMENT '流量商品标签',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`det_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单详情';

-- ----------------------------
-- Records of t_order_detail
-- ----------------------------

-- ----------------------------
-- Table structure for `t_order_send_product`
-- ----------------------------
DROP TABLE IF EXISTS `t_order_send_product`;
CREATE TABLE `t_order_send_product` (
  `id` varchar(64) NOT NULL COMMENT '主键id',
  `order_no` varchar(64) DEFAULT NULL COMMENT '订单编号',
  `parent_order_no` varchar(64) DEFAULT NULL COMMENT '上级订单编号',
  `order_model` tinyint(4) DEFAULT NULL COMMENT '订单发货模式 1、 一码 2、二码',
  `send_status` tinyint(4) DEFAULT NULL COMMENT '发送订单状态 0未完成 1已完成 2取消',
  `phone` varchar(11) DEFAULT NULL COMMENT '手机号码',
  `activityid` varchar(64) DEFAULT NULL COMMENT '业务id',
  `create_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='业务发货表';

-- ----------------------------
-- Records of t_order_send_product
-- ----------------------------

-- ----------------------------
-- Table structure for `t_order_send_product_detail`
-- ----------------------------
DROP TABLE IF EXISTS `t_order_send_product_detail`;
CREATE TABLE `t_order_send_product_detail` (
  `id` varchar(64) NOT NULL COMMENT '主键id',
  `send_id` varchar(64) DEFAULT NULL COMMENT '上级id',
  `order_no` varchar(64) DEFAULT NULL COMMENT '订单编号',
  `parent_order_no` varchar(64) DEFAULT NULL COMMENT '上级订单编号',
  `step_number` tinyint(4) DEFAULT NULL COMMENT '步奏 1234',
  `smscode` varchar(10) DEFAULT NULL COMMENT '短信验证码',
  `phone` varchar(11) DEFAULT NULL COMMENT '手机号码',
  `busniess_status` tinyint(4) DEFAULT NULL COMMENT '业务状态 0 失败 1成功',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `activityid` varchar(64) DEFAULT NULL COMMENT '业务id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='业务发货表详情';

-- ----------------------------
-- Records of t_order_send_product_detail
-- ----------------------------

-- ----------------------------
-- Table structure for `t_platform_infos`
-- ----------------------------
DROP TABLE IF EXISTS `t_platform_infos`;
CREATE TABLE `t_platform_infos` (
  `id` varchar(64) NOT NULL COMMENT '主键id',
  `platform_name` varchar(100) DEFAULT NULL COMMENT '第三方平台名称',
  `platform_key` varchar(100) DEFAULT NULL COMMENT '平台关键字',
  `plaform_url` varchar(500) DEFAULT NULL COMMENT '平台链接地址',
  `user_token` varchar(200) DEFAULT NULL COMMENT '用户token',
  `user_secrect` varchar(200) DEFAULT NULL COMMENT '用户秘钥',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `del_flag` tinyint(4) DEFAULT NULL COMMENT '删除标示 0未删除 1已删除',
  `use_status` tinyint(4) DEFAULT NULL COMMENT '使用状态 0 未开启 1已开启',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='第三方充值平台管理';

-- ----------------------------
-- Records of t_platform_infos
-- ----------------------------

-- ----------------------------
-- Table structure for `t_privacy_info`
-- ----------------------------
DROP TABLE IF EXISTS `t_privacy_info`;
CREATE TABLE `t_privacy_info` (
  `id` varchar(64) NOT NULL COMMENT '主键id',
  `content_info` text COMMENT '隐私正常内容',
  `privacy_name` varchar(100) DEFAULT NULL,
  `privacy_title` varchar(200) DEFAULT NULL COMMENT '隐私标题',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='隐私政策表';

-- ----------------------------
-- Records of t_privacy_info
-- ----------------------------

-- ----------------------------
-- Table structure for `t_product`
-- ----------------------------
DROP TABLE IF EXISTS `t_product`;
CREATE TABLE `t_product` (
  `id` varchar(64) NOT NULL COMMENT '主键id',
  `product_name` varchar(200) DEFAULT NULL COMMENT '项目名称',
  `product_sname` varchar(200) DEFAULT NULL COMMENT '项目副名称',
  `price` decimal(10,2) DEFAULT NULL COMMENT '单价',
  `order_by` int(11) DEFAULT NULL COMMENT '排序号码',
  `product_title` varchar(200) DEFAULT NULL COMMENT '商品标签',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(50) DEFAULT NULL COMMENT '备注',
  `del_flag` int(11) DEFAULT NULL COMMENT '删除标识 0 未删除 1已删除',
  `status` int(11) DEFAULT NULL COMMENT '上架状态 0下架 1上架',
  `product_no` varchar(64) DEFAULT NULL COMMENT '项目编号',
  `sales_total` int(11) DEFAULT NULL COMMENT '初始销售数量',
  `yys` tinyint(4) DEFAULT NULL COMMENT '运营商类型1 、移动 2、联通 3、电信',
  `province` int(20) DEFAULT NULL COMMENT '省',
  `city` int(20) DEFAULT NULL COMMENT '市',
  `activity_describes` varchar(255) DEFAULT NULL COMMENT '产品描述',
  `activity_product_id` varchar(64) DEFAULT NULL COMMENT '绑定的业务商品id',
  `activityid` varchar(64) DEFAULT NULL COMMENT '绑定的业务id',
  `platform_product_id` varchar(64) DEFAULT NULL COMMENT '平台id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='产品项目';

-- ----------------------------
-- Records of t_product
-- ----------------------------

-- ----------------------------
-- Table structure for `t_supplier`
-- ----------------------------
DROP TABLE IF EXISTS `t_supplier`;
CREATE TABLE `t_supplier` (
  `id` varchar(64) NOT NULL COMMENT '主键id',
  `sup_no` varchar(64) DEFAULT NULL COMMENT '代理商编号',
  `sup_name` varchar(100) DEFAULT NULL COMMENT '代理商名称',
  `user_name` varchar(50) DEFAULT NULL COMMENT '用户的登陆账号',
  `contact_people` varchar(50) DEFAULT NULL COMMENT '联系人',
  `phone` varchar(11) DEFAULT NULL COMMENT '说明',
  `remarks` varchar(200) DEFAULT NULL COMMENT '联系方式',
  `localtion` varchar(200) DEFAULT NULL COMMENT '地址',
  `del_flag` tinyint(4) DEFAULT NULL COMMENT '删除标示0：表示正常使用的数据 1：表示已删除的数据',
  `create_time` date DEFAULT NULL COMMENT '创建时间',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `app_id` varchar(64) DEFAULT NULL COMMENT '公众号id',
  `app_secret` varchar(128) DEFAULT NULL COMMENT '公众号秘钥',
  `app_url` varchar(255) DEFAULT NULL COMMENT '公众号分配的域名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of t_supplier
-- ----------------------------

-- ----------------------------
-- Table structure for `t_supplier_capital`
-- ----------------------------
DROP TABLE IF EXISTS `t_supplier_capital`;
CREATE TABLE `t_supplier_capital` (
  `id` varchar(64) NOT NULL COMMENT '主键id',
  `supplier_id` varchar(64) DEFAULT NULL COMMENT '代理商id',
  `capital_total` decimal(10,2) DEFAULT NULL COMMENT '资金总数',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '变更时间',
  `del_flag` tinyint(4) DEFAULT NULL COMMENT '删除标示 0未删除 1已删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='代理商资金表';

-- ----------------------------
-- Records of t_supplier_capital
-- ----------------------------

-- ----------------------------
-- Table structure for `t_supplier_capital_log`
-- ----------------------------
DROP TABLE IF EXISTS `t_supplier_capital_log`;
CREATE TABLE `t_supplier_capital_log` (
  `id` varchar(64) NOT NULL COMMENT '主键id',
  `supplier_capital_id` varchar(64) NOT NULL COMMENT '代理商资金表id',
  `supplier_id` varchar(64) DEFAULT NULL COMMENT '代理商id',
  `capital_type` tinyint(4) DEFAULT NULL COMMENT '资金记录类型， 1 增加 2减少',
  `old_total` decimal(10,2) DEFAULT NULL COMMENT '原资金',
  `new_total` decimal(10,2) DEFAULT NULL COMMENT '现资金',
  `capital_total` decimal(10,2) DEFAULT NULL COMMENT '资金数量',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `del_flag` tinyint(4) DEFAULT NULL COMMENT '删除标示 0 未删除 1已删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='代理商资金使用记录';

-- ----------------------------
-- Records of t_supplier_capital_log
-- ----------------------------

-- ----------------------------
-- Table structure for `t_user_unique`
-- ----------------------------
DROP TABLE IF EXISTS `t_user_unique`;
CREATE TABLE `t_user_unique` (
  `id` varchar(64) NOT NULL COMMENT '主键id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户唯一编号记录表';

-- ----------------------------
-- Records of t_user_unique
-- ----------------------------

-- ----------------------------
-- Table structure for `t_wechart_pay_info`
-- ----------------------------
DROP TABLE IF EXISTS `t_wechart_pay_info`;
CREATE TABLE `t_wechart_pay_info` (
  `id` varchar(64) NOT NULL COMMENT '主键id',
  `serial_no` varchar(200) DEFAULT NULL COMMENT '商户支付证书序列号',
  `pay_name` varchar(100) DEFAULT NULL COMMENT '商户号名称',
  `partner_key` varchar(100) DEFAULT NULL COMMENT 'api-v3秘钥',
  `mchid` varchar(20) DEFAULT NULL COMMENT '商户id',
  `private_key_path` varchar(200) DEFAULT NULL COMMENT '商户V3私钥证书',
  `public_key_path` varchar(200) DEFAULT NULL COMMENT '商户V3公钥证书',
  `supplier_id` varchar(64) DEFAULT NULL COMMENT '代理商id',
  `use_status` tinyint(4) DEFAULT NULL COMMENT '状态开启 0未开启 1已开启',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `del_flag` tinyint(4) DEFAULT NULL COMMENT '删除标识 0 未删除 1已删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='微信支付信息表';

-- ----------------------------
-- Records of t_wechart_pay_info
-- ----------------------------

-- ----------------------------
-- Table structure for `t_wechat_page_url`
-- ----------------------------
DROP TABLE IF EXISTS `t_wechat_page_url`;
CREATE TABLE `t_wechat_page_url` (
  `id` varchar(64) NOT NULL COMMENT '主键id',
  `page_url` varchar(500) DEFAULT NULL COMMENT '链接地址',
  `page_show_url` varchar(500) DEFAULT NULL COMMENT '代理商显示链接地址',
  `page_name` varchar(50) DEFAULT NULL COMMENT '页面名称',
  `del_flag` tinyint(4) DEFAULT NULL COMMENT '删除标识  0未删除 1已删除',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='微信公众号页面链接地址表';

-- ----------------------------
-- Records of t_wechat_page_url
-- ----------------------------

-- ----------------------------
-- Table structure for `t_wechat_program_info`
-- ----------------------------
DROP TABLE IF EXISTS `t_wechat_program_info`;
CREATE TABLE `t_wechat_program_info` (
  `id` varchar(64) NOT NULL COMMENT '主键id',
  `authorizer_appid` varchar(100) DEFAULT NULL COMMENT '公众号id',
  `authorization_info` varchar(1000) DEFAULT NULL COMMENT '得到授权信息',
  `authorizer_access_token` varchar(1000) DEFAULT NULL COMMENT '得到接口调用令牌',
  `authorizer_refresh_token` varchar(1000) DEFAULT NULL COMMENT '得到接口刷新令牌   存入数据库',
  `expires_in` int(11) DEFAULT NULL COMMENT '接口调用令牌的有效期',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `del_flag` tinyint(4) DEFAULT NULL COMMENT '删除标识0 未删除 1已删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='微信公众号信息表';

-- ----------------------------
-- Records of t_wechat_program_info
-- ----------------------------

-- ----------------------------
-- Table structure for `t_we_chat_user`
-- ----------------------------
DROP TABLE IF EXISTS `t_we_chat_user`;
CREATE TABLE `t_we_chat_user` (
  `id` varchar(64) NOT NULL COMMENT '微信用户ID',
  `openid` varchar(64) NOT NULL DEFAULT '' COMMENT '用户的标识，对当前公众号唯一',
  `nickname` varchar(64) DEFAULT '' COMMENT '用户的昵称',
  `sex` char(1) DEFAULT '' COMMENT '用户的性别，值为1时是男性，值为2时是女性，值为0时是未知',
  `city` varchar(30) DEFAULT '' COMMENT '用户所在城市',
  `country` varchar(30) DEFAULT '' COMMENT '用户所在国家',
  `province` varchar(30) DEFAULT '' COMMENT '用户所在省份',
  `language` varchar(30) DEFAULT '' COMMENT '用户的语言，简体中文为zh_CN',
  `headimgurl` varchar(200) DEFAULT '' COMMENT '用户头像，最后一个数值代表正方形头像大小（有0、46、64、96、132数值可选，0代表640*640正方形头像），用户没有头像时该项为空。若用户更换头像，原有头像URL将失效',
  `remark` varchar(100) DEFAULT '' COMMENT '备注',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `with_scope` int(11) DEFAULT NULL COMMENT '是否已授权 0未授权 1已授权',
  `bind_phone` varchar(50) DEFAULT NULL COMMENT '绑定手机号码',
  `points_total` int(11) DEFAULT NULL COMMENT '用户积分',
  `user_id` varchar(64) DEFAULT NULL COMMENT '用户编号',
  `user_level` int(11) DEFAULT NULL COMMENT '用户等级',
  `vip_user` int(11) DEFAULT NULL COMMENT '是否 vip 0 否 1是',
  `vip_phone` varchar(100) DEFAULT NULL COMMENT '会员手机号码',
  `vip_nick_name` varchar(100) DEFAULT NULL COMMENT '会员昵称',
  `vip_address` varchar(255) DEFAULT NULL COMMENT '用户地址',
  `vip_time` datetime DEFAULT NULL COMMENT 'vip时间',
  `last_vip_time` datetime DEFAULT NULL COMMENT '最后一次加积分的时间',
  `qr_code_url` varchar(255) DEFAULT NULL COMMENT '用户二维码',
  `unionid` varchar(64) DEFAULT NULL COMMENT '微信唯一id',
  `supplier_id` varchar(64) DEFAULT NULL COMMENT '绑定的代理商id',
  `app_id` varchar(64) DEFAULT NULL COMMENT '公众号id',
  PRIMARY KEY (`id`,`openid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='微名用户信息表';

-- ----------------------------
-- Records of t_we_chat_user
-- ----------------------------
