/*
 Navicat Premium Data Transfer

 Source Server         : localdb
 Source Server Type    : MySQL
 Source Server Version : 80029
 Source Host           : localhost:3306
 Source Schema         : pv_dev

 Target Server Type    : MySQL
 Target Server Version : 80029
 File Encoding         : 65001

 Date: 20/11/2022 11:27:11
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for gen_table
-- ----------------------------
DROP TABLE IF EXISTS `gen_table`;
CREATE TABLE `gen_table`  (
  `table_id` bigint NOT NULL AUTO_INCREMENT COMMENT '编号',
  `table_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '表名称',
  `table_comment` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '表描述',
  `sub_table_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '关联子表的表名',
  `sub_table_fk_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '子表关联的外键名',
  `class_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '实体类名称',
  `tpl_category` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'crud' COMMENT '使用的模板（crud单表操作 tree树表操作）',
  `package_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '生成包路径',
  `module_name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '生成模块名',
  `business_name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '生成业务名',
  `function_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '生成功能名',
  `function_author` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '生成功能作者',
  `gen_type` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '生成代码方式（0zip压缩包 1自定义路径）',
  `gen_path` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '/' COMMENT '生成路径（不填默认项目路径）',
  `options` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '其它生成选项',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`table_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '代码生成业务表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of gen_table
-- ----------------------------
INSERT INTO `gen_table` VALUES (3, 'pv_area', '区域', NULL, NULL, 'PvArea', 'crud', 'com.zcty.pv', 'pv', 'area', '区域', 'luohui', '0', '/', '{}', 'admin', '2022-11-12 14:12:30', '', '2022-11-12 14:12:46', NULL);

-- ----------------------------
-- Table structure for gen_table_column
-- ----------------------------
DROP TABLE IF EXISTS `gen_table_column`;
CREATE TABLE `gen_table_column`  (
  `column_id` bigint NOT NULL AUTO_INCREMENT COMMENT '编号',
  `table_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '归属表编号',
  `column_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '列名称',
  `column_comment` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '列描述',
  `column_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '列类型',
  `java_type` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'JAVA类型',
  `java_field` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'JAVA字段名',
  `is_pk` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '是否主键（1是）',
  `is_increment` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '是否自增（1是）',
  `is_required` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '是否必填（1是）',
  `is_insert` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '是否为插入字段（1是）',
  `is_edit` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '是否编辑字段（1是）',
  `is_list` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '是否列表字段（1是）',
  `is_query` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '是否查询字段（1是）',
  `query_type` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'EQ' COMMENT '查询方式（等于、不等于、大于、小于、范围）',
  `html_type` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '显示类型（文本框、文本域、下拉框、复选框、单选框、日期控件）',
  `dict_type` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '字典类型',
  `sort` int NULL DEFAULT NULL COMMENT '排序',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`column_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 38 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '代码生成业务表字段' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of gen_table_column
-- ----------------------------
INSERT INTO `gen_table_column` VALUES (28, '3', 'area_id', '区域id', 'varchar(20)', 'String', 'areaId', '1', '0', NULL, '1', NULL, NULL, NULL, 'EQ', 'input', '', 1, 'admin', '2022-11-12 14:12:30', '', '2022-11-12 14:12:46');
INSERT INTO `gen_table_column` VALUES (29, '3', 'parent_id', '上级区域id', 'varchar(20)', 'String', 'parentId', '0', '0', NULL, '1', '1', '1', '1', 'EQ', 'input', '', 2, 'admin', '2022-11-12 14:12:30', '', '2022-11-12 14:12:46');
INSERT INTO `gen_table_column` VALUES (30, '3', 'ancestors', '祖级列表', 'varchar(100)', 'String', 'ancestors', '0', '0', NULL, '1', '1', '1', '1', 'EQ', 'input', '', 3, 'admin', '2022-11-12 14:12:30', '', '2022-11-12 14:12:46');
INSERT INTO `gen_table_column` VALUES (31, '3', 'short_name', '省市区名称', 'varchar(100)', 'String', 'shortName', '0', '0', NULL, '1', '1', '1', '1', 'LIKE', 'input', '', 4, 'admin', '2022-11-12 14:12:30', '', '2022-11-12 14:12:46');
INSERT INTO `gen_table_column` VALUES (32, '3', 'real_name', '省市区简称', 'varchar(300)', 'String', 'realName', '0', '0', NULL, '1', '1', '1', '1', 'LIKE', 'input', '', 5, 'admin', '2022-11-12 14:12:30', '', '2022-11-12 14:12:46');
INSERT INTO `gen_table_column` VALUES (33, '3', 'level', '显示层级', 'int', 'Long', 'level', '0', '0', NULL, '1', '1', '1', '1', 'EQ', 'input', '', 6, 'admin', '2022-11-12 14:12:30', '', '2022-11-12 14:12:46');
INSERT INTO `gen_table_column` VALUES (34, '3', 'create_by', '创建者', 'varchar(64)', 'String', 'createBy', '0', '0', NULL, '1', NULL, NULL, NULL, 'EQ', 'input', '', 7, 'admin', '2022-11-12 14:12:30', '', '2022-11-12 14:12:46');
INSERT INTO `gen_table_column` VALUES (35, '3', 'create_time', '创建时间', 'datetime', 'Date', 'createTime', '0', '0', NULL, '1', NULL, NULL, NULL, 'EQ', 'datetime', '', 8, 'admin', '2022-11-12 14:12:30', '', '2022-11-12 14:12:46');
INSERT INTO `gen_table_column` VALUES (36, '3', 'update_by', '更新者', 'varchar(64)', 'String', 'updateBy', '0', '0', NULL, '1', '1', NULL, NULL, 'EQ', 'input', '', 9, 'admin', '2022-11-12 14:12:30', '', '2022-11-12 14:12:46');
INSERT INTO `gen_table_column` VALUES (37, '3', 'update_time', '更新时间', 'datetime', 'Date', 'updateTime', '0', '0', NULL, '1', '1', NULL, NULL, 'EQ', 'datetime', '', 10, 'admin', '2022-11-12 14:12:30', '', '2022-11-12 14:12:46');
INSERT INTO `gen_table_column` VALUES (38, '3', 'remark', '备注', 'varchar(500)', 'String', 'remark', '0', '0', NULL, '1', '1', '1', NULL, 'EQ', 'textarea', '', 11, 'admin', '2022-11-12 14:12:30', '', '2022-11-12 14:12:46');

-- ----------------------------
-- Table structure for pub_file
-- ----------------------------
DROP TABLE IF EXISTS `pub_file`;
CREATE TABLE `pub_file`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '文件id',
  `biz_id` bigint NULL DEFAULT NULL COMMENT '业务id',
  `biz_key` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '业务类型',
  `file_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '文件名',
  `file_url` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '文件存储路径',
  `file_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '文件类型',
  `size` bigint NULL DEFAULT NULL COMMENT '文件大小',
  `agent_id` bigint NULL DEFAULT NULL COMMENT '代理商id',
  `audit_remark` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '审核意见',
  `status` int NULL DEFAULT 0 COMMENT '状态',
  `auditor` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '审核人',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `sort_num` int NULL DEFAULT 0 COMMENT '序号',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '通用文件' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pub_file
-- ----------------------------

-- ----------------------------
-- Table structure for pv_agent
-- ----------------------------
DROP TABLE IF EXISTS `pv_agent`;
CREATE TABLE `pv_agent`  (
  `agent_id` bigint NOT NULL COMMENT '代理商ID，使用分布式id',
  `agent_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '单位名称',
  `credit_code` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '统一社会信用代码',
  `legal_person` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '法人',
  `contacts` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '联络人',
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '联络人手机',
  `credit` int NULL DEFAULT NULL COMMENT '信用额（单位：元）',
  `dept_id` bigint NULL DEFAULT NULL COMMENT '对应部门id',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  `status` tinyint NULL DEFAULT NULL COMMENT '状态',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `sort_num` int NULL DEFAULT 0 COMMENT '序号',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  PRIMARY KEY (`agent_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '代理商' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pv_agent
-- ----------------------------

-- ----------------------------
-- Table structure for pv_area
-- ----------------------------
DROP TABLE IF EXISTS `pv_area`;
CREATE TABLE `pv_area`  (
  `area_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '区域id',
  `parent_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '上级区域id',
  `ancestors` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '祖级列表',
  `short_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '省市区名称',
  `real_name` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '省市区简称',
  `level` int NULL DEFAULT NULL COMMENT '显示层级',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`area_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '区域' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of pv_area
-- ----------------------------
INSERT INTO `pv_area` VALUES ('110000', '86', '', '北京市', '北京市', 1, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('110100', '110000', '110000', '市辖区', '北京市/市辖区', 2, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('110101', '110100', '110000,110100', '东城区', '北京市/市辖区/东城区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('110102', '110100', '110000,110100', '西城区', '北京市/市辖区/西城区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('110105', '110100', '110000,110100', '朝阳区', '北京市/市辖区/朝阳区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('110106', '110100', '110000,110100', '丰台区', '北京市/市辖区/丰台区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('110107', '110100', '110000,110100', '石景山区', '北京市/市辖区/石景山区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('110108', '110100', '110000,110100', '海淀区', '北京市/市辖区/海淀区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('110109', '110100', '110000,110100', '门头沟区', '北京市/市辖区/门头沟区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('110111', '110100', '110000,110100', '房山区', '北京市/市辖区/房山区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('110112', '110100', '110000,110100', '通州区', '北京市/市辖区/通州区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('110113', '110100', '110000,110100', '顺义区', '北京市/市辖区/顺义区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('110114', '110100', '110000,110100', '昌平区', '北京市/市辖区/昌平区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('110115', '110100', '110000,110100', '大兴区', '北京市/市辖区/大兴区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('110116', '110100', '110000,110100', '怀柔区', '北京市/市辖区/怀柔区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('110117', '110100', '110000,110100', '平谷区', '北京市/市辖区/平谷区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('110118', '110100', '110000,110100', '密云区', '北京市/市辖区/密云区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('110119', '110100', '110000,110100', '延庆区', '北京市/市辖区/延庆区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('120000', '86', '', '天津市', '天津市', 1, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('120100', '120000', '120000', '市辖区', '天津市/市辖区', 2, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('120101', '120100', '120000,120100', '和平区', '天津市/市辖区/和平区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('120102', '120100', '120000,120100', '河东区', '天津市/市辖区/河东区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('120103', '120100', '120000,120100', '河西区', '天津市/市辖区/河西区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('120104', '120100', '120000,120100', '南开区', '天津市/市辖区/南开区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('120105', '120100', '120000,120100', '河北区', '天津市/市辖区/河北区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('120106', '120100', '120000,120100', '红桥区', '天津市/市辖区/红桥区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('120110', '120100', '120000,120100', '东丽区', '天津市/市辖区/东丽区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('120111', '120100', '120000,120100', '西青区', '天津市/市辖区/西青区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('120112', '120100', '120000,120100', '津南区', '天津市/市辖区/津南区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('120113', '120100', '120000,120100', '北辰区', '天津市/市辖区/北辰区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('120114', '120100', '120000,120100', '武清区', '天津市/市辖区/武清区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('120115', '120100', '120000,120100', '宝坻区', '天津市/市辖区/宝坻区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('120116', '120100', '120000,120100', '滨海新区', '天津市/市辖区/滨海新区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('120117', '120100', '120000,120100', '宁河区', '天津市/市辖区/宁河区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('120118', '120100', '120000,120100', '静海区', '天津市/市辖区/静海区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('120119', '120100', '120000,120100', '蓟州区', '天津市/市辖区/蓟州区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130000', '86', '', '河北省', '河北省', 1, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130100', '130000', '130000', '石家庄市', '河北省/石家庄市', 2, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130101', '130100', '130000,130100', '市辖区', '河北省/石家庄市/市辖区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130102', '130100', '130000,130100', '长安区', '河北省/石家庄市/长安区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130104', '130100', '130000,130100', '桥西区', '河北省/石家庄市/桥西区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130105', '130100', '130000,130100', '新华区', '河北省/石家庄市/新华区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130107', '130100', '130000,130100', '井陉矿区', '河北省/石家庄市/井陉矿区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130108', '130100', '130000,130100', '裕华区', '河北省/石家庄市/裕华区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130109', '130100', '130000,130100', '藁城区', '河北省/石家庄市/藁城区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130110', '130100', '130000,130100', '鹿泉区', '河北省/石家庄市/鹿泉区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130111', '130100', '130000,130100', '栾城区', '河北省/石家庄市/栾城区', 3, 'admin', '2022-05-22 20:35:11', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130121', '130100', '130000,130100', '井陉县', '河北省/石家庄市/井陉县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130123', '130100', '130000,130100', '正定县', '河北省/石家庄市/正定县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130125', '130100', '130000,130100', '行唐县', '河北省/石家庄市/行唐县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130126', '130100', '130000,130100', '灵寿县', '河北省/石家庄市/灵寿县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130127', '130100', '130000,130100', '高邑县', '河北省/石家庄市/高邑县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130128', '130100', '130000,130100', '深泽县', '河北省/石家庄市/深泽县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130129', '130100', '130000,130100', '赞皇县', '河北省/石家庄市/赞皇县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130130', '130100', '130000,130100', '无极县', '河北省/石家庄市/无极县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130131', '130100', '130000,130100', '平山县', '河北省/石家庄市/平山县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130132', '130100', '130000,130100', '元氏县', '河北省/石家庄市/元氏县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130133', '130100', '130000,130100', '赵县', '河北省/石家庄市/赵县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130171', '130100', '130000,130100', '石家庄高新技术产业开发区', '河北省/石家庄市/石家庄高新技术产业开发区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130172', '130100', '130000,130100', '石家庄循环化工园区', '河北省/石家庄市/石家庄循环化工园区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130181', '130100', '130000,130100', '辛集市', '河北省/石家庄市/辛集市', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130183', '130100', '130000,130100', '晋州市', '河北省/石家庄市/晋州市', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130184', '130100', '130000,130100', '新乐市', '河北省/石家庄市/新乐市', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130200', '130000', '130000', '唐山市', '河北省/唐山市', 2, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130201', '130200', '130000,130200', '市辖区', '河北省/唐山市/市辖区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130202', '130200', '130000,130200', '路南区', '河北省/唐山市/路南区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130203', '130200', '130000,130200', '路北区', '河北省/唐山市/路北区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130204', '130200', '130000,130200', '古冶区', '河北省/唐山市/古冶区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130205', '130200', '130000,130200', '开平区', '河北省/唐山市/开平区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130207', '130200', '130000,130200', '丰南区', '河北省/唐山市/丰南区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130208', '130200', '130000,130200', '丰润区', '河北省/唐山市/丰润区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130209', '130200', '130000,130200', '曹妃甸区', '河北省/唐山市/曹妃甸区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130224', '130200', '130000,130200', '滦南县', '河北省/唐山市/滦南县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130225', '130200', '130000,130200', '乐亭县', '河北省/唐山市/乐亭县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130227', '130200', '130000,130200', '迁西县', '河北省/唐山市/迁西县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130229', '130200', '130000,130200', '玉田县', '河北省/唐山市/玉田县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130271', '130200', '130000,130200', '河北唐山芦台经济开发区', '河北省/唐山市/河北唐山芦台经济开发区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130272', '130200', '130000,130200', '唐山市汉沽管理区', '河北省/唐山市/唐山市汉沽管理区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130273', '130200', '130000,130200', '唐山高新技术产业开发区', '河北省/唐山市/唐山高新技术产业开发区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130274', '130200', '130000,130200', '河北唐山海港经济开发区', '河北省/唐山市/河北唐山海港经济开发区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130281', '130200', '130000,130200', '遵化市', '河北省/唐山市/遵化市', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130283', '130200', '130000,130200', '迁安市', '河北省/唐山市/迁安市', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130284', '130200', '130000,130200', '滦州市', '河北省/唐山市/滦州市', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130300', '130000', '130000', '秦皇岛市', '河北省/秦皇岛市', 2, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130301', '130300', '130000,130300', '市辖区', '河北省/秦皇岛市/市辖区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130302', '130300', '130000,130300', '海港区', '河北省/秦皇岛市/海港区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130303', '130300', '130000,130300', '山海关区', '河北省/秦皇岛市/山海关区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130304', '130300', '130000,130300', '北戴河区', '河北省/秦皇岛市/北戴河区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130306', '130300', '130000,130300', '抚宁区', '河北省/秦皇岛市/抚宁区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130321', '130300', '130000,130300', '青龙满族自治县', '河北省/秦皇岛市/青龙满族自治县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130322', '130300', '130000,130300', '昌黎县', '河北省/秦皇岛市/昌黎县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130324', '130300', '130000,130300', '卢龙县', '河北省/秦皇岛市/卢龙县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130371', '130300', '130000,130300', '秦皇岛市经济技术开发区', '河北省/秦皇岛市/秦皇岛市经济技术开发区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130372', '130300', '130000,130300', '北戴河新区', '河北省/秦皇岛市/北戴河新区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130400', '130000', '130000', '邯郸市', '河北省/邯郸市', 2, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130401', '130400', '130000,130400', '市辖区', '河北省/邯郸市/市辖区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130402', '130400', '130000,130400', '邯山区', '河北省/邯郸市/邯山区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130403', '130400', '130000,130400', '丛台区', '河北省/邯郸市/丛台区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130404', '130400', '130000,130400', '复兴区', '河北省/邯郸市/复兴区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130406', '130400', '130000,130400', '峰峰矿区', '河北省/邯郸市/峰峰矿区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130407', '130400', '130000,130400', '肥乡区', '河北省/邯郸市/肥乡区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130408', '130400', '130000,130400', '永年区', '河北省/邯郸市/永年区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130423', '130400', '130000,130400', '临漳县', '河北省/邯郸市/临漳县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130424', '130400', '130000,130400', '成安县', '河北省/邯郸市/成安县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130425', '130400', '130000,130400', '大名县', '河北省/邯郸市/大名县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130426', '130400', '130000,130400', '涉县', '河北省/邯郸市/涉县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130427', '130400', '130000,130400', '磁县', '河北省/邯郸市/磁县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130430', '130400', '130000,130400', '邱县', '河北省/邯郸市/邱县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130431', '130400', '130000,130400', '鸡泽县', '河北省/邯郸市/鸡泽县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130432', '130400', '130000,130400', '广平县', '河北省/邯郸市/广平县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130433', '130400', '130000,130400', '馆陶县', '河北省/邯郸市/馆陶县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130434', '130400', '130000,130400', '魏县', '河北省/邯郸市/魏县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130435', '130400', '130000,130400', '曲周县', '河北省/邯郸市/曲周县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130471', '130400', '130000,130400', '邯郸经济技术开发区', '河北省/邯郸市/邯郸经济技术开发区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130473', '130400', '130000,130400', '邯郸冀南新区', '河北省/邯郸市/邯郸冀南新区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130481', '130400', '130000,130400', '武安市', '河北省/邯郸市/武安市', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130500', '130000', '130000', '邢台市', '河北省/邢台市', 2, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130501', '130500', '130000,130500', '市辖区', '河北省/邢台市/市辖区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130502', '130500', '130000,130500', '桥东区', '河北省/邢台市/桥东区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130503', '130500', '130000,130500', '桥西区', '河北省/邢台市/桥西区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130521', '130500', '130000,130500', '邢台县', '河北省/邢台市/邢台县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130522', '130500', '130000,130500', '临城县', '河北省/邢台市/临城县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130523', '130500', '130000,130500', '内丘县', '河北省/邢台市/内丘县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130524', '130500', '130000,130500', '柏乡县', '河北省/邢台市/柏乡县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130525', '130500', '130000,130500', '隆尧县', '河北省/邢台市/隆尧县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130526', '130500', '130000,130500', '任县', '河北省/邢台市/任县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130527', '130500', '130000,130500', '南和县', '河北省/邢台市/南和县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130528', '130500', '130000,130500', '宁晋县', '河北省/邢台市/宁晋县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130529', '130500', '130000,130500', '巨鹿县', '河北省/邢台市/巨鹿县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130530', '130500', '130000,130500', '新河县', '河北省/邢台市/新河县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130531', '130500', '130000,130500', '广宗县', '河北省/邢台市/广宗县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130532', '130500', '130000,130500', '平乡县', '河北省/邢台市/平乡县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130533', '130500', '130000,130500', '威县', '河北省/邢台市/威县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130534', '130500', '130000,130500', '清河县', '河北省/邢台市/清河县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130535', '130500', '130000,130500', '临西县', '河北省/邢台市/临西县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130571', '130500', '130000,130500', '河北邢台经济开发区', '河北省/邢台市/河北邢台经济开发区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130581', '130500', '130000,130500', '南宫市', '河北省/邢台市/南宫市', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130582', '130500', '130000,130500', '沙河市', '河北省/邢台市/沙河市', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130600', '130000', '130000', '保定市', '河北省/保定市', 2, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130601', '130600', '130000,130600', '市辖区', '河北省/保定市/市辖区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130602', '130600', '130000,130600', '竞秀区', '河北省/保定市/竞秀区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130606', '130600', '130000,130600', '莲池区', '河北省/保定市/莲池区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130607', '130600', '130000,130600', '满城区', '河北省/保定市/满城区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130608', '130600', '130000,130600', '清苑区', '河北省/保定市/清苑区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130609', '130600', '130000,130600', '徐水区', '河北省/保定市/徐水区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130623', '130600', '130000,130600', '涞水县', '河北省/保定市/涞水县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130624', '130600', '130000,130600', '阜平县', '河北省/保定市/阜平县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130626', '130600', '130000,130600', '定兴县', '河北省/保定市/定兴县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130627', '130600', '130000,130600', '唐县', '河北省/保定市/唐县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130628', '130600', '130000,130600', '高阳县', '河北省/保定市/高阳县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130629', '130600', '130000,130600', '容城县', '河北省/保定市/容城县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130630', '130600', '130000,130600', '涞源县', '河北省/保定市/涞源县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130631', '130600', '130000,130600', '望都县', '河北省/保定市/望都县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130632', '130600', '130000,130600', '安新县', '河北省/保定市/安新县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130633', '130600', '130000,130600', '易县', '河北省/保定市/易县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130634', '130600', '130000,130600', '曲阳县', '河北省/保定市/曲阳县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130635', '130600', '130000,130600', '蠡县', '河北省/保定市/蠡县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130636', '130600', '130000,130600', '顺平县', '河北省/保定市/顺平县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130637', '130600', '130000,130600', '博野县', '河北省/保定市/博野县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130638', '130600', '130000,130600', '雄县', '河北省/保定市/雄县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130671', '130600', '130000,130600', '保定高新技术产业开发区', '河北省/保定市/保定高新技术产业开发区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130672', '130600', '130000,130600', '保定白沟新城', '河北省/保定市/保定白沟新城', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130681', '130600', '130000,130600', '涿州市', '河北省/保定市/涿州市', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130682', '130600', '130000,130600', '定州市', '河北省/保定市/定州市', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130683', '130600', '130000,130600', '安国市', '河北省/保定市/安国市', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130684', '130600', '130000,130600', '高碑店市', '河北省/保定市/高碑店市', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130700', '130000', '130000', '张家口市', '河北省/张家口市', 2, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130701', '130700', '130000,130700', '市辖区', '河北省/张家口市/市辖区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130702', '130700', '130000,130700', '桥东区', '河北省/张家口市/桥东区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130703', '130700', '130000,130700', '桥西区', '河北省/张家口市/桥西区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130705', '130700', '130000,130700', '宣化区', '河北省/张家口市/宣化区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130706', '130700', '130000,130700', '下花园区', '河北省/张家口市/下花园区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130708', '130700', '130000,130700', '万全区', '河北省/张家口市/万全区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130709', '130700', '130000,130700', '崇礼区', '河北省/张家口市/崇礼区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130722', '130700', '130000,130700', '张北县', '河北省/张家口市/张北县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130723', '130700', '130000,130700', '康保县', '河北省/张家口市/康保县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130724', '130700', '130000,130700', '沽源县', '河北省/张家口市/沽源县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130725', '130700', '130000,130700', '尚义县', '河北省/张家口市/尚义县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130726', '130700', '130000,130700', '蔚县', '河北省/张家口市/蔚县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130727', '130700', '130000,130700', '阳原县', '河北省/张家口市/阳原县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130728', '130700', '130000,130700', '怀安县', '河北省/张家口市/怀安县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130730', '130700', '130000,130700', '怀来县', '河北省/张家口市/怀来县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130731', '130700', '130000,130700', '涿鹿县', '河北省/张家口市/涿鹿县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130732', '130700', '130000,130700', '赤城县', '河北省/张家口市/赤城县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130771', '130700', '130000,130700', '张家口经济开发区', '河北省/张家口市/张家口经济开发区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130772', '130700', '130000,130700', '张家口市察北管理区', '河北省/张家口市/张家口市察北管理区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130773', '130700', '130000,130700', '张家口市塞北管理区', '河北省/张家口市/张家口市塞北管理区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130800', '130000', '130000', '承德市', '河北省/承德市', 2, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130801', '130800', '130000,130800', '市辖区', '河北省/承德市/市辖区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130802', '130800', '130000,130800', '双桥区', '河北省/承德市/双桥区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130803', '130800', '130000,130800', '双滦区', '河北省/承德市/双滦区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130804', '130800', '130000,130800', '鹰手营子矿区', '河北省/承德市/鹰手营子矿区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130821', '130800', '130000,130800', '承德县', '河北省/承德市/承德县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130822', '130800', '130000,130800', '兴隆县', '河北省/承德市/兴隆县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130824', '130800', '130000,130800', '滦平县', '河北省/承德市/滦平县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130825', '130800', '130000,130800', '隆化县', '河北省/承德市/隆化县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130826', '130800', '130000,130800', '丰宁满族自治县', '河北省/承德市/丰宁满族自治县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130827', '130800', '130000,130800', '宽城满族自治县', '河北省/承德市/宽城满族自治县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130828', '130800', '130000,130800', '围场满族蒙古族自治县', '河北省/承德市/围场满族蒙古族自治县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130871', '130800', '130000,130800', '承德高新技术产业开发区', '河北省/承德市/承德高新技术产业开发区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130881', '130800', '130000,130800', '平泉市', '河北省/承德市/平泉市', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130900', '130000', '130000', '沧州市', '河北省/沧州市', 2, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130901', '130900', '130000,130900', '市辖区', '河北省/沧州市/市辖区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130902', '130900', '130000,130900', '新华区', '河北省/沧州市/新华区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130903', '130900', '130000,130900', '运河区', '河北省/沧州市/运河区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130921', '130900', '130000,130900', '沧县', '河北省/沧州市/沧县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130922', '130900', '130000,130900', '青县', '河北省/沧州市/青县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130923', '130900', '130000,130900', '东光县', '河北省/沧州市/东光县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130924', '130900', '130000,130900', '海兴县', '河北省/沧州市/海兴县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130925', '130900', '130000,130900', '盐山县', '河北省/沧州市/盐山县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130926', '130900', '130000,130900', '肃宁县', '河北省/沧州市/肃宁县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130927', '130900', '130000,130900', '南皮县', '河北省/沧州市/南皮县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130928', '130900', '130000,130900', '吴桥县', '河北省/沧州市/吴桥县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130929', '130900', '130000,130900', '献县', '河北省/沧州市/献县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130930', '130900', '130000,130900', '孟村回族自治县', '河北省/沧州市/孟村回族自治县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130971', '130900', '130000,130900', '河北沧州经济开发区', '河北省/沧州市/河北沧州经济开发区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130972', '130900', '130000,130900', '沧州高新技术产业开发区', '河北省/沧州市/沧州高新技术产业开发区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130973', '130900', '130000,130900', '沧州渤海新区', '河北省/沧州市/沧州渤海新区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130981', '130900', '130000,130900', '泊头市', '河北省/沧州市/泊头市', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130982', '130900', '130000,130900', '任丘市', '河北省/沧州市/任丘市', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130983', '130900', '130000,130900', '黄骅市', '河北省/沧州市/黄骅市', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('130984', '130900', '130000,130900', '河间市', '河北省/沧州市/河间市', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('131000', '130000', '130000', '廊坊市', '河北省/廊坊市', 2, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('131001', '131000', '130000,131000', '市辖区', '河北省/廊坊市/市辖区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('131002', '131000', '130000,131000', '安次区', '河北省/廊坊市/安次区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('131003', '131000', '130000,131000', '广阳区', '河北省/廊坊市/广阳区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('131022', '131000', '130000,131000', '固安县', '河北省/廊坊市/固安县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('131023', '131000', '130000,131000', '永清县', '河北省/廊坊市/永清县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('131024', '131000', '130000,131000', '香河县', '河北省/廊坊市/香河县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('131025', '131000', '130000,131000', '大城县', '河北省/廊坊市/大城县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('131026', '131000', '130000,131000', '文安县', '河北省/廊坊市/文安县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('131028', '131000', '130000,131000', '大厂回族自治县', '河北省/廊坊市/大厂回族自治县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('131071', '131000', '130000,131000', '廊坊经济技术开发区', '河北省/廊坊市/廊坊经济技术开发区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('131081', '131000', '130000,131000', '霸州市', '河北省/廊坊市/霸州市', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('131082', '131000', '130000,131000', '三河市', '河北省/廊坊市/三河市', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('131100', '130000', '130000', '衡水市', '河北省/衡水市', 2, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('131101', '131100', '130000,131100', '市辖区', '河北省/衡水市/市辖区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('131102', '131100', '130000,131100', '桃城区', '河北省/衡水市/桃城区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('131103', '131100', '130000,131100', '冀州区', '河北省/衡水市/冀州区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('131121', '131100', '130000,131100', '枣强县', '河北省/衡水市/枣强县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('131122', '131100', '130000,131100', '武邑县', '河北省/衡水市/武邑县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('131123', '131100', '130000,131100', '武强县', '河北省/衡水市/武强县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('131124', '131100', '130000,131100', '饶阳县', '河北省/衡水市/饶阳县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('131125', '131100', '130000,131100', '安平县', '河北省/衡水市/安平县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('131126', '131100', '130000,131100', '故城县', '河北省/衡水市/故城县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('131127', '131100', '130000,131100', '景县', '河北省/衡水市/景县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('131128', '131100', '130000,131100', '阜城县', '河北省/衡水市/阜城县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('131171', '131100', '130000,131100', '河北衡水高新技术产业开发区', '河北省/衡水市/河北衡水高新技术产业开发区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('131172', '131100', '130000,131100', '衡水滨湖新区', '河北省/衡水市/衡水滨湖新区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('131182', '131100', '130000,131100', '深州市', '河北省/衡水市/深州市', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140000', '86', '', '山西省', '山西省', 1, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140100', '140000', '140000', '太原市', '山西省/太原市', 2, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140101', '140100', '140000,140100', '市辖区', '山西省/太原市/市辖区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140105', '140100', '140000,140100', '小店区', '山西省/太原市/小店区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140106', '140100', '140000,140100', '迎泽区', '山西省/太原市/迎泽区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140107', '140100', '140000,140100', '杏花岭区', '山西省/太原市/杏花岭区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140108', '140100', '140000,140100', '尖草坪区', '山西省/太原市/尖草坪区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140109', '140100', '140000,140100', '万柏林区', '山西省/太原市/万柏林区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140110', '140100', '140000,140100', '晋源区', '山西省/太原市/晋源区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140121', '140100', '140000,140100', '清徐县', '山西省/太原市/清徐县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140122', '140100', '140000,140100', '阳曲县', '山西省/太原市/阳曲县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140123', '140100', '140000,140100', '娄烦县', '山西省/太原市/娄烦县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140171', '140100', '140000,140100', '山西转型综合改革示范区', '山西省/太原市/山西转型综合改革示范区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140181', '140100', '140000,140100', '古交市', '山西省/太原市/古交市', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140200', '140000', '140000', '大同市', '山西省/大同市', 2, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140201', '140200', '140000,140200', '市辖区', '山西省/大同市/市辖区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140212', '140200', '140000,140200', '新荣区', '山西省/大同市/新荣区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140213', '140200', '140000,140200', '平城区', '山西省/大同市/平城区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140214', '140200', '140000,140200', '云冈区', '山西省/大同市/云冈区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140215', '140200', '140000,140200', '云州区', '山西省/大同市/云州区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140221', '140200', '140000,140200', '阳高县', '山西省/大同市/阳高县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140222', '140200', '140000,140200', '天镇县', '山西省/大同市/天镇县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140223', '140200', '140000,140200', '广灵县', '山西省/大同市/广灵县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140224', '140200', '140000,140200', '灵丘县', '山西省/大同市/灵丘县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140225', '140200', '140000,140200', '浑源县', '山西省/大同市/浑源县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140226', '140200', '140000,140200', '左云县', '山西省/大同市/左云县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140271', '140200', '140000,140200', '山西大同经济开发区', '山西省/大同市/山西大同经济开发区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140300', '140000', '140000', '阳泉市', '山西省/阳泉市', 2, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140301', '140300', '140000,140300', '市辖区', '山西省/阳泉市/市辖区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140302', '140300', '140000,140300', '城区', '山西省/阳泉市/城区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140303', '140300', '140000,140300', '矿区', '山西省/阳泉市/矿区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140311', '140300', '140000,140300', '郊区', '山西省/阳泉市/郊区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140321', '140300', '140000,140300', '平定县', '山西省/阳泉市/平定县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140322', '140300', '140000,140300', '盂县', '山西省/阳泉市/盂县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140400', '140000', '140000', '长治市', '山西省/长治市', 2, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140401', '140400', '140000,140400', '市辖区', '山西省/长治市/市辖区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140403', '140400', '140000,140400', '潞州区', '山西省/长治市/潞州区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140404', '140400', '140000,140400', '上党区', '山西省/长治市/上党区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140405', '140400', '140000,140400', '屯留区', '山西省/长治市/屯留区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140406', '140400', '140000,140400', '潞城区', '山西省/长治市/潞城区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140423', '140400', '140000,140400', '襄垣县', '山西省/长治市/襄垣县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140425', '140400', '140000,140400', '平顺县', '山西省/长治市/平顺县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140426', '140400', '140000,140400', '黎城县', '山西省/长治市/黎城县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140427', '140400', '140000,140400', '壶关县', '山西省/长治市/壶关县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140428', '140400', '140000,140400', '长子县', '山西省/长治市/长子县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140429', '140400', '140000,140400', '武乡县', '山西省/长治市/武乡县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140430', '140400', '140000,140400', '沁县', '山西省/长治市/沁县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140431', '140400', '140000,140400', '沁源县', '山西省/长治市/沁源县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140471', '140400', '140000,140400', '山西长治高新技术产业园区', '山西省/长治市/山西长治高新技术产业园区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140500', '140000', '140000', '晋城市', '山西省/晋城市', 2, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140501', '140500', '140000,140500', '市辖区', '山西省/晋城市/市辖区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140502', '140500', '140000,140500', '城区', '山西省/晋城市/城区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140521', '140500', '140000,140500', '沁水县', '山西省/晋城市/沁水县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140522', '140500', '140000,140500', '阳城县', '山西省/晋城市/阳城县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140524', '140500', '140000,140500', '陵川县', '山西省/晋城市/陵川县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140525', '140500', '140000,140500', '泽州县', '山西省/晋城市/泽州县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140581', '140500', '140000,140500', '高平市', '山西省/晋城市/高平市', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140600', '140000', '140000', '朔州市', '山西省/朔州市', 2, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140601', '140600', '140000,140600', '市辖区', '山西省/朔州市/市辖区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140602', '140600', '140000,140600', '朔城区', '山西省/朔州市/朔城区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140603', '140600', '140000,140600', '平鲁区', '山西省/朔州市/平鲁区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140621', '140600', '140000,140600', '山阴县', '山西省/朔州市/山阴县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140622', '140600', '140000,140600', '应县', '山西省/朔州市/应县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140623', '140600', '140000,140600', '右玉县', '山西省/朔州市/右玉县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140671', '140600', '140000,140600', '山西朔州经济开发区', '山西省/朔州市/山西朔州经济开发区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140681', '140600', '140000,140600', '怀仁市', '山西省/朔州市/怀仁市', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140700', '140000', '140000', '晋中市', '山西省/晋中市', 2, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140701', '140700', '140000,140700', '市辖区', '山西省/晋中市/市辖区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140702', '140700', '140000,140700', '榆次区', '山西省/晋中市/榆次区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140721', '140700', '140000,140700', '榆社县', '山西省/晋中市/榆社县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140722', '140700', '140000,140700', '左权县', '山西省/晋中市/左权县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140723', '140700', '140000,140700', '和顺县', '山西省/晋中市/和顺县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140724', '140700', '140000,140700', '昔阳县', '山西省/晋中市/昔阳县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140725', '140700', '140000,140700', '寿阳县', '山西省/晋中市/寿阳县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140726', '140700', '140000,140700', '太谷县', '山西省/晋中市/太谷县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140727', '140700', '140000,140700', '祁县', '山西省/晋中市/祁县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140728', '140700', '140000,140700', '平遥县', '山西省/晋中市/平遥县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140729', '140700', '140000,140700', '灵石县', '山西省/晋中市/灵石县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140781', '140700', '140000,140700', '介休市', '山西省/晋中市/介休市', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140800', '140000', '140000', '运城市', '山西省/运城市', 2, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140801', '140800', '140000,140800', '市辖区', '山西省/运城市/市辖区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140802', '140800', '140000,140800', '盐湖区', '山西省/运城市/盐湖区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140821', '140800', '140000,140800', '临猗县', '山西省/运城市/临猗县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140822', '140800', '140000,140800', '万荣县', '山西省/运城市/万荣县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140823', '140800', '140000,140800', '闻喜县', '山西省/运城市/闻喜县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140824', '140800', '140000,140800', '稷山县', '山西省/运城市/稷山县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140825', '140800', '140000,140800', '新绛县', '山西省/运城市/新绛县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140826', '140800', '140000,140800', '绛县', '山西省/运城市/绛县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140827', '140800', '140000,140800', '垣曲县', '山西省/运城市/垣曲县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140828', '140800', '140000,140800', '夏县', '山西省/运城市/夏县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140829', '140800', '140000,140800', '平陆县', '山西省/运城市/平陆县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140830', '140800', '140000,140800', '芮城县', '山西省/运城市/芮城县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140881', '140800', '140000,140800', '永济市', '山西省/运城市/永济市', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140882', '140800', '140000,140800', '河津市', '山西省/运城市/河津市', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140900', '140000', '140000', '忻州市', '山西省/忻州市', 2, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140901', '140900', '140000,140900', '市辖区', '山西省/忻州市/市辖区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140902', '140900', '140000,140900', '忻府区', '山西省/忻州市/忻府区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140921', '140900', '140000,140900', '定襄县', '山西省/忻州市/定襄县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140922', '140900', '140000,140900', '五台县', '山西省/忻州市/五台县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140923', '140900', '140000,140900', '代县', '山西省/忻州市/代县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140924', '140900', '140000,140900', '繁峙县', '山西省/忻州市/繁峙县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140925', '140900', '140000,140900', '宁武县', '山西省/忻州市/宁武县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140926', '140900', '140000,140900', '静乐县', '山西省/忻州市/静乐县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140927', '140900', '140000,140900', '神池县', '山西省/忻州市/神池县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140928', '140900', '140000,140900', '五寨县', '山西省/忻州市/五寨县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140929', '140900', '140000,140900', '岢岚县', '山西省/忻州市/岢岚县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140930', '140900', '140000,140900', '河曲县', '山西省/忻州市/河曲县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140931', '140900', '140000,140900', '保德县', '山西省/忻州市/保德县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140932', '140900', '140000,140900', '偏关县', '山西省/忻州市/偏关县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140971', '140900', '140000,140900', '五台山风景名胜区', '山西省/忻州市/五台山风景名胜区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('140981', '140900', '140000,140900', '原平市', '山西省/忻州市/原平市', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141000', '140000', '140000', '临汾市', '山西省/临汾市', 2, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141001', '141000', '140000,141000', '市辖区', '山西省/临汾市/市辖区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141002', '141000', '140000,141000', '尧都区', '山西省/临汾市/尧都区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141021', '141000', '140000,141000', '曲沃县', '山西省/临汾市/曲沃县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141022', '141000', '140000,141000', '翼城县', '山西省/临汾市/翼城县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141023', '141000', '140000,141000', '襄汾县', '山西省/临汾市/襄汾县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141024', '141000', '140000,141000', '洪洞县', '山西省/临汾市/洪洞县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141025', '141000', '140000,141000', '古县', '山西省/临汾市/古县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141026', '141000', '140000,141000', '安泽县', '山西省/临汾市/安泽县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141027', '141000', '140000,141000', '浮山县', '山西省/临汾市/浮山县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141028', '141000', '140000,141000', '吉县', '山西省/临汾市/吉县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141029', '141000', '140000,141000', '乡宁县', '山西省/临汾市/乡宁县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141030', '141000', '140000,141000', '大宁县', '山西省/临汾市/大宁县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141031', '141000', '140000,141000', '隰县', '山西省/临汾市/隰县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141032', '141000', '140000,141000', '永和县', '山西省/临汾市/永和县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141033', '141000', '140000,141000', '蒲县', '山西省/临汾市/蒲县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141034', '141000', '140000,141000', '汾西县', '山西省/临汾市/汾西县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141081', '141000', '140000,141000', '侯马市', '山西省/临汾市/侯马市', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141082', '141000', '140000,141000', '霍州市', '山西省/临汾市/霍州市', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141100', '140000', '140000', '吕梁市', '山西省/吕梁市', 2, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141101', '141100', '140000,141100', '市辖区', '山西省/吕梁市/市辖区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141102', '141100', '140000,141100', '离石区', '山西省/吕梁市/离石区', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141121', '141100', '140000,141100', '文水县', '山西省/吕梁市/文水县', 3, 'admin', '2022-05-22 20:35:12', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141122', '141100', '140000,141100', '交城县', '山西省/吕梁市/交城县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141123', '141100', '140000,141100', '兴县', '山西省/吕梁市/兴县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141124', '141100', '140000,141100', '临县', '山西省/吕梁市/临县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141125', '141100', '140000,141100', '柳林县', '山西省/吕梁市/柳林县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141126', '141100', '140000,141100', '石楼县', '山西省/吕梁市/石楼县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141127', '141100', '140000,141100', '岚县', '山西省/吕梁市/岚县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141128', '141100', '140000,141100', '方山县', '山西省/吕梁市/方山县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141129', '141100', '140000,141100', '中阳县', '山西省/吕梁市/中阳县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141130', '141100', '140000,141100', '交口县', '山西省/吕梁市/交口县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141181', '141100', '140000,141100', '孝义市', '山西省/吕梁市/孝义市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('141182', '141100', '140000,141100', '汾阳市', '山西省/吕梁市/汾阳市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150000', '86', '', '内蒙古自治区', '内蒙古自治区', 1, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150100', '150000', '150000', '呼和浩特市', '内蒙古自治区/呼和浩特市', 2, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150101', '150100', '150000,150100', '市辖区', '内蒙古自治区/呼和浩特市/市辖区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150102', '150100', '150000,150100', '新城区', '内蒙古自治区/呼和浩特市/新城区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150103', '150100', '150000,150100', '回民区', '内蒙古自治区/呼和浩特市/回民区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150104', '150100', '150000,150100', '玉泉区', '内蒙古自治区/呼和浩特市/玉泉区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150105', '150100', '150000,150100', '赛罕区', '内蒙古自治区/呼和浩特市/赛罕区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150121', '150100', '150000,150100', '土默特左旗', '内蒙古自治区/呼和浩特市/土默特左旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150122', '150100', '150000,150100', '托克托县', '内蒙古自治区/呼和浩特市/托克托县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150123', '150100', '150000,150100', '和林格尔县', '内蒙古自治区/呼和浩特市/和林格尔县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150124', '150100', '150000,150100', '清水河县', '内蒙古自治区/呼和浩特市/清水河县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150125', '150100', '150000,150100', '武川县', '内蒙古自治区/呼和浩特市/武川县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150171', '150100', '150000,150100', '呼和浩特金海工业园区', '内蒙古自治区/呼和浩特市/呼和浩特金海工业园区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150172', '150100', '150000,150100', '呼和浩特经济技术开发区', '内蒙古自治区/呼和浩特市/呼和浩特经济技术开发区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150200', '150000', '150000', '包头市', '内蒙古自治区/包头市', 2, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150201', '150200', '150000,150200', '市辖区', '内蒙古自治区/包头市/市辖区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150202', '150200', '150000,150200', '东河区', '内蒙古自治区/包头市/东河区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150203', '150200', '150000,150200', '昆都仑区', '内蒙古自治区/包头市/昆都仑区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150204', '150200', '150000,150200', '青山区', '内蒙古自治区/包头市/青山区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150205', '150200', '150000,150200', '石拐区', '内蒙古自治区/包头市/石拐区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150206', '150200', '150000,150200', '白云鄂博矿区', '内蒙古自治区/包头市/白云鄂博矿区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150207', '150200', '150000,150200', '九原区', '内蒙古自治区/包头市/九原区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150221', '150200', '150000,150200', '土默特右旗', '内蒙古自治区/包头市/土默特右旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150222', '150200', '150000,150200', '固阳县', '内蒙古自治区/包头市/固阳县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150223', '150200', '150000,150200', '达尔罕茂明安联合旗', '内蒙古自治区/包头市/达尔罕茂明安联合旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150271', '150200', '150000,150200', '包头稀土高新技术产业开发区', '内蒙古自治区/包头市/包头稀土高新技术产业开发区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150300', '150000', '150000', '乌海市', '内蒙古自治区/乌海市', 2, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150301', '150300', '150000,150300', '市辖区', '内蒙古自治区/乌海市/市辖区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150302', '150300', '150000,150300', '海勃湾区', '内蒙古自治区/乌海市/海勃湾区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150303', '150300', '150000,150300', '海南区', '内蒙古自治区/乌海市/海南区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150304', '150300', '150000,150300', '乌达区', '内蒙古自治区/乌海市/乌达区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150400', '150000', '150000', '赤峰市', '内蒙古自治区/赤峰市', 2, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150401', '150400', '150000,150400', '市辖区', '内蒙古自治区/赤峰市/市辖区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150402', '150400', '150000,150400', '红山区', '内蒙古自治区/赤峰市/红山区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150403', '150400', '150000,150400', '元宝山区', '内蒙古自治区/赤峰市/元宝山区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150404', '150400', '150000,150400', '松山区', '内蒙古自治区/赤峰市/松山区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150421', '150400', '150000,150400', '阿鲁科尔沁旗', '内蒙古自治区/赤峰市/阿鲁科尔沁旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150422', '150400', '150000,150400', '巴林左旗', '内蒙古自治区/赤峰市/巴林左旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150423', '150400', '150000,150400', '巴林右旗', '内蒙古自治区/赤峰市/巴林右旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150424', '150400', '150000,150400', '林西县', '内蒙古自治区/赤峰市/林西县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150425', '150400', '150000,150400', '克什克腾旗', '内蒙古自治区/赤峰市/克什克腾旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150426', '150400', '150000,150400', '翁牛特旗', '内蒙古自治区/赤峰市/翁牛特旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150428', '150400', '150000,150400', '喀喇沁旗', '内蒙古自治区/赤峰市/喀喇沁旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150429', '150400', '150000,150400', '宁城县', '内蒙古自治区/赤峰市/宁城县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150430', '150400', '150000,150400', '敖汉旗', '内蒙古自治区/赤峰市/敖汉旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150500', '150000', '150000', '通辽市', '内蒙古自治区/通辽市', 2, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150501', '150500', '150000,150500', '市辖区', '内蒙古自治区/通辽市/市辖区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150502', '150500', '150000,150500', '科尔沁区', '内蒙古自治区/通辽市/科尔沁区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150521', '150500', '150000,150500', '科尔沁左翼中旗', '内蒙古自治区/通辽市/科尔沁左翼中旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150522', '150500', '150000,150500', '科尔沁左翼后旗', '内蒙古自治区/通辽市/科尔沁左翼后旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150523', '150500', '150000,150500', '开鲁县', '内蒙古自治区/通辽市/开鲁县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150524', '150500', '150000,150500', '库伦旗', '内蒙古自治区/通辽市/库伦旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150525', '150500', '150000,150500', '奈曼旗', '内蒙古自治区/通辽市/奈曼旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150526', '150500', '150000,150500', '扎鲁特旗', '内蒙古自治区/通辽市/扎鲁特旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150571', '150500', '150000,150500', '通辽经济技术开发区', '内蒙古自治区/通辽市/通辽经济技术开发区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150581', '150500', '150000,150500', '霍林郭勒市', '内蒙古自治区/通辽市/霍林郭勒市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150600', '150000', '150000', '鄂尔多斯市', '内蒙古自治区/鄂尔多斯市', 2, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150601', '150600', '150000,150600', '市辖区', '内蒙古自治区/鄂尔多斯市/市辖区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150602', '150600', '150000,150600', '东胜区', '内蒙古自治区/鄂尔多斯市/东胜区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150603', '150600', '150000,150600', '康巴什区', '内蒙古自治区/鄂尔多斯市/康巴什区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150621', '150600', '150000,150600', '达拉特旗', '内蒙古自治区/鄂尔多斯市/达拉特旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150622', '150600', '150000,150600', '准格尔旗', '内蒙古自治区/鄂尔多斯市/准格尔旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150623', '150600', '150000,150600', '鄂托克前旗', '内蒙古自治区/鄂尔多斯市/鄂托克前旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150624', '150600', '150000,150600', '鄂托克旗', '内蒙古自治区/鄂尔多斯市/鄂托克旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150625', '150600', '150000,150600', '杭锦旗', '内蒙古自治区/鄂尔多斯市/杭锦旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150626', '150600', '150000,150600', '乌审旗', '内蒙古自治区/鄂尔多斯市/乌审旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150627', '150600', '150000,150600', '伊金霍洛旗', '内蒙古自治区/鄂尔多斯市/伊金霍洛旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150700', '150000', '150000', '呼伦贝尔市', '内蒙古自治区/呼伦贝尔市', 2, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150701', '150700', '150000,150700', '市辖区', '内蒙古自治区/呼伦贝尔市/市辖区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150702', '150700', '150000,150700', '海拉尔区', '内蒙古自治区/呼伦贝尔市/海拉尔区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150703', '150700', '150000,150700', '扎赉诺尔区', '内蒙古自治区/呼伦贝尔市/扎赉诺尔区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150721', '150700', '150000,150700', '阿荣旗', '内蒙古自治区/呼伦贝尔市/阿荣旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150722', '150700', '150000,150700', '莫力达瓦达斡尔族自治旗', '内蒙古自治区/呼伦贝尔市/莫力达瓦达斡尔族自治旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150723', '150700', '150000,150700', '鄂伦春自治旗', '内蒙古自治区/呼伦贝尔市/鄂伦春自治旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150724', '150700', '150000,150700', '鄂温克族自治旗', '内蒙古自治区/呼伦贝尔市/鄂温克族自治旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150725', '150700', '150000,150700', '陈巴尔虎旗', '内蒙古自治区/呼伦贝尔市/陈巴尔虎旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150726', '150700', '150000,150700', '新巴尔虎左旗', '内蒙古自治区/呼伦贝尔市/新巴尔虎左旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150727', '150700', '150000,150700', '新巴尔虎右旗', '内蒙古自治区/呼伦贝尔市/新巴尔虎右旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150781', '150700', '150000,150700', '满洲里市', '内蒙古自治区/呼伦贝尔市/满洲里市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150782', '150700', '150000,150700', '牙克石市', '内蒙古自治区/呼伦贝尔市/牙克石市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150783', '150700', '150000,150700', '扎兰屯市', '内蒙古自治区/呼伦贝尔市/扎兰屯市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150784', '150700', '150000,150700', '额尔古纳市', '内蒙古自治区/呼伦贝尔市/额尔古纳市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150785', '150700', '150000,150700', '根河市', '内蒙古自治区/呼伦贝尔市/根河市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150800', '150000', '150000', '巴彦淖尔市', '内蒙古自治区/巴彦淖尔市', 2, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150801', '150800', '150000,150800', '市辖区', '内蒙古自治区/巴彦淖尔市/市辖区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150802', '150800', '150000,150800', '临河区', '内蒙古自治区/巴彦淖尔市/临河区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150821', '150800', '150000,150800', '五原县', '内蒙古自治区/巴彦淖尔市/五原县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150822', '150800', '150000,150800', '磴口县', '内蒙古自治区/巴彦淖尔市/磴口县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150823', '150800', '150000,150800', '乌拉特前旗', '内蒙古自治区/巴彦淖尔市/乌拉特前旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150824', '150800', '150000,150800', '乌拉特中旗', '内蒙古自治区/巴彦淖尔市/乌拉特中旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150825', '150800', '150000,150800', '乌拉特后旗', '内蒙古自治区/巴彦淖尔市/乌拉特后旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150826', '150800', '150000,150800', '杭锦后旗', '内蒙古自治区/巴彦淖尔市/杭锦后旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150900', '150000', '150000', '乌兰察布市', '内蒙古自治区/乌兰察布市', 2, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150901', '150900', '150000,150900', '市辖区', '内蒙古自治区/乌兰察布市/市辖区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150902', '150900', '150000,150900', '集宁区', '内蒙古自治区/乌兰察布市/集宁区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150921', '150900', '150000,150900', '卓资县', '内蒙古自治区/乌兰察布市/卓资县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150922', '150900', '150000,150900', '化德县', '内蒙古自治区/乌兰察布市/化德县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150923', '150900', '150000,150900', '商都县', '内蒙古自治区/乌兰察布市/商都县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150924', '150900', '150000,150900', '兴和县', '内蒙古自治区/乌兰察布市/兴和县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150925', '150900', '150000,150900', '凉城县', '内蒙古自治区/乌兰察布市/凉城县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150926', '150900', '150000,150900', '察哈尔右翼前旗', '内蒙古自治区/乌兰察布市/察哈尔右翼前旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150927', '150900', '150000,150900', '察哈尔右翼中旗', '内蒙古自治区/乌兰察布市/察哈尔右翼中旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150928', '150900', '150000,150900', '察哈尔右翼后旗', '内蒙古自治区/乌兰察布市/察哈尔右翼后旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150929', '150900', '150000,150900', '四子王旗', '内蒙古自治区/乌兰察布市/四子王旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('150981', '150900', '150000,150900', '丰镇市', '内蒙古自治区/乌兰察布市/丰镇市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('152200', '150000', '150000', '兴安盟', '内蒙古自治区/兴安盟', 2, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('152201', '152200', '150000,152200', '乌兰浩特市', '内蒙古自治区/兴安盟/乌兰浩特市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('152202', '152200', '150000,152200', '阿尔山市', '内蒙古自治区/兴安盟/阿尔山市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('152221', '152200', '150000,152200', '科尔沁右翼前旗', '内蒙古自治区/兴安盟/科尔沁右翼前旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('152222', '152200', '150000,152200', '科尔沁右翼中旗', '内蒙古自治区/兴安盟/科尔沁右翼中旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('152223', '152200', '150000,152200', '扎赉特旗', '内蒙古自治区/兴安盟/扎赉特旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('152224', '152200', '150000,152200', '突泉县', '内蒙古自治区/兴安盟/突泉县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('152500', '150000', '150000', '锡林郭勒盟', '内蒙古自治区/锡林郭勒盟', 2, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('152501', '152500', '150000,152500', '二连浩特市', '内蒙古自治区/锡林郭勒盟/二连浩特市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('152502', '152500', '150000,152500', '锡林浩特市', '内蒙古自治区/锡林郭勒盟/锡林浩特市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('152522', '152500', '150000,152500', '阿巴嘎旗', '内蒙古自治区/锡林郭勒盟/阿巴嘎旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('152523', '152500', '150000,152500', '苏尼特左旗', '内蒙古自治区/锡林郭勒盟/苏尼特左旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('152524', '152500', '150000,152500', '苏尼特右旗', '内蒙古自治区/锡林郭勒盟/苏尼特右旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('152525', '152500', '150000,152500', '东乌珠穆沁旗', '内蒙古自治区/锡林郭勒盟/东乌珠穆沁旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('152526', '152500', '150000,152500', '西乌珠穆沁旗', '内蒙古自治区/锡林郭勒盟/西乌珠穆沁旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('152527', '152500', '150000,152500', '太仆寺旗', '内蒙古自治区/锡林郭勒盟/太仆寺旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('152528', '152500', '150000,152500', '镶黄旗', '内蒙古自治区/锡林郭勒盟/镶黄旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('152529', '152500', '150000,152500', '正镶白旗', '内蒙古自治区/锡林郭勒盟/正镶白旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('152530', '152500', '150000,152500', '正蓝旗', '内蒙古自治区/锡林郭勒盟/正蓝旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('152531', '152500', '150000,152500', '多伦县', '内蒙古自治区/锡林郭勒盟/多伦县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('152571', '152500', '150000,152500', '乌拉盖管委会', '内蒙古自治区/锡林郭勒盟/乌拉盖管委会', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('152900', '150000', '150000', '阿拉善盟', '内蒙古自治区/阿拉善盟', 2, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('152921', '152900', '150000,152900', '阿拉善左旗', '内蒙古自治区/阿拉善盟/阿拉善左旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('152922', '152900', '150000,152900', '阿拉善右旗', '内蒙古自治区/阿拉善盟/阿拉善右旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('152923', '152900', '150000,152900', '额济纳旗', '内蒙古自治区/阿拉善盟/额济纳旗', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('152971', '152900', '150000,152900', '内蒙古阿拉善经济开发区', '内蒙古自治区/阿拉善盟/内蒙古阿拉善经济开发区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210000', '86', '', '辽宁省', '辽宁省', 1, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210100', '210000', '210000', '沈阳市', '辽宁省/沈阳市', 2, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210101', '210100', '210000,210100', '市辖区', '辽宁省/沈阳市/市辖区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210102', '210100', '210000,210100', '和平区', '辽宁省/沈阳市/和平区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210103', '210100', '210000,210100', '沈河区', '辽宁省/沈阳市/沈河区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210104', '210100', '210000,210100', '大东区', '辽宁省/沈阳市/大东区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210105', '210100', '210000,210100', '皇姑区', '辽宁省/沈阳市/皇姑区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210106', '210100', '210000,210100', '铁西区', '辽宁省/沈阳市/铁西区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210111', '210100', '210000,210100', '苏家屯区', '辽宁省/沈阳市/苏家屯区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210112', '210100', '210000,210100', '浑南区', '辽宁省/沈阳市/浑南区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210113', '210100', '210000,210100', '沈北新区', '辽宁省/沈阳市/沈北新区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210114', '210100', '210000,210100', '于洪区', '辽宁省/沈阳市/于洪区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210115', '210100', '210000,210100', '辽中区', '辽宁省/沈阳市/辽中区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210123', '210100', '210000,210100', '康平县', '辽宁省/沈阳市/康平县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210124', '210100', '210000,210100', '法库县', '辽宁省/沈阳市/法库县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210181', '210100', '210000,210100', '新民市', '辽宁省/沈阳市/新民市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210200', '210000', '210000', '大连市', '辽宁省/大连市', 2, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210201', '210200', '210000,210200', '市辖区', '辽宁省/大连市/市辖区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210202', '210200', '210000,210200', '中山区', '辽宁省/大连市/中山区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210203', '210200', '210000,210200', '西岗区', '辽宁省/大连市/西岗区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210204', '210200', '210000,210200', '沙河口区', '辽宁省/大连市/沙河口区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210211', '210200', '210000,210200', '甘井子区', '辽宁省/大连市/甘井子区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210212', '210200', '210000,210200', '旅顺口区', '辽宁省/大连市/旅顺口区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210213', '210200', '210000,210200', '金州区', '辽宁省/大连市/金州区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210214', '210200', '210000,210200', '普兰店区', '辽宁省/大连市/普兰店区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210224', '210200', '210000,210200', '长海县', '辽宁省/大连市/长海县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210281', '210200', '210000,210200', '瓦房店市', '辽宁省/大连市/瓦房店市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210283', '210200', '210000,210200', '庄河市', '辽宁省/大连市/庄河市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210300', '210000', '210000', '鞍山市', '辽宁省/鞍山市', 2, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210301', '210300', '210000,210300', '市辖区', '辽宁省/鞍山市/市辖区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210302', '210300', '210000,210300', '铁东区', '辽宁省/鞍山市/铁东区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210303', '210300', '210000,210300', '铁西区', '辽宁省/鞍山市/铁西区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210304', '210300', '210000,210300', '立山区', '辽宁省/鞍山市/立山区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210311', '210300', '210000,210300', '千山区', '辽宁省/鞍山市/千山区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210321', '210300', '210000,210300', '台安县', '辽宁省/鞍山市/台安县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210323', '210300', '210000,210300', '岫岩满族自治县', '辽宁省/鞍山市/岫岩满族自治县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210381', '210300', '210000,210300', '海城市', '辽宁省/鞍山市/海城市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210400', '210000', '210000', '抚顺市', '辽宁省/抚顺市', 2, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210401', '210400', '210000,210400', '市辖区', '辽宁省/抚顺市/市辖区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210402', '210400', '210000,210400', '新抚区', '辽宁省/抚顺市/新抚区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210403', '210400', '210000,210400', '东洲区', '辽宁省/抚顺市/东洲区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210404', '210400', '210000,210400', '望花区', '辽宁省/抚顺市/望花区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210411', '210400', '210000,210400', '顺城区', '辽宁省/抚顺市/顺城区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210421', '210400', '210000,210400', '抚顺县', '辽宁省/抚顺市/抚顺县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210422', '210400', '210000,210400', '新宾满族自治县', '辽宁省/抚顺市/新宾满族自治县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210423', '210400', '210000,210400', '清原满族自治县', '辽宁省/抚顺市/清原满族自治县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210500', '210000', '210000', '本溪市', '辽宁省/本溪市', 2, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210501', '210500', '210000,210500', '市辖区', '辽宁省/本溪市/市辖区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210502', '210500', '210000,210500', '平山区', '辽宁省/本溪市/平山区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210503', '210500', '210000,210500', '溪湖区', '辽宁省/本溪市/溪湖区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210504', '210500', '210000,210500', '明山区', '辽宁省/本溪市/明山区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210505', '210500', '210000,210500', '南芬区', '辽宁省/本溪市/南芬区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210521', '210500', '210000,210500', '本溪满族自治县', '辽宁省/本溪市/本溪满族自治县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210522', '210500', '210000,210500', '桓仁满族自治县', '辽宁省/本溪市/桓仁满族自治县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210600', '210000', '210000', '丹东市', '辽宁省/丹东市', 2, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210601', '210600', '210000,210600', '市辖区', '辽宁省/丹东市/市辖区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210602', '210600', '210000,210600', '元宝区', '辽宁省/丹东市/元宝区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210603', '210600', '210000,210600', '振兴区', '辽宁省/丹东市/振兴区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210604', '210600', '210000,210600', '振安区', '辽宁省/丹东市/振安区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210624', '210600', '210000,210600', '宽甸满族自治县', '辽宁省/丹东市/宽甸满族自治县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210681', '210600', '210000,210600', '东港市', '辽宁省/丹东市/东港市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210682', '210600', '210000,210600', '凤城市', '辽宁省/丹东市/凤城市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210700', '210000', '210000', '锦州市', '辽宁省/锦州市', 2, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210701', '210700', '210000,210700', '市辖区', '辽宁省/锦州市/市辖区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210702', '210700', '210000,210700', '古塔区', '辽宁省/锦州市/古塔区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210703', '210700', '210000,210700', '凌河区', '辽宁省/锦州市/凌河区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210711', '210700', '210000,210700', '太和区', '辽宁省/锦州市/太和区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210726', '210700', '210000,210700', '黑山县', '辽宁省/锦州市/黑山县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210727', '210700', '210000,210700', '义县', '辽宁省/锦州市/义县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210781', '210700', '210000,210700', '凌海市', '辽宁省/锦州市/凌海市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210782', '210700', '210000,210700', '北镇市', '辽宁省/锦州市/北镇市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210800', '210000', '210000', '营口市', '辽宁省/营口市', 2, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210801', '210800', '210000,210800', '市辖区', '辽宁省/营口市/市辖区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210802', '210800', '210000,210800', '站前区', '辽宁省/营口市/站前区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210803', '210800', '210000,210800', '西市区', '辽宁省/营口市/西市区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210804', '210800', '210000,210800', '鲅鱼圈区', '辽宁省/营口市/鲅鱼圈区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210811', '210800', '210000,210800', '老边区', '辽宁省/营口市/老边区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210881', '210800', '210000,210800', '盖州市', '辽宁省/营口市/盖州市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210882', '210800', '210000,210800', '大石桥市', '辽宁省/营口市/大石桥市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210900', '210000', '210000', '阜新市', '辽宁省/阜新市', 2, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210901', '210900', '210000,210900', '市辖区', '辽宁省/阜新市/市辖区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210902', '210900', '210000,210900', '海州区', '辽宁省/阜新市/海州区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210903', '210900', '210000,210900', '新邱区', '辽宁省/阜新市/新邱区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210904', '210900', '210000,210900', '太平区', '辽宁省/阜新市/太平区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210905', '210900', '210000,210900', '清河门区', '辽宁省/阜新市/清河门区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210911', '210900', '210000,210900', '细河区', '辽宁省/阜新市/细河区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210921', '210900', '210000,210900', '阜新蒙古族自治县', '辽宁省/阜新市/阜新蒙古族自治县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('210922', '210900', '210000,210900', '彰武县', '辽宁省/阜新市/彰武县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211000', '210000', '210000', '辽阳市', '辽宁省/辽阳市', 2, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211001', '211000', '210000,211000', '市辖区', '辽宁省/辽阳市/市辖区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211002', '211000', '210000,211000', '白塔区', '辽宁省/辽阳市/白塔区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211003', '211000', '210000,211000', '文圣区', '辽宁省/辽阳市/文圣区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211004', '211000', '210000,211000', '宏伟区', '辽宁省/辽阳市/宏伟区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211005', '211000', '210000,211000', '弓长岭区', '辽宁省/辽阳市/弓长岭区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211011', '211000', '210000,211000', '太子河区', '辽宁省/辽阳市/太子河区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211021', '211000', '210000,211000', '辽阳县', '辽宁省/辽阳市/辽阳县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211081', '211000', '210000,211000', '灯塔市', '辽宁省/辽阳市/灯塔市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211100', '210000', '210000', '盘锦市', '辽宁省/盘锦市', 2, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211101', '211100', '210000,211100', '市辖区', '辽宁省/盘锦市/市辖区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211102', '211100', '210000,211100', '双台子区', '辽宁省/盘锦市/双台子区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211103', '211100', '210000,211100', '兴隆台区', '辽宁省/盘锦市/兴隆台区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211104', '211100', '210000,211100', '大洼区', '辽宁省/盘锦市/大洼区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211122', '211100', '210000,211100', '盘山县', '辽宁省/盘锦市/盘山县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211200', '210000', '210000', '铁岭市', '辽宁省/铁岭市', 2, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211201', '211200', '210000,211200', '市辖区', '辽宁省/铁岭市/市辖区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211202', '211200', '210000,211200', '银州区', '辽宁省/铁岭市/银州区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211204', '211200', '210000,211200', '清河区', '辽宁省/铁岭市/清河区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211221', '211200', '210000,211200', '铁岭县', '辽宁省/铁岭市/铁岭县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211223', '211200', '210000,211200', '西丰县', '辽宁省/铁岭市/西丰县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211224', '211200', '210000,211200', '昌图县', '辽宁省/铁岭市/昌图县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211281', '211200', '210000,211200', '调兵山市', '辽宁省/铁岭市/调兵山市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211282', '211200', '210000,211200', '开原市', '辽宁省/铁岭市/开原市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211300', '210000', '210000', '朝阳市', '辽宁省/朝阳市', 2, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211301', '211300', '210000,211300', '市辖区', '辽宁省/朝阳市/市辖区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211302', '211300', '210000,211300', '双塔区', '辽宁省/朝阳市/双塔区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211303', '211300', '210000,211300', '龙城区', '辽宁省/朝阳市/龙城区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211321', '211300', '210000,211300', '朝阳县', '辽宁省/朝阳市/朝阳县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211322', '211300', '210000,211300', '建平县', '辽宁省/朝阳市/建平县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211324', '211300', '210000,211300', '喀喇沁左翼蒙古族自治县', '辽宁省/朝阳市/喀喇沁左翼蒙古族自治县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211381', '211300', '210000,211300', '北票市', '辽宁省/朝阳市/北票市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211382', '211300', '210000,211300', '凌源市', '辽宁省/朝阳市/凌源市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211400', '210000', '210000', '葫芦岛市', '辽宁省/葫芦岛市', 2, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211401', '211400', '210000,211400', '市辖区', '辽宁省/葫芦岛市/市辖区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211402', '211400', '210000,211400', '连山区', '辽宁省/葫芦岛市/连山区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211403', '211400', '210000,211400', '龙港区', '辽宁省/葫芦岛市/龙港区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211404', '211400', '210000,211400', '南票区', '辽宁省/葫芦岛市/南票区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211421', '211400', '210000,211400', '绥中县', '辽宁省/葫芦岛市/绥中县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211422', '211400', '210000,211400', '建昌县', '辽宁省/葫芦岛市/建昌县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('211481', '211400', '210000,211400', '兴城市', '辽宁省/葫芦岛市/兴城市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220000', '86', '', '吉林省', '吉林省', 1, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220100', '220000', '220000', '长春市', '吉林省/长春市', 2, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220101', '220100', '220000,220100', '市辖区', '吉林省/长春市/市辖区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220102', '220100', '220000,220100', '南关区', '吉林省/长春市/南关区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220103', '220100', '220000,220100', '宽城区', '吉林省/长春市/宽城区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220104', '220100', '220000,220100', '朝阳区', '吉林省/长春市/朝阳区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220105', '220100', '220000,220100', '二道区', '吉林省/长春市/二道区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220106', '220100', '220000,220100', '绿园区', '吉林省/长春市/绿园区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220112', '220100', '220000,220100', '双阳区', '吉林省/长春市/双阳区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220113', '220100', '220000,220100', '九台区', '吉林省/长春市/九台区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220122', '220100', '220000,220100', '农安县', '吉林省/长春市/农安县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220171', '220100', '220000,220100', '长春经济技术开发区', '吉林省/长春市/长春经济技术开发区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220172', '220100', '220000,220100', '长春净月高新技术产业开发区', '吉林省/长春市/长春净月高新技术产业开发区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220173', '220100', '220000,220100', '长春高新技术产业开发区', '吉林省/长春市/长春高新技术产业开发区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220174', '220100', '220000,220100', '长春汽车经济技术开发区', '吉林省/长春市/长春汽车经济技术开发区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220182', '220100', '220000,220100', '榆树市', '吉林省/长春市/榆树市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220183', '220100', '220000,220100', '德惠市', '吉林省/长春市/德惠市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220200', '220000', '220000', '吉林市', '吉林省/吉林市', 2, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220201', '220200', '220000,220200', '市辖区', '吉林省/吉林市/市辖区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220202', '220200', '220000,220200', '昌邑区', '吉林省/吉林市/昌邑区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220203', '220200', '220000,220200', '龙潭区', '吉林省/吉林市/龙潭区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220204', '220200', '220000,220200', '船营区', '吉林省/吉林市/船营区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220211', '220200', '220000,220200', '丰满区', '吉林省/吉林市/丰满区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220221', '220200', '220000,220200', '永吉县', '吉林省/吉林市/永吉县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220271', '220200', '220000,220200', '吉林经济开发区', '吉林省/吉林市/吉林经济开发区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220272', '220200', '220000,220200', '吉林高新技术产业开发区', '吉林省/吉林市/吉林高新技术产业开发区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220273', '220200', '220000,220200', '吉林中国新加坡食品区', '吉林省/吉林市/吉林中国新加坡食品区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220281', '220200', '220000,220200', '蛟河市', '吉林省/吉林市/蛟河市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220282', '220200', '220000,220200', '桦甸市', '吉林省/吉林市/桦甸市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220283', '220200', '220000,220200', '舒兰市', '吉林省/吉林市/舒兰市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220284', '220200', '220000,220200', '磐石市', '吉林省/吉林市/磐石市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220300', '220000', '220000', '四平市', '吉林省/四平市', 2, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220301', '220300', '220000,220300', '市辖区', '吉林省/四平市/市辖区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220302', '220300', '220000,220300', '铁西区', '吉林省/四平市/铁西区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220303', '220300', '220000,220300', '铁东区', '吉林省/四平市/铁东区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220322', '220300', '220000,220300', '梨树县', '吉林省/四平市/梨树县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220323', '220300', '220000,220300', '伊通满族自治县', '吉林省/四平市/伊通满族自治县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220381', '220300', '220000,220300', '公主岭市', '吉林省/四平市/公主岭市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220382', '220300', '220000,220300', '双辽市', '吉林省/四平市/双辽市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220400', '220000', '220000', '辽源市', '吉林省/辽源市', 2, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220401', '220400', '220000,220400', '市辖区', '吉林省/辽源市/市辖区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220402', '220400', '220000,220400', '龙山区', '吉林省/辽源市/龙山区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220403', '220400', '220000,220400', '西安区', '吉林省/辽源市/西安区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220421', '220400', '220000,220400', '东丰县', '吉林省/辽源市/东丰县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220422', '220400', '220000,220400', '东辽县', '吉林省/辽源市/东辽县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220500', '220000', '220000', '通化市', '吉林省/通化市', 2, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220501', '220500', '220000,220500', '市辖区', '吉林省/通化市/市辖区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220502', '220500', '220000,220500', '东昌区', '吉林省/通化市/东昌区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220503', '220500', '220000,220500', '二道江区', '吉林省/通化市/二道江区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220521', '220500', '220000,220500', '通化县', '吉林省/通化市/通化县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220523', '220500', '220000,220500', '辉南县', '吉林省/通化市/辉南县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220524', '220500', '220000,220500', '柳河县', '吉林省/通化市/柳河县', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220581', '220500', '220000,220500', '梅河口市', '吉林省/通化市/梅河口市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220582', '220500', '220000,220500', '集安市', '吉林省/通化市/集安市', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220600', '220000', '220000', '白山市', '吉林省/白山市', 2, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220601', '220600', '220000,220600', '市辖区', '吉林省/白山市/市辖区', 3, 'admin', '2022-05-22 20:35:13', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220602', '220600', '220000,220600', '浑江区', '吉林省/白山市/浑江区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220605', '220600', '220000,220600', '江源区', '吉林省/白山市/江源区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220621', '220600', '220000,220600', '抚松县', '吉林省/白山市/抚松县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220622', '220600', '220000,220600', '靖宇县', '吉林省/白山市/靖宇县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220623', '220600', '220000,220600', '长白朝鲜族自治县', '吉林省/白山市/长白朝鲜族自治县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220681', '220600', '220000,220600', '临江市', '吉林省/白山市/临江市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220700', '220000', '220000', '松原市', '吉林省/松原市', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220701', '220700', '220000,220700', '市辖区', '吉林省/松原市/市辖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220702', '220700', '220000,220700', '宁江区', '吉林省/松原市/宁江区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220721', '220700', '220000,220700', '前郭尔罗斯蒙古族自治县', '吉林省/松原市/前郭尔罗斯蒙古族自治县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220722', '220700', '220000,220700', '长岭县', '吉林省/松原市/长岭县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220723', '220700', '220000,220700', '乾安县', '吉林省/松原市/乾安县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220771', '220700', '220000,220700', '吉林松原经济开发区', '吉林省/松原市/吉林松原经济开发区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220781', '220700', '220000,220700', '扶余市', '吉林省/松原市/扶余市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220800', '220000', '220000', '白城市', '吉林省/白城市', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220801', '220800', '220000,220800', '市辖区', '吉林省/白城市/市辖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220802', '220800', '220000,220800', '洮北区', '吉林省/白城市/洮北区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220821', '220800', '220000,220800', '镇赉县', '吉林省/白城市/镇赉县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220822', '220800', '220000,220800', '通榆县', '吉林省/白城市/通榆县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220871', '220800', '220000,220800', '吉林白城经济开发区', '吉林省/白城市/吉林白城经济开发区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220881', '220800', '220000,220800', '洮南市', '吉林省/白城市/洮南市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('220882', '220800', '220000,220800', '大安市', '吉林省/白城市/大安市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('222400', '220000', '220000', '延边朝鲜族自治州', '吉林省/延边朝鲜族自治州', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('222401', '222400', '220000,222400', '延吉市', '吉林省/延边朝鲜族自治州/延吉市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('222402', '222400', '220000,222400', '图们市', '吉林省/延边朝鲜族自治州/图们市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('222403', '222400', '220000,222400', '敦化市', '吉林省/延边朝鲜族自治州/敦化市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('222404', '222400', '220000,222400', '珲春市', '吉林省/延边朝鲜族自治州/珲春市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('222405', '222400', '220000,222400', '龙井市', '吉林省/延边朝鲜族自治州/龙井市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('222406', '222400', '220000,222400', '和龙市', '吉林省/延边朝鲜族自治州/和龙市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('222424', '222400', '220000,222400', '汪清县', '吉林省/延边朝鲜族自治州/汪清县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('222426', '222400', '220000,222400', '安图县', '吉林省/延边朝鲜族自治州/安图县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230000', '86', '', '黑龙江省', '黑龙江省', 1, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230100', '230000', '230000', '哈尔滨市', '黑龙江省/哈尔滨市', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230101', '230100', '230000,230100', '市辖区', '黑龙江省/哈尔滨市/市辖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230102', '230100', '230000,230100', '道里区', '黑龙江省/哈尔滨市/道里区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230103', '230100', '230000,230100', '南岗区', '黑龙江省/哈尔滨市/南岗区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230104', '230100', '230000,230100', '道外区', '黑龙江省/哈尔滨市/道外区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230108', '230100', '230000,230100', '平房区', '黑龙江省/哈尔滨市/平房区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230109', '230100', '230000,230100', '松北区', '黑龙江省/哈尔滨市/松北区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230110', '230100', '230000,230100', '香坊区', '黑龙江省/哈尔滨市/香坊区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230111', '230100', '230000,230100', '呼兰区', '黑龙江省/哈尔滨市/呼兰区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230112', '230100', '230000,230100', '阿城区', '黑龙江省/哈尔滨市/阿城区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230113', '230100', '230000,230100', '双城区', '黑龙江省/哈尔滨市/双城区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230123', '230100', '230000,230100', '依兰县', '黑龙江省/哈尔滨市/依兰县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230124', '230100', '230000,230100', '方正县', '黑龙江省/哈尔滨市/方正县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230125', '230100', '230000,230100', '宾县', '黑龙江省/哈尔滨市/宾县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230126', '230100', '230000,230100', '巴彦县', '黑龙江省/哈尔滨市/巴彦县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230127', '230100', '230000,230100', '木兰县', '黑龙江省/哈尔滨市/木兰县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230128', '230100', '230000,230100', '通河县', '黑龙江省/哈尔滨市/通河县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230129', '230100', '230000,230100', '延寿县', '黑龙江省/哈尔滨市/延寿县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230183', '230100', '230000,230100', '尚志市', '黑龙江省/哈尔滨市/尚志市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230184', '230100', '230000,230100', '五常市', '黑龙江省/哈尔滨市/五常市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230200', '230000', '230000', '齐齐哈尔市', '黑龙江省/齐齐哈尔市', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230201', '230200', '230000,230200', '市辖区', '黑龙江省/齐齐哈尔市/市辖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230202', '230200', '230000,230200', '龙沙区', '黑龙江省/齐齐哈尔市/龙沙区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230203', '230200', '230000,230200', '建华区', '黑龙江省/齐齐哈尔市/建华区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230204', '230200', '230000,230200', '铁锋区', '黑龙江省/齐齐哈尔市/铁锋区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230205', '230200', '230000,230200', '昂昂溪区', '黑龙江省/齐齐哈尔市/昂昂溪区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230206', '230200', '230000,230200', '富拉尔基区', '黑龙江省/齐齐哈尔市/富拉尔基区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230207', '230200', '230000,230200', '碾子山区', '黑龙江省/齐齐哈尔市/碾子山区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230208', '230200', '230000,230200', '梅里斯达斡尔族区', '黑龙江省/齐齐哈尔市/梅里斯达斡尔族区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230221', '230200', '230000,230200', '龙江县', '黑龙江省/齐齐哈尔市/龙江县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230223', '230200', '230000,230200', '依安县', '黑龙江省/齐齐哈尔市/依安县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230224', '230200', '230000,230200', '泰来县', '黑龙江省/齐齐哈尔市/泰来县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230225', '230200', '230000,230200', '甘南县', '黑龙江省/齐齐哈尔市/甘南县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230227', '230200', '230000,230200', '富裕县', '黑龙江省/齐齐哈尔市/富裕县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230229', '230200', '230000,230200', '克山县', '黑龙江省/齐齐哈尔市/克山县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230230', '230200', '230000,230200', '克东县', '黑龙江省/齐齐哈尔市/克东县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230231', '230200', '230000,230200', '拜泉县', '黑龙江省/齐齐哈尔市/拜泉县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230281', '230200', '230000,230200', '讷河市', '黑龙江省/齐齐哈尔市/讷河市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230300', '230000', '230000', '鸡西市', '黑龙江省/鸡西市', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230301', '230300', '230000,230300', '市辖区', '黑龙江省/鸡西市/市辖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230302', '230300', '230000,230300', '鸡冠区', '黑龙江省/鸡西市/鸡冠区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230303', '230300', '230000,230300', '恒山区', '黑龙江省/鸡西市/恒山区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230304', '230300', '230000,230300', '滴道区', '黑龙江省/鸡西市/滴道区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230305', '230300', '230000,230300', '梨树区', '黑龙江省/鸡西市/梨树区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230306', '230300', '230000,230300', '城子河区', '黑龙江省/鸡西市/城子河区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230307', '230300', '230000,230300', '麻山区', '黑龙江省/鸡西市/麻山区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230321', '230300', '230000,230300', '鸡东县', '黑龙江省/鸡西市/鸡东县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230381', '230300', '230000,230300', '虎林市', '黑龙江省/鸡西市/虎林市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230382', '230300', '230000,230300', '密山市', '黑龙江省/鸡西市/密山市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230400', '230000', '230000', '鹤岗市', '黑龙江省/鹤岗市', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230401', '230400', '230000,230400', '市辖区', '黑龙江省/鹤岗市/市辖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230402', '230400', '230000,230400', '向阳区', '黑龙江省/鹤岗市/向阳区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230403', '230400', '230000,230400', '工农区', '黑龙江省/鹤岗市/工农区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230404', '230400', '230000,230400', '南山区', '黑龙江省/鹤岗市/南山区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230405', '230400', '230000,230400', '兴安区', '黑龙江省/鹤岗市/兴安区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230406', '230400', '230000,230400', '东山区', '黑龙江省/鹤岗市/东山区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230407', '230400', '230000,230400', '兴山区', '黑龙江省/鹤岗市/兴山区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230421', '230400', '230000,230400', '萝北县', '黑龙江省/鹤岗市/萝北县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230422', '230400', '230000,230400', '绥滨县', '黑龙江省/鹤岗市/绥滨县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230500', '230000', '230000', '双鸭山市', '黑龙江省/双鸭山市', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230501', '230500', '230000,230500', '市辖区', '黑龙江省/双鸭山市/市辖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230502', '230500', '230000,230500', '尖山区', '黑龙江省/双鸭山市/尖山区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230503', '230500', '230000,230500', '岭东区', '黑龙江省/双鸭山市/岭东区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230505', '230500', '230000,230500', '四方台区', '黑龙江省/双鸭山市/四方台区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230506', '230500', '230000,230500', '宝山区', '黑龙江省/双鸭山市/宝山区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230521', '230500', '230000,230500', '集贤县', '黑龙江省/双鸭山市/集贤县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230522', '230500', '230000,230500', '友谊县', '黑龙江省/双鸭山市/友谊县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230523', '230500', '230000,230500', '宝清县', '黑龙江省/双鸭山市/宝清县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230524', '230500', '230000,230500', '饶河县', '黑龙江省/双鸭山市/饶河县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230600', '230000', '230000', '大庆市', '黑龙江省/大庆市', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230601', '230600', '230000,230600', '市辖区', '黑龙江省/大庆市/市辖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230602', '230600', '230000,230600', '萨尔图区', '黑龙江省/大庆市/萨尔图区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230603', '230600', '230000,230600', '龙凤区', '黑龙江省/大庆市/龙凤区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230604', '230600', '230000,230600', '让胡路区', '黑龙江省/大庆市/让胡路区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230605', '230600', '230000,230600', '红岗区', '黑龙江省/大庆市/红岗区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230606', '230600', '230000,230600', '大同区', '黑龙江省/大庆市/大同区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230621', '230600', '230000,230600', '肇州县', '黑龙江省/大庆市/肇州县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230622', '230600', '230000,230600', '肇源县', '黑龙江省/大庆市/肇源县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230623', '230600', '230000,230600', '林甸县', '黑龙江省/大庆市/林甸县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230624', '230600', '230000,230600', '杜尔伯特蒙古族自治县', '黑龙江省/大庆市/杜尔伯特蒙古族自治县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230671', '230600', '230000,230600', '大庆高新技术产业开发区', '黑龙江省/大庆市/大庆高新技术产业开发区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230700', '230000', '230000', '伊春市', '黑龙江省/伊春市', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230701', '230700', '230000,230700', '市辖区', '黑龙江省/伊春市/市辖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230717', '230700', '230000,230700', '伊美区', '黑龙江省/伊春市/伊美区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230718', '230700', '230000,230700', '乌翠区', '黑龙江省/伊春市/乌翠区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230719', '230700', '230000,230700', '友好区', '黑龙江省/伊春市/友好区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230722', '230700', '230000,230700', '嘉荫县', '黑龙江省/伊春市/嘉荫县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230723', '230700', '230000,230700', '汤旺县', '黑龙江省/伊春市/汤旺县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230724', '230700', '230000,230700', '丰林县', '黑龙江省/伊春市/丰林县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230725', '230700', '230000,230700', '大箐山县', '黑龙江省/伊春市/大箐山县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230726', '230700', '230000,230700', '南岔县', '黑龙江省/伊春市/南岔县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230751', '230700', '230000,230700', '金林区', '黑龙江省/伊春市/金林区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230781', '230700', '230000,230700', '铁力市', '黑龙江省/伊春市/铁力市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230800', '230000', '230000', '佳木斯市', '黑龙江省/佳木斯市', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230801', '230800', '230000,230800', '市辖区', '黑龙江省/佳木斯市/市辖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230803', '230800', '230000,230800', '向阳区', '黑龙江省/佳木斯市/向阳区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230804', '230800', '230000,230800', '前进区', '黑龙江省/佳木斯市/前进区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230805', '230800', '230000,230800', '东风区', '黑龙江省/佳木斯市/东风区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230811', '230800', '230000,230800', '郊区', '黑龙江省/佳木斯市/郊区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230822', '230800', '230000,230800', '桦南县', '黑龙江省/佳木斯市/桦南县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230826', '230800', '230000,230800', '桦川县', '黑龙江省/佳木斯市/桦川县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230828', '230800', '230000,230800', '汤原县', '黑龙江省/佳木斯市/汤原县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230881', '230800', '230000,230800', '同江市', '黑龙江省/佳木斯市/同江市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230882', '230800', '230000,230800', '富锦市', '黑龙江省/佳木斯市/富锦市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230883', '230800', '230000,230800', '抚远市', '黑龙江省/佳木斯市/抚远市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230900', '230000', '230000', '七台河市', '黑龙江省/七台河市', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230901', '230900', '230000,230900', '市辖区', '黑龙江省/七台河市/市辖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230902', '230900', '230000,230900', '新兴区', '黑龙江省/七台河市/新兴区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230903', '230900', '230000,230900', '桃山区', '黑龙江省/七台河市/桃山区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230904', '230900', '230000,230900', '茄子河区', '黑龙江省/七台河市/茄子河区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('230921', '230900', '230000,230900', '勃利县', '黑龙江省/七台河市/勃利县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231000', '230000', '230000', '牡丹江市', '黑龙江省/牡丹江市', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231001', '231000', '230000,231000', '市辖区', '黑龙江省/牡丹江市/市辖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231002', '231000', '230000,231000', '东安区', '黑龙江省/牡丹江市/东安区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231003', '231000', '230000,231000', '阳明区', '黑龙江省/牡丹江市/阳明区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231004', '231000', '230000,231000', '爱民区', '黑龙江省/牡丹江市/爱民区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231005', '231000', '230000,231000', '西安区', '黑龙江省/牡丹江市/西安区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231025', '231000', '230000,231000', '林口县', '黑龙江省/牡丹江市/林口县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231071', '231000', '230000,231000', '牡丹江经济技术开发区', '黑龙江省/牡丹江市/牡丹江经济技术开发区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231081', '231000', '230000,231000', '绥芬河市', '黑龙江省/牡丹江市/绥芬河市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231083', '231000', '230000,231000', '海林市', '黑龙江省/牡丹江市/海林市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231084', '231000', '230000,231000', '宁安市', '黑龙江省/牡丹江市/宁安市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231085', '231000', '230000,231000', '穆棱市', '黑龙江省/牡丹江市/穆棱市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231086', '231000', '230000,231000', '东宁市', '黑龙江省/牡丹江市/东宁市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231100', '230000', '230000', '黑河市', '黑龙江省/黑河市', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231101', '231100', '230000,231100', '市辖区', '黑龙江省/黑河市/市辖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231102', '231100', '230000,231100', '爱辉区', '黑龙江省/黑河市/爱辉区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231123', '231100', '230000,231100', '逊克县', '黑龙江省/黑河市/逊克县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231124', '231100', '230000,231100', '孙吴县', '黑龙江省/黑河市/孙吴县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231181', '231100', '230000,231100', '北安市', '黑龙江省/黑河市/北安市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231182', '231100', '230000,231100', '五大连池市', '黑龙江省/黑河市/五大连池市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231183', '231100', '230000,231100', '嫩江市', '黑龙江省/黑河市/嫩江市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231200', '230000', '230000', '绥化市', '黑龙江省/绥化市', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231201', '231200', '230000,231200', '市辖区', '黑龙江省/绥化市/市辖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231202', '231200', '230000,231200', '北林区', '黑龙江省/绥化市/北林区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231221', '231200', '230000,231200', '望奎县', '黑龙江省/绥化市/望奎县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231222', '231200', '230000,231200', '兰西县', '黑龙江省/绥化市/兰西县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231223', '231200', '230000,231200', '青冈县', '黑龙江省/绥化市/青冈县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231224', '231200', '230000,231200', '庆安县', '黑龙江省/绥化市/庆安县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231225', '231200', '230000,231200', '明水县', '黑龙江省/绥化市/明水县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231226', '231200', '230000,231200', '绥棱县', '黑龙江省/绥化市/绥棱县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231281', '231200', '230000,231200', '安达市', '黑龙江省/绥化市/安达市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231282', '231200', '230000,231200', '肇东市', '黑龙江省/绥化市/肇东市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('231283', '231200', '230000,231200', '海伦市', '黑龙江省/绥化市/海伦市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('232700', '230000', '230000', '大兴安岭地区', '黑龙江省/大兴安岭地区', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('232701', '232700', '230000,232700', '漠河市', '黑龙江省/大兴安岭地区/漠河市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('232721', '232700', '230000,232700', '呼玛县', '黑龙江省/大兴安岭地区/呼玛县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('232722', '232700', '230000,232700', '塔河县', '黑龙江省/大兴安岭地区/塔河县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('232761', '232700', '230000,232700', '加格达奇区', '黑龙江省/大兴安岭地区/加格达奇区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('232762', '232700', '230000,232700', '松岭区', '黑龙江省/大兴安岭地区/松岭区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('232763', '232700', '230000,232700', '新林区', '黑龙江省/大兴安岭地区/新林区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('232764', '232700', '230000,232700', '呼中区', '黑龙江省/大兴安岭地区/呼中区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('310000', '86', '', '上海市', '上海市', 1, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('310100', '310000', '310000', '市辖区', '上海市/市辖区', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('310101', '310100', '310000,310100', '黄浦区', '上海市/市辖区/黄浦区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('310104', '310100', '310000,310100', '徐汇区', '上海市/市辖区/徐汇区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('310105', '310100', '310000,310100', '长宁区', '上海市/市辖区/长宁区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('310106', '310100', '310000,310100', '静安区', '上海市/市辖区/静安区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('310107', '310100', '310000,310100', '普陀区', '上海市/市辖区/普陀区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('310109', '310100', '310000,310100', '虹口区', '上海市/市辖区/虹口区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('310110', '310100', '310000,310100', '杨浦区', '上海市/市辖区/杨浦区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('310112', '310100', '310000,310100', '闵行区', '上海市/市辖区/闵行区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('310113', '310100', '310000,310100', '宝山区', '上海市/市辖区/宝山区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('310114', '310100', '310000,310100', '嘉定区', '上海市/市辖区/嘉定区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('310115', '310100', '310000,310100', '浦东新区', '上海市/市辖区/浦东新区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('310116', '310100', '310000,310100', '金山区', '上海市/市辖区/金山区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('310117', '310100', '310000,310100', '松江区', '上海市/市辖区/松江区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('310118', '310100', '310000,310100', '青浦区', '上海市/市辖区/青浦区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('310120', '310100', '310000,310100', '奉贤区', '上海市/市辖区/奉贤区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('310151', '310100', '310000,310100', '崇明区', '上海市/市辖区/崇明区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320000', '86', '', '江苏省', '江苏省', 1, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320100', '320000', '320000', '南京市', '江苏省/南京市', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320101', '320100', '320000,320100', '市辖区', '江苏省/南京市/市辖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320102', '320100', '320000,320100', '玄武区', '江苏省/南京市/玄武区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320104', '320100', '320000,320100', '秦淮区', '江苏省/南京市/秦淮区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320105', '320100', '320000,320100', '建邺区', '江苏省/南京市/建邺区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320106', '320100', '320000,320100', '鼓楼区', '江苏省/南京市/鼓楼区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320111', '320100', '320000,320100', '浦口区', '江苏省/南京市/浦口区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320113', '320100', '320000,320100', '栖霞区', '江苏省/南京市/栖霞区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320114', '320100', '320000,320100', '雨花台区', '江苏省/南京市/雨花台区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320115', '320100', '320000,320100', '江宁区', '江苏省/南京市/江宁区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320116', '320100', '320000,320100', '六合区', '江苏省/南京市/六合区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320117', '320100', '320000,320100', '溧水区', '江苏省/南京市/溧水区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320118', '320100', '320000,320100', '高淳区', '江苏省/南京市/高淳区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320200', '320000', '320000', '无锡市', '江苏省/无锡市', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320201', '320200', '320000,320200', '市辖区', '江苏省/无锡市/市辖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320205', '320200', '320000,320200', '锡山区', '江苏省/无锡市/锡山区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320206', '320200', '320000,320200', '惠山区', '江苏省/无锡市/惠山区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320211', '320200', '320000,320200', '滨湖区', '江苏省/无锡市/滨湖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320213', '320200', '320000,320200', '梁溪区', '江苏省/无锡市/梁溪区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320214', '320200', '320000,320200', '新吴区', '江苏省/无锡市/新吴区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320281', '320200', '320000,320200', '江阴市', '江苏省/无锡市/江阴市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320282', '320200', '320000,320200', '宜兴市', '江苏省/无锡市/宜兴市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320300', '320000', '320000', '徐州市', '江苏省/徐州市', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320301', '320300', '320000,320300', '市辖区', '江苏省/徐州市/市辖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320302', '320300', '320000,320300', '鼓楼区', '江苏省/徐州市/鼓楼区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320303', '320300', '320000,320300', '云龙区', '江苏省/徐州市/云龙区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320305', '320300', '320000,320300', '贾汪区', '江苏省/徐州市/贾汪区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320311', '320300', '320000,320300', '泉山区', '江苏省/徐州市/泉山区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320312', '320300', '320000,320300', '铜山区', '江苏省/徐州市/铜山区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320321', '320300', '320000,320300', '丰县', '江苏省/徐州市/丰县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320322', '320300', '320000,320300', '沛县', '江苏省/徐州市/沛县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320324', '320300', '320000,320300', '睢宁县', '江苏省/徐州市/睢宁县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320371', '320300', '320000,320300', '徐州经济技术开发区', '江苏省/徐州市/徐州经济技术开发区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320381', '320300', '320000,320300', '新沂市', '江苏省/徐州市/新沂市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320382', '320300', '320000,320300', '邳州市', '江苏省/徐州市/邳州市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320400', '320000', '320000', '常州市', '江苏省/常州市', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320401', '320400', '320000,320400', '市辖区', '江苏省/常州市/市辖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320402', '320400', '320000,320400', '天宁区', '江苏省/常州市/天宁区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320404', '320400', '320000,320400', '钟楼区', '江苏省/常州市/钟楼区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320411', '320400', '320000,320400', '新北区', '江苏省/常州市/新北区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320412', '320400', '320000,320400', '武进区', '江苏省/常州市/武进区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320413', '320400', '320000,320400', '金坛区', '江苏省/常州市/金坛区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320481', '320400', '320000,320400', '溧阳市', '江苏省/常州市/溧阳市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320500', '320000', '320000', '苏州市', '江苏省/苏州市', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320501', '320500', '320000,320500', '市辖区', '江苏省/苏州市/市辖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320505', '320500', '320000,320500', '虎丘区', '江苏省/苏州市/虎丘区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320506', '320500', '320000,320500', '吴中区', '江苏省/苏州市/吴中区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320507', '320500', '320000,320500', '相城区', '江苏省/苏州市/相城区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320508', '320500', '320000,320500', '姑苏区', '江苏省/苏州市/姑苏区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320509', '320500', '320000,320500', '吴江区', '江苏省/苏州市/吴江区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320571', '320500', '320000,320500', '苏州工业园区', '江苏省/苏州市/苏州工业园区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320581', '320500', '320000,320500', '常熟市', '江苏省/苏州市/常熟市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320582', '320500', '320000,320500', '张家港市', '江苏省/苏州市/张家港市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320583', '320500', '320000,320500', '昆山市', '江苏省/苏州市/昆山市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320585', '320500', '320000,320500', '太仓市', '江苏省/苏州市/太仓市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320600', '320000', '320000', '南通市', '江苏省/南通市', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320601', '320600', '320000,320600', '市辖区', '江苏省/南通市/市辖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320602', '320600', '320000,320600', '崇川区', '江苏省/南通市/崇川区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320611', '320600', '320000,320600', '港闸区', '江苏省/南通市/港闸区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320612', '320600', '320000,320600', '通州区', '江苏省/南通市/通州区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320623', '320600', '320000,320600', '如东县', '江苏省/南通市/如东县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320671', '320600', '320000,320600', '南通经济技术开发区', '江苏省/南通市/南通经济技术开发区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320681', '320600', '320000,320600', '启东市', '江苏省/南通市/启东市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320682', '320600', '320000,320600', '如皋市', '江苏省/南通市/如皋市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320684', '320600', '320000,320600', '海门市', '江苏省/南通市/海门市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320685', '320600', '320000,320600', '海安市', '江苏省/南通市/海安市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320700', '320000', '320000', '连云港市', '江苏省/连云港市', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320701', '320700', '320000,320700', '市辖区', '江苏省/连云港市/市辖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320703', '320700', '320000,320700', '连云区', '江苏省/连云港市/连云区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320706', '320700', '320000,320700', '海州区', '江苏省/连云港市/海州区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320707', '320700', '320000,320700', '赣榆区', '江苏省/连云港市/赣榆区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320722', '320700', '320000,320700', '东海县', '江苏省/连云港市/东海县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320723', '320700', '320000,320700', '灌云县', '江苏省/连云港市/灌云县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320724', '320700', '320000,320700', '灌南县', '江苏省/连云港市/灌南县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320771', '320700', '320000,320700', '连云港经济技术开发区', '江苏省/连云港市/连云港经济技术开发区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320772', '320700', '320000,320700', '连云港高新技术产业开发区', '江苏省/连云港市/连云港高新技术产业开发区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320800', '320000', '320000', '淮安市', '江苏省/淮安市', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320801', '320800', '320000,320800', '市辖区', '江苏省/淮安市/市辖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320803', '320800', '320000,320800', '淮安区', '江苏省/淮安市/淮安区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320804', '320800', '320000,320800', '淮阴区', '江苏省/淮安市/淮阴区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320812', '320800', '320000,320800', '清江浦区', '江苏省/淮安市/清江浦区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320813', '320800', '320000,320800', '洪泽区', '江苏省/淮安市/洪泽区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320826', '320800', '320000,320800', '涟水县', '江苏省/淮安市/涟水县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320830', '320800', '320000,320800', '盱眙县', '江苏省/淮安市/盱眙县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320831', '320800', '320000,320800', '金湖县', '江苏省/淮安市/金湖县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320871', '320800', '320000,320800', '淮安经济技术开发区', '江苏省/淮安市/淮安经济技术开发区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320900', '320000', '320000', '盐城市', '江苏省/盐城市', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320901', '320900', '320000,320900', '市辖区', '江苏省/盐城市/市辖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320902', '320900', '320000,320900', '亭湖区', '江苏省/盐城市/亭湖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320903', '320900', '320000,320900', '盐都区', '江苏省/盐城市/盐都区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320904', '320900', '320000,320900', '大丰区', '江苏省/盐城市/大丰区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320921', '320900', '320000,320900', '响水县', '江苏省/盐城市/响水县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320922', '320900', '320000,320900', '滨海县', '江苏省/盐城市/滨海县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320923', '320900', '320000,320900', '阜宁县', '江苏省/盐城市/阜宁县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320924', '320900', '320000,320900', '射阳县', '江苏省/盐城市/射阳县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320925', '320900', '320000,320900', '建湖县', '江苏省/盐城市/建湖县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320971', '320900', '320000,320900', '盐城经济技术开发区', '江苏省/盐城市/盐城经济技术开发区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('320981', '320900', '320000,320900', '东台市', '江苏省/盐城市/东台市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321000', '320000', '320000', '扬州市', '江苏省/扬州市', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321001', '321000', '320000,321000', '市辖区', '江苏省/扬州市/市辖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321002', '321000', '320000,321000', '广陵区', '江苏省/扬州市/广陵区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321003', '321000', '320000,321000', '邗江区', '江苏省/扬州市/邗江区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321012', '321000', '320000,321000', '江都区', '江苏省/扬州市/江都区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321023', '321000', '320000,321000', '宝应县', '江苏省/扬州市/宝应县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321071', '321000', '320000,321000', '扬州经济技术开发区', '江苏省/扬州市/扬州经济技术开发区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321081', '321000', '320000,321000', '仪征市', '江苏省/扬州市/仪征市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321084', '321000', '320000,321000', '高邮市', '江苏省/扬州市/高邮市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321100', '320000', '320000', '镇江市', '江苏省/镇江市', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321101', '321100', '320000,321100', '市辖区', '江苏省/镇江市/市辖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321102', '321100', '320000,321100', '京口区', '江苏省/镇江市/京口区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321111', '321100', '320000,321100', '润州区', '江苏省/镇江市/润州区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321112', '321100', '320000,321100', '丹徒区', '江苏省/镇江市/丹徒区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321171', '321100', '320000,321100', '镇江新区', '江苏省/镇江市/镇江新区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321181', '321100', '320000,321100', '丹阳市', '江苏省/镇江市/丹阳市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321182', '321100', '320000,321100', '扬中市', '江苏省/镇江市/扬中市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321183', '321100', '320000,321100', '句容市', '江苏省/镇江市/句容市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321200', '320000', '320000', '泰州市', '江苏省/泰州市', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321201', '321200', '320000,321200', '市辖区', '江苏省/泰州市/市辖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321202', '321200', '320000,321200', '海陵区', '江苏省/泰州市/海陵区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321203', '321200', '320000,321200', '高港区', '江苏省/泰州市/高港区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321204', '321200', '320000,321200', '姜堰区', '江苏省/泰州市/姜堰区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321271', '321200', '320000,321200', '泰州医药高新技术产业开发区', '江苏省/泰州市/泰州医药高新技术产业开发区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321281', '321200', '320000,321200', '兴化市', '江苏省/泰州市/兴化市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321282', '321200', '320000,321200', '靖江市', '江苏省/泰州市/靖江市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321283', '321200', '320000,321200', '泰兴市', '江苏省/泰州市/泰兴市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321300', '320000', '320000', '宿迁市', '江苏省/宿迁市', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321301', '321300', '320000,321300', '市辖区', '江苏省/宿迁市/市辖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321302', '321300', '320000,321300', '宿城区', '江苏省/宿迁市/宿城区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321311', '321300', '320000,321300', '宿豫区', '江苏省/宿迁市/宿豫区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321322', '321300', '320000,321300', '沭阳县', '江苏省/宿迁市/沭阳县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321323', '321300', '320000,321300', '泗阳县', '江苏省/宿迁市/泗阳县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321324', '321300', '320000,321300', '泗洪县', '江苏省/宿迁市/泗洪县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('321371', '321300', '320000,321300', '宿迁经济技术开发区', '江苏省/宿迁市/宿迁经济技术开发区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330000', '86', '', '浙江省', '浙江省', 1, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330100', '330000', '330000', '杭州市', '浙江省/杭州市', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330101', '330100', '330000,330100', '市辖区', '浙江省/杭州市/市辖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330102', '330100', '330000,330100', '上城区', '浙江省/杭州市/上城区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330103', '330100', '330000,330100', '下城区', '浙江省/杭州市/下城区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330104', '330100', '330000,330100', '江干区', '浙江省/杭州市/江干区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330105', '330100', '330000,330100', '拱墅区', '浙江省/杭州市/拱墅区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330106', '330100', '330000,330100', '西湖区', '浙江省/杭州市/西湖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330108', '330100', '330000,330100', '滨江区', '浙江省/杭州市/滨江区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330109', '330100', '330000,330100', '萧山区', '浙江省/杭州市/萧山区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330110', '330100', '330000,330100', '余杭区', '浙江省/杭州市/余杭区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330111', '330100', '330000,330100', '富阳区', '浙江省/杭州市/富阳区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330112', '330100', '330000,330100', '临安区', '浙江省/杭州市/临安区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330122', '330100', '330000,330100', '桐庐县', '浙江省/杭州市/桐庐县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330127', '330100', '330000,330100', '淳安县', '浙江省/杭州市/淳安县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330182', '330100', '330000,330100', '建德市', '浙江省/杭州市/建德市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330200', '330000', '330000', '宁波市', '浙江省/宁波市', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330201', '330200', '330000,330200', '市辖区', '浙江省/宁波市/市辖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330203', '330200', '330000,330200', '海曙区', '浙江省/宁波市/海曙区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330205', '330200', '330000,330200', '江北区', '浙江省/宁波市/江北区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330206', '330200', '330000,330200', '北仑区', '浙江省/宁波市/北仑区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330211', '330200', '330000,330200', '镇海区', '浙江省/宁波市/镇海区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330212', '330200', '330000,330200', '鄞州区', '浙江省/宁波市/鄞州区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330213', '330200', '330000,330200', '奉化区', '浙江省/宁波市/奉化区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330225', '330200', '330000,330200', '象山县', '浙江省/宁波市/象山县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330226', '330200', '330000,330200', '宁海县', '浙江省/宁波市/宁海县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330281', '330200', '330000,330200', '余姚市', '浙江省/宁波市/余姚市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330282', '330200', '330000,330200', '慈溪市', '浙江省/宁波市/慈溪市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330300', '330000', '330000', '温州市', '浙江省/温州市', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330301', '330300', '330000,330300', '市辖区', '浙江省/温州市/市辖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330302', '330300', '330000,330300', '鹿城区', '浙江省/温州市/鹿城区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330303', '330300', '330000,330300', '龙湾区', '浙江省/温州市/龙湾区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330304', '330300', '330000,330300', '瓯海区', '浙江省/温州市/瓯海区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330305', '330300', '330000,330300', '洞头区', '浙江省/温州市/洞头区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330324', '330300', '330000,330300', '永嘉县', '浙江省/温州市/永嘉县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330326', '330300', '330000,330300', '平阳县', '浙江省/温州市/平阳县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330327', '330300', '330000,330300', '苍南县', '浙江省/温州市/苍南县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330328', '330300', '330000,330300', '文成县', '浙江省/温州市/文成县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330329', '330300', '330000,330300', '泰顺县', '浙江省/温州市/泰顺县', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330371', '330300', '330000,330300', '温州经济技术开发区', '浙江省/温州市/温州经济技术开发区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330381', '330300', '330000,330300', '瑞安市', '浙江省/温州市/瑞安市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330382', '330300', '330000,330300', '乐清市', '浙江省/温州市/乐清市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330383', '330300', '330000,330300', '龙港市', '浙江省/温州市/龙港市', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330400', '330000', '330000', '嘉兴市', '浙江省/嘉兴市', 2, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330401', '330400', '330000,330400', '市辖区', '浙江省/嘉兴市/市辖区', 3, 'admin', '2022-05-22 20:35:14', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330402', '330400', '330000,330400', '南湖区', '浙江省/嘉兴市/南湖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330411', '330400', '330000,330400', '秀洲区', '浙江省/嘉兴市/秀洲区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330421', '330400', '330000,330400', '嘉善县', '浙江省/嘉兴市/嘉善县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330424', '330400', '330000,330400', '海盐县', '浙江省/嘉兴市/海盐县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330481', '330400', '330000,330400', '海宁市', '浙江省/嘉兴市/海宁市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330482', '330400', '330000,330400', '平湖市', '浙江省/嘉兴市/平湖市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330483', '330400', '330000,330400', '桐乡市', '浙江省/嘉兴市/桐乡市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330500', '330000', '330000', '湖州市', '浙江省/湖州市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330501', '330500', '330000,330500', '市辖区', '浙江省/湖州市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330502', '330500', '330000,330500', '吴兴区', '浙江省/湖州市/吴兴区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330503', '330500', '330000,330500', '南浔区', '浙江省/湖州市/南浔区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330521', '330500', '330000,330500', '德清县', '浙江省/湖州市/德清县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330522', '330500', '330000,330500', '长兴县', '浙江省/湖州市/长兴县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330523', '330500', '330000,330500', '安吉县', '浙江省/湖州市/安吉县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330600', '330000', '330000', '绍兴市', '浙江省/绍兴市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330601', '330600', '330000,330600', '市辖区', '浙江省/绍兴市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330602', '330600', '330000,330600', '越城区', '浙江省/绍兴市/越城区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330603', '330600', '330000,330600', '柯桥区', '浙江省/绍兴市/柯桥区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330604', '330600', '330000,330600', '上虞区', '浙江省/绍兴市/上虞区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330624', '330600', '330000,330600', '新昌县', '浙江省/绍兴市/新昌县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330681', '330600', '330000,330600', '诸暨市', '浙江省/绍兴市/诸暨市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330683', '330600', '330000,330600', '嵊州市', '浙江省/绍兴市/嵊州市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330700', '330000', '330000', '金华市', '浙江省/金华市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330701', '330700', '330000,330700', '市辖区', '浙江省/金华市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330702', '330700', '330000,330700', '婺城区', '浙江省/金华市/婺城区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330703', '330700', '330000,330700', '金东区', '浙江省/金华市/金东区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330723', '330700', '330000,330700', '武义县', '浙江省/金华市/武义县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330726', '330700', '330000,330700', '浦江县', '浙江省/金华市/浦江县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330727', '330700', '330000,330700', '磐安县', '浙江省/金华市/磐安县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330781', '330700', '330000,330700', '兰溪市', '浙江省/金华市/兰溪市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330782', '330700', '330000,330700', '义乌市', '浙江省/金华市/义乌市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330783', '330700', '330000,330700', '东阳市', '浙江省/金华市/东阳市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330784', '330700', '330000,330700', '永康市', '浙江省/金华市/永康市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330800', '330000', '330000', '衢州市', '浙江省/衢州市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330801', '330800', '330000,330800', '市辖区', '浙江省/衢州市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330802', '330800', '330000,330800', '柯城区', '浙江省/衢州市/柯城区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330803', '330800', '330000,330800', '衢江区', '浙江省/衢州市/衢江区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330822', '330800', '330000,330800', '常山县', '浙江省/衢州市/常山县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330824', '330800', '330000,330800', '开化县', '浙江省/衢州市/开化县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330825', '330800', '330000,330800', '龙游县', '浙江省/衢州市/龙游县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330881', '330800', '330000,330800', '江山市', '浙江省/衢州市/江山市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330900', '330000', '330000', '舟山市', '浙江省/舟山市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330901', '330900', '330000,330900', '市辖区', '浙江省/舟山市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330902', '330900', '330000,330900', '定海区', '浙江省/舟山市/定海区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330903', '330900', '330000,330900', '普陀区', '浙江省/舟山市/普陀区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330921', '330900', '330000,330900', '岱山县', '浙江省/舟山市/岱山县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('330922', '330900', '330000,330900', '嵊泗县', '浙江省/舟山市/嵊泗县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('331000', '330000', '330000', '台州市', '浙江省/台州市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('331001', '331000', '330000,331000', '市辖区', '浙江省/台州市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('331002', '331000', '330000,331000', '椒江区', '浙江省/台州市/椒江区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('331003', '331000', '330000,331000', '黄岩区', '浙江省/台州市/黄岩区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('331004', '331000', '330000,331000', '路桥区', '浙江省/台州市/路桥区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('331022', '331000', '330000,331000', '三门县', '浙江省/台州市/三门县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('331023', '331000', '330000,331000', '天台县', '浙江省/台州市/天台县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('331024', '331000', '330000,331000', '仙居县', '浙江省/台州市/仙居县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('331081', '331000', '330000,331000', '温岭市', '浙江省/台州市/温岭市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('331082', '331000', '330000,331000', '临海市', '浙江省/台州市/临海市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('331083', '331000', '330000,331000', '玉环市', '浙江省/台州市/玉环市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('331100', '330000', '330000', '丽水市', '浙江省/丽水市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('331101', '331100', '330000,331100', '市辖区', '浙江省/丽水市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('331102', '331100', '330000,331100', '莲都区', '浙江省/丽水市/莲都区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('331121', '331100', '330000,331100', '青田县', '浙江省/丽水市/青田县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('331122', '331100', '330000,331100', '缙云县', '浙江省/丽水市/缙云县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('331123', '331100', '330000,331100', '遂昌县', '浙江省/丽水市/遂昌县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('331124', '331100', '330000,331100', '松阳县', '浙江省/丽水市/松阳县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('331125', '331100', '330000,331100', '云和县', '浙江省/丽水市/云和县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('331126', '331100', '330000,331100', '庆元县', '浙江省/丽水市/庆元县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('331127', '331100', '330000,331100', '景宁畲族自治县', '浙江省/丽水市/景宁畲族自治县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('331181', '331100', '330000,331100', '龙泉市', '浙江省/丽水市/龙泉市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340000', '86', '', '安徽省', '安徽省', 1, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340100', '340000', '340000', '合肥市', '安徽省/合肥市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340101', '340100', '340000,340100', '市辖区', '安徽省/合肥市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340102', '340100', '340000,340100', '瑶海区', '安徽省/合肥市/瑶海区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340103', '340100', '340000,340100', '庐阳区', '安徽省/合肥市/庐阳区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340104', '340100', '340000,340100', '蜀山区', '安徽省/合肥市/蜀山区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340111', '340100', '340000,340100', '包河区', '安徽省/合肥市/包河区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340121', '340100', '340000,340100', '长丰县', '安徽省/合肥市/长丰县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340122', '340100', '340000,340100', '肥东县', '安徽省/合肥市/肥东县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340123', '340100', '340000,340100', '肥西县', '安徽省/合肥市/肥西县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340124', '340100', '340000,340100', '庐江县', '安徽省/合肥市/庐江县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340171', '340100', '340000,340100', '合肥高新技术产业开发区', '安徽省/合肥市/合肥高新技术产业开发区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340172', '340100', '340000,340100', '合肥经济技术开发区', '安徽省/合肥市/合肥经济技术开发区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340173', '340100', '340000,340100', '合肥新站高新技术产业开发区', '安徽省/合肥市/合肥新站高新技术产业开发区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340181', '340100', '340000,340100', '巢湖市', '安徽省/合肥市/巢湖市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340200', '340000', '340000', '芜湖市', '安徽省/芜湖市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340201', '340200', '340000,340200', '市辖区', '安徽省/芜湖市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340202', '340200', '340000,340200', '镜湖区', '安徽省/芜湖市/镜湖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340203', '340200', '340000,340200', '弋江区', '安徽省/芜湖市/弋江区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340207', '340200', '340000,340200', '鸠江区', '安徽省/芜湖市/鸠江区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340208', '340200', '340000,340200', '三山区', '安徽省/芜湖市/三山区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340221', '340200', '340000,340200', '芜湖县', '安徽省/芜湖市/芜湖县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340222', '340200', '340000,340200', '繁昌县', '安徽省/芜湖市/繁昌县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340223', '340200', '340000,340200', '南陵县', '安徽省/芜湖市/南陵县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340225', '340200', '340000,340200', '无为县', '安徽省/芜湖市/无为县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340271', '340200', '340000,340200', '芜湖经济技术开发区', '安徽省/芜湖市/芜湖经济技术开发区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340272', '340200', '340000,340200', '安徽芜湖长江大桥经济开发区', '安徽省/芜湖市/安徽芜湖长江大桥经济开发区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340300', '340000', '340000', '蚌埠市', '安徽省/蚌埠市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340301', '340300', '340000,340300', '市辖区', '安徽省/蚌埠市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340302', '340300', '340000,340300', '龙子湖区', '安徽省/蚌埠市/龙子湖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340303', '340300', '340000,340300', '蚌山区', '安徽省/蚌埠市/蚌山区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340304', '340300', '340000,340300', '禹会区', '安徽省/蚌埠市/禹会区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340311', '340300', '340000,340300', '淮上区', '安徽省/蚌埠市/淮上区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340321', '340300', '340000,340300', '怀远县', '安徽省/蚌埠市/怀远县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340322', '340300', '340000,340300', '五河县', '安徽省/蚌埠市/五河县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340323', '340300', '340000,340300', '固镇县', '安徽省/蚌埠市/固镇县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340371', '340300', '340000,340300', '蚌埠市高新技术开发区', '安徽省/蚌埠市/蚌埠市高新技术开发区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340372', '340300', '340000,340300', '蚌埠市经济开发区', '安徽省/蚌埠市/蚌埠市经济开发区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340400', '340000', '340000', '淮南市', '安徽省/淮南市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340401', '340400', '340000,340400', '市辖区', '安徽省/淮南市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340402', '340400', '340000,340400', '大通区', '安徽省/淮南市/大通区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340403', '340400', '340000,340400', '田家庵区', '安徽省/淮南市/田家庵区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340404', '340400', '340000,340400', '谢家集区', '安徽省/淮南市/谢家集区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340405', '340400', '340000,340400', '八公山区', '安徽省/淮南市/八公山区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340406', '340400', '340000,340400', '潘集区', '安徽省/淮南市/潘集区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340421', '340400', '340000,340400', '凤台县', '安徽省/淮南市/凤台县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340422', '340400', '340000,340400', '寿县', '安徽省/淮南市/寿县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340500', '340000', '340000', '马鞍山市', '安徽省/马鞍山市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340501', '340500', '340000,340500', '市辖区', '安徽省/马鞍山市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340503', '340500', '340000,340500', '花山区', '安徽省/马鞍山市/花山区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340504', '340500', '340000,340500', '雨山区', '安徽省/马鞍山市/雨山区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340506', '340500', '340000,340500', '博望区', '安徽省/马鞍山市/博望区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340521', '340500', '340000,340500', '当涂县', '安徽省/马鞍山市/当涂县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340522', '340500', '340000,340500', '含山县', '安徽省/马鞍山市/含山县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340523', '340500', '340000,340500', '和县', '安徽省/马鞍山市/和县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340600', '340000', '340000', '淮北市', '安徽省/淮北市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340601', '340600', '340000,340600', '市辖区', '安徽省/淮北市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340602', '340600', '340000,340600', '杜集区', '安徽省/淮北市/杜集区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340603', '340600', '340000,340600', '相山区', '安徽省/淮北市/相山区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340604', '340600', '340000,340600', '烈山区', '安徽省/淮北市/烈山区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340621', '340600', '340000,340600', '濉溪县', '安徽省/淮北市/濉溪县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340700', '340000', '340000', '铜陵市', '安徽省/铜陵市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340701', '340700', '340000,340700', '市辖区', '安徽省/铜陵市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340705', '340700', '340000,340700', '铜官区', '安徽省/铜陵市/铜官区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340706', '340700', '340000,340700', '义安区', '安徽省/铜陵市/义安区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340711', '340700', '340000,340700', '郊区', '安徽省/铜陵市/郊区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340722', '340700', '340000,340700', '枞阳县', '安徽省/铜陵市/枞阳县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340800', '340000', '340000', '安庆市', '安徽省/安庆市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340801', '340800', '340000,340800', '市辖区', '安徽省/安庆市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340802', '340800', '340000,340800', '迎江区', '安徽省/安庆市/迎江区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340803', '340800', '340000,340800', '大观区', '安徽省/安庆市/大观区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340811', '340800', '340000,340800', '宜秀区', '安徽省/安庆市/宜秀区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340822', '340800', '340000,340800', '怀宁县', '安徽省/安庆市/怀宁县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340825', '340800', '340000,340800', '太湖县', '安徽省/安庆市/太湖县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340826', '340800', '340000,340800', '宿松县', '安徽省/安庆市/宿松县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340827', '340800', '340000,340800', '望江县', '安徽省/安庆市/望江县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340828', '340800', '340000,340800', '岳西县', '安徽省/安庆市/岳西县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340871', '340800', '340000,340800', '安徽安庆经济开发区', '安徽省/安庆市/安徽安庆经济开发区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340881', '340800', '340000,340800', '桐城市', '安徽省/安庆市/桐城市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('340882', '340800', '340000,340800', '潜山市', '安徽省/安庆市/潜山市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341000', '340000', '340000', '黄山市', '安徽省/黄山市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341001', '341000', '340000,341000', '市辖区', '安徽省/黄山市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341002', '341000', '340000,341000', '屯溪区', '安徽省/黄山市/屯溪区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341003', '341000', '340000,341000', '黄山区', '安徽省/黄山市/黄山区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341004', '341000', '340000,341000', '徽州区', '安徽省/黄山市/徽州区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341021', '341000', '340000,341000', '歙县', '安徽省/黄山市/歙县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341022', '341000', '340000,341000', '休宁县', '安徽省/黄山市/休宁县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341023', '341000', '340000,341000', '黟县', '安徽省/黄山市/黟县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341024', '341000', '340000,341000', '祁门县', '安徽省/黄山市/祁门县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341100', '340000', '340000', '滁州市', '安徽省/滁州市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341101', '341100', '340000,341100', '市辖区', '安徽省/滁州市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341102', '341100', '340000,341100', '琅琊区', '安徽省/滁州市/琅琊区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341103', '341100', '340000,341100', '南谯区', '安徽省/滁州市/南谯区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341122', '341100', '340000,341100', '来安县', '安徽省/滁州市/来安县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341124', '341100', '340000,341100', '全椒县', '安徽省/滁州市/全椒县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341125', '341100', '340000,341100', '定远县', '安徽省/滁州市/定远县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341126', '341100', '340000,341100', '凤阳县', '安徽省/滁州市/凤阳县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341171', '341100', '340000,341100', '苏滁现代产业园', '安徽省/滁州市/苏滁现代产业园', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341172', '341100', '340000,341100', '滁州经济技术开发区', '安徽省/滁州市/滁州经济技术开发区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341181', '341100', '340000,341100', '天长市', '安徽省/滁州市/天长市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341182', '341100', '340000,341100', '明光市', '安徽省/滁州市/明光市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341200', '340000', '340000', '阜阳市', '安徽省/阜阳市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341201', '341200', '340000,341200', '市辖区', '安徽省/阜阳市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341202', '341200', '340000,341200', '颍州区', '安徽省/阜阳市/颍州区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341203', '341200', '340000,341200', '颍东区', '安徽省/阜阳市/颍东区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341204', '341200', '340000,341200', '颍泉区', '安徽省/阜阳市/颍泉区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341221', '341200', '340000,341200', '临泉县', '安徽省/阜阳市/临泉县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341222', '341200', '340000,341200', '太和县', '安徽省/阜阳市/太和县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341225', '341200', '340000,341200', '阜南县', '安徽省/阜阳市/阜南县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341226', '341200', '340000,341200', '颍上县', '安徽省/阜阳市/颍上县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341271', '341200', '340000,341200', '阜阳合肥现代产业园区', '安徽省/阜阳市/阜阳合肥现代产业园区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341272', '341200', '340000,341200', '阜阳经济技术开发区', '安徽省/阜阳市/阜阳经济技术开发区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341282', '341200', '340000,341200', '界首市', '安徽省/阜阳市/界首市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341300', '340000', '340000', '宿州市', '安徽省/宿州市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341301', '341300', '340000,341300', '市辖区', '安徽省/宿州市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341302', '341300', '340000,341300', '埇桥区', '安徽省/宿州市/埇桥区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341321', '341300', '340000,341300', '砀山县', '安徽省/宿州市/砀山县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341322', '341300', '340000,341300', '萧县', '安徽省/宿州市/萧县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341323', '341300', '340000,341300', '灵璧县', '安徽省/宿州市/灵璧县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341324', '341300', '340000,341300', '泗县', '安徽省/宿州市/泗县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341371', '341300', '340000,341300', '宿州马鞍山现代产业园区', '安徽省/宿州市/宿州马鞍山现代产业园区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341372', '341300', '340000,341300', '宿州经济技术开发区', '安徽省/宿州市/宿州经济技术开发区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341500', '340000', '340000', '六安市', '安徽省/六安市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341501', '341500', '340000,341500', '市辖区', '安徽省/六安市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341502', '341500', '340000,341500', '金安区', '安徽省/六安市/金安区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341503', '341500', '340000,341500', '裕安区', '安徽省/六安市/裕安区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341504', '341500', '340000,341500', '叶集区', '安徽省/六安市/叶集区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341522', '341500', '340000,341500', '霍邱县', '安徽省/六安市/霍邱县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341523', '341500', '340000,341500', '舒城县', '安徽省/六安市/舒城县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341524', '341500', '340000,341500', '金寨县', '安徽省/六安市/金寨县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341525', '341500', '340000,341500', '霍山县', '安徽省/六安市/霍山县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341600', '340000', '340000', '亳州市', '安徽省/亳州市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341601', '341600', '340000,341600', '市辖区', '安徽省/亳州市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341602', '341600', '340000,341600', '谯城区', '安徽省/亳州市/谯城区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341621', '341600', '340000,341600', '涡阳县', '安徽省/亳州市/涡阳县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341622', '341600', '340000,341600', '蒙城县', '安徽省/亳州市/蒙城县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341623', '341600', '340000,341600', '利辛县', '安徽省/亳州市/利辛县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341700', '340000', '340000', '池州市', '安徽省/池州市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341701', '341700', '340000,341700', '市辖区', '安徽省/池州市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341702', '341700', '340000,341700', '贵池区', '安徽省/池州市/贵池区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341721', '341700', '340000,341700', '东至县', '安徽省/池州市/东至县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341722', '341700', '340000,341700', '石台县', '安徽省/池州市/石台县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341723', '341700', '340000,341700', '青阳县', '安徽省/池州市/青阳县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341800', '340000', '340000', '宣城市', '安徽省/宣城市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341801', '341800', '340000,341800', '市辖区', '安徽省/宣城市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341802', '341800', '340000,341800', '宣州区', '安徽省/宣城市/宣州区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341821', '341800', '340000,341800', '郎溪县', '安徽省/宣城市/郎溪县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341823', '341800', '340000,341800', '泾县', '安徽省/宣城市/泾县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341824', '341800', '340000,341800', '绩溪县', '安徽省/宣城市/绩溪县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341825', '341800', '340000,341800', '旌德县', '安徽省/宣城市/旌德县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341871', '341800', '340000,341800', '宣城市经济开发区', '安徽省/宣城市/宣城市经济开发区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341881', '341800', '340000,341800', '宁国市', '安徽省/宣城市/宁国市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('341882', '341800', '340000,341800', '广德市', '安徽省/宣城市/广德市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350000', '86', '', '福建省', '福建省', 1, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350100', '350000', '350000', '福州市', '福建省/福州市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350101', '350100', '350000,350100', '市辖区', '福建省/福州市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350102', '350100', '350000,350100', '鼓楼区', '福建省/福州市/鼓楼区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350103', '350100', '350000,350100', '台江区', '福建省/福州市/台江区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350104', '350100', '350000,350100', '仓山区', '福建省/福州市/仓山区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350105', '350100', '350000,350100', '马尾区', '福建省/福州市/马尾区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350111', '350100', '350000,350100', '晋安区', '福建省/福州市/晋安区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350112', '350100', '350000,350100', '长乐区', '福建省/福州市/长乐区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350121', '350100', '350000,350100', '闽侯县', '福建省/福州市/闽侯县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350122', '350100', '350000,350100', '连江县', '福建省/福州市/连江县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350123', '350100', '350000,350100', '罗源县', '福建省/福州市/罗源县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350124', '350100', '350000,350100', '闽清县', '福建省/福州市/闽清县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350125', '350100', '350000,350100', '永泰县', '福建省/福州市/永泰县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350128', '350100', '350000,350100', '平潭县', '福建省/福州市/平潭县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350181', '350100', '350000,350100', '福清市', '福建省/福州市/福清市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350200', '350000', '350000', '厦门市', '福建省/厦门市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350201', '350200', '350000,350200', '市辖区', '福建省/厦门市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350203', '350200', '350000,350200', '思明区', '福建省/厦门市/思明区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350205', '350200', '350000,350200', '海沧区', '福建省/厦门市/海沧区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350206', '350200', '350000,350200', '湖里区', '福建省/厦门市/湖里区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350211', '350200', '350000,350200', '集美区', '福建省/厦门市/集美区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350212', '350200', '350000,350200', '同安区', '福建省/厦门市/同安区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350213', '350200', '350000,350200', '翔安区', '福建省/厦门市/翔安区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350300', '350000', '350000', '莆田市', '福建省/莆田市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350301', '350300', '350000,350300', '市辖区', '福建省/莆田市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350302', '350300', '350000,350300', '城厢区', '福建省/莆田市/城厢区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350303', '350300', '350000,350300', '涵江区', '福建省/莆田市/涵江区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350304', '350300', '350000,350300', '荔城区', '福建省/莆田市/荔城区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350305', '350300', '350000,350300', '秀屿区', '福建省/莆田市/秀屿区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350322', '350300', '350000,350300', '仙游县', '福建省/莆田市/仙游县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350400', '350000', '350000', '三明市', '福建省/三明市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350401', '350400', '350000,350400', '市辖区', '福建省/三明市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350402', '350400', '350000,350400', '梅列区', '福建省/三明市/梅列区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350403', '350400', '350000,350400', '三元区', '福建省/三明市/三元区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350421', '350400', '350000,350400', '明溪县', '福建省/三明市/明溪县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350423', '350400', '350000,350400', '清流县', '福建省/三明市/清流县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350424', '350400', '350000,350400', '宁化县', '福建省/三明市/宁化县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350425', '350400', '350000,350400', '大田县', '福建省/三明市/大田县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350426', '350400', '350000,350400', '尤溪县', '福建省/三明市/尤溪县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350427', '350400', '350000,350400', '沙县', '福建省/三明市/沙县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350428', '350400', '350000,350400', '将乐县', '福建省/三明市/将乐县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350429', '350400', '350000,350400', '泰宁县', '福建省/三明市/泰宁县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350430', '350400', '350000,350400', '建宁县', '福建省/三明市/建宁县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350481', '350400', '350000,350400', '永安市', '福建省/三明市/永安市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350500', '350000', '350000', '泉州市', '福建省/泉州市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350501', '350500', '350000,350500', '市辖区', '福建省/泉州市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350502', '350500', '350000,350500', '鲤城区', '福建省/泉州市/鲤城区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350503', '350500', '350000,350500', '丰泽区', '福建省/泉州市/丰泽区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350504', '350500', '350000,350500', '洛江区', '福建省/泉州市/洛江区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350505', '350500', '350000,350500', '泉港区', '福建省/泉州市/泉港区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350521', '350500', '350000,350500', '惠安县', '福建省/泉州市/惠安县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350524', '350500', '350000,350500', '安溪县', '福建省/泉州市/安溪县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350525', '350500', '350000,350500', '永春县', '福建省/泉州市/永春县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350526', '350500', '350000,350500', '德化县', '福建省/泉州市/德化县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350527', '350500', '350000,350500', '金门县', '福建省/泉州市/金门县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350581', '350500', '350000,350500', '石狮市', '福建省/泉州市/石狮市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350582', '350500', '350000,350500', '晋江市', '福建省/泉州市/晋江市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350583', '350500', '350000,350500', '南安市', '福建省/泉州市/南安市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350600', '350000', '350000', '漳州市', '福建省/漳州市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350601', '350600', '350000,350600', '市辖区', '福建省/漳州市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350602', '350600', '350000,350600', '芗城区', '福建省/漳州市/芗城区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350603', '350600', '350000,350600', '龙文区', '福建省/漳州市/龙文区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350622', '350600', '350000,350600', '云霄县', '福建省/漳州市/云霄县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350623', '350600', '350000,350600', '漳浦县', '福建省/漳州市/漳浦县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350624', '350600', '350000,350600', '诏安县', '福建省/漳州市/诏安县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350625', '350600', '350000,350600', '长泰县', '福建省/漳州市/长泰县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350626', '350600', '350000,350600', '东山县', '福建省/漳州市/东山县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350627', '350600', '350000,350600', '南靖县', '福建省/漳州市/南靖县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350628', '350600', '350000,350600', '平和县', '福建省/漳州市/平和县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350629', '350600', '350000,350600', '华安县', '福建省/漳州市/华安县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350681', '350600', '350000,350600', '龙海市', '福建省/漳州市/龙海市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350700', '350000', '350000', '南平市', '福建省/南平市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350701', '350700', '350000,350700', '市辖区', '福建省/南平市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350702', '350700', '350000,350700', '延平区', '福建省/南平市/延平区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350703', '350700', '350000,350700', '建阳区', '福建省/南平市/建阳区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350721', '350700', '350000,350700', '顺昌县', '福建省/南平市/顺昌县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350722', '350700', '350000,350700', '浦城县', '福建省/南平市/浦城县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350723', '350700', '350000,350700', '光泽县', '福建省/南平市/光泽县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350724', '350700', '350000,350700', '松溪县', '福建省/南平市/松溪县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350725', '350700', '350000,350700', '政和县', '福建省/南平市/政和县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350781', '350700', '350000,350700', '邵武市', '福建省/南平市/邵武市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350782', '350700', '350000,350700', '武夷山市', '福建省/南平市/武夷山市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350783', '350700', '350000,350700', '建瓯市', '福建省/南平市/建瓯市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350800', '350000', '350000', '龙岩市', '福建省/龙岩市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350801', '350800', '350000,350800', '市辖区', '福建省/龙岩市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350802', '350800', '350000,350800', '新罗区', '福建省/龙岩市/新罗区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350803', '350800', '350000,350800', '永定区', '福建省/龙岩市/永定区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350821', '350800', '350000,350800', '长汀县', '福建省/龙岩市/长汀县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350823', '350800', '350000,350800', '上杭县', '福建省/龙岩市/上杭县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350824', '350800', '350000,350800', '武平县', '福建省/龙岩市/武平县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350825', '350800', '350000,350800', '连城县', '福建省/龙岩市/连城县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350881', '350800', '350000,350800', '漳平市', '福建省/龙岩市/漳平市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350900', '350000', '350000', '宁德市', '福建省/宁德市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350901', '350900', '350000,350900', '市辖区', '福建省/宁德市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350902', '350900', '350000,350900', '蕉城区', '福建省/宁德市/蕉城区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350921', '350900', '350000,350900', '霞浦县', '福建省/宁德市/霞浦县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350922', '350900', '350000,350900', '古田县', '福建省/宁德市/古田县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350923', '350900', '350000,350900', '屏南县', '福建省/宁德市/屏南县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350924', '350900', '350000,350900', '寿宁县', '福建省/宁德市/寿宁县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350925', '350900', '350000,350900', '周宁县', '福建省/宁德市/周宁县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350926', '350900', '350000,350900', '柘荣县', '福建省/宁德市/柘荣县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350981', '350900', '350000,350900', '福安市', '福建省/宁德市/福安市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('350982', '350900', '350000,350900', '福鼎市', '福建省/宁德市/福鼎市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360000', '86', '', '江西省', '江西省', 1, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360100', '360000', '360000', '南昌市', '江西省/南昌市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360101', '360100', '360000,360100', '市辖区', '江西省/南昌市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360102', '360100', '360000,360100', '东湖区', '江西省/南昌市/东湖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360103', '360100', '360000,360100', '西湖区', '江西省/南昌市/西湖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360104', '360100', '360000,360100', '青云谱区', '江西省/南昌市/青云谱区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360105', '360100', '360000,360100', '湾里区', '江西省/南昌市/湾里区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360111', '360100', '360000,360100', '青山湖区', '江西省/南昌市/青山湖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360112', '360100', '360000,360100', '新建区', '江西省/南昌市/新建区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360121', '360100', '360000,360100', '南昌县', '江西省/南昌市/南昌县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360123', '360100', '360000,360100', '安义县', '江西省/南昌市/安义县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360124', '360100', '360000,360100', '进贤县', '江西省/南昌市/进贤县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360200', '360000', '360000', '景德镇市', '江西省/景德镇市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360201', '360200', '360000,360200', '市辖区', '江西省/景德镇市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360202', '360200', '360000,360200', '昌江区', '江西省/景德镇市/昌江区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360203', '360200', '360000,360200', '珠山区', '江西省/景德镇市/珠山区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360222', '360200', '360000,360200', '浮梁县', '江西省/景德镇市/浮梁县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360281', '360200', '360000,360200', '乐平市', '江西省/景德镇市/乐平市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360300', '360000', '360000', '萍乡市', '江西省/萍乡市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360301', '360300', '360000,360300', '市辖区', '江西省/萍乡市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360302', '360300', '360000,360300', '安源区', '江西省/萍乡市/安源区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360313', '360300', '360000,360300', '湘东区', '江西省/萍乡市/湘东区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360321', '360300', '360000,360300', '莲花县', '江西省/萍乡市/莲花县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360322', '360300', '360000,360300', '上栗县', '江西省/萍乡市/上栗县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360323', '360300', '360000,360300', '芦溪县', '江西省/萍乡市/芦溪县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360400', '360000', '360000', '九江市', '江西省/九江市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360401', '360400', '360000,360400', '市辖区', '江西省/九江市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360402', '360400', '360000,360400', '濂溪区', '江西省/九江市/濂溪区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360403', '360400', '360000,360400', '浔阳区', '江西省/九江市/浔阳区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360404', '360400', '360000,360400', '柴桑区', '江西省/九江市/柴桑区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360423', '360400', '360000,360400', '武宁县', '江西省/九江市/武宁县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360424', '360400', '360000,360400', '修水县', '江西省/九江市/修水县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360425', '360400', '360000,360400', '永修县', '江西省/九江市/永修县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360426', '360400', '360000,360400', '德安县', '江西省/九江市/德安县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360428', '360400', '360000,360400', '都昌县', '江西省/九江市/都昌县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360429', '360400', '360000,360400', '湖口县', '江西省/九江市/湖口县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360430', '360400', '360000,360400', '彭泽县', '江西省/九江市/彭泽县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360481', '360400', '360000,360400', '瑞昌市', '江西省/九江市/瑞昌市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360482', '360400', '360000,360400', '共青城市', '江西省/九江市/共青城市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360483', '360400', '360000,360400', '庐山市', '江西省/九江市/庐山市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360500', '360000', '360000', '新余市', '江西省/新余市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360501', '360500', '360000,360500', '市辖区', '江西省/新余市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360502', '360500', '360000,360500', '渝水区', '江西省/新余市/渝水区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360521', '360500', '360000,360500', '分宜县', '江西省/新余市/分宜县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360600', '360000', '360000', '鹰潭市', '江西省/鹰潭市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360601', '360600', '360000,360600', '市辖区', '江西省/鹰潭市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360602', '360600', '360000,360600', '月湖区', '江西省/鹰潭市/月湖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360603', '360600', '360000,360600', '余江区', '江西省/鹰潭市/余江区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360681', '360600', '360000,360600', '贵溪市', '江西省/鹰潭市/贵溪市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360700', '360000', '360000', '赣州市', '江西省/赣州市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360701', '360700', '360000,360700', '市辖区', '江西省/赣州市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360702', '360700', '360000,360700', '章贡区', '江西省/赣州市/章贡区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360703', '360700', '360000,360700', '南康区', '江西省/赣州市/南康区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360704', '360700', '360000,360700', '赣县区', '江西省/赣州市/赣县区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360722', '360700', '360000,360700', '信丰县', '江西省/赣州市/信丰县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360723', '360700', '360000,360700', '大余县', '江西省/赣州市/大余县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360724', '360700', '360000,360700', '上犹县', '江西省/赣州市/上犹县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360725', '360700', '360000,360700', '崇义县', '江西省/赣州市/崇义县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360726', '360700', '360000,360700', '安远县', '江西省/赣州市/安远县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360727', '360700', '360000,360700', '龙南县', '江西省/赣州市/龙南县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360728', '360700', '360000,360700', '定南县', '江西省/赣州市/定南县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360729', '360700', '360000,360700', '全南县', '江西省/赣州市/全南县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360730', '360700', '360000,360700', '宁都县', '江西省/赣州市/宁都县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360731', '360700', '360000,360700', '于都县', '江西省/赣州市/于都县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360732', '360700', '360000,360700', '兴国县', '江西省/赣州市/兴国县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360733', '360700', '360000,360700', '会昌县', '江西省/赣州市/会昌县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360734', '360700', '360000,360700', '寻乌县', '江西省/赣州市/寻乌县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360735', '360700', '360000,360700', '石城县', '江西省/赣州市/石城县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360781', '360700', '360000,360700', '瑞金市', '江西省/赣州市/瑞金市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360800', '360000', '360000', '吉安市', '江西省/吉安市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360801', '360800', '360000,360800', '市辖区', '江西省/吉安市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360802', '360800', '360000,360800', '吉州区', '江西省/吉安市/吉州区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360803', '360800', '360000,360800', '青原区', '江西省/吉安市/青原区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360821', '360800', '360000,360800', '吉安县', '江西省/吉安市/吉安县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360822', '360800', '360000,360800', '吉水县', '江西省/吉安市/吉水县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360823', '360800', '360000,360800', '峡江县', '江西省/吉安市/峡江县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360824', '360800', '360000,360800', '新干县', '江西省/吉安市/新干县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360825', '360800', '360000,360800', '永丰县', '江西省/吉安市/永丰县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360826', '360800', '360000,360800', '泰和县', '江西省/吉安市/泰和县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360827', '360800', '360000,360800', '遂川县', '江西省/吉安市/遂川县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360828', '360800', '360000,360800', '万安县', '江西省/吉安市/万安县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360829', '360800', '360000,360800', '安福县', '江西省/吉安市/安福县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360830', '360800', '360000,360800', '永新县', '江西省/吉安市/永新县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360881', '360800', '360000,360800', '井冈山市', '江西省/吉安市/井冈山市', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360900', '360000', '360000', '宜春市', '江西省/宜春市', 2, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360901', '360900', '360000,360900', '市辖区', '江西省/宜春市/市辖区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360902', '360900', '360000,360900', '袁州区', '江西省/宜春市/袁州区', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360921', '360900', '360000,360900', '奉新县', '江西省/宜春市/奉新县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360922', '360900', '360000,360900', '万载县', '江西省/宜春市/万载县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360923', '360900', '360000,360900', '上高县', '江西省/宜春市/上高县', 3, 'admin', '2022-05-22 20:35:15', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360924', '360900', '360000,360900', '宜丰县', '江西省/宜春市/宜丰县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360925', '360900', '360000,360900', '靖安县', '江西省/宜春市/靖安县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360926', '360900', '360000,360900', '铜鼓县', '江西省/宜春市/铜鼓县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360981', '360900', '360000,360900', '丰城市', '江西省/宜春市/丰城市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360982', '360900', '360000,360900', '樟树市', '江西省/宜春市/樟树市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('360983', '360900', '360000,360900', '高安市', '江西省/宜春市/高安市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('361000', '360000', '360000', '抚州市', '江西省/抚州市', 2, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('361001', '361000', '360000,361000', '市辖区', '江西省/抚州市/市辖区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('361002', '361000', '360000,361000', '临川区', '江西省/抚州市/临川区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('361003', '361000', '360000,361000', '东乡区', '江西省/抚州市/东乡区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('361021', '361000', '360000,361000', '南城县', '江西省/抚州市/南城县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('361022', '361000', '360000,361000', '黎川县', '江西省/抚州市/黎川县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('361023', '361000', '360000,361000', '南丰县', '江西省/抚州市/南丰县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('361024', '361000', '360000,361000', '崇仁县', '江西省/抚州市/崇仁县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('361025', '361000', '360000,361000', '乐安县', '江西省/抚州市/乐安县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('361026', '361000', '360000,361000', '宜黄县', '江西省/抚州市/宜黄县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('361027', '361000', '360000,361000', '金溪县', '江西省/抚州市/金溪县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('361028', '361000', '360000,361000', '资溪县', '江西省/抚州市/资溪县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('361030', '361000', '360000,361000', '广昌县', '江西省/抚州市/广昌县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('361100', '360000', '360000', '上饶市', '江西省/上饶市', 2, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('361101', '361100', '360000,361100', '市辖区', '江西省/上饶市/市辖区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('361102', '361100', '360000,361100', '信州区', '江西省/上饶市/信州区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('361103', '361100', '360000,361100', '广丰区', '江西省/上饶市/广丰区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('361104', '361100', '360000,361100', '广信区', '江西省/上饶市/广信区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('361123', '361100', '360000,361100', '玉山县', '江西省/上饶市/玉山县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('361124', '361100', '360000,361100', '铅山县', '江西省/上饶市/铅山县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('361125', '361100', '360000,361100', '横峰县', '江西省/上饶市/横峰县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('361126', '361100', '360000,361100', '弋阳县', '江西省/上饶市/弋阳县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('361127', '361100', '360000,361100', '余干县', '江西省/上饶市/余干县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('361128', '361100', '360000,361100', '鄱阳县', '江西省/上饶市/鄱阳县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('361129', '361100', '360000,361100', '万年县', '江西省/上饶市/万年县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('361130', '361100', '360000,361100', '婺源县', '江西省/上饶市/婺源县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('361181', '361100', '360000,361100', '德兴市', '江西省/上饶市/德兴市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370000', '86', '', '山东省', '山东省', 1, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370100', '370000', '370000', '济南市', '山东省/济南市', 2, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370101', '370100', '370000,370100', '市辖区', '山东省/济南市/市辖区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370102', '370100', '370000,370100', '历下区', '山东省/济南市/历下区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370103', '370100', '370000,370100', '市中区', '山东省/济南市/市中区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370104', '370100', '370000,370100', '槐荫区', '山东省/济南市/槐荫区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370105', '370100', '370000,370100', '天桥区', '山东省/济南市/天桥区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370112', '370100', '370000,370100', '历城区', '山东省/济南市/历城区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370113', '370100', '370000,370100', '长清区', '山东省/济南市/长清区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370114', '370100', '370000,370100', '章丘区', '山东省/济南市/章丘区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370115', '370100', '370000,370100', '济阳区', '山东省/济南市/济阳区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370116', '370100', '370000,370100', '莱芜区', '山东省/济南市/莱芜区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370117', '370100', '370000,370100', '钢城区', '山东省/济南市/钢城区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370124', '370100', '370000,370100', '平阴县', '山东省/济南市/平阴县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370126', '370100', '370000,370100', '商河县', '山东省/济南市/商河县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370171', '370100', '370000,370100', '济南高新技术产业开发区', '山东省/济南市/济南高新技术产业开发区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370200', '370000', '370000', '青岛市', '山东省/青岛市', 2, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370201', '370200', '370000,370200', '市辖区', '山东省/青岛市/市辖区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370202', '370200', '370000,370200', '市南区', '山东省/青岛市/市南区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370203', '370200', '370000,370200', '市北区', '山东省/青岛市/市北区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370211', '370200', '370000,370200', '黄岛区', '山东省/青岛市/黄岛区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370212', '370200', '370000,370200', '崂山区', '山东省/青岛市/崂山区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370213', '370200', '370000,370200', '李沧区', '山东省/青岛市/李沧区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370214', '370200', '370000,370200', '城阳区', '山东省/青岛市/城阳区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370215', '370200', '370000,370200', '即墨区', '山东省/青岛市/即墨区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370271', '370200', '370000,370200', '青岛高新技术产业开发区', '山东省/青岛市/青岛高新技术产业开发区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370281', '370200', '370000,370200', '胶州市', '山东省/青岛市/胶州市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370283', '370200', '370000,370200', '平度市', '山东省/青岛市/平度市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370285', '370200', '370000,370200', '莱西市', '山东省/青岛市/莱西市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370300', '370000', '370000', '淄博市', '山东省/淄博市', 2, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370301', '370300', '370000,370300', '市辖区', '山东省/淄博市/市辖区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370302', '370300', '370000,370300', '淄川区', '山东省/淄博市/淄川区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370303', '370300', '370000,370300', '张店区', '山东省/淄博市/张店区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370304', '370300', '370000,370300', '博山区', '山东省/淄博市/博山区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370305', '370300', '370000,370300', '临淄区', '山东省/淄博市/临淄区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370306', '370300', '370000,370300', '周村区', '山东省/淄博市/周村区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370321', '370300', '370000,370300', '桓台县', '山东省/淄博市/桓台县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370322', '370300', '370000,370300', '高青县', '山东省/淄博市/高青县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370323', '370300', '370000,370300', '沂源县', '山东省/淄博市/沂源县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370400', '370000', '370000', '枣庄市', '山东省/枣庄市', 2, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370401', '370400', '370000,370400', '市辖区', '山东省/枣庄市/市辖区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370402', '370400', '370000,370400', '市中区', '山东省/枣庄市/市中区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370403', '370400', '370000,370400', '薛城区', '山东省/枣庄市/薛城区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370404', '370400', '370000,370400', '峄城区', '山东省/枣庄市/峄城区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370405', '370400', '370000,370400', '台儿庄区', '山东省/枣庄市/台儿庄区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370406', '370400', '370000,370400', '山亭区', '山东省/枣庄市/山亭区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370481', '370400', '370000,370400', '滕州市', '山东省/枣庄市/滕州市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370500', '370000', '370000', '东营市', '山东省/东营市', 2, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370501', '370500', '370000,370500', '市辖区', '山东省/东营市/市辖区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370502', '370500', '370000,370500', '东营区', '山东省/东营市/东营区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370503', '370500', '370000,370500', '河口区', '山东省/东营市/河口区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370505', '370500', '370000,370500', '垦利区', '山东省/东营市/垦利区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370522', '370500', '370000,370500', '利津县', '山东省/东营市/利津县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370523', '370500', '370000,370500', '广饶县', '山东省/东营市/广饶县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370571', '370500', '370000,370500', '东营经济技术开发区', '山东省/东营市/东营经济技术开发区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370572', '370500', '370000,370500', '东营港经济开发区', '山东省/东营市/东营港经济开发区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370600', '370000', '370000', '烟台市', '山东省/烟台市', 2, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370601', '370600', '370000,370600', '市辖区', '山东省/烟台市/市辖区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370602', '370600', '370000,370600', '芝罘区', '山东省/烟台市/芝罘区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370611', '370600', '370000,370600', '福山区', '山东省/烟台市/福山区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370612', '370600', '370000,370600', '牟平区', '山东省/烟台市/牟平区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370613', '370600', '370000,370600', '莱山区', '山东省/烟台市/莱山区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370634', '370600', '370000,370600', '长岛县', '山东省/烟台市/长岛县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370671', '370600', '370000,370600', '烟台高新技术产业开发区', '山东省/烟台市/烟台高新技术产业开发区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370672', '370600', '370000,370600', '烟台经济技术开发区', '山东省/烟台市/烟台经济技术开发区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370681', '370600', '370000,370600', '龙口市', '山东省/烟台市/龙口市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370682', '370600', '370000,370600', '莱阳市', '山东省/烟台市/莱阳市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370683', '370600', '370000,370600', '莱州市', '山东省/烟台市/莱州市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370684', '370600', '370000,370600', '蓬莱市', '山东省/烟台市/蓬莱市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370685', '370600', '370000,370600', '招远市', '山东省/烟台市/招远市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370686', '370600', '370000,370600', '栖霞市', '山东省/烟台市/栖霞市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370687', '370600', '370000,370600', '海阳市', '山东省/烟台市/海阳市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370700', '370000', '370000', '潍坊市', '山东省/潍坊市', 2, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370701', '370700', '370000,370700', '市辖区', '山东省/潍坊市/市辖区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370702', '370700', '370000,370700', '潍城区', '山东省/潍坊市/潍城区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370703', '370700', '370000,370700', '寒亭区', '山东省/潍坊市/寒亭区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370704', '370700', '370000,370700', '坊子区', '山东省/潍坊市/坊子区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370705', '370700', '370000,370700', '奎文区', '山东省/潍坊市/奎文区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370724', '370700', '370000,370700', '临朐县', '山东省/潍坊市/临朐县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370725', '370700', '370000,370700', '昌乐县', '山东省/潍坊市/昌乐县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370772', '370700', '370000,370700', '潍坊滨海经济技术开发区', '山东省/潍坊市/潍坊滨海经济技术开发区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370781', '370700', '370000,370700', '青州市', '山东省/潍坊市/青州市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370782', '370700', '370000,370700', '诸城市', '山东省/潍坊市/诸城市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370783', '370700', '370000,370700', '寿光市', '山东省/潍坊市/寿光市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370784', '370700', '370000,370700', '安丘市', '山东省/潍坊市/安丘市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370785', '370700', '370000,370700', '高密市', '山东省/潍坊市/高密市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370786', '370700', '370000,370700', '昌邑市', '山东省/潍坊市/昌邑市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370800', '370000', '370000', '济宁市', '山东省/济宁市', 2, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370801', '370800', '370000,370800', '市辖区', '山东省/济宁市/市辖区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370811', '370800', '370000,370800', '任城区', '山东省/济宁市/任城区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370812', '370800', '370000,370800', '兖州区', '山东省/济宁市/兖州区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370826', '370800', '370000,370800', '微山县', '山东省/济宁市/微山县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370827', '370800', '370000,370800', '鱼台县', '山东省/济宁市/鱼台县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370828', '370800', '370000,370800', '金乡县', '山东省/济宁市/金乡县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370829', '370800', '370000,370800', '嘉祥县', '山东省/济宁市/嘉祥县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370830', '370800', '370000,370800', '汶上县', '山东省/济宁市/汶上县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370831', '370800', '370000,370800', '泗水县', '山东省/济宁市/泗水县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370832', '370800', '370000,370800', '梁山县', '山东省/济宁市/梁山县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370871', '370800', '370000,370800', '济宁高新技术产业开发区', '山东省/济宁市/济宁高新技术产业开发区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370881', '370800', '370000,370800', '曲阜市', '山东省/济宁市/曲阜市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370883', '370800', '370000,370800', '邹城市', '山东省/济宁市/邹城市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370900', '370000', '370000', '泰安市', '山东省/泰安市', 2, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370901', '370900', '370000,370900', '市辖区', '山东省/泰安市/市辖区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370902', '370900', '370000,370900', '泰山区', '山东省/泰安市/泰山区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370911', '370900', '370000,370900', '岱岳区', '山东省/泰安市/岱岳区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370921', '370900', '370000,370900', '宁阳县', '山东省/泰安市/宁阳县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370923', '370900', '370000,370900', '东平县', '山东省/泰安市/东平县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370982', '370900', '370000,370900', '新泰市', '山东省/泰安市/新泰市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('370983', '370900', '370000,370900', '肥城市', '山东省/泰安市/肥城市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371000', '370000', '370000', '威海市', '山东省/威海市', 2, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371001', '371000', '370000,371000', '市辖区', '山东省/威海市/市辖区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371002', '371000', '370000,371000', '环翠区', '山东省/威海市/环翠区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371003', '371000', '370000,371000', '文登区', '山东省/威海市/文登区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371071', '371000', '370000,371000', '威海火炬高技术产业开发区', '山东省/威海市/威海火炬高技术产业开发区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371072', '371000', '370000,371000', '威海经济技术开发区', '山东省/威海市/威海经济技术开发区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371073', '371000', '370000,371000', '威海临港经济技术开发区', '山东省/威海市/威海临港经济技术开发区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371082', '371000', '370000,371000', '荣成市', '山东省/威海市/荣成市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371083', '371000', '370000,371000', '乳山市', '山东省/威海市/乳山市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371100', '370000', '370000', '日照市', '山东省/日照市', 2, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371101', '371100', '370000,371100', '市辖区', '山东省/日照市/市辖区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371102', '371100', '370000,371100', '东港区', '山东省/日照市/东港区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371103', '371100', '370000,371100', '岚山区', '山东省/日照市/岚山区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371121', '371100', '370000,371100', '五莲县', '山东省/日照市/五莲县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371122', '371100', '370000,371100', '莒县', '山东省/日照市/莒县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371171', '371100', '370000,371100', '日照经济技术开发区', '山东省/日照市/日照经济技术开发区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371300', '370000', '370000', '临沂市', '山东省/临沂市', 2, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371301', '371300', '370000,371300', '市辖区', '山东省/临沂市/市辖区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371302', '371300', '370000,371300', '兰山区', '山东省/临沂市/兰山区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371311', '371300', '370000,371300', '罗庄区', '山东省/临沂市/罗庄区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371312', '371300', '370000,371300', '河东区', '山东省/临沂市/河东区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371321', '371300', '370000,371300', '沂南县', '山东省/临沂市/沂南县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371322', '371300', '370000,371300', '郯城县', '山东省/临沂市/郯城县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371323', '371300', '370000,371300', '沂水县', '山东省/临沂市/沂水县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371324', '371300', '370000,371300', '兰陵县', '山东省/临沂市/兰陵县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371325', '371300', '370000,371300', '费县', '山东省/临沂市/费县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371326', '371300', '370000,371300', '平邑县', '山东省/临沂市/平邑县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371327', '371300', '370000,371300', '莒南县', '山东省/临沂市/莒南县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371328', '371300', '370000,371300', '蒙阴县', '山东省/临沂市/蒙阴县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371329', '371300', '370000,371300', '临沭县', '山东省/临沂市/临沭县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371371', '371300', '370000,371300', '临沂高新技术产业开发区', '山东省/临沂市/临沂高新技术产业开发区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371372', '371300', '370000,371300', '临沂经济技术开发区', '山东省/临沂市/临沂经济技术开发区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371373', '371300', '370000,371300', '临沂临港经济开发区', '山东省/临沂市/临沂临港经济开发区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371400', '370000', '370000', '德州市', '山东省/德州市', 2, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371401', '371400', '370000,371400', '市辖区', '山东省/德州市/市辖区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371402', '371400', '370000,371400', '德城区', '山东省/德州市/德城区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371403', '371400', '370000,371400', '陵城区', '山东省/德州市/陵城区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371422', '371400', '370000,371400', '宁津县', '山东省/德州市/宁津县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371423', '371400', '370000,371400', '庆云县', '山东省/德州市/庆云县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371424', '371400', '370000,371400', '临邑县', '山东省/德州市/临邑县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371425', '371400', '370000,371400', '齐河县', '山东省/德州市/齐河县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371426', '371400', '370000,371400', '平原县', '山东省/德州市/平原县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371427', '371400', '370000,371400', '夏津县', '山东省/德州市/夏津县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371428', '371400', '370000,371400', '武城县', '山东省/德州市/武城县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371471', '371400', '370000,371400', '德州经济技术开发区', '山东省/德州市/德州经济技术开发区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371472', '371400', '370000,371400', '德州运河经济开发区', '山东省/德州市/德州运河经济开发区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371481', '371400', '370000,371400', '乐陵市', '山东省/德州市/乐陵市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371482', '371400', '370000,371400', '禹城市', '山东省/德州市/禹城市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371500', '370000', '370000', '聊城市', '山东省/聊城市', 2, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371501', '371500', '370000,371500', '市辖区', '山东省/聊城市/市辖区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371502', '371500', '370000,371500', '东昌府区', '山东省/聊城市/东昌府区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371503', '371500', '370000,371500', '茌平区', '山东省/聊城市/茌平区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371521', '371500', '370000,371500', '阳谷县', '山东省/聊城市/阳谷县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371522', '371500', '370000,371500', '莘县', '山东省/聊城市/莘县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371524', '371500', '370000,371500', '东阿县', '山东省/聊城市/东阿县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371525', '371500', '370000,371500', '冠县', '山东省/聊城市/冠县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371526', '371500', '370000,371500', '高唐县', '山东省/聊城市/高唐县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371581', '371500', '370000,371500', '临清市', '山东省/聊城市/临清市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371600', '370000', '370000', '滨州市', '山东省/滨州市', 2, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371601', '371600', '370000,371600', '市辖区', '山东省/滨州市/市辖区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371602', '371600', '370000,371600', '滨城区', '山东省/滨州市/滨城区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371603', '371600', '370000,371600', '沾化区', '山东省/滨州市/沾化区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371621', '371600', '370000,371600', '惠民县', '山东省/滨州市/惠民县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371622', '371600', '370000,371600', '阳信县', '山东省/滨州市/阳信县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371623', '371600', '370000,371600', '无棣县', '山东省/滨州市/无棣县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371625', '371600', '370000,371600', '博兴县', '山东省/滨州市/博兴县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371681', '371600', '370000,371600', '邹平市', '山东省/滨州市/邹平市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371700', '370000', '370000', '菏泽市', '山东省/菏泽市', 2, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371701', '371700', '370000,371700', '市辖区', '山东省/菏泽市/市辖区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371702', '371700', '370000,371700', '牡丹区', '山东省/菏泽市/牡丹区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371703', '371700', '370000,371700', '定陶区', '山东省/菏泽市/定陶区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371721', '371700', '370000,371700', '曹县', '山东省/菏泽市/曹县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371722', '371700', '370000,371700', '单县', '山东省/菏泽市/单县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371723', '371700', '370000,371700', '成武县', '山东省/菏泽市/成武县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371724', '371700', '370000,371700', '巨野县', '山东省/菏泽市/巨野县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371725', '371700', '370000,371700', '郓城县', '山东省/菏泽市/郓城县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371726', '371700', '370000,371700', '鄄城县', '山东省/菏泽市/鄄城县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371728', '371700', '370000,371700', '东明县', '山东省/菏泽市/东明县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371771', '371700', '370000,371700', '菏泽经济技术开发区', '山东省/菏泽市/菏泽经济技术开发区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('371772', '371700', '370000,371700', '菏泽高新技术开发区', '山东省/菏泽市/菏泽高新技术开发区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410000', '86', '', '河南省', '河南省', 1, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410100', '410000', '410000', '郑州市', '河南省/郑州市', 2, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410101', '410100', '410000,410100', '市辖区', '河南省/郑州市/市辖区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410102', '410100', '410000,410100', '中原区', '河南省/郑州市/中原区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410103', '410100', '410000,410100', '二七区', '河南省/郑州市/二七区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410104', '410100', '410000,410100', '管城回族区', '河南省/郑州市/管城回族区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410105', '410100', '410000,410100', '金水区', '河南省/郑州市/金水区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410106', '410100', '410000,410100', '上街区', '河南省/郑州市/上街区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410108', '410100', '410000,410100', '惠济区', '河南省/郑州市/惠济区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410122', '410100', '410000,410100', '中牟县', '河南省/郑州市/中牟县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410171', '410100', '410000,410100', '郑州经济技术开发区', '河南省/郑州市/郑州经济技术开发区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410172', '410100', '410000,410100', '郑州高新技术产业开发区', '河南省/郑州市/郑州高新技术产业开发区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410173', '410100', '410000,410100', '郑州航空港经济综合实验区', '河南省/郑州市/郑州航空港经济综合实验区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410181', '410100', '410000,410100', '巩义市', '河南省/郑州市/巩义市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410182', '410100', '410000,410100', '荥阳市', '河南省/郑州市/荥阳市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410183', '410100', '410000,410100', '新密市', '河南省/郑州市/新密市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410184', '410100', '410000,410100', '新郑市', '河南省/郑州市/新郑市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410185', '410100', '410000,410100', '登封市', '河南省/郑州市/登封市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410200', '410000', '410000', '开封市', '河南省/开封市', 2, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410201', '410200', '410000,410200', '市辖区', '河南省/开封市/市辖区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410202', '410200', '410000,410200', '龙亭区', '河南省/开封市/龙亭区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410203', '410200', '410000,410200', '顺河回族区', '河南省/开封市/顺河回族区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410204', '410200', '410000,410200', '鼓楼区', '河南省/开封市/鼓楼区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410205', '410200', '410000,410200', '禹王台区', '河南省/开封市/禹王台区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410212', '410200', '410000,410200', '祥符区', '河南省/开封市/祥符区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410221', '410200', '410000,410200', '杞县', '河南省/开封市/杞县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410222', '410200', '410000,410200', '通许县', '河南省/开封市/通许县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410223', '410200', '410000,410200', '尉氏县', '河南省/开封市/尉氏县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410225', '410200', '410000,410200', '兰考县', '河南省/开封市/兰考县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410300', '410000', '410000', '洛阳市', '河南省/洛阳市', 2, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410301', '410300', '410000,410300', '市辖区', '河南省/洛阳市/市辖区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410302', '410300', '410000,410300', '老城区', '河南省/洛阳市/老城区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410303', '410300', '410000,410300', '西工区', '河南省/洛阳市/西工区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410304', '410300', '410000,410300', '瀍河回族区', '河南省/洛阳市/瀍河回族区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410305', '410300', '410000,410300', '涧西区', '河南省/洛阳市/涧西区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410306', '410300', '410000,410300', '吉利区', '河南省/洛阳市/吉利区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410311', '410300', '410000,410300', '洛龙区', '河南省/洛阳市/洛龙区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410322', '410300', '410000,410300', '孟津县', '河南省/洛阳市/孟津县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410323', '410300', '410000,410300', '新安县', '河南省/洛阳市/新安县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410324', '410300', '410000,410300', '栾川县', '河南省/洛阳市/栾川县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410325', '410300', '410000,410300', '嵩县', '河南省/洛阳市/嵩县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410326', '410300', '410000,410300', '汝阳县', '河南省/洛阳市/汝阳县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410327', '410300', '410000,410300', '宜阳县', '河南省/洛阳市/宜阳县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410328', '410300', '410000,410300', '洛宁县', '河南省/洛阳市/洛宁县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410329', '410300', '410000,410300', '伊川县', '河南省/洛阳市/伊川县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410371', '410300', '410000,410300', '洛阳高新技术产业开发区', '河南省/洛阳市/洛阳高新技术产业开发区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410381', '410300', '410000,410300', '偃师市', '河南省/洛阳市/偃师市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410400', '410000', '410000', '平顶山市', '河南省/平顶山市', 2, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410401', '410400', '410000,410400', '市辖区', '河南省/平顶山市/市辖区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410402', '410400', '410000,410400', '新华区', '河南省/平顶山市/新华区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410403', '410400', '410000,410400', '卫东区', '河南省/平顶山市/卫东区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410404', '410400', '410000,410400', '石龙区', '河南省/平顶山市/石龙区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410411', '410400', '410000,410400', '湛河区', '河南省/平顶山市/湛河区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410421', '410400', '410000,410400', '宝丰县', '河南省/平顶山市/宝丰县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410422', '410400', '410000,410400', '叶县', '河南省/平顶山市/叶县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410423', '410400', '410000,410400', '鲁山县', '河南省/平顶山市/鲁山县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410425', '410400', '410000,410400', '郏县', '河南省/平顶山市/郏县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410471', '410400', '410000,410400', '平顶山高新技术产业开发区', '河南省/平顶山市/平顶山高新技术产业开发区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410472', '410400', '410000,410400', '平顶山市城乡一体化示范区', '河南省/平顶山市/平顶山市城乡一体化示范区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410481', '410400', '410000,410400', '舞钢市', '河南省/平顶山市/舞钢市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410482', '410400', '410000,410400', '汝州市', '河南省/平顶山市/汝州市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410500', '410000', '410000', '安阳市', '河南省/安阳市', 2, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410501', '410500', '410000,410500', '市辖区', '河南省/安阳市/市辖区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410502', '410500', '410000,410500', '文峰区', '河南省/安阳市/文峰区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410503', '410500', '410000,410500', '北关区', '河南省/安阳市/北关区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410505', '410500', '410000,410500', '殷都区', '河南省/安阳市/殷都区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410506', '410500', '410000,410500', '龙安区', '河南省/安阳市/龙安区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410522', '410500', '410000,410500', '安阳县', '河南省/安阳市/安阳县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410523', '410500', '410000,410500', '汤阴县', '河南省/安阳市/汤阴县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410526', '410500', '410000,410500', '滑县', '河南省/安阳市/滑县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410527', '410500', '410000,410500', '内黄县', '河南省/安阳市/内黄县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410571', '410500', '410000,410500', '安阳高新技术产业开发区', '河南省/安阳市/安阳高新技术产业开发区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410581', '410500', '410000,410500', '林州市', '河南省/安阳市/林州市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410600', '410000', '410000', '鹤壁市', '河南省/鹤壁市', 2, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410601', '410600', '410000,410600', '市辖区', '河南省/鹤壁市/市辖区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410602', '410600', '410000,410600', '鹤山区', '河南省/鹤壁市/鹤山区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410603', '410600', '410000,410600', '山城区', '河南省/鹤壁市/山城区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410611', '410600', '410000,410600', '淇滨区', '河南省/鹤壁市/淇滨区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410621', '410600', '410000,410600', '浚县', '河南省/鹤壁市/浚县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410622', '410600', '410000,410600', '淇县', '河南省/鹤壁市/淇县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410671', '410600', '410000,410600', '鹤壁经济技术开发区', '河南省/鹤壁市/鹤壁经济技术开发区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410700', '410000', '410000', '新乡市', '河南省/新乡市', 2, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410701', '410700', '410000,410700', '市辖区', '河南省/新乡市/市辖区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410702', '410700', '410000,410700', '红旗区', '河南省/新乡市/红旗区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410703', '410700', '410000,410700', '卫滨区', '河南省/新乡市/卫滨区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410704', '410700', '410000,410700', '凤泉区', '河南省/新乡市/凤泉区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410711', '410700', '410000,410700', '牧野区', '河南省/新乡市/牧野区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410721', '410700', '410000,410700', '新乡县', '河南省/新乡市/新乡县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410724', '410700', '410000,410700', '获嘉县', '河南省/新乡市/获嘉县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410725', '410700', '410000,410700', '原阳县', '河南省/新乡市/原阳县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410726', '410700', '410000,410700', '延津县', '河南省/新乡市/延津县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410727', '410700', '410000,410700', '封丘县', '河南省/新乡市/封丘县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410771', '410700', '410000,410700', '新乡高新技术产业开发区', '河南省/新乡市/新乡高新技术产业开发区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410772', '410700', '410000,410700', '新乡经济技术开发区', '河南省/新乡市/新乡经济技术开发区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410773', '410700', '410000,410700', '新乡市平原城乡一体化示范区', '河南省/新乡市/新乡市平原城乡一体化示范区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410781', '410700', '410000,410700', '卫辉市', '河南省/新乡市/卫辉市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410782', '410700', '410000,410700', '辉县市', '河南省/新乡市/辉县市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410783', '410700', '410000,410700', '长垣市', '河南省/新乡市/长垣市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410800', '410000', '410000', '焦作市', '河南省/焦作市', 2, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410801', '410800', '410000,410800', '市辖区', '河南省/焦作市/市辖区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410802', '410800', '410000,410800', '解放区', '河南省/焦作市/解放区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410803', '410800', '410000,410800', '中站区', '河南省/焦作市/中站区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410804', '410800', '410000,410800', '马村区', '河南省/焦作市/马村区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410811', '410800', '410000,410800', '山阳区', '河南省/焦作市/山阳区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410821', '410800', '410000,410800', '修武县', '河南省/焦作市/修武县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410822', '410800', '410000,410800', '博爱县', '河南省/焦作市/博爱县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410823', '410800', '410000,410800', '武陟县', '河南省/焦作市/武陟县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410825', '410800', '410000,410800', '温县', '河南省/焦作市/温县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410871', '410800', '410000,410800', '焦作城乡一体化示范区', '河南省/焦作市/焦作城乡一体化示范区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410882', '410800', '410000,410800', '沁阳市', '河南省/焦作市/沁阳市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410883', '410800', '410000,410800', '孟州市', '河南省/焦作市/孟州市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410900', '410000', '410000', '濮阳市', '河南省/濮阳市', 2, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410901', '410900', '410000,410900', '市辖区', '河南省/濮阳市/市辖区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410902', '410900', '410000,410900', '华龙区', '河南省/濮阳市/华龙区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410922', '410900', '410000,410900', '清丰县', '河南省/濮阳市/清丰县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410923', '410900', '410000,410900', '南乐县', '河南省/濮阳市/南乐县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410926', '410900', '410000,410900', '范县', '河南省/濮阳市/范县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410927', '410900', '410000,410900', '台前县', '河南省/濮阳市/台前县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410928', '410900', '410000,410900', '濮阳县', '河南省/濮阳市/濮阳县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410971', '410900', '410000,410900', '河南濮阳工业园区', '河南省/濮阳市/河南濮阳工业园区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('410972', '410900', '410000,410900', '濮阳经济技术开发区', '河南省/濮阳市/濮阳经济技术开发区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411000', '410000', '410000', '许昌市', '河南省/许昌市', 2, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411001', '411000', '410000,411000', '市辖区', '河南省/许昌市/市辖区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411002', '411000', '410000,411000', '魏都区', '河南省/许昌市/魏都区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411003', '411000', '410000,411000', '建安区', '河南省/许昌市/建安区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411024', '411000', '410000,411000', '鄢陵县', '河南省/许昌市/鄢陵县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411025', '411000', '410000,411000', '襄城县', '河南省/许昌市/襄城县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411071', '411000', '410000,411000', '许昌经济技术开发区', '河南省/许昌市/许昌经济技术开发区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411081', '411000', '410000,411000', '禹州市', '河南省/许昌市/禹州市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411082', '411000', '410000,411000', '长葛市', '河南省/许昌市/长葛市', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411100', '410000', '410000', '漯河市', '河南省/漯河市', 2, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411101', '411100', '410000,411100', '市辖区', '河南省/漯河市/市辖区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411102', '411100', '410000,411100', '源汇区', '河南省/漯河市/源汇区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411103', '411100', '410000,411100', '郾城区', '河南省/漯河市/郾城区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411104', '411100', '410000,411100', '召陵区', '河南省/漯河市/召陵区', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411121', '411100', '410000,411100', '舞阳县', '河南省/漯河市/舞阳县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411122', '411100', '410000,411100', '临颍县', '河南省/漯河市/临颍县', 3, 'admin', '2022-05-22 20:35:16', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411171', '411100', '410000,411100', '漯河经济技术开发区', '河南省/漯河市/漯河经济技术开发区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411200', '410000', '410000', '三门峡市', '河南省/三门峡市', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411201', '411200', '410000,411200', '市辖区', '河南省/三门峡市/市辖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411202', '411200', '410000,411200', '湖滨区', '河南省/三门峡市/湖滨区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411203', '411200', '410000,411200', '陕州区', '河南省/三门峡市/陕州区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411221', '411200', '410000,411200', '渑池县', '河南省/三门峡市/渑池县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411224', '411200', '410000,411200', '卢氏县', '河南省/三门峡市/卢氏县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411271', '411200', '410000,411200', '河南三门峡经济开发区', '河南省/三门峡市/河南三门峡经济开发区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411281', '411200', '410000,411200', '义马市', '河南省/三门峡市/义马市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411282', '411200', '410000,411200', '灵宝市', '河南省/三门峡市/灵宝市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411300', '410000', '410000', '南阳市', '河南省/南阳市', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411301', '411300', '410000,411300', '市辖区', '河南省/南阳市/市辖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411302', '411300', '410000,411300', '宛城区', '河南省/南阳市/宛城区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411303', '411300', '410000,411300', '卧龙区', '河南省/南阳市/卧龙区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411321', '411300', '410000,411300', '南召县', '河南省/南阳市/南召县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411322', '411300', '410000,411300', '方城县', '河南省/南阳市/方城县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411323', '411300', '410000,411300', '西峡县', '河南省/南阳市/西峡县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411324', '411300', '410000,411300', '镇平县', '河南省/南阳市/镇平县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411325', '411300', '410000,411300', '内乡县', '河南省/南阳市/内乡县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411326', '411300', '410000,411300', '淅川县', '河南省/南阳市/淅川县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411327', '411300', '410000,411300', '社旗县', '河南省/南阳市/社旗县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411328', '411300', '410000,411300', '唐河县', '河南省/南阳市/唐河县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411329', '411300', '410000,411300', '新野县', '河南省/南阳市/新野县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411330', '411300', '410000,411300', '桐柏县', '河南省/南阳市/桐柏县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411371', '411300', '410000,411300', '南阳高新技术产业开发区', '河南省/南阳市/南阳高新技术产业开发区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411372', '411300', '410000,411300', '南阳市城乡一体化示范区', '河南省/南阳市/南阳市城乡一体化示范区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411381', '411300', '410000,411300', '邓州市', '河南省/南阳市/邓州市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411400', '410000', '410000', '商丘市', '河南省/商丘市', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411401', '411400', '410000,411400', '市辖区', '河南省/商丘市/市辖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411402', '411400', '410000,411400', '梁园区', '河南省/商丘市/梁园区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411403', '411400', '410000,411400', '睢阳区', '河南省/商丘市/睢阳区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411421', '411400', '410000,411400', '民权县', '河南省/商丘市/民权县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411422', '411400', '410000,411400', '睢县', '河南省/商丘市/睢县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411423', '411400', '410000,411400', '宁陵县', '河南省/商丘市/宁陵县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411424', '411400', '410000,411400', '柘城县', '河南省/商丘市/柘城县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411425', '411400', '410000,411400', '虞城县', '河南省/商丘市/虞城县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411426', '411400', '410000,411400', '夏邑县', '河南省/商丘市/夏邑县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411471', '411400', '410000,411400', '豫东综合物流产业聚集区', '河南省/商丘市/豫东综合物流产业聚集区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411472', '411400', '410000,411400', '河南商丘经济开发区', '河南省/商丘市/河南商丘经济开发区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411481', '411400', '410000,411400', '永城市', '河南省/商丘市/永城市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411500', '410000', '410000', '信阳市', '河南省/信阳市', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411501', '411500', '410000,411500', '市辖区', '河南省/信阳市/市辖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411502', '411500', '410000,411500', '浉河区', '河南省/信阳市/浉河区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411503', '411500', '410000,411500', '平桥区', '河南省/信阳市/平桥区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411521', '411500', '410000,411500', '罗山县', '河南省/信阳市/罗山县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411522', '411500', '410000,411500', '光山县', '河南省/信阳市/光山县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411523', '411500', '410000,411500', '新县', '河南省/信阳市/新县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411524', '411500', '410000,411500', '商城县', '河南省/信阳市/商城县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411525', '411500', '410000,411500', '固始县', '河南省/信阳市/固始县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411526', '411500', '410000,411500', '潢川县', '河南省/信阳市/潢川县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411527', '411500', '410000,411500', '淮滨县', '河南省/信阳市/淮滨县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411528', '411500', '410000,411500', '息县', '河南省/信阳市/息县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411571', '411500', '410000,411500', '信阳高新技术产业开发区', '河南省/信阳市/信阳高新技术产业开发区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411600', '410000', '410000', '周口市', '河南省/周口市', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411601', '411600', '410000,411600', '市辖区', '河南省/周口市/市辖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411602', '411600', '410000,411600', '川汇区', '河南省/周口市/川汇区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411603', '411600', '410000,411600', '淮阳区', '河南省/周口市/淮阳区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411621', '411600', '410000,411600', '扶沟县', '河南省/周口市/扶沟县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411622', '411600', '410000,411600', '西华县', '河南省/周口市/西华县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411623', '411600', '410000,411600', '商水县', '河南省/周口市/商水县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411624', '411600', '410000,411600', '沈丘县', '河南省/周口市/沈丘县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411625', '411600', '410000,411600', '郸城县', '河南省/周口市/郸城县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411627', '411600', '410000,411600', '太康县', '河南省/周口市/太康县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411628', '411600', '410000,411600', '鹿邑县', '河南省/周口市/鹿邑县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411671', '411600', '410000,411600', '河南周口经济开发区', '河南省/周口市/河南周口经济开发区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411681', '411600', '410000,411600', '项城市', '河南省/周口市/项城市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411700', '410000', '410000', '驻马店市', '河南省/驻马店市', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411701', '411700', '410000,411700', '市辖区', '河南省/驻马店市/市辖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411702', '411700', '410000,411700', '驿城区', '河南省/驻马店市/驿城区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411721', '411700', '410000,411700', '西平县', '河南省/驻马店市/西平县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411722', '411700', '410000,411700', '上蔡县', '河南省/驻马店市/上蔡县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411723', '411700', '410000,411700', '平舆县', '河南省/驻马店市/平舆县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411724', '411700', '410000,411700', '正阳县', '河南省/驻马店市/正阳县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411725', '411700', '410000,411700', '确山县', '河南省/驻马店市/确山县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411726', '411700', '410000,411700', '泌阳县', '河南省/驻马店市/泌阳县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411727', '411700', '410000,411700', '汝南县', '河南省/驻马店市/汝南县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411728', '411700', '410000,411700', '遂平县', '河南省/驻马店市/遂平县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411729', '411700', '410000,411700', '新蔡县', '河南省/驻马店市/新蔡县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('411771', '411700', '410000,411700', '河南驻马店经济开发区', '河南省/驻马店市/河南驻马店经济开发区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('419000', '410000', '410000', '省直辖县级行政区划', '河南省/省直辖县级行政区划', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('419001', '419000', '410000,419000', '济源市', '河南省/省直辖县级行政区划/济源市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420000', '86', '', '湖北省', '湖北省', 1, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420100', '420000', '420000', '武汉市', '湖北省/武汉市', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420101', '420100', '420000,420100', '市辖区', '湖北省/武汉市/市辖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420102', '420100', '420000,420100', '江岸区', '湖北省/武汉市/江岸区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420103', '420100', '420000,420100', '江汉区', '湖北省/武汉市/江汉区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420104', '420100', '420000,420100', '硚口区', '湖北省/武汉市/硚口区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420105', '420100', '420000,420100', '汉阳区', '湖北省/武汉市/汉阳区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420106', '420100', '420000,420100', '武昌区', '湖北省/武汉市/武昌区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420107', '420100', '420000,420100', '青山区', '湖北省/武汉市/青山区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420111', '420100', '420000,420100', '洪山区', '湖北省/武汉市/洪山区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420112', '420100', '420000,420100', '东西湖区', '湖北省/武汉市/东西湖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420113', '420100', '420000,420100', '汉南区', '湖北省/武汉市/汉南区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420114', '420100', '420000,420100', '蔡甸区', '湖北省/武汉市/蔡甸区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420115', '420100', '420000,420100', '江夏区', '湖北省/武汉市/江夏区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420116', '420100', '420000,420100', '黄陂区', '湖北省/武汉市/黄陂区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420117', '420100', '420000,420100', '新洲区', '湖北省/武汉市/新洲区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420200', '420000', '420000', '黄石市', '湖北省/黄石市', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420201', '420200', '420000,420200', '市辖区', '湖北省/黄石市/市辖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420202', '420200', '420000,420200', '黄石港区', '湖北省/黄石市/黄石港区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420203', '420200', '420000,420200', '西塞山区', '湖北省/黄石市/西塞山区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420204', '420200', '420000,420200', '下陆区', '湖北省/黄石市/下陆区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420205', '420200', '420000,420200', '铁山区', '湖北省/黄石市/铁山区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420222', '420200', '420000,420200', '阳新县', '湖北省/黄石市/阳新县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420281', '420200', '420000,420200', '大冶市', '湖北省/黄石市/大冶市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420300', '420000', '420000', '十堰市', '湖北省/十堰市', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420301', '420300', '420000,420300', '市辖区', '湖北省/十堰市/市辖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420302', '420300', '420000,420300', '茅箭区', '湖北省/十堰市/茅箭区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420303', '420300', '420000,420300', '张湾区', '湖北省/十堰市/张湾区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420304', '420300', '420000,420300', '郧阳区', '湖北省/十堰市/郧阳区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420322', '420300', '420000,420300', '郧西县', '湖北省/十堰市/郧西县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420323', '420300', '420000,420300', '竹山县', '湖北省/十堰市/竹山县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420324', '420300', '420000,420300', '竹溪县', '湖北省/十堰市/竹溪县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420325', '420300', '420000,420300', '房县', '湖北省/十堰市/房县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420381', '420300', '420000,420300', '丹江口市', '湖北省/十堰市/丹江口市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420500', '420000', '420000', '宜昌市', '湖北省/宜昌市', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420501', '420500', '420000,420500', '市辖区', '湖北省/宜昌市/市辖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420502', '420500', '420000,420500', '西陵区', '湖北省/宜昌市/西陵区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420503', '420500', '420000,420500', '伍家岗区', '湖北省/宜昌市/伍家岗区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420504', '420500', '420000,420500', '点军区', '湖北省/宜昌市/点军区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420505', '420500', '420000,420500', '猇亭区', '湖北省/宜昌市/猇亭区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420506', '420500', '420000,420500', '夷陵区', '湖北省/宜昌市/夷陵区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420525', '420500', '420000,420500', '远安县', '湖北省/宜昌市/远安县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420526', '420500', '420000,420500', '兴山县', '湖北省/宜昌市/兴山县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420527', '420500', '420000,420500', '秭归县', '湖北省/宜昌市/秭归县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420528', '420500', '420000,420500', '长阳土家族自治县', '湖北省/宜昌市/长阳土家族自治县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420529', '420500', '420000,420500', '五峰土家族自治县', '湖北省/宜昌市/五峰土家族自治县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420581', '420500', '420000,420500', '宜都市', '湖北省/宜昌市/宜都市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420582', '420500', '420000,420500', '当阳市', '湖北省/宜昌市/当阳市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420583', '420500', '420000,420500', '枝江市', '湖北省/宜昌市/枝江市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420600', '420000', '420000', '襄阳市', '湖北省/襄阳市', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420601', '420600', '420000,420600', '市辖区', '湖北省/襄阳市/市辖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420602', '420600', '420000,420600', '襄城区', '湖北省/襄阳市/襄城区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420606', '420600', '420000,420600', '樊城区', '湖北省/襄阳市/樊城区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420607', '420600', '420000,420600', '襄州区', '湖北省/襄阳市/襄州区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420624', '420600', '420000,420600', '南漳县', '湖北省/襄阳市/南漳县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420625', '420600', '420000,420600', '谷城县', '湖北省/襄阳市/谷城县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420626', '420600', '420000,420600', '保康县', '湖北省/襄阳市/保康县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420682', '420600', '420000,420600', '老河口市', '湖北省/襄阳市/老河口市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420683', '420600', '420000,420600', '枣阳市', '湖北省/襄阳市/枣阳市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420684', '420600', '420000,420600', '宜城市', '湖北省/襄阳市/宜城市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420700', '420000', '420000', '鄂州市', '湖北省/鄂州市', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420701', '420700', '420000,420700', '市辖区', '湖北省/鄂州市/市辖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420702', '420700', '420000,420700', '梁子湖区', '湖北省/鄂州市/梁子湖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420703', '420700', '420000,420700', '华容区', '湖北省/鄂州市/华容区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420704', '420700', '420000,420700', '鄂城区', '湖北省/鄂州市/鄂城区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420800', '420000', '420000', '荆门市', '湖北省/荆门市', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420801', '420800', '420000,420800', '市辖区', '湖北省/荆门市/市辖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420802', '420800', '420000,420800', '东宝区', '湖北省/荆门市/东宝区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420804', '420800', '420000,420800', '掇刀区', '湖北省/荆门市/掇刀区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420822', '420800', '420000,420800', '沙洋县', '湖北省/荆门市/沙洋县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420881', '420800', '420000,420800', '钟祥市', '湖北省/荆门市/钟祥市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420882', '420800', '420000,420800', '京山市', '湖北省/荆门市/京山市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420900', '420000', '420000', '孝感市', '湖北省/孝感市', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420901', '420900', '420000,420900', '市辖区', '湖北省/孝感市/市辖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420902', '420900', '420000,420900', '孝南区', '湖北省/孝感市/孝南区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420921', '420900', '420000,420900', '孝昌县', '湖北省/孝感市/孝昌县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420922', '420900', '420000,420900', '大悟县', '湖北省/孝感市/大悟县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420923', '420900', '420000,420900', '云梦县', '湖北省/孝感市/云梦县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420981', '420900', '420000,420900', '应城市', '湖北省/孝感市/应城市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420982', '420900', '420000,420900', '安陆市', '湖北省/孝感市/安陆市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('420984', '420900', '420000,420900', '汉川市', '湖北省/孝感市/汉川市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421000', '420000', '420000', '荆州市', '湖北省/荆州市', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421001', '421000', '420000,421000', '市辖区', '湖北省/荆州市/市辖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421002', '421000', '420000,421000', '沙市区', '湖北省/荆州市/沙市区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421003', '421000', '420000,421000', '荆州区', '湖北省/荆州市/荆州区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421022', '421000', '420000,421000', '公安县', '湖北省/荆州市/公安县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421023', '421000', '420000,421000', '监利县', '湖北省/荆州市/监利县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421024', '421000', '420000,421000', '江陵县', '湖北省/荆州市/江陵县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421071', '421000', '420000,421000', '荆州经济技术开发区', '湖北省/荆州市/荆州经济技术开发区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421081', '421000', '420000,421000', '石首市', '湖北省/荆州市/石首市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421083', '421000', '420000,421000', '洪湖市', '湖北省/荆州市/洪湖市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421087', '421000', '420000,421000', '松滋市', '湖北省/荆州市/松滋市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421100', '420000', '420000', '黄冈市', '湖北省/黄冈市', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421101', '421100', '420000,421100', '市辖区', '湖北省/黄冈市/市辖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421102', '421100', '420000,421100', '黄州区', '湖北省/黄冈市/黄州区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421121', '421100', '420000,421100', '团风县', '湖北省/黄冈市/团风县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421122', '421100', '420000,421100', '红安县', '湖北省/黄冈市/红安县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421123', '421100', '420000,421100', '罗田县', '湖北省/黄冈市/罗田县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421124', '421100', '420000,421100', '英山县', '湖北省/黄冈市/英山县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421125', '421100', '420000,421100', '浠水县', '湖北省/黄冈市/浠水县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421126', '421100', '420000,421100', '蕲春县', '湖北省/黄冈市/蕲春县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421127', '421100', '420000,421100', '黄梅县', '湖北省/黄冈市/黄梅县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421171', '421100', '420000,421100', '龙感湖管理区', '湖北省/黄冈市/龙感湖管理区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421181', '421100', '420000,421100', '麻城市', '湖北省/黄冈市/麻城市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421182', '421100', '420000,421100', '武穴市', '湖北省/黄冈市/武穴市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421200', '420000', '420000', '咸宁市', '湖北省/咸宁市', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421201', '421200', '420000,421200', '市辖区', '湖北省/咸宁市/市辖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421202', '421200', '420000,421200', '咸安区', '湖北省/咸宁市/咸安区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421221', '421200', '420000,421200', '嘉鱼县', '湖北省/咸宁市/嘉鱼县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421222', '421200', '420000,421200', '通城县', '湖北省/咸宁市/通城县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421223', '421200', '420000,421200', '崇阳县', '湖北省/咸宁市/崇阳县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421224', '421200', '420000,421200', '通山县', '湖北省/咸宁市/通山县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421281', '421200', '420000,421200', '赤壁市', '湖北省/咸宁市/赤壁市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421300', '420000', '420000', '随州市', '湖北省/随州市', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421301', '421300', '420000,421300', '市辖区', '湖北省/随州市/市辖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421303', '421300', '420000,421300', '曾都区', '湖北省/随州市/曾都区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421321', '421300', '420000,421300', '随县', '湖北省/随州市/随县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('421381', '421300', '420000,421300', '广水市', '湖北省/随州市/广水市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('422800', '420000', '420000', '恩施土家族苗族自治州', '湖北省/恩施土家族苗族自治州', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('422801', '422800', '420000,422800', '恩施市', '湖北省/恩施土家族苗族自治州/恩施市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('422802', '422800', '420000,422800', '利川市', '湖北省/恩施土家族苗族自治州/利川市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('422822', '422800', '420000,422800', '建始县', '湖北省/恩施土家族苗族自治州/建始县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('422823', '422800', '420000,422800', '巴东县', '湖北省/恩施土家族苗族自治州/巴东县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('422825', '422800', '420000,422800', '宣恩县', '湖北省/恩施土家族苗族自治州/宣恩县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('422826', '422800', '420000,422800', '咸丰县', '湖北省/恩施土家族苗族自治州/咸丰县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('422827', '422800', '420000,422800', '来凤县', '湖北省/恩施土家族苗族自治州/来凤县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('422828', '422800', '420000,422800', '鹤峰县', '湖北省/恩施土家族苗族自治州/鹤峰县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('429000', '420000', '420000', '省直辖县级行政区划', '湖北省/省直辖县级行政区划', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('429004', '429000', '420000,429000', '仙桃市', '湖北省/省直辖县级行政区划/仙桃市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('429005', '429000', '420000,429000', '潜江市', '湖北省/省直辖县级行政区划/潜江市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('429006', '429000', '420000,429000', '天门市', '湖北省/省直辖县级行政区划/天门市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('429021', '429000', '420000,429000', '神农架林区', '湖北省/省直辖县级行政区划/神农架林区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430000', '86', '', '湖南省', '湖南省', 1, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430100', '430000', '430000', '长沙市', '湖南省/长沙市', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430101', '430100', '430000,430100', '市辖区', '湖南省/长沙市/市辖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430102', '430100', '430000,430100', '芙蓉区', '湖南省/长沙市/芙蓉区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430103', '430100', '430000,430100', '天心区', '湖南省/长沙市/天心区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430104', '430100', '430000,430100', '岳麓区', '湖南省/长沙市/岳麓区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430105', '430100', '430000,430100', '开福区', '湖南省/长沙市/开福区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430111', '430100', '430000,430100', '雨花区', '湖南省/长沙市/雨花区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430112', '430100', '430000,430100', '望城区', '湖南省/长沙市/望城区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430121', '430100', '430000,430100', '长沙县', '湖南省/长沙市/长沙县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430181', '430100', '430000,430100', '浏阳市', '湖南省/长沙市/浏阳市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430182', '430100', '430000,430100', '宁乡市', '湖南省/长沙市/宁乡市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430200', '430000', '430000', '株洲市', '湖南省/株洲市', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430201', '430200', '430000,430200', '市辖区', '湖南省/株洲市/市辖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430202', '430200', '430000,430200', '荷塘区', '湖南省/株洲市/荷塘区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430203', '430200', '430000,430200', '芦淞区', '湖南省/株洲市/芦淞区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430204', '430200', '430000,430200', '石峰区', '湖南省/株洲市/石峰区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430211', '430200', '430000,430200', '天元区', '湖南省/株洲市/天元区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430212', '430200', '430000,430200', '渌口区', '湖南省/株洲市/渌口区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430223', '430200', '430000,430200', '攸县', '湖南省/株洲市/攸县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430224', '430200', '430000,430200', '茶陵县', '湖南省/株洲市/茶陵县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430225', '430200', '430000,430200', '炎陵县', '湖南省/株洲市/炎陵县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430271', '430200', '430000,430200', '云龙示范区', '湖南省/株洲市/云龙示范区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430281', '430200', '430000,430200', '醴陵市', '湖南省/株洲市/醴陵市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430300', '430000', '430000', '湘潭市', '湖南省/湘潭市', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430301', '430300', '430000,430300', '市辖区', '湖南省/湘潭市/市辖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430302', '430300', '430000,430300', '雨湖区', '湖南省/湘潭市/雨湖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430304', '430300', '430000,430300', '岳塘区', '湖南省/湘潭市/岳塘区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430321', '430300', '430000,430300', '湘潭县', '湖南省/湘潭市/湘潭县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430371', '430300', '430000,430300', '湖南湘潭高新技术产业园区', '湖南省/湘潭市/湖南湘潭高新技术产业园区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430372', '430300', '430000,430300', '湘潭昭山示范区', '湖南省/湘潭市/湘潭昭山示范区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430373', '430300', '430000,430300', '湘潭九华示范区', '湖南省/湘潭市/湘潭九华示范区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430381', '430300', '430000,430300', '湘乡市', '湖南省/湘潭市/湘乡市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430382', '430300', '430000,430300', '韶山市', '湖南省/湘潭市/韶山市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430400', '430000', '430000', '衡阳市', '湖南省/衡阳市', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430401', '430400', '430000,430400', '市辖区', '湖南省/衡阳市/市辖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430405', '430400', '430000,430400', '珠晖区', '湖南省/衡阳市/珠晖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430406', '430400', '430000,430400', '雁峰区', '湖南省/衡阳市/雁峰区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430407', '430400', '430000,430400', '石鼓区', '湖南省/衡阳市/石鼓区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430408', '430400', '430000,430400', '蒸湘区', '湖南省/衡阳市/蒸湘区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430412', '430400', '430000,430400', '南岳区', '湖南省/衡阳市/南岳区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430421', '430400', '430000,430400', '衡阳县', '湖南省/衡阳市/衡阳县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430422', '430400', '430000,430400', '衡南县', '湖南省/衡阳市/衡南县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430423', '430400', '430000,430400', '衡山县', '湖南省/衡阳市/衡山县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430424', '430400', '430000,430400', '衡东县', '湖南省/衡阳市/衡东县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430426', '430400', '430000,430400', '祁东县', '湖南省/衡阳市/祁东县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430471', '430400', '430000,430400', '衡阳综合保税区', '湖南省/衡阳市/衡阳综合保税区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430472', '430400', '430000,430400', '湖南衡阳高新技术产业园区', '湖南省/衡阳市/湖南衡阳高新技术产业园区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430473', '430400', '430000,430400', '湖南衡阳松木经济开发区', '湖南省/衡阳市/湖南衡阳松木经济开发区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430481', '430400', '430000,430400', '耒阳市', '湖南省/衡阳市/耒阳市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430482', '430400', '430000,430400', '常宁市', '湖南省/衡阳市/常宁市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430500', '430000', '430000', '邵阳市', '湖南省/邵阳市', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430501', '430500', '430000,430500', '市辖区', '湖南省/邵阳市/市辖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430502', '430500', '430000,430500', '双清区', '湖南省/邵阳市/双清区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430503', '430500', '430000,430500', '大祥区', '湖南省/邵阳市/大祥区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430511', '430500', '430000,430500', '北塔区', '湖南省/邵阳市/北塔区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430522', '430500', '430000,430500', '新邵县', '湖南省/邵阳市/新邵县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430523', '430500', '430000,430500', '邵阳县', '湖南省/邵阳市/邵阳县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430524', '430500', '430000,430500', '隆回县', '湖南省/邵阳市/隆回县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430525', '430500', '430000,430500', '洞口县', '湖南省/邵阳市/洞口县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430527', '430500', '430000,430500', '绥宁县', '湖南省/邵阳市/绥宁县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430528', '430500', '430000,430500', '新宁县', '湖南省/邵阳市/新宁县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430529', '430500', '430000,430500', '城步苗族自治县', '湖南省/邵阳市/城步苗族自治县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430581', '430500', '430000,430500', '武冈市', '湖南省/邵阳市/武冈市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430582', '430500', '430000,430500', '邵东市', '湖南省/邵阳市/邵东市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430600', '430000', '430000', '岳阳市', '湖南省/岳阳市', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430601', '430600', '430000,430600', '市辖区', '湖南省/岳阳市/市辖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430602', '430600', '430000,430600', '岳阳楼区', '湖南省/岳阳市/岳阳楼区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430603', '430600', '430000,430600', '云溪区', '湖南省/岳阳市/云溪区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430611', '430600', '430000,430600', '君山区', '湖南省/岳阳市/君山区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430621', '430600', '430000,430600', '岳阳县', '湖南省/岳阳市/岳阳县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430623', '430600', '430000,430600', '华容县', '湖南省/岳阳市/华容县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430624', '430600', '430000,430600', '湘阴县', '湖南省/岳阳市/湘阴县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430626', '430600', '430000,430600', '平江县', '湖南省/岳阳市/平江县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430671', '430600', '430000,430600', '岳阳市屈原管理区', '湖南省/岳阳市/岳阳市屈原管理区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430681', '430600', '430000,430600', '汨罗市', '湖南省/岳阳市/汨罗市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430682', '430600', '430000,430600', '临湘市', '湖南省/岳阳市/临湘市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430700', '430000', '430000', '常德市', '湖南省/常德市', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430701', '430700', '430000,430700', '市辖区', '湖南省/常德市/市辖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430702', '430700', '430000,430700', '武陵区', '湖南省/常德市/武陵区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430703', '430700', '430000,430700', '鼎城区', '湖南省/常德市/鼎城区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430721', '430700', '430000,430700', '安乡县', '湖南省/常德市/安乡县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430722', '430700', '430000,430700', '汉寿县', '湖南省/常德市/汉寿县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430723', '430700', '430000,430700', '澧县', '湖南省/常德市/澧县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430724', '430700', '430000,430700', '临澧县', '湖南省/常德市/临澧县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430725', '430700', '430000,430700', '桃源县', '湖南省/常德市/桃源县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430726', '430700', '430000,430700', '石门县', '湖南省/常德市/石门县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430771', '430700', '430000,430700', '常德市西洞庭管理区', '湖南省/常德市/常德市西洞庭管理区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430781', '430700', '430000,430700', '津市市', '湖南省/常德市/津市市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430800', '430000', '430000', '张家界市', '湖南省/张家界市', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430801', '430800', '430000,430800', '市辖区', '湖南省/张家界市/市辖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430802', '430800', '430000,430800', '永定区', '湖南省/张家界市/永定区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430811', '430800', '430000,430800', '武陵源区', '湖南省/张家界市/武陵源区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430821', '430800', '430000,430800', '慈利县', '湖南省/张家界市/慈利县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430822', '430800', '430000,430800', '桑植县', '湖南省/张家界市/桑植县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430900', '430000', '430000', '益阳市', '湖南省/益阳市', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430901', '430900', '430000,430900', '市辖区', '湖南省/益阳市/市辖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430902', '430900', '430000,430900', '资阳区', '湖南省/益阳市/资阳区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430903', '430900', '430000,430900', '赫山区', '湖南省/益阳市/赫山区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430921', '430900', '430000,430900', '南县', '湖南省/益阳市/南县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430922', '430900', '430000,430900', '桃江县', '湖南省/益阳市/桃江县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430923', '430900', '430000,430900', '安化县', '湖南省/益阳市/安化县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430971', '430900', '430000,430900', '益阳市大通湖管理区', '湖南省/益阳市/益阳市大通湖管理区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430972', '430900', '430000,430900', '湖南益阳高新技术产业园区', '湖南省/益阳市/湖南益阳高新技术产业园区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('430981', '430900', '430000,430900', '沅江市', '湖南省/益阳市/沅江市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431000', '430000', '430000', '郴州市', '湖南省/郴州市', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431001', '431000', '430000,431000', '市辖区', '湖南省/郴州市/市辖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431002', '431000', '430000,431000', '北湖区', '湖南省/郴州市/北湖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431003', '431000', '430000,431000', '苏仙区', '湖南省/郴州市/苏仙区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431021', '431000', '430000,431000', '桂阳县', '湖南省/郴州市/桂阳县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431022', '431000', '430000,431000', '宜章县', '湖南省/郴州市/宜章县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431023', '431000', '430000,431000', '永兴县', '湖南省/郴州市/永兴县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431024', '431000', '430000,431000', '嘉禾县', '湖南省/郴州市/嘉禾县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431025', '431000', '430000,431000', '临武县', '湖南省/郴州市/临武县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431026', '431000', '430000,431000', '汝城县', '湖南省/郴州市/汝城县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431027', '431000', '430000,431000', '桂东县', '湖南省/郴州市/桂东县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431028', '431000', '430000,431000', '安仁县', '湖南省/郴州市/安仁县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431081', '431000', '430000,431000', '资兴市', '湖南省/郴州市/资兴市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431100', '430000', '430000', '永州市', '湖南省/永州市', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431101', '431100', '430000,431100', '市辖区', '湖南省/永州市/市辖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431102', '431100', '430000,431100', '零陵区', '湖南省/永州市/零陵区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431103', '431100', '430000,431100', '冷水滩区', '湖南省/永州市/冷水滩区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431121', '431100', '430000,431100', '祁阳县', '湖南省/永州市/祁阳县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431122', '431100', '430000,431100', '东安县', '湖南省/永州市/东安县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431123', '431100', '430000,431100', '双牌县', '湖南省/永州市/双牌县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431124', '431100', '430000,431100', '道县', '湖南省/永州市/道县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431125', '431100', '430000,431100', '江永县', '湖南省/永州市/江永县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431126', '431100', '430000,431100', '宁远县', '湖南省/永州市/宁远县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431127', '431100', '430000,431100', '蓝山县', '湖南省/永州市/蓝山县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431128', '431100', '430000,431100', '新田县', '湖南省/永州市/新田县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431129', '431100', '430000,431100', '江华瑶族自治县', '湖南省/永州市/江华瑶族自治县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431171', '431100', '430000,431100', '永州经济技术开发区', '湖南省/永州市/永州经济技术开发区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431172', '431100', '430000,431100', '永州市金洞管理区', '湖南省/永州市/永州市金洞管理区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431173', '431100', '430000,431100', '永州市回龙圩管理区', '湖南省/永州市/永州市回龙圩管理区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431200', '430000', '430000', '怀化市', '湖南省/怀化市', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431201', '431200', '430000,431200', '市辖区', '湖南省/怀化市/市辖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431202', '431200', '430000,431200', '鹤城区', '湖南省/怀化市/鹤城区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431221', '431200', '430000,431200', '中方县', '湖南省/怀化市/中方县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431222', '431200', '430000,431200', '沅陵县', '湖南省/怀化市/沅陵县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431223', '431200', '430000,431200', '辰溪县', '湖南省/怀化市/辰溪县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431224', '431200', '430000,431200', '溆浦县', '湖南省/怀化市/溆浦县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431225', '431200', '430000,431200', '会同县', '湖南省/怀化市/会同县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431226', '431200', '430000,431200', '麻阳苗族自治县', '湖南省/怀化市/麻阳苗族自治县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431227', '431200', '430000,431200', '新晃侗族自治县', '湖南省/怀化市/新晃侗族自治县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431228', '431200', '430000,431200', '芷江侗族自治县', '湖南省/怀化市/芷江侗族自治县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431229', '431200', '430000,431200', '靖州苗族侗族自治县', '湖南省/怀化市/靖州苗族侗族自治县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431230', '431200', '430000,431200', '通道侗族自治县', '湖南省/怀化市/通道侗族自治县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431271', '431200', '430000,431200', '怀化市洪江管理区', '湖南省/怀化市/怀化市洪江管理区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431281', '431200', '430000,431200', '洪江市', '湖南省/怀化市/洪江市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431300', '430000', '430000', '娄底市', '湖南省/娄底市', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431301', '431300', '430000,431300', '市辖区', '湖南省/娄底市/市辖区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431302', '431300', '430000,431300', '娄星区', '湖南省/娄底市/娄星区', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431321', '431300', '430000,431300', '双峰县', '湖南省/娄底市/双峰县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431322', '431300', '430000,431300', '新化县', '湖南省/娄底市/新化县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431381', '431300', '430000,431300', '冷水江市', '湖南省/娄底市/冷水江市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('431382', '431300', '430000,431300', '涟源市', '湖南省/娄底市/涟源市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('433100', '430000', '430000', '湘西土家族苗族自治州', '湖南省/湘西土家族苗族自治州', 2, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('433101', '433100', '430000,433100', '吉首市', '湖南省/湘西土家族苗族自治州/吉首市', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('433122', '433100', '430000,433100', '泸溪县', '湖南省/湘西土家族苗族自治州/泸溪县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('433123', '433100', '430000,433100', '凤凰县', '湖南省/湘西土家族苗族自治州/凤凰县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('433124', '433100', '430000,433100', '花垣县', '湖南省/湘西土家族苗族自治州/花垣县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('433125', '433100', '430000,433100', '保靖县', '湖南省/湘西土家族苗族自治州/保靖县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('433126', '433100', '430000,433100', '古丈县', '湖南省/湘西土家族苗族自治州/古丈县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('433127', '433100', '430000,433100', '永顺县', '湖南省/湘西土家族苗族自治州/永顺县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('433130', '433100', '430000,433100', '龙山县', '湖南省/湘西土家族苗族自治州/龙山县', 3, 'admin', '2022-05-22 20:35:17', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('433173', '433100', '430000,433100', '湖南永顺经济开发区', '湖南省/湘西土家族苗族自治州/湖南永顺经济开发区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440000', '86', '', '广东省', '广东省', 1, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440100', '440000', '440000', '广州市', '广东省/广州市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440101', '440100', '440000,440100', '市辖区', '广东省/广州市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440103', '440100', '440000,440100', '荔湾区', '广东省/广州市/荔湾区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440104', '440100', '440000,440100', '越秀区', '广东省/广州市/越秀区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440105', '440100', '440000,440100', '海珠区', '广东省/广州市/海珠区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440106', '440100', '440000,440100', '天河区', '广东省/广州市/天河区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440111', '440100', '440000,440100', '白云区', '广东省/广州市/白云区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440112', '440100', '440000,440100', '黄埔区', '广东省/广州市/黄埔区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440113', '440100', '440000,440100', '番禺区', '广东省/广州市/番禺区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440114', '440100', '440000,440100', '花都区', '广东省/广州市/花都区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440115', '440100', '440000,440100', '南沙区', '广东省/广州市/南沙区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440117', '440100', '440000,440100', '从化区', '广东省/广州市/从化区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440118', '440100', '440000,440100', '增城区', '广东省/广州市/增城区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440200', '440000', '440000', '韶关市', '广东省/韶关市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440201', '440200', '440000,440200', '市辖区', '广东省/韶关市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440203', '440200', '440000,440200', '武江区', '广东省/韶关市/武江区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440204', '440200', '440000,440200', '浈江区', '广东省/韶关市/浈江区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440205', '440200', '440000,440200', '曲江区', '广东省/韶关市/曲江区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440222', '440200', '440000,440200', '始兴县', '广东省/韶关市/始兴县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440224', '440200', '440000,440200', '仁化县', '广东省/韶关市/仁化县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440229', '440200', '440000,440200', '翁源县', '广东省/韶关市/翁源县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440232', '440200', '440000,440200', '乳源瑶族自治县', '广东省/韶关市/乳源瑶族自治县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440233', '440200', '440000,440200', '新丰县', '广东省/韶关市/新丰县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440281', '440200', '440000,440200', '乐昌市', '广东省/韶关市/乐昌市', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440282', '440200', '440000,440200', '南雄市', '广东省/韶关市/南雄市', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440300', '440000', '440000', '深圳市', '广东省/深圳市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440301', '440300', '440000,440300', '市辖区', '广东省/深圳市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440303', '440300', '440000,440300', '罗湖区', '广东省/深圳市/罗湖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440304', '440300', '440000,440300', '福田区', '广东省/深圳市/福田区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440305', '440300', '440000,440300', '南山区', '广东省/深圳市/南山区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440306', '440300', '440000,440300', '宝安区', '广东省/深圳市/宝安区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440307', '440300', '440000,440300', '龙岗区', '广东省/深圳市/龙岗区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440308', '440300', '440000,440300', '盐田区', '广东省/深圳市/盐田区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440309', '440300', '440000,440300', '龙华区', '广东省/深圳市/龙华区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440310', '440300', '440000,440300', '坪山区', '广东省/深圳市/坪山区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440311', '440300', '440000,440300', '光明区', '广东省/深圳市/光明区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440400', '440000', '440000', '珠海市', '广东省/珠海市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440401', '440400', '440000,440400', '市辖区', '广东省/珠海市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440402', '440400', '440000,440400', '香洲区', '广东省/珠海市/香洲区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440403', '440400', '440000,440400', '斗门区', '广东省/珠海市/斗门区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440404', '440400', '440000,440400', '金湾区', '广东省/珠海市/金湾区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440500', '440000', '440000', '汕头市', '广东省/汕头市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440501', '440500', '440000,440500', '市辖区', '广东省/汕头市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440507', '440500', '440000,440500', '龙湖区', '广东省/汕头市/龙湖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440511', '440500', '440000,440500', '金平区', '广东省/汕头市/金平区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440512', '440500', '440000,440500', '濠江区', '广东省/汕头市/濠江区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440513', '440500', '440000,440500', '潮阳区', '广东省/汕头市/潮阳区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440514', '440500', '440000,440500', '潮南区', '广东省/汕头市/潮南区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440515', '440500', '440000,440500', '澄海区', '广东省/汕头市/澄海区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440523', '440500', '440000,440500', '南澳县', '广东省/汕头市/南澳县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440600', '440000', '440000', '佛山市', '广东省/佛山市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440601', '440600', '440000,440600', '市辖区', '广东省/佛山市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440604', '440600', '440000,440600', '禅城区', '广东省/佛山市/禅城区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440605', '440600', '440000,440600', '南海区', '广东省/佛山市/南海区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440606', '440600', '440000,440600', '顺德区', '广东省/佛山市/顺德区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440607', '440600', '440000,440600', '三水区', '广东省/佛山市/三水区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440608', '440600', '440000,440600', '高明区', '广东省/佛山市/高明区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440700', '440000', '440000', '江门市', '广东省/江门市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440701', '440700', '440000,440700', '市辖区', '广东省/江门市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440703', '440700', '440000,440700', '蓬江区', '广东省/江门市/蓬江区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440704', '440700', '440000,440700', '江海区', '广东省/江门市/江海区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440705', '440700', '440000,440700', '新会区', '广东省/江门市/新会区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440781', '440700', '440000,440700', '台山市', '广东省/江门市/台山市', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440783', '440700', '440000,440700', '开平市', '广东省/江门市/开平市', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440784', '440700', '440000,440700', '鹤山市', '广东省/江门市/鹤山市', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440785', '440700', '440000,440700', '恩平市', '广东省/江门市/恩平市', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440800', '440000', '440000', '湛江市', '广东省/湛江市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440801', '440800', '440000,440800', '市辖区', '广东省/湛江市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440802', '440800', '440000,440800', '赤坎区', '广东省/湛江市/赤坎区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440803', '440800', '440000,440800', '霞山区', '广东省/湛江市/霞山区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440804', '440800', '440000,440800', '坡头区', '广东省/湛江市/坡头区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440811', '440800', '440000,440800', '麻章区', '广东省/湛江市/麻章区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440823', '440800', '440000,440800', '遂溪县', '广东省/湛江市/遂溪县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440825', '440800', '440000,440800', '徐闻县', '广东省/湛江市/徐闻县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440881', '440800', '440000,440800', '廉江市', '广东省/湛江市/廉江市', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440882', '440800', '440000,440800', '雷州市', '广东省/湛江市/雷州市', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440883', '440800', '440000,440800', '吴川市', '广东省/湛江市/吴川市', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440900', '440000', '440000', '茂名市', '广东省/茂名市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440901', '440900', '440000,440900', '市辖区', '广东省/茂名市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440902', '440900', '440000,440900', '茂南区', '广东省/茂名市/茂南区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440904', '440900', '440000,440900', '电白区', '广东省/茂名市/电白区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440981', '440900', '440000,440900', '高州市', '广东省/茂名市/高州市', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440982', '440900', '440000,440900', '化州市', '广东省/茂名市/化州市', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('440983', '440900', '440000,440900', '信宜市', '广东省/茂名市/信宜市', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441200', '440000', '440000', '肇庆市', '广东省/肇庆市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441201', '441200', '440000,441200', '市辖区', '广东省/肇庆市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441202', '441200', '440000,441200', '端州区', '广东省/肇庆市/端州区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441203', '441200', '440000,441200', '鼎湖区', '广东省/肇庆市/鼎湖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441204', '441200', '440000,441200', '高要区', '广东省/肇庆市/高要区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441223', '441200', '440000,441200', '广宁县', '广东省/肇庆市/广宁县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441224', '441200', '440000,441200', '怀集县', '广东省/肇庆市/怀集县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441225', '441200', '440000,441200', '封开县', '广东省/肇庆市/封开县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441226', '441200', '440000,441200', '德庆县', '广东省/肇庆市/德庆县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441284', '441200', '440000,441200', '四会市', '广东省/肇庆市/四会市', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441300', '440000', '440000', '惠州市', '广东省/惠州市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441301', '441300', '440000,441300', '市辖区', '广东省/惠州市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441302', '441300', '440000,441300', '惠城区', '广东省/惠州市/惠城区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441303', '441300', '440000,441300', '惠阳区', '广东省/惠州市/惠阳区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441322', '441300', '440000,441300', '博罗县', '广东省/惠州市/博罗县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441323', '441300', '440000,441300', '惠东县', '广东省/惠州市/惠东县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441324', '441300', '440000,441300', '龙门县', '广东省/惠州市/龙门县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441400', '440000', '440000', '梅州市', '广东省/梅州市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441401', '441400', '440000,441400', '市辖区', '广东省/梅州市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441402', '441400', '440000,441400', '梅江区', '广东省/梅州市/梅江区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441403', '441400', '440000,441400', '梅县区', '广东省/梅州市/梅县区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441422', '441400', '440000,441400', '大埔县', '广东省/梅州市/大埔县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441423', '441400', '440000,441400', '丰顺县', '广东省/梅州市/丰顺县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441424', '441400', '440000,441400', '五华县', '广东省/梅州市/五华县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441426', '441400', '440000,441400', '平远县', '广东省/梅州市/平远县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441427', '441400', '440000,441400', '蕉岭县', '广东省/梅州市/蕉岭县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441481', '441400', '440000,441400', '兴宁市', '广东省/梅州市/兴宁市', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441500', '440000', '440000', '汕尾市', '广东省/汕尾市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441501', '441500', '440000,441500', '市辖区', '广东省/汕尾市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441502', '441500', '440000,441500', '城区', '广东省/汕尾市/城区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441521', '441500', '440000,441500', '海丰县', '广东省/汕尾市/海丰县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441523', '441500', '440000,441500', '陆河县', '广东省/汕尾市/陆河县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441581', '441500', '440000,441500', '陆丰市', '广东省/汕尾市/陆丰市', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441600', '440000', '440000', '河源市', '广东省/河源市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441601', '441600', '440000,441600', '市辖区', '广东省/河源市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441602', '441600', '440000,441600', '源城区', '广东省/河源市/源城区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441621', '441600', '440000,441600', '紫金县', '广东省/河源市/紫金县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441622', '441600', '440000,441600', '龙川县', '广东省/河源市/龙川县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441623', '441600', '440000,441600', '连平县', '广东省/河源市/连平县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441624', '441600', '440000,441600', '和平县', '广东省/河源市/和平县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441625', '441600', '440000,441600', '东源县', '广东省/河源市/东源县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441700', '440000', '440000', '阳江市', '广东省/阳江市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441701', '441700', '440000,441700', '市辖区', '广东省/阳江市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441702', '441700', '440000,441700', '江城区', '广东省/阳江市/江城区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441704', '441700', '440000,441700', '阳东区', '广东省/阳江市/阳东区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441721', '441700', '440000,441700', '阳西县', '广东省/阳江市/阳西县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441781', '441700', '440000,441700', '阳春市', '广东省/阳江市/阳春市', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441800', '440000', '440000', '清远市', '广东省/清远市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441801', '441800', '440000,441800', '市辖区', '广东省/清远市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441802', '441800', '440000,441800', '清城区', '广东省/清远市/清城区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441803', '441800', '440000,441800', '清新区', '广东省/清远市/清新区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441821', '441800', '440000,441800', '佛冈县', '广东省/清远市/佛冈县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441823', '441800', '440000,441800', '阳山县', '广东省/清远市/阳山县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441825', '441800', '440000,441800', '连山壮族瑶族自治县', '广东省/清远市/连山壮族瑶族自治县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441826', '441800', '440000,441800', '连南瑶族自治县', '广东省/清远市/连南瑶族自治县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441881', '441800', '440000,441800', '英德市', '广东省/清远市/英德市', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441882', '441800', '440000,441800', '连州市', '广东省/清远市/连州市', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900', '440000', '440000', '东莞市', '广东省/东莞市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900003', '441900', '440000,441900', '东城街道', '广东省/东莞市/东城街道', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900004', '441900', '440000,441900', '南城街道', '广东省/东莞市/南城街道', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900005', '441900', '440000,441900', '万江街道', '广东省/东莞市/万江街道', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900006', '441900', '440000,441900', '莞城街道', '广东省/东莞市/莞城街道', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900101', '441900', '440000,441900', '石碣镇', '广东省/东莞市/石碣镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900102', '441900', '440000,441900', '石龙镇', '广东省/东莞市/石龙镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900103', '441900', '440000,441900', '茶山镇', '广东省/东莞市/茶山镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900104', '441900', '440000,441900', '石排镇', '广东省/东莞市/石排镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900105', '441900', '440000,441900', '企石镇', '广东省/东莞市/企石镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900106', '441900', '440000,441900', '横沥镇', '广东省/东莞市/横沥镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900107', '441900', '440000,441900', '桥头镇', '广东省/东莞市/桥头镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900108', '441900', '440000,441900', '谢岗镇', '广东省/东莞市/谢岗镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900109', '441900', '440000,441900', '东坑镇', '广东省/东莞市/东坑镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900110', '441900', '440000,441900', '常平镇', '广东省/东莞市/常平镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900111', '441900', '440000,441900', '寮步镇', '广东省/东莞市/寮步镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900112', '441900', '440000,441900', '樟木头镇', '广东省/东莞市/樟木头镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900113', '441900', '440000,441900', '大朗镇', '广东省/东莞市/大朗镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900114', '441900', '440000,441900', '黄江镇', '广东省/东莞市/黄江镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900115', '441900', '440000,441900', '清溪镇', '广东省/东莞市/清溪镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900116', '441900', '440000,441900', '塘厦镇', '广东省/东莞市/塘厦镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900117', '441900', '440000,441900', '凤岗镇', '广东省/东莞市/凤岗镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900118', '441900', '440000,441900', '大岭山镇', '广东省/东莞市/大岭山镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900119', '441900', '440000,441900', '长安镇', '广东省/东莞市/长安镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900121', '441900', '440000,441900', '虎门镇', '广东省/东莞市/虎门镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900122', '441900', '440000,441900', '厚街镇', '广东省/东莞市/厚街镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900123', '441900', '440000,441900', '沙田镇', '广东省/东莞市/沙田镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900124', '441900', '440000,441900', '道滘镇', '广东省/东莞市/道滘镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900125', '441900', '440000,441900', '洪梅镇', '广东省/东莞市/洪梅镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900126', '441900', '440000,441900', '麻涌镇', '广东省/东莞市/麻涌镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900127', '441900', '440000,441900', '望牛墩镇', '广东省/东莞市/望牛墩镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900128', '441900', '440000,441900', '中堂镇', '广东省/东莞市/中堂镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900129', '441900', '440000,441900', '高埗镇', '广东省/东莞市/高埗镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900401', '441900', '440000,441900', '松山湖', '广东省/东莞市/松山湖', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900402', '441900', '440000,441900', '东莞港', '广东省/东莞市/东莞港', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('441900403', '441900', '440000,441900', '东莞生态园', '广东省/东莞市/东莞生态园', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('442000', '440000', '440000', '中山市', '广东省/中山市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('442000001', '442000', '440000,442000', '石岐街道', '广东省/中山市/石岐街道', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('442000002', '442000', '440000,442000', '东区街道', '广东省/中山市/东区街道', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('442000003', '442000', '440000,442000', '中山港街道', '广东省/中山市/中山港街道', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('442000004', '442000', '440000,442000', '西区街道', '广东省/中山市/西区街道', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('442000005', '442000', '440000,442000', '南区街道', '广东省/中山市/南区街道', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('442000006', '442000', '440000,442000', '五桂山街道', '广东省/中山市/五桂山街道', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('442000100', '442000', '440000,442000', '小榄镇', '广东省/中山市/小榄镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('442000101', '442000', '440000,442000', '黄圃镇', '广东省/中山市/黄圃镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('442000102', '442000', '440000,442000', '民众镇', '广东省/中山市/民众镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('442000103', '442000', '440000,442000', '东凤镇', '广东省/中山市/东凤镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('442000104', '442000', '440000,442000', '东升镇', '广东省/中山市/东升镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('442000105', '442000', '440000,442000', '古镇镇', '广东省/中山市/古镇镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('442000106', '442000', '440000,442000', '沙溪镇', '广东省/中山市/沙溪镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('442000107', '442000', '440000,442000', '坦洲镇', '广东省/中山市/坦洲镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('442000108', '442000', '440000,442000', '港口镇', '广东省/中山市/港口镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('442000109', '442000', '440000,442000', '三角镇', '广东省/中山市/三角镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('442000110', '442000', '440000,442000', '横栏镇', '广东省/中山市/横栏镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('442000111', '442000', '440000,442000', '南头镇', '广东省/中山市/南头镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('442000112', '442000', '440000,442000', '阜沙镇', '广东省/中山市/阜沙镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('442000113', '442000', '440000,442000', '南朗镇', '广东省/中山市/南朗镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('442000114', '442000', '440000,442000', '三乡镇', '广东省/中山市/三乡镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('442000115', '442000', '440000,442000', '板芙镇', '广东省/中山市/板芙镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('442000116', '442000', '440000,442000', '大涌镇', '广东省/中山市/大涌镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('442000117', '442000', '440000,442000', '神湾镇', '广东省/中山市/神湾镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('445100', '440000', '440000', '潮州市', '广东省/潮州市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('445101', '445100', '440000,445100', '市辖区', '广东省/潮州市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('445102', '445100', '440000,445100', '湘桥区', '广东省/潮州市/湘桥区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('445103', '445100', '440000,445100', '潮安区', '广东省/潮州市/潮安区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('445122', '445100', '440000,445100', '饶平县', '广东省/潮州市/饶平县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('445200', '440000', '440000', '揭阳市', '广东省/揭阳市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('445201', '445200', '440000,445200', '市辖区', '广东省/揭阳市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('445202', '445200', '440000,445200', '榕城区', '广东省/揭阳市/榕城区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('445203', '445200', '440000,445200', '揭东区', '广东省/揭阳市/揭东区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('445222', '445200', '440000,445200', '揭西县', '广东省/揭阳市/揭西县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('445224', '445200', '440000,445200', '惠来县', '广东省/揭阳市/惠来县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('445281', '445200', '440000,445200', '普宁市', '广东省/揭阳市/普宁市', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('445300', '440000', '440000', '云浮市', '广东省/云浮市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('445301', '445300', '440000,445300', '市辖区', '广东省/云浮市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('445302', '445300', '440000,445300', '云城区', '广东省/云浮市/云城区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('445303', '445300', '440000,445300', '云安区', '广东省/云浮市/云安区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('445321', '445300', '440000,445300', '新兴县', '广东省/云浮市/新兴县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('445322', '445300', '440000,445300', '郁南县', '广东省/云浮市/郁南县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('445381', '445300', '440000,445300', '罗定市', '广东省/云浮市/罗定市', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450000', '86', '', '广西壮族自治区', '广西壮族自治区', 1, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450100', '450000', '450000', '南宁市', '广西壮族自治区/南宁市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450101', '450100', '450000,450100', '市辖区', '广西壮族自治区/南宁市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450102', '450100', '450000,450100', '兴宁区', '广西壮族自治区/南宁市/兴宁区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450103', '450100', '450000,450100', '青秀区', '广西壮族自治区/南宁市/青秀区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450105', '450100', '450000,450100', '江南区', '广西壮族自治区/南宁市/江南区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450107', '450100', '450000,450100', '西乡塘区', '广西壮族自治区/南宁市/西乡塘区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450108', '450100', '450000,450100', '良庆区', '广西壮族自治区/南宁市/良庆区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450109', '450100', '450000,450100', '邕宁区', '广西壮族自治区/南宁市/邕宁区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450110', '450100', '450000,450100', '武鸣区', '广西壮族自治区/南宁市/武鸣区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450123', '450100', '450000,450100', '隆安县', '广西壮族自治区/南宁市/隆安县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450124', '450100', '450000,450100', '马山县', '广西壮族自治区/南宁市/马山县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450125', '450100', '450000,450100', '上林县', '广西壮族自治区/南宁市/上林县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450126', '450100', '450000,450100', '宾阳县', '广西壮族自治区/南宁市/宾阳县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450127', '450100', '450000,450100', '横县', '广西壮族自治区/南宁市/横县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450200', '450000', '450000', '柳州市', '广西壮族自治区/柳州市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450201', '450200', '450000,450200', '市辖区', '广西壮族自治区/柳州市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450202', '450200', '450000,450200', '城中区', '广西壮族自治区/柳州市/城中区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450203', '450200', '450000,450200', '鱼峰区', '广西壮族自治区/柳州市/鱼峰区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450204', '450200', '450000,450200', '柳南区', '广西壮族自治区/柳州市/柳南区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450205', '450200', '450000,450200', '柳北区', '广西壮族自治区/柳州市/柳北区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450206', '450200', '450000,450200', '柳江区', '广西壮族自治区/柳州市/柳江区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450222', '450200', '450000,450200', '柳城县', '广西壮族自治区/柳州市/柳城县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450223', '450200', '450000,450200', '鹿寨县', '广西壮族自治区/柳州市/鹿寨县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450224', '450200', '450000,450200', '融安县', '广西壮族自治区/柳州市/融安县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450225', '450200', '450000,450200', '融水苗族自治县', '广西壮族自治区/柳州市/融水苗族自治县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450226', '450200', '450000,450200', '三江侗族自治县', '广西壮族自治区/柳州市/三江侗族自治县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450300', '450000', '450000', '桂林市', '广西壮族自治区/桂林市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450301', '450300', '450000,450300', '市辖区', '广西壮族自治区/桂林市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450302', '450300', '450000,450300', '秀峰区', '广西壮族自治区/桂林市/秀峰区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450303', '450300', '450000,450300', '叠彩区', '广西壮族自治区/桂林市/叠彩区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450304', '450300', '450000,450300', '象山区', '广西壮族自治区/桂林市/象山区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450305', '450300', '450000,450300', '七星区', '广西壮族自治区/桂林市/七星区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450311', '450300', '450000,450300', '雁山区', '广西壮族自治区/桂林市/雁山区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450312', '450300', '450000,450300', '临桂区', '广西壮族自治区/桂林市/临桂区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450321', '450300', '450000,450300', '阳朔县', '广西壮族自治区/桂林市/阳朔县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450323', '450300', '450000,450300', '灵川县', '广西壮族自治区/桂林市/灵川县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450324', '450300', '450000,450300', '全州县', '广西壮族自治区/桂林市/全州县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450325', '450300', '450000,450300', '兴安县', '广西壮族自治区/桂林市/兴安县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450326', '450300', '450000,450300', '永福县', '广西壮族自治区/桂林市/永福县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450327', '450300', '450000,450300', '灌阳县', '广西壮族自治区/桂林市/灌阳县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450328', '450300', '450000,450300', '龙胜各族自治县', '广西壮族自治区/桂林市/龙胜各族自治县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450329', '450300', '450000,450300', '资源县', '广西壮族自治区/桂林市/资源县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450330', '450300', '450000,450300', '平乐县', '广西壮族自治区/桂林市/平乐县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450332', '450300', '450000,450300', '恭城瑶族自治县', '广西壮族自治区/桂林市/恭城瑶族自治县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450381', '450300', '450000,450300', '荔浦市', '广西壮族自治区/桂林市/荔浦市', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450400', '450000', '450000', '梧州市', '广西壮族自治区/梧州市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450401', '450400', '450000,450400', '市辖区', '广西壮族自治区/梧州市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450403', '450400', '450000,450400', '万秀区', '广西壮族自治区/梧州市/万秀区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450405', '450400', '450000,450400', '长洲区', '广西壮族自治区/梧州市/长洲区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450406', '450400', '450000,450400', '龙圩区', '广西壮族自治区/梧州市/龙圩区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450421', '450400', '450000,450400', '苍梧县', '广西壮族自治区/梧州市/苍梧县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450422', '450400', '450000,450400', '藤县', '广西壮族自治区/梧州市/藤县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450423', '450400', '450000,450400', '蒙山县', '广西壮族自治区/梧州市/蒙山县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450481', '450400', '450000,450400', '岑溪市', '广西壮族自治区/梧州市/岑溪市', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450500', '450000', '450000', '北海市', '广西壮族自治区/北海市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450501', '450500', '450000,450500', '市辖区', '广西壮族自治区/北海市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450502', '450500', '450000,450500', '海城区', '广西壮族自治区/北海市/海城区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450503', '450500', '450000,450500', '银海区', '广西壮族自治区/北海市/银海区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450512', '450500', '450000,450500', '铁山港区', '广西壮族自治区/北海市/铁山港区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450521', '450500', '450000,450500', '合浦县', '广西壮族自治区/北海市/合浦县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450600', '450000', '450000', '防城港市', '广西壮族自治区/防城港市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450601', '450600', '450000,450600', '市辖区', '广西壮族自治区/防城港市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450602', '450600', '450000,450600', '港口区', '广西壮族自治区/防城港市/港口区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450603', '450600', '450000,450600', '防城区', '广西壮族自治区/防城港市/防城区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450621', '450600', '450000,450600', '上思县', '广西壮族自治区/防城港市/上思县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450681', '450600', '450000,450600', '东兴市', '广西壮族自治区/防城港市/东兴市', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450700', '450000', '450000', '钦州市', '广西壮族自治区/钦州市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450701', '450700', '450000,450700', '市辖区', '广西壮族自治区/钦州市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450702', '450700', '450000,450700', '钦南区', '广西壮族自治区/钦州市/钦南区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450703', '450700', '450000,450700', '钦北区', '广西壮族自治区/钦州市/钦北区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450721', '450700', '450000,450700', '灵山县', '广西壮族自治区/钦州市/灵山县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450722', '450700', '450000,450700', '浦北县', '广西壮族自治区/钦州市/浦北县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450800', '450000', '450000', '贵港市', '广西壮族自治区/贵港市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450801', '450800', '450000,450800', '市辖区', '广西壮族自治区/贵港市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450802', '450800', '450000,450800', '港北区', '广西壮族自治区/贵港市/港北区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450803', '450800', '450000,450800', '港南区', '广西壮族自治区/贵港市/港南区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450804', '450800', '450000,450800', '覃塘区', '广西壮族自治区/贵港市/覃塘区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450821', '450800', '450000,450800', '平南县', '广西壮族自治区/贵港市/平南县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450881', '450800', '450000,450800', '桂平市', '广西壮族自治区/贵港市/桂平市', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450900', '450000', '450000', '玉林市', '广西壮族自治区/玉林市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450901', '450900', '450000,450900', '市辖区', '广西壮族自治区/玉林市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450902', '450900', '450000,450900', '玉州区', '广西壮族自治区/玉林市/玉州区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450903', '450900', '450000,450900', '福绵区', '广西壮族自治区/玉林市/福绵区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450921', '450900', '450000,450900', '容县', '广西壮族自治区/玉林市/容县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450922', '450900', '450000,450900', '陆川县', '广西壮族自治区/玉林市/陆川县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450923', '450900', '450000,450900', '博白县', '广西壮族自治区/玉林市/博白县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450924', '450900', '450000,450900', '兴业县', '广西壮族自治区/玉林市/兴业县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('450981', '450900', '450000,450900', '北流市', '广西壮族自治区/玉林市/北流市', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451000', '450000', '450000', '百色市', '广西壮族自治区/百色市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451001', '451000', '450000,451000', '市辖区', '广西壮族自治区/百色市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451002', '451000', '450000,451000', '右江区', '广西壮族自治区/百色市/右江区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451003', '451000', '450000,451000', '田阳区', '广西壮族自治区/百色市/田阳区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451022', '451000', '450000,451000', '田东县', '广西壮族自治区/百色市/田东县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451023', '451000', '450000,451000', '平果县', '广西壮族自治区/百色市/平果县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451024', '451000', '450000,451000', '德保县', '广西壮族自治区/百色市/德保县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451026', '451000', '450000,451000', '那坡县', '广西壮族自治区/百色市/那坡县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451027', '451000', '450000,451000', '凌云县', '广西壮族自治区/百色市/凌云县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451028', '451000', '450000,451000', '乐业县', '广西壮族自治区/百色市/乐业县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451029', '451000', '450000,451000', '田林县', '广西壮族自治区/百色市/田林县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451030', '451000', '450000,451000', '西林县', '广西壮族自治区/百色市/西林县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451031', '451000', '450000,451000', '隆林各族自治县', '广西壮族自治区/百色市/隆林各族自治县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451081', '451000', '450000,451000', '靖西市', '广西壮族自治区/百色市/靖西市', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451100', '450000', '450000', '贺州市', '广西壮族自治区/贺州市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451101', '451100', '450000,451100', '市辖区', '广西壮族自治区/贺州市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451102', '451100', '450000,451100', '八步区', '广西壮族自治区/贺州市/八步区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451103', '451100', '450000,451100', '平桂区', '广西壮族自治区/贺州市/平桂区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451121', '451100', '450000,451100', '昭平县', '广西壮族自治区/贺州市/昭平县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451122', '451100', '450000,451100', '钟山县', '广西壮族自治区/贺州市/钟山县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451123', '451100', '450000,451100', '富川瑶族自治县', '广西壮族自治区/贺州市/富川瑶族自治县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451200', '450000', '450000', '河池市', '广西壮族自治区/河池市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451201', '451200', '450000,451200', '市辖区', '广西壮族自治区/河池市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451202', '451200', '450000,451200', '金城江区', '广西壮族自治区/河池市/金城江区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451203', '451200', '450000,451200', '宜州区', '广西壮族自治区/河池市/宜州区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451221', '451200', '450000,451200', '南丹县', '广西壮族自治区/河池市/南丹县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451222', '451200', '450000,451200', '天峨县', '广西壮族自治区/河池市/天峨县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451223', '451200', '450000,451200', '凤山县', '广西壮族自治区/河池市/凤山县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451224', '451200', '450000,451200', '东兰县', '广西壮族自治区/河池市/东兰县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451225', '451200', '450000,451200', '罗城仫佬族自治县', '广西壮族自治区/河池市/罗城仫佬族自治县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451226', '451200', '450000,451200', '环江毛南族自治县', '广西壮族自治区/河池市/环江毛南族自治县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451227', '451200', '450000,451200', '巴马瑶族自治县', '广西壮族自治区/河池市/巴马瑶族自治县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451228', '451200', '450000,451200', '都安瑶族自治县', '广西壮族自治区/河池市/都安瑶族自治县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451229', '451200', '450000,451200', '大化瑶族自治县', '广西壮族自治区/河池市/大化瑶族自治县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451300', '450000', '450000', '来宾市', '广西壮族自治区/来宾市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451301', '451300', '450000,451300', '市辖区', '广西壮族自治区/来宾市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451302', '451300', '450000,451300', '兴宾区', '广西壮族自治区/来宾市/兴宾区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451321', '451300', '450000,451300', '忻城县', '广西壮族自治区/来宾市/忻城县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451322', '451300', '450000,451300', '象州县', '广西壮族自治区/来宾市/象州县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451323', '451300', '450000,451300', '武宣县', '广西壮族自治区/来宾市/武宣县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451324', '451300', '450000,451300', '金秀瑶族自治县', '广西壮族自治区/来宾市/金秀瑶族自治县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451381', '451300', '450000,451300', '合山市', '广西壮族自治区/来宾市/合山市', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451400', '450000', '450000', '崇左市', '广西壮族自治区/崇左市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451401', '451400', '450000,451400', '市辖区', '广西壮族自治区/崇左市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451402', '451400', '450000,451400', '江州区', '广西壮族自治区/崇左市/江州区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451421', '451400', '450000,451400', '扶绥县', '广西壮族自治区/崇左市/扶绥县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451422', '451400', '450000,451400', '宁明县', '广西壮族自治区/崇左市/宁明县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451423', '451400', '450000,451400', '龙州县', '广西壮族自治区/崇左市/龙州县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451424', '451400', '450000,451400', '大新县', '广西壮族自治区/崇左市/大新县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451425', '451400', '450000,451400', '天等县', '广西壮族自治区/崇左市/天等县', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('451481', '451400', '450000,451400', '凭祥市', '广西壮族自治区/崇左市/凭祥市', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460000', '86', '', '海南省', '海南省', 1, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460100', '460000', '460000', '海口市', '海南省/海口市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460101', '460100', '460000,460100', '市辖区', '海南省/海口市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460105', '460100', '460000,460100', '秀英区', '海南省/海口市/秀英区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460106', '460100', '460000,460100', '龙华区', '海南省/海口市/龙华区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460107', '460100', '460000,460100', '琼山区', '海南省/海口市/琼山区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460108', '460100', '460000,460100', '美兰区', '海南省/海口市/美兰区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460200', '460000', '460000', '三亚市', '海南省/三亚市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460201', '460200', '460000,460200', '市辖区', '海南省/三亚市/市辖区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460202', '460200', '460000,460200', '海棠区', '海南省/三亚市/海棠区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460203', '460200', '460000,460200', '吉阳区', '海南省/三亚市/吉阳区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460204', '460200', '460000,460200', '天涯区', '海南省/三亚市/天涯区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460205', '460200', '460000,460200', '崖州区', '海南省/三亚市/崖州区', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460300', '460000', '460000', '三沙市', '海南省/三沙市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460321', '460300', '460000,460300', '西沙群岛', '海南省/三沙市/西沙群岛', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460322', '460300', '460000,460300', '南沙群岛', '海南省/三沙市/南沙群岛', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460323', '460300', '460000,460300', '中沙群岛的岛礁及其海域', '海南省/三沙市/中沙群岛的岛礁及其海域', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460400', '460000', '460000', '儋州市', '海南省/儋州市', 2, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460400100', '460400', '460000,460400', '那大镇', '海南省/儋州市/那大镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460400101', '460400', '460000,460400', '和庆镇', '海南省/儋州市/和庆镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460400102', '460400', '460000,460400', '南丰镇', '海南省/儋州市/南丰镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460400103', '460400', '460000,460400', '大成镇', '海南省/儋州市/大成镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460400104', '460400', '460000,460400', '雅星镇', '海南省/儋州市/雅星镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460400105', '460400', '460000,460400', '兰洋镇', '海南省/儋州市/兰洋镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460400106', '460400', '460000,460400', '光村镇', '海南省/儋州市/光村镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460400107', '460400', '460000,460400', '木棠镇', '海南省/儋州市/木棠镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460400108', '460400', '460000,460400', '海头镇', '海南省/儋州市/海头镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460400109', '460400', '460000,460400', '峨蔓镇', '海南省/儋州市/峨蔓镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460400111', '460400', '460000,460400', '王五镇', '海南省/儋州市/王五镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460400112', '460400', '460000,460400', '白马井镇', '海南省/儋州市/白马井镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460400113', '460400', '460000,460400', '中和镇', '海南省/儋州市/中和镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460400114', '460400', '460000,460400', '排浦镇', '海南省/儋州市/排浦镇', 3, 'admin', '2022-05-22 20:35:18', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460400115', '460400', '460000,460400', '东成镇', '海南省/儋州市/东成镇', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460400116', '460400', '460000,460400', '新州镇', '海南省/儋州市/新州镇', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460400499', '460400', '460000,460400', '洋浦经济开发区', '海南省/儋州市/洋浦经济开发区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('460400500', '460400', '460000,460400', '华南热作学院', '海南省/儋州市/华南热作学院', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('469000', '460000', '460000', '省直辖县级行政区划', '海南省/省直辖县级行政区划', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('469001', '469000', '460000,469000', '五指山市', '海南省/省直辖县级行政区划/五指山市', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('469002', '469000', '460000,469000', '琼海市', '海南省/省直辖县级行政区划/琼海市', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('469005', '469000', '460000,469000', '文昌市', '海南省/省直辖县级行政区划/文昌市', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('469006', '469000', '460000,469000', '万宁市', '海南省/省直辖县级行政区划/万宁市', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('469007', '469000', '460000,469000', '东方市', '海南省/省直辖县级行政区划/东方市', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('469021', '469000', '460000,469000', '定安县', '海南省/省直辖县级行政区划/定安县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('469022', '469000', '460000,469000', '屯昌县', '海南省/省直辖县级行政区划/屯昌县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('469023', '469000', '460000,469000', '澄迈县', '海南省/省直辖县级行政区划/澄迈县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('469024', '469000', '460000,469000', '临高县', '海南省/省直辖县级行政区划/临高县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('469025', '469000', '460000,469000', '白沙黎族自治县', '海南省/省直辖县级行政区划/白沙黎族自治县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('469026', '469000', '460000,469000', '昌江黎族自治县', '海南省/省直辖县级行政区划/昌江黎族自治县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('469027', '469000', '460000,469000', '乐东黎族自治县', '海南省/省直辖县级行政区划/乐东黎族自治县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('469028', '469000', '460000,469000', '陵水黎族自治县', '海南省/省直辖县级行政区划/陵水黎族自治县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('469029', '469000', '460000,469000', '保亭黎族苗族自治县', '海南省/省直辖县级行政区划/保亭黎族苗族自治县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('469030', '469000', '460000,469000', '琼中黎族苗族自治县', '海南省/省直辖县级行政区划/琼中黎族苗族自治县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500000', '86', '', '重庆市', '重庆市', 1, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500100', '500000', '500000', '市辖区', '重庆市/市辖区', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500101', '500100', '500000,500100', '万州区', '重庆市/市辖区/万州区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500102', '500100', '500000,500100', '涪陵区', '重庆市/市辖区/涪陵区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500103', '500100', '500000,500100', '渝中区', '重庆市/市辖区/渝中区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500104', '500100', '500000,500100', '大渡口区', '重庆市/市辖区/大渡口区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500105', '500100', '500000,500100', '江北区', '重庆市/市辖区/江北区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500106', '500100', '500000,500100', '沙坪坝区', '重庆市/市辖区/沙坪坝区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500107', '500100', '500000,500100', '九龙坡区', '重庆市/市辖区/九龙坡区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500108', '500100', '500000,500100', '南岸区', '重庆市/市辖区/南岸区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500109', '500100', '500000,500100', '北碚区', '重庆市/市辖区/北碚区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500110', '500100', '500000,500100', '綦江区', '重庆市/市辖区/綦江区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500111', '500100', '500000,500100', '大足区', '重庆市/市辖区/大足区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500112', '500100', '500000,500100', '渝北区', '重庆市/市辖区/渝北区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500113', '500100', '500000,500100', '巴南区', '重庆市/市辖区/巴南区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500114', '500100', '500000,500100', '黔江区', '重庆市/市辖区/黔江区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500115', '500100', '500000,500100', '长寿区', '重庆市/市辖区/长寿区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500116', '500100', '500000,500100', '江津区', '重庆市/市辖区/江津区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500117', '500100', '500000,500100', '合川区', '重庆市/市辖区/合川区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500118', '500100', '500000,500100', '永川区', '重庆市/市辖区/永川区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500119', '500100', '500000,500100', '南川区', '重庆市/市辖区/南川区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500120', '500100', '500000,500100', '璧山区', '重庆市/市辖区/璧山区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500151', '500100', '500000,500100', '铜梁区', '重庆市/市辖区/铜梁区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500152', '500100', '500000,500100', '潼南区', '重庆市/市辖区/潼南区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500153', '500100', '500000,500100', '荣昌区', '重庆市/市辖区/荣昌区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500154', '500100', '500000,500100', '开州区', '重庆市/市辖区/开州区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500155', '500100', '500000,500100', '梁平区', '重庆市/市辖区/梁平区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500156', '500100', '500000,500100', '武隆区', '重庆市/市辖区/武隆区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500200', '500000', '500000', '县', '重庆市/县', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500229', '500200', '500000,500200', '城口县', '重庆市/县/城口县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500230', '500200', '500000,500200', '丰都县', '重庆市/县/丰都县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500231', '500200', '500000,500200', '垫江县', '重庆市/县/垫江县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500233', '500200', '500000,500200', '忠县', '重庆市/县/忠县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500235', '500200', '500000,500200', '云阳县', '重庆市/县/云阳县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500236', '500200', '500000,500200', '奉节县', '重庆市/县/奉节县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500237', '500200', '500000,500200', '巫山县', '重庆市/县/巫山县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500238', '500200', '500000,500200', '巫溪县', '重庆市/县/巫溪县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500240', '500200', '500000,500200', '石柱土家族自治县', '重庆市/县/石柱土家族自治县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500241', '500200', '500000,500200', '秀山土家族苗族自治县', '重庆市/县/秀山土家族苗族自治县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500242', '500200', '500000,500200', '酉阳土家族苗族自治县', '重庆市/县/酉阳土家族苗族自治县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('500243', '500200', '500000,500200', '彭水苗族土家族自治县', '重庆市/县/彭水苗族土家族自治县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510000', '86', '', '四川省', '四川省', 1, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510100', '510000', '510000', '成都市', '四川省/成都市', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510101', '510100', '510000,510100', '市辖区', '四川省/成都市/市辖区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510104', '510100', '510000,510100', '锦江区', '四川省/成都市/锦江区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510105', '510100', '510000,510100', '青羊区', '四川省/成都市/青羊区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510106', '510100', '510000,510100', '金牛区', '四川省/成都市/金牛区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510107', '510100', '510000,510100', '武侯区', '四川省/成都市/武侯区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510108', '510100', '510000,510100', '成华区', '四川省/成都市/成华区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510112', '510100', '510000,510100', '龙泉驿区', '四川省/成都市/龙泉驿区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510113', '510100', '510000,510100', '青白江区', '四川省/成都市/青白江区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510114', '510100', '510000,510100', '新都区', '四川省/成都市/新都区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510115', '510100', '510000,510100', '温江区', '四川省/成都市/温江区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510116', '510100', '510000,510100', '双流区', '四川省/成都市/双流区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510117', '510100', '510000,510100', '郫都区', '四川省/成都市/郫都区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510121', '510100', '510000,510100', '金堂县', '四川省/成都市/金堂县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510129', '510100', '510000,510100', '大邑县', '四川省/成都市/大邑县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510131', '510100', '510000,510100', '蒲江县', '四川省/成都市/蒲江县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510132', '510100', '510000,510100', '新津县', '四川省/成都市/新津县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510181', '510100', '510000,510100', '都江堰市', '四川省/成都市/都江堰市', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510182', '510100', '510000,510100', '彭州市', '四川省/成都市/彭州市', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510183', '510100', '510000,510100', '邛崃市', '四川省/成都市/邛崃市', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510184', '510100', '510000,510100', '崇州市', '四川省/成都市/崇州市', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510185', '510100', '510000,510100', '简阳市', '四川省/成都市/简阳市', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510300', '510000', '510000', '自贡市', '四川省/自贡市', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510301', '510300', '510000,510300', '市辖区', '四川省/自贡市/市辖区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510302', '510300', '510000,510300', '自流井区', '四川省/自贡市/自流井区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510303', '510300', '510000,510300', '贡井区', '四川省/自贡市/贡井区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510304', '510300', '510000,510300', '大安区', '四川省/自贡市/大安区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510311', '510300', '510000,510300', '沿滩区', '四川省/自贡市/沿滩区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510321', '510300', '510000,510300', '荣县', '四川省/自贡市/荣县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510322', '510300', '510000,510300', '富顺县', '四川省/自贡市/富顺县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510400', '510000', '510000', '攀枝花市', '四川省/攀枝花市', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510401', '510400', '510000,510400', '市辖区', '四川省/攀枝花市/市辖区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510402', '510400', '510000,510400', '东区', '四川省/攀枝花市/东区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510403', '510400', '510000,510400', '西区', '四川省/攀枝花市/西区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510411', '510400', '510000,510400', '仁和区', '四川省/攀枝花市/仁和区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510421', '510400', '510000,510400', '米易县', '四川省/攀枝花市/米易县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510422', '510400', '510000,510400', '盐边县', '四川省/攀枝花市/盐边县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510500', '510000', '510000', '泸州市', '四川省/泸州市', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510501', '510500', '510000,510500', '市辖区', '四川省/泸州市/市辖区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510502', '510500', '510000,510500', '江阳区', '四川省/泸州市/江阳区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510503', '510500', '510000,510500', '纳溪区', '四川省/泸州市/纳溪区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510504', '510500', '510000,510500', '龙马潭区', '四川省/泸州市/龙马潭区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510521', '510500', '510000,510500', '泸县', '四川省/泸州市/泸县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510522', '510500', '510000,510500', '合江县', '四川省/泸州市/合江县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510524', '510500', '510000,510500', '叙永县', '四川省/泸州市/叙永县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510525', '510500', '510000,510500', '古蔺县', '四川省/泸州市/古蔺县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510600', '510000', '510000', '德阳市', '四川省/德阳市', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510601', '510600', '510000,510600', '市辖区', '四川省/德阳市/市辖区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510603', '510600', '510000,510600', '旌阳区', '四川省/德阳市/旌阳区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510604', '510600', '510000,510600', '罗江区', '四川省/德阳市/罗江区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510623', '510600', '510000,510600', '中江县', '四川省/德阳市/中江县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510681', '510600', '510000,510600', '广汉市', '四川省/德阳市/广汉市', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510682', '510600', '510000,510600', '什邡市', '四川省/德阳市/什邡市', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510683', '510600', '510000,510600', '绵竹市', '四川省/德阳市/绵竹市', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510700', '510000', '510000', '绵阳市', '四川省/绵阳市', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510701', '510700', '510000,510700', '市辖区', '四川省/绵阳市/市辖区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510703', '510700', '510000,510700', '涪城区', '四川省/绵阳市/涪城区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510704', '510700', '510000,510700', '游仙区', '四川省/绵阳市/游仙区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510705', '510700', '510000,510700', '安州区', '四川省/绵阳市/安州区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510722', '510700', '510000,510700', '三台县', '四川省/绵阳市/三台县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510723', '510700', '510000,510700', '盐亭县', '四川省/绵阳市/盐亭县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510725', '510700', '510000,510700', '梓潼县', '四川省/绵阳市/梓潼县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510726', '510700', '510000,510700', '北川羌族自治县', '四川省/绵阳市/北川羌族自治县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510727', '510700', '510000,510700', '平武县', '四川省/绵阳市/平武县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510781', '510700', '510000,510700', '江油市', '四川省/绵阳市/江油市', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510800', '510000', '510000', '广元市', '四川省/广元市', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510801', '510800', '510000,510800', '市辖区', '四川省/广元市/市辖区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510802', '510800', '510000,510800', '利州区', '四川省/广元市/利州区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510811', '510800', '510000,510800', '昭化区', '四川省/广元市/昭化区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510812', '510800', '510000,510800', '朝天区', '四川省/广元市/朝天区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510821', '510800', '510000,510800', '旺苍县', '四川省/广元市/旺苍县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510822', '510800', '510000,510800', '青川县', '四川省/广元市/青川县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510823', '510800', '510000,510800', '剑阁县', '四川省/广元市/剑阁县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510824', '510800', '510000,510800', '苍溪县', '四川省/广元市/苍溪县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510900', '510000', '510000', '遂宁市', '四川省/遂宁市', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510901', '510900', '510000,510900', '市辖区', '四川省/遂宁市/市辖区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510903', '510900', '510000,510900', '船山区', '四川省/遂宁市/船山区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510904', '510900', '510000,510900', '安居区', '四川省/遂宁市/安居区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510921', '510900', '510000,510900', '蓬溪县', '四川省/遂宁市/蓬溪县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510923', '510900', '510000,510900', '大英县', '四川省/遂宁市/大英县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('510981', '510900', '510000,510900', '射洪市', '四川省/遂宁市/射洪市', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511000', '510000', '510000', '内江市', '四川省/内江市', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511001', '511000', '510000,511000', '市辖区', '四川省/内江市/市辖区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511002', '511000', '510000,511000', '市中区', '四川省/内江市/市中区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511011', '511000', '510000,511000', '东兴区', '四川省/内江市/东兴区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511024', '511000', '510000,511000', '威远县', '四川省/内江市/威远县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511025', '511000', '510000,511000', '资中县', '四川省/内江市/资中县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511071', '511000', '510000,511000', '内江经济开发区', '四川省/内江市/内江经济开发区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511083', '511000', '510000,511000', '隆昌市', '四川省/内江市/隆昌市', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511100', '510000', '510000', '乐山市', '四川省/乐山市', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511101', '511100', '510000,511100', '市辖区', '四川省/乐山市/市辖区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511102', '511100', '510000,511100', '市中区', '四川省/乐山市/市中区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511111', '511100', '510000,511100', '沙湾区', '四川省/乐山市/沙湾区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511112', '511100', '510000,511100', '五通桥区', '四川省/乐山市/五通桥区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511113', '511100', '510000,511100', '金口河区', '四川省/乐山市/金口河区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511123', '511100', '510000,511100', '犍为县', '四川省/乐山市/犍为县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511124', '511100', '510000,511100', '井研县', '四川省/乐山市/井研县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511126', '511100', '510000,511100', '夹江县', '四川省/乐山市/夹江县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511129', '511100', '510000,511100', '沐川县', '四川省/乐山市/沐川县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511132', '511100', '510000,511100', '峨边彝族自治县', '四川省/乐山市/峨边彝族自治县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511133', '511100', '510000,511100', '马边彝族自治县', '四川省/乐山市/马边彝族自治县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511181', '511100', '510000,511100', '峨眉山市', '四川省/乐山市/峨眉山市', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511300', '510000', '510000', '南充市', '四川省/南充市', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511301', '511300', '510000,511300', '市辖区', '四川省/南充市/市辖区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511302', '511300', '510000,511300', '顺庆区', '四川省/南充市/顺庆区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511303', '511300', '510000,511300', '高坪区', '四川省/南充市/高坪区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511304', '511300', '510000,511300', '嘉陵区', '四川省/南充市/嘉陵区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511321', '511300', '510000,511300', '南部县', '四川省/南充市/南部县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511322', '511300', '510000,511300', '营山县', '四川省/南充市/营山县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511323', '511300', '510000,511300', '蓬安县', '四川省/南充市/蓬安县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511324', '511300', '510000,511300', '仪陇县', '四川省/南充市/仪陇县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511325', '511300', '510000,511300', '西充县', '四川省/南充市/西充县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511381', '511300', '510000,511300', '阆中市', '四川省/南充市/阆中市', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511400', '510000', '510000', '眉山市', '四川省/眉山市', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511401', '511400', '510000,511400', '市辖区', '四川省/眉山市/市辖区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511402', '511400', '510000,511400', '东坡区', '四川省/眉山市/东坡区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511403', '511400', '510000,511400', '彭山区', '四川省/眉山市/彭山区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511421', '511400', '510000,511400', '仁寿县', '四川省/眉山市/仁寿县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511423', '511400', '510000,511400', '洪雅县', '四川省/眉山市/洪雅县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511424', '511400', '510000,511400', '丹棱县', '四川省/眉山市/丹棱县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511425', '511400', '510000,511400', '青神县', '四川省/眉山市/青神县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511500', '510000', '510000', '宜宾市', '四川省/宜宾市', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511501', '511500', '510000,511500', '市辖区', '四川省/宜宾市/市辖区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511502', '511500', '510000,511500', '翠屏区', '四川省/宜宾市/翠屏区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511503', '511500', '510000,511500', '南溪区', '四川省/宜宾市/南溪区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511504', '511500', '510000,511500', '叙州区', '四川省/宜宾市/叙州区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511523', '511500', '510000,511500', '江安县', '四川省/宜宾市/江安县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511524', '511500', '510000,511500', '长宁县', '四川省/宜宾市/长宁县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511525', '511500', '510000,511500', '高县', '四川省/宜宾市/高县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511526', '511500', '510000,511500', '珙县', '四川省/宜宾市/珙县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511527', '511500', '510000,511500', '筠连县', '四川省/宜宾市/筠连县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511528', '511500', '510000,511500', '兴文县', '四川省/宜宾市/兴文县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511529', '511500', '510000,511500', '屏山县', '四川省/宜宾市/屏山县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511600', '510000', '510000', '广安市', '四川省/广安市', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511601', '511600', '510000,511600', '市辖区', '四川省/广安市/市辖区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511602', '511600', '510000,511600', '广安区', '四川省/广安市/广安区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511603', '511600', '510000,511600', '前锋区', '四川省/广安市/前锋区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511621', '511600', '510000,511600', '岳池县', '四川省/广安市/岳池县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511622', '511600', '510000,511600', '武胜县', '四川省/广安市/武胜县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511623', '511600', '510000,511600', '邻水县', '四川省/广安市/邻水县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511681', '511600', '510000,511600', '华蓥市', '四川省/广安市/华蓥市', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511700', '510000', '510000', '达州市', '四川省/达州市', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511701', '511700', '510000,511700', '市辖区', '四川省/达州市/市辖区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511702', '511700', '510000,511700', '通川区', '四川省/达州市/通川区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511703', '511700', '510000,511700', '达川区', '四川省/达州市/达川区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511722', '511700', '510000,511700', '宣汉县', '四川省/达州市/宣汉县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511723', '511700', '510000,511700', '开江县', '四川省/达州市/开江县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511724', '511700', '510000,511700', '大竹县', '四川省/达州市/大竹县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511725', '511700', '510000,511700', '渠县', '四川省/达州市/渠县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511771', '511700', '510000,511700', '达州经济开发区', '四川省/达州市/达州经济开发区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511781', '511700', '510000,511700', '万源市', '四川省/达州市/万源市', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511800', '510000', '510000', '雅安市', '四川省/雅安市', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511801', '511800', '510000,511800', '市辖区', '四川省/雅安市/市辖区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511802', '511800', '510000,511800', '雨城区', '四川省/雅安市/雨城区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511803', '511800', '510000,511800', '名山区', '四川省/雅安市/名山区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511822', '511800', '510000,511800', '荥经县', '四川省/雅安市/荥经县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511823', '511800', '510000,511800', '汉源县', '四川省/雅安市/汉源县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511824', '511800', '510000,511800', '石棉县', '四川省/雅安市/石棉县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511825', '511800', '510000,511800', '天全县', '四川省/雅安市/天全县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511826', '511800', '510000,511800', '芦山县', '四川省/雅安市/芦山县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511827', '511800', '510000,511800', '宝兴县', '四川省/雅安市/宝兴县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511900', '510000', '510000', '巴中市', '四川省/巴中市', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511901', '511900', '510000,511900', '市辖区', '四川省/巴中市/市辖区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511902', '511900', '510000,511900', '巴州区', '四川省/巴中市/巴州区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511903', '511900', '510000,511900', '恩阳区', '四川省/巴中市/恩阳区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511921', '511900', '510000,511900', '通江县', '四川省/巴中市/通江县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511922', '511900', '510000,511900', '南江县', '四川省/巴中市/南江县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511923', '511900', '510000,511900', '平昌县', '四川省/巴中市/平昌县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('511971', '511900', '510000,511900', '巴中经济开发区', '四川省/巴中市/巴中经济开发区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('512000', '510000', '510000', '资阳市', '四川省/资阳市', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('512001', '512000', '510000,512000', '市辖区', '四川省/资阳市/市辖区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('512002', '512000', '510000,512000', '雁江区', '四川省/资阳市/雁江区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('512021', '512000', '510000,512000', '安岳县', '四川省/资阳市/安岳县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('512022', '512000', '510000,512000', '乐至县', '四川省/资阳市/乐至县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513200', '510000', '510000', '阿坝藏族羌族自治州', '四川省/阿坝藏族羌族自治州', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513201', '513200', '510000,513200', '马尔康市', '四川省/阿坝藏族羌族自治州/马尔康市', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513221', '513200', '510000,513200', '汶川县', '四川省/阿坝藏族羌族自治州/汶川县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513222', '513200', '510000,513200', '理县', '四川省/阿坝藏族羌族自治州/理县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513223', '513200', '510000,513200', '茂县', '四川省/阿坝藏族羌族自治州/茂县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513224', '513200', '510000,513200', '松潘县', '四川省/阿坝藏族羌族自治州/松潘县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513225', '513200', '510000,513200', '九寨沟县', '四川省/阿坝藏族羌族自治州/九寨沟县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513226', '513200', '510000,513200', '金川县', '四川省/阿坝藏族羌族自治州/金川县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513227', '513200', '510000,513200', '小金县', '四川省/阿坝藏族羌族自治州/小金县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513228', '513200', '510000,513200', '黑水县', '四川省/阿坝藏族羌族自治州/黑水县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513230', '513200', '510000,513200', '壤塘县', '四川省/阿坝藏族羌族自治州/壤塘县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513231', '513200', '510000,513200', '阿坝县', '四川省/阿坝藏族羌族自治州/阿坝县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513232', '513200', '510000,513200', '若尔盖县', '四川省/阿坝藏族羌族自治州/若尔盖县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513233', '513200', '510000,513200', '红原县', '四川省/阿坝藏族羌族自治州/红原县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513300', '510000', '510000', '甘孜藏族自治州', '四川省/甘孜藏族自治州', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513301', '513300', '510000,513300', '康定市', '四川省/甘孜藏族自治州/康定市', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513322', '513300', '510000,513300', '泸定县', '四川省/甘孜藏族自治州/泸定县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513323', '513300', '510000,513300', '丹巴县', '四川省/甘孜藏族自治州/丹巴县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513324', '513300', '510000,513300', '九龙县', '四川省/甘孜藏族自治州/九龙县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513325', '513300', '510000,513300', '雅江县', '四川省/甘孜藏族自治州/雅江县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513326', '513300', '510000,513300', '道孚县', '四川省/甘孜藏族自治州/道孚县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513327', '513300', '510000,513300', '炉霍县', '四川省/甘孜藏族自治州/炉霍县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513328', '513300', '510000,513300', '甘孜县', '四川省/甘孜藏族自治州/甘孜县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513329', '513300', '510000,513300', '新龙县', '四川省/甘孜藏族自治州/新龙县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513330', '513300', '510000,513300', '德格县', '四川省/甘孜藏族自治州/德格县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513331', '513300', '510000,513300', '白玉县', '四川省/甘孜藏族自治州/白玉县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513332', '513300', '510000,513300', '石渠县', '四川省/甘孜藏族自治州/石渠县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513333', '513300', '510000,513300', '色达县', '四川省/甘孜藏族自治州/色达县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513334', '513300', '510000,513300', '理塘县', '四川省/甘孜藏族自治州/理塘县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513335', '513300', '510000,513300', '巴塘县', '四川省/甘孜藏族自治州/巴塘县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513336', '513300', '510000,513300', '乡城县', '四川省/甘孜藏族自治州/乡城县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513337', '513300', '510000,513300', '稻城县', '四川省/甘孜藏族自治州/稻城县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513338', '513300', '510000,513300', '得荣县', '四川省/甘孜藏族自治州/得荣县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513400', '510000', '510000', '凉山彝族自治州', '四川省/凉山彝族自治州', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513401', '513400', '510000,513400', '西昌市', '四川省/凉山彝族自治州/西昌市', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513422', '513400', '510000,513400', '木里藏族自治县', '四川省/凉山彝族自治州/木里藏族自治县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513423', '513400', '510000,513400', '盐源县', '四川省/凉山彝族自治州/盐源县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513424', '513400', '510000,513400', '德昌县', '四川省/凉山彝族自治州/德昌县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513425', '513400', '510000,513400', '会理县', '四川省/凉山彝族自治州/会理县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513426', '513400', '510000,513400', '会东县', '四川省/凉山彝族自治州/会东县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513427', '513400', '510000,513400', '宁南县', '四川省/凉山彝族自治州/宁南县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513428', '513400', '510000,513400', '普格县', '四川省/凉山彝族自治州/普格县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513429', '513400', '510000,513400', '布拖县', '四川省/凉山彝族自治州/布拖县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513430', '513400', '510000,513400', '金阳县', '四川省/凉山彝族自治州/金阳县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513431', '513400', '510000,513400', '昭觉县', '四川省/凉山彝族自治州/昭觉县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513432', '513400', '510000,513400', '喜德县', '四川省/凉山彝族自治州/喜德县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513433', '513400', '510000,513400', '冕宁县', '四川省/凉山彝族自治州/冕宁县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513434', '513400', '510000,513400', '越西县', '四川省/凉山彝族自治州/越西县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513435', '513400', '510000,513400', '甘洛县', '四川省/凉山彝族自治州/甘洛县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513436', '513400', '510000,513400', '美姑县', '四川省/凉山彝族自治州/美姑县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('513437', '513400', '510000,513400', '雷波县', '四川省/凉山彝族自治州/雷波县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520000', '86', '', '贵州省', '贵州省', 1, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520100', '520000', '520000', '贵阳市', '贵州省/贵阳市', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520101', '520100', '520000,520100', '市辖区', '贵州省/贵阳市/市辖区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520102', '520100', '520000,520100', '南明区', '贵州省/贵阳市/南明区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520103', '520100', '520000,520100', '云岩区', '贵州省/贵阳市/云岩区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520111', '520100', '520000,520100', '花溪区', '贵州省/贵阳市/花溪区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520112', '520100', '520000,520100', '乌当区', '贵州省/贵阳市/乌当区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520113', '520100', '520000,520100', '白云区', '贵州省/贵阳市/白云区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520115', '520100', '520000,520100', '观山湖区', '贵州省/贵阳市/观山湖区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520121', '520100', '520000,520100', '开阳县', '贵州省/贵阳市/开阳县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520122', '520100', '520000,520100', '息烽县', '贵州省/贵阳市/息烽县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520123', '520100', '520000,520100', '修文县', '贵州省/贵阳市/修文县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520181', '520100', '520000,520100', '清镇市', '贵州省/贵阳市/清镇市', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520200', '520000', '520000', '六盘水市', '贵州省/六盘水市', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520201', '520200', '520000,520200', '钟山区', '贵州省/六盘水市/钟山区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520203', '520200', '520000,520200', '六枝特区', '贵州省/六盘水市/六枝特区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520221', '520200', '520000,520200', '水城县', '贵州省/六盘水市/水城县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520281', '520200', '520000,520200', '盘州市', '贵州省/六盘水市/盘州市', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520300', '520000', '520000', '遵义市', '贵州省/遵义市', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520301', '520300', '520000,520300', '市辖区', '贵州省/遵义市/市辖区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520302', '520300', '520000,520300', '红花岗区', '贵州省/遵义市/红花岗区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520303', '520300', '520000,520300', '汇川区', '贵州省/遵义市/汇川区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520304', '520300', '520000,520300', '播州区', '贵州省/遵义市/播州区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520322', '520300', '520000,520300', '桐梓县', '贵州省/遵义市/桐梓县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520323', '520300', '520000,520300', '绥阳县', '贵州省/遵义市/绥阳县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520324', '520300', '520000,520300', '正安县', '贵州省/遵义市/正安县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520325', '520300', '520000,520300', '道真仡佬族苗族自治县', '贵州省/遵义市/道真仡佬族苗族自治县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520326', '520300', '520000,520300', '务川仡佬族苗族自治县', '贵州省/遵义市/务川仡佬族苗族自治县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520327', '520300', '520000,520300', '凤冈县', '贵州省/遵义市/凤冈县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520328', '520300', '520000,520300', '湄潭县', '贵州省/遵义市/湄潭县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520329', '520300', '520000,520300', '余庆县', '贵州省/遵义市/余庆县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520330', '520300', '520000,520300', '习水县', '贵州省/遵义市/习水县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520381', '520300', '520000,520300', '赤水市', '贵州省/遵义市/赤水市', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520382', '520300', '520000,520300', '仁怀市', '贵州省/遵义市/仁怀市', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520400', '520000', '520000', '安顺市', '贵州省/安顺市', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520401', '520400', '520000,520400', '市辖区', '贵州省/安顺市/市辖区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520402', '520400', '520000,520400', '西秀区', '贵州省/安顺市/西秀区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520403', '520400', '520000,520400', '平坝区', '贵州省/安顺市/平坝区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520422', '520400', '520000,520400', '普定县', '贵州省/安顺市/普定县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520423', '520400', '520000,520400', '镇宁布依族苗族自治县', '贵州省/安顺市/镇宁布依族苗族自治县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520424', '520400', '520000,520400', '关岭布依族苗族自治县', '贵州省/安顺市/关岭布依族苗族自治县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520425', '520400', '520000,520400', '紫云苗族布依族自治县', '贵州省/安顺市/紫云苗族布依族自治县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520500', '520000', '520000', '毕节市', '贵州省/毕节市', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520501', '520500', '520000,520500', '市辖区', '贵州省/毕节市/市辖区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520502', '520500', '520000,520500', '七星关区', '贵州省/毕节市/七星关区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520521', '520500', '520000,520500', '大方县', '贵州省/毕节市/大方县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520522', '520500', '520000,520500', '黔西县', '贵州省/毕节市/黔西县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520523', '520500', '520000,520500', '金沙县', '贵州省/毕节市/金沙县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520524', '520500', '520000,520500', '织金县', '贵州省/毕节市/织金县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520525', '520500', '520000,520500', '纳雍县', '贵州省/毕节市/纳雍县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520526', '520500', '520000,520500', '威宁彝族回族苗族自治县', '贵州省/毕节市/威宁彝族回族苗族自治县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520527', '520500', '520000,520500', '赫章县', '贵州省/毕节市/赫章县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520600', '520000', '520000', '铜仁市', '贵州省/铜仁市', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520601', '520600', '520000,520600', '市辖区', '贵州省/铜仁市/市辖区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520602', '520600', '520000,520600', '碧江区', '贵州省/铜仁市/碧江区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520603', '520600', '520000,520600', '万山区', '贵州省/铜仁市/万山区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520621', '520600', '520000,520600', '江口县', '贵州省/铜仁市/江口县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520622', '520600', '520000,520600', '玉屏侗族自治县', '贵州省/铜仁市/玉屏侗族自治县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520623', '520600', '520000,520600', '石阡县', '贵州省/铜仁市/石阡县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520624', '520600', '520000,520600', '思南县', '贵州省/铜仁市/思南县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520625', '520600', '520000,520600', '印江土家族苗族自治县', '贵州省/铜仁市/印江土家族苗族自治县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520626', '520600', '520000,520600', '德江县', '贵州省/铜仁市/德江县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520627', '520600', '520000,520600', '沿河土家族自治县', '贵州省/铜仁市/沿河土家族自治县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('520628', '520600', '520000,520600', '松桃苗族自治县', '贵州省/铜仁市/松桃苗族自治县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522300', '520000', '520000', '黔西南布依族苗族自治州', '贵州省/黔西南布依族苗族自治州', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522301', '522300', '520000,522300', '兴义市', '贵州省/黔西南布依族苗族自治州/兴义市', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522302', '522300', '520000,522300', '兴仁市', '贵州省/黔西南布依族苗族自治州/兴仁市', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522323', '522300', '520000,522300', '普安县', '贵州省/黔西南布依族苗族自治州/普安县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522324', '522300', '520000,522300', '晴隆县', '贵州省/黔西南布依族苗族自治州/晴隆县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522325', '522300', '520000,522300', '贞丰县', '贵州省/黔西南布依族苗族自治州/贞丰县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522326', '522300', '520000,522300', '望谟县', '贵州省/黔西南布依族苗族自治州/望谟县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522327', '522300', '520000,522300', '册亨县', '贵州省/黔西南布依族苗族自治州/册亨县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522328', '522300', '520000,522300', '安龙县', '贵州省/黔西南布依族苗族自治州/安龙县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522600', '520000', '520000', '黔东南苗族侗族自治州', '贵州省/黔东南苗族侗族自治州', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522601', '522600', '520000,522600', '凯里市', '贵州省/黔东南苗族侗族自治州/凯里市', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522622', '522600', '520000,522600', '黄平县', '贵州省/黔东南苗族侗族自治州/黄平县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522623', '522600', '520000,522600', '施秉县', '贵州省/黔东南苗族侗族自治州/施秉县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522624', '522600', '520000,522600', '三穗县', '贵州省/黔东南苗族侗族自治州/三穗县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522625', '522600', '520000,522600', '镇远县', '贵州省/黔东南苗族侗族自治州/镇远县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522626', '522600', '520000,522600', '岑巩县', '贵州省/黔东南苗族侗族自治州/岑巩县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522627', '522600', '520000,522600', '天柱县', '贵州省/黔东南苗族侗族自治州/天柱县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522628', '522600', '520000,522600', '锦屏县', '贵州省/黔东南苗族侗族自治州/锦屏县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522629', '522600', '520000,522600', '剑河县', '贵州省/黔东南苗族侗族自治州/剑河县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522630', '522600', '520000,522600', '台江县', '贵州省/黔东南苗族侗族自治州/台江县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522631', '522600', '520000,522600', '黎平县', '贵州省/黔东南苗族侗族自治州/黎平县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522632', '522600', '520000,522600', '榕江县', '贵州省/黔东南苗族侗族自治州/榕江县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522633', '522600', '520000,522600', '从江县', '贵州省/黔东南苗族侗族自治州/从江县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522634', '522600', '520000,522600', '雷山县', '贵州省/黔东南苗族侗族自治州/雷山县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522635', '522600', '520000,522600', '麻江县', '贵州省/黔东南苗族侗族自治州/麻江县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522636', '522600', '520000,522600', '丹寨县', '贵州省/黔东南苗族侗族自治州/丹寨县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522700', '520000', '520000', '黔南布依族苗族自治州', '贵州省/黔南布依族苗族自治州', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522701', '522700', '520000,522700', '都匀市', '贵州省/黔南布依族苗族自治州/都匀市', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522702', '522700', '520000,522700', '福泉市', '贵州省/黔南布依族苗族自治州/福泉市', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522722', '522700', '520000,522700', '荔波县', '贵州省/黔南布依族苗族自治州/荔波县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522723', '522700', '520000,522700', '贵定县', '贵州省/黔南布依族苗族自治州/贵定县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522725', '522700', '520000,522700', '瓮安县', '贵州省/黔南布依族苗族自治州/瓮安县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522726', '522700', '520000,522700', '独山县', '贵州省/黔南布依族苗族自治州/独山县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522727', '522700', '520000,522700', '平塘县', '贵州省/黔南布依族苗族自治州/平塘县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522728', '522700', '520000,522700', '罗甸县', '贵州省/黔南布依族苗族自治州/罗甸县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522729', '522700', '520000,522700', '长顺县', '贵州省/黔南布依族苗族自治州/长顺县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522730', '522700', '520000,522700', '龙里县', '贵州省/黔南布依族苗族自治州/龙里县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522731', '522700', '520000,522700', '惠水县', '贵州省/黔南布依族苗族自治州/惠水县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('522732', '522700', '520000,522700', '三都水族自治县', '贵州省/黔南布依族苗族自治州/三都水族自治县', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530000', '86', '', '云南省', '云南省', 1, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530100', '530000', '530000', '昆明市', '云南省/昆明市', 2, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530101', '530100', '530000,530100', '市辖区', '云南省/昆明市/市辖区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530102', '530100', '530000,530100', '五华区', '云南省/昆明市/五华区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530103', '530100', '530000,530100', '盘龙区', '云南省/昆明市/盘龙区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530111', '530100', '530000,530100', '官渡区', '云南省/昆明市/官渡区', 3, 'admin', '2022-05-22 20:35:19', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530112', '530100', '530000,530100', '西山区', '云南省/昆明市/西山区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530113', '530100', '530000,530100', '东川区', '云南省/昆明市/东川区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530114', '530100', '530000,530100', '呈贡区', '云南省/昆明市/呈贡区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530115', '530100', '530000,530100', '晋宁区', '云南省/昆明市/晋宁区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530124', '530100', '530000,530100', '富民县', '云南省/昆明市/富民县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530125', '530100', '530000,530100', '宜良县', '云南省/昆明市/宜良县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530126', '530100', '530000,530100', '石林彝族自治县', '云南省/昆明市/石林彝族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530127', '530100', '530000,530100', '嵩明县', '云南省/昆明市/嵩明县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530128', '530100', '530000,530100', '禄劝彝族苗族自治县', '云南省/昆明市/禄劝彝族苗族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530129', '530100', '530000,530100', '寻甸回族彝族自治县', '云南省/昆明市/寻甸回族彝族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530181', '530100', '530000,530100', '安宁市', '云南省/昆明市/安宁市', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530300', '530000', '530000', '曲靖市', '云南省/曲靖市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530301', '530300', '530000,530300', '市辖区', '云南省/曲靖市/市辖区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530302', '530300', '530000,530300', '麒麟区', '云南省/曲靖市/麒麟区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530303', '530300', '530000,530300', '沾益区', '云南省/曲靖市/沾益区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530304', '530300', '530000,530300', '马龙区', '云南省/曲靖市/马龙区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530322', '530300', '530000,530300', '陆良县', '云南省/曲靖市/陆良县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530323', '530300', '530000,530300', '师宗县', '云南省/曲靖市/师宗县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530324', '530300', '530000,530300', '罗平县', '云南省/曲靖市/罗平县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530325', '530300', '530000,530300', '富源县', '云南省/曲靖市/富源县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530326', '530300', '530000,530300', '会泽县', '云南省/曲靖市/会泽县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530381', '530300', '530000,530300', '宣威市', '云南省/曲靖市/宣威市', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530400', '530000', '530000', '玉溪市', '云南省/玉溪市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530401', '530400', '530000,530400', '市辖区', '云南省/玉溪市/市辖区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530402', '530400', '530000,530400', '红塔区', '云南省/玉溪市/红塔区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530403', '530400', '530000,530400', '江川区', '云南省/玉溪市/江川区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530422', '530400', '530000,530400', '澄江县', '云南省/玉溪市/澄江县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530423', '530400', '530000,530400', '通海县', '云南省/玉溪市/通海县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530424', '530400', '530000,530400', '华宁县', '云南省/玉溪市/华宁县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530425', '530400', '530000,530400', '易门县', '云南省/玉溪市/易门县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530426', '530400', '530000,530400', '峨山彝族自治县', '云南省/玉溪市/峨山彝族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530427', '530400', '530000,530400', '新平彝族傣族自治县', '云南省/玉溪市/新平彝族傣族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530428', '530400', '530000,530400', '元江哈尼族彝族傣族自治县', '云南省/玉溪市/元江哈尼族彝族傣族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530500', '530000', '530000', '保山市', '云南省/保山市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530501', '530500', '530000,530500', '市辖区', '云南省/保山市/市辖区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530502', '530500', '530000,530500', '隆阳区', '云南省/保山市/隆阳区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530521', '530500', '530000,530500', '施甸县', '云南省/保山市/施甸县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530523', '530500', '530000,530500', '龙陵县', '云南省/保山市/龙陵县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530524', '530500', '530000,530500', '昌宁县', '云南省/保山市/昌宁县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530581', '530500', '530000,530500', '腾冲市', '云南省/保山市/腾冲市', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530600', '530000', '530000', '昭通市', '云南省/昭通市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530601', '530600', '530000,530600', '市辖区', '云南省/昭通市/市辖区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530602', '530600', '530000,530600', '昭阳区', '云南省/昭通市/昭阳区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530621', '530600', '530000,530600', '鲁甸县', '云南省/昭通市/鲁甸县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530622', '530600', '530000,530600', '巧家县', '云南省/昭通市/巧家县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530623', '530600', '530000,530600', '盐津县', '云南省/昭通市/盐津县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530624', '530600', '530000,530600', '大关县', '云南省/昭通市/大关县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530625', '530600', '530000,530600', '永善县', '云南省/昭通市/永善县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530626', '530600', '530000,530600', '绥江县', '云南省/昭通市/绥江县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530627', '530600', '530000,530600', '镇雄县', '云南省/昭通市/镇雄县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530628', '530600', '530000,530600', '彝良县', '云南省/昭通市/彝良县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530629', '530600', '530000,530600', '威信县', '云南省/昭通市/威信县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530681', '530600', '530000,530600', '水富市', '云南省/昭通市/水富市', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530700', '530000', '530000', '丽江市', '云南省/丽江市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530701', '530700', '530000,530700', '市辖区', '云南省/丽江市/市辖区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530702', '530700', '530000,530700', '古城区', '云南省/丽江市/古城区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530721', '530700', '530000,530700', '玉龙纳西族自治县', '云南省/丽江市/玉龙纳西族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530722', '530700', '530000,530700', '永胜县', '云南省/丽江市/永胜县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530723', '530700', '530000,530700', '华坪县', '云南省/丽江市/华坪县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530724', '530700', '530000,530700', '宁蒗彝族自治县', '云南省/丽江市/宁蒗彝族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530800', '530000', '530000', '普洱市', '云南省/普洱市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530801', '530800', '530000,530800', '市辖区', '云南省/普洱市/市辖区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530802', '530800', '530000,530800', '思茅区', '云南省/普洱市/思茅区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530821', '530800', '530000,530800', '宁洱哈尼族彝族自治县', '云南省/普洱市/宁洱哈尼族彝族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530822', '530800', '530000,530800', '墨江哈尼族自治县', '云南省/普洱市/墨江哈尼族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530823', '530800', '530000,530800', '景东彝族自治县', '云南省/普洱市/景东彝族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530824', '530800', '530000,530800', '景谷傣族彝族自治县', '云南省/普洱市/景谷傣族彝族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530825', '530800', '530000,530800', '镇沅彝族哈尼族拉祜族自治县', '云南省/普洱市/镇沅彝族哈尼族拉祜族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530826', '530800', '530000,530800', '江城哈尼族彝族自治县', '云南省/普洱市/江城哈尼族彝族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530827', '530800', '530000,530800', '孟连傣族拉祜族佤族自治县', '云南省/普洱市/孟连傣族拉祜族佤族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530828', '530800', '530000,530800', '澜沧拉祜族自治县', '云南省/普洱市/澜沧拉祜族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530829', '530800', '530000,530800', '西盟佤族自治县', '云南省/普洱市/西盟佤族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530900', '530000', '530000', '临沧市', '云南省/临沧市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530901', '530900', '530000,530900', '市辖区', '云南省/临沧市/市辖区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530902', '530900', '530000,530900', '临翔区', '云南省/临沧市/临翔区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530921', '530900', '530000,530900', '凤庆县', '云南省/临沧市/凤庆县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530922', '530900', '530000,530900', '云县', '云南省/临沧市/云县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530923', '530900', '530000,530900', '永德县', '云南省/临沧市/永德县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530924', '530900', '530000,530900', '镇康县', '云南省/临沧市/镇康县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530925', '530900', '530000,530900', '双江拉祜族佤族布朗族傣族自治县', '云南省/临沧市/双江拉祜族佤族布朗族傣族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530926', '530900', '530000,530900', '耿马傣族佤族自治县', '云南省/临沧市/耿马傣族佤族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('530927', '530900', '530000,530900', '沧源佤族自治县', '云南省/临沧市/沧源佤族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532300', '530000', '530000', '楚雄彝族自治州', '云南省/楚雄彝族自治州', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532301', '532300', '530000,532300', '楚雄市', '云南省/楚雄彝族自治州/楚雄市', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532322', '532300', '530000,532300', '双柏县', '云南省/楚雄彝族自治州/双柏县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532323', '532300', '530000,532300', '牟定县', '云南省/楚雄彝族自治州/牟定县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532324', '532300', '530000,532300', '南华县', '云南省/楚雄彝族自治州/南华县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532325', '532300', '530000,532300', '姚安县', '云南省/楚雄彝族自治州/姚安县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532326', '532300', '530000,532300', '大姚县', '云南省/楚雄彝族自治州/大姚县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532327', '532300', '530000,532300', '永仁县', '云南省/楚雄彝族自治州/永仁县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532328', '532300', '530000,532300', '元谋县', '云南省/楚雄彝族自治州/元谋县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532329', '532300', '530000,532300', '武定县', '云南省/楚雄彝族自治州/武定县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532331', '532300', '530000,532300', '禄丰县', '云南省/楚雄彝族自治州/禄丰县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532500', '530000', '530000', '红河哈尼族彝族自治州', '云南省/红河哈尼族彝族自治州', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532501', '532500', '530000,532500', '个旧市', '云南省/红河哈尼族彝族自治州/个旧市', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532502', '532500', '530000,532500', '开远市', '云南省/红河哈尼族彝族自治州/开远市', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532503', '532500', '530000,532500', '蒙自市', '云南省/红河哈尼族彝族自治州/蒙自市', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532504', '532500', '530000,532500', '弥勒市', '云南省/红河哈尼族彝族自治州/弥勒市', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532523', '532500', '530000,532500', '屏边苗族自治县', '云南省/红河哈尼族彝族自治州/屏边苗族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532524', '532500', '530000,532500', '建水县', '云南省/红河哈尼族彝族自治州/建水县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532525', '532500', '530000,532500', '石屏县', '云南省/红河哈尼族彝族自治州/石屏县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532527', '532500', '530000,532500', '泸西县', '云南省/红河哈尼族彝族自治州/泸西县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532528', '532500', '530000,532500', '元阳县', '云南省/红河哈尼族彝族自治州/元阳县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532529', '532500', '530000,532500', '红河县', '云南省/红河哈尼族彝族自治州/红河县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532530', '532500', '530000,532500', '金平苗族瑶族傣族自治县', '云南省/红河哈尼族彝族自治州/金平苗族瑶族傣族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532531', '532500', '530000,532500', '绿春县', '云南省/红河哈尼族彝族自治州/绿春县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532532', '532500', '530000,532500', '河口瑶族自治县', '云南省/红河哈尼族彝族自治州/河口瑶族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532600', '530000', '530000', '文山壮族苗族自治州', '云南省/文山壮族苗族自治州', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532601', '532600', '530000,532600', '文山市', '云南省/文山壮族苗族自治州/文山市', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532622', '532600', '530000,532600', '砚山县', '云南省/文山壮族苗族自治州/砚山县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532623', '532600', '530000,532600', '西畴县', '云南省/文山壮族苗族自治州/西畴县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532624', '532600', '530000,532600', '麻栗坡县', '云南省/文山壮族苗族自治州/麻栗坡县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532625', '532600', '530000,532600', '马关县', '云南省/文山壮族苗族自治州/马关县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532626', '532600', '530000,532600', '丘北县', '云南省/文山壮族苗族自治州/丘北县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532627', '532600', '530000,532600', '广南县', '云南省/文山壮族苗族自治州/广南县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532628', '532600', '530000,532600', '富宁县', '云南省/文山壮族苗族自治州/富宁县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532800', '530000', '530000', '西双版纳傣族自治州', '云南省/西双版纳傣族自治州', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532801', '532800', '530000,532800', '景洪市', '云南省/西双版纳傣族自治州/景洪市', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532822', '532800', '530000,532800', '勐海县', '云南省/西双版纳傣族自治州/勐海县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532823', '532800', '530000,532800', '勐腊县', '云南省/西双版纳傣族自治州/勐腊县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532900', '530000', '530000', '大理白族自治州', '云南省/大理白族自治州', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532901', '532900', '530000,532900', '大理市', '云南省/大理白族自治州/大理市', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532922', '532900', '530000,532900', '漾濞彝族自治县', '云南省/大理白族自治州/漾濞彝族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532923', '532900', '530000,532900', '祥云县', '云南省/大理白族自治州/祥云县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532924', '532900', '530000,532900', '宾川县', '云南省/大理白族自治州/宾川县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532925', '532900', '530000,532900', '弥渡县', '云南省/大理白族自治州/弥渡县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532926', '532900', '530000,532900', '南涧彝族自治县', '云南省/大理白族自治州/南涧彝族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532927', '532900', '530000,532900', '巍山彝族回族自治县', '云南省/大理白族自治州/巍山彝族回族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532928', '532900', '530000,532900', '永平县', '云南省/大理白族自治州/永平县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532929', '532900', '530000,532900', '云龙县', '云南省/大理白族自治州/云龙县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532930', '532900', '530000,532900', '洱源县', '云南省/大理白族自治州/洱源县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532931', '532900', '530000,532900', '剑川县', '云南省/大理白族自治州/剑川县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('532932', '532900', '530000,532900', '鹤庆县', '云南省/大理白族自治州/鹤庆县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('533100', '530000', '530000', '德宏傣族景颇族自治州', '云南省/德宏傣族景颇族自治州', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('533102', '533100', '530000,533100', '瑞丽市', '云南省/德宏傣族景颇族自治州/瑞丽市', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('533103', '533100', '530000,533100', '芒市', '云南省/德宏傣族景颇族自治州/芒市', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('533122', '533100', '530000,533100', '梁河县', '云南省/德宏傣族景颇族自治州/梁河县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('533123', '533100', '530000,533100', '盈江县', '云南省/德宏傣族景颇族自治州/盈江县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('533124', '533100', '530000,533100', '陇川县', '云南省/德宏傣族景颇族自治州/陇川县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('533300', '530000', '530000', '怒江傈僳族自治州', '云南省/怒江傈僳族自治州', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('533301', '533300', '530000,533300', '泸水市', '云南省/怒江傈僳族自治州/泸水市', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('533323', '533300', '530000,533300', '福贡县', '云南省/怒江傈僳族自治州/福贡县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('533324', '533300', '530000,533300', '贡山独龙族怒族自治县', '云南省/怒江傈僳族自治州/贡山独龙族怒族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('533325', '533300', '530000,533300', '兰坪白族普米族自治县', '云南省/怒江傈僳族自治州/兰坪白族普米族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('533400', '530000', '530000', '迪庆藏族自治州', '云南省/迪庆藏族自治州', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('533401', '533400', '530000,533400', '香格里拉市', '云南省/迪庆藏族自治州/香格里拉市', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('533422', '533400', '530000,533400', '德钦县', '云南省/迪庆藏族自治州/德钦县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('533423', '533400', '530000,533400', '维西傈僳族自治县', '云南省/迪庆藏族自治州/维西傈僳族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540000', '86', '', '西藏自治区', '西藏自治区', 1, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540100', '540000', '540000', '拉萨市', '西藏自治区/拉萨市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540101', '540100', '540000,540100', '市辖区', '西藏自治区/拉萨市/市辖区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540102', '540100', '540000,540100', '城关区', '西藏自治区/拉萨市/城关区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540103', '540100', '540000,540100', '堆龙德庆区', '西藏自治区/拉萨市/堆龙德庆区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540104', '540100', '540000,540100', '达孜区', '西藏自治区/拉萨市/达孜区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540121', '540100', '540000,540100', '林周县', '西藏自治区/拉萨市/林周县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540122', '540100', '540000,540100', '当雄县', '西藏自治区/拉萨市/当雄县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540123', '540100', '540000,540100', '尼木县', '西藏自治区/拉萨市/尼木县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540124', '540100', '540000,540100', '曲水县', '西藏自治区/拉萨市/曲水县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540127', '540100', '540000,540100', '墨竹工卡县', '西藏自治区/拉萨市/墨竹工卡县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540171', '540100', '540000,540100', '格尔木藏青工业园区', '西藏自治区/拉萨市/格尔木藏青工业园区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540172', '540100', '540000,540100', '拉萨经济技术开发区', '西藏自治区/拉萨市/拉萨经济技术开发区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540173', '540100', '540000,540100', '西藏文化旅游创意园区', '西藏自治区/拉萨市/西藏文化旅游创意园区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540174', '540100', '540000,540100', '达孜工业园区', '西藏自治区/拉萨市/达孜工业园区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540200', '540000', '540000', '日喀则市', '西藏自治区/日喀则市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540202', '540200', '540000,540200', '桑珠孜区', '西藏自治区/日喀则市/桑珠孜区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540221', '540200', '540000,540200', '南木林县', '西藏自治区/日喀则市/南木林县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540222', '540200', '540000,540200', '江孜县', '西藏自治区/日喀则市/江孜县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540223', '540200', '540000,540200', '定日县', '西藏自治区/日喀则市/定日县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540224', '540200', '540000,540200', '萨迦县', '西藏自治区/日喀则市/萨迦县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540225', '540200', '540000,540200', '拉孜县', '西藏自治区/日喀则市/拉孜县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540226', '540200', '540000,540200', '昂仁县', '西藏自治区/日喀则市/昂仁县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540227', '540200', '540000,540200', '谢通门县', '西藏自治区/日喀则市/谢通门县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540228', '540200', '540000,540200', '白朗县', '西藏自治区/日喀则市/白朗县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540229', '540200', '540000,540200', '仁布县', '西藏自治区/日喀则市/仁布县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540230', '540200', '540000,540200', '康马县', '西藏自治区/日喀则市/康马县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540231', '540200', '540000,540200', '定结县', '西藏自治区/日喀则市/定结县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540232', '540200', '540000,540200', '仲巴县', '西藏自治区/日喀则市/仲巴县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540233', '540200', '540000,540200', '亚东县', '西藏自治区/日喀则市/亚东县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540234', '540200', '540000,540200', '吉隆县', '西藏自治区/日喀则市/吉隆县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540235', '540200', '540000,540200', '聂拉木县', '西藏自治区/日喀则市/聂拉木县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540236', '540200', '540000,540200', '萨嘎县', '西藏自治区/日喀则市/萨嘎县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540237', '540200', '540000,540200', '岗巴县', '西藏自治区/日喀则市/岗巴县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540300', '540000', '540000', '昌都市', '西藏自治区/昌都市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540302', '540300', '540000,540300', '卡若区', '西藏自治区/昌都市/卡若区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540321', '540300', '540000,540300', '江达县', '西藏自治区/昌都市/江达县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540322', '540300', '540000,540300', '贡觉县', '西藏自治区/昌都市/贡觉县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540323', '540300', '540000,540300', '类乌齐县', '西藏自治区/昌都市/类乌齐县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540324', '540300', '540000,540300', '丁青县', '西藏自治区/昌都市/丁青县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540325', '540300', '540000,540300', '察雅县', '西藏自治区/昌都市/察雅县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540326', '540300', '540000,540300', '八宿县', '西藏自治区/昌都市/八宿县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540327', '540300', '540000,540300', '左贡县', '西藏自治区/昌都市/左贡县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540328', '540300', '540000,540300', '芒康县', '西藏自治区/昌都市/芒康县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540329', '540300', '540000,540300', '洛隆县', '西藏自治区/昌都市/洛隆县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540330', '540300', '540000,540300', '边坝县', '西藏自治区/昌都市/边坝县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540400', '540000', '540000', '林芝市', '西藏自治区/林芝市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540402', '540400', '540000,540400', '巴宜区', '西藏自治区/林芝市/巴宜区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540421', '540400', '540000,540400', '工布江达县', '西藏自治区/林芝市/工布江达县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540422', '540400', '540000,540400', '米林县', '西藏自治区/林芝市/米林县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540423', '540400', '540000,540400', '墨脱县', '西藏自治区/林芝市/墨脱县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540424', '540400', '540000,540400', '波密县', '西藏自治区/林芝市/波密县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540425', '540400', '540000,540400', '察隅县', '西藏自治区/林芝市/察隅县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540426', '540400', '540000,540400', '朗县', '西藏自治区/林芝市/朗县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540500', '540000', '540000', '山南市', '西藏自治区/山南市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540501', '540500', '540000,540500', '市辖区', '西藏自治区/山南市/市辖区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540502', '540500', '540000,540500', '乃东区', '西藏自治区/山南市/乃东区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540521', '540500', '540000,540500', '扎囊县', '西藏自治区/山南市/扎囊县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540522', '540500', '540000,540500', '贡嘎县', '西藏自治区/山南市/贡嘎县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540523', '540500', '540000,540500', '桑日县', '西藏自治区/山南市/桑日县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540524', '540500', '540000,540500', '琼结县', '西藏自治区/山南市/琼结县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540525', '540500', '540000,540500', '曲松县', '西藏自治区/山南市/曲松县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540526', '540500', '540000,540500', '措美县', '西藏自治区/山南市/措美县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540527', '540500', '540000,540500', '洛扎县', '西藏自治区/山南市/洛扎县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540528', '540500', '540000,540500', '加查县', '西藏自治区/山南市/加查县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540529', '540500', '540000,540500', '隆子县', '西藏自治区/山南市/隆子县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540530', '540500', '540000,540500', '错那县', '西藏自治区/山南市/错那县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540531', '540500', '540000,540500', '浪卡子县', '西藏自治区/山南市/浪卡子县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540600', '540000', '540000', '那曲市', '西藏自治区/那曲市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540602', '540600', '540000,540600', '色尼区', '西藏自治区/那曲市/色尼区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540621', '540600', '540000,540600', '嘉黎县', '西藏自治区/那曲市/嘉黎县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540622', '540600', '540000,540600', '比如县', '西藏自治区/那曲市/比如县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540623', '540600', '540000,540600', '聂荣县', '西藏自治区/那曲市/聂荣县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540624', '540600', '540000,540600', '安多县', '西藏自治区/那曲市/安多县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540625', '540600', '540000,540600', '申扎县', '西藏自治区/那曲市/申扎县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540626', '540600', '540000,540600', '索县', '西藏自治区/那曲市/索县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540627', '540600', '540000,540600', '班戈县', '西藏自治区/那曲市/班戈县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540628', '540600', '540000,540600', '巴青县', '西藏自治区/那曲市/巴青县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540629', '540600', '540000,540600', '尼玛县', '西藏自治区/那曲市/尼玛县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('540630', '540600', '540000,540600', '双湖县', '西藏自治区/那曲市/双湖县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('542500', '540000', '540000', '阿里地区', '西藏自治区/阿里地区', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('542521', '542500', '540000,542500', '普兰县', '西藏自治区/阿里地区/普兰县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('542522', '542500', '540000,542500', '札达县', '西藏自治区/阿里地区/札达县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('542523', '542500', '540000,542500', '噶尔县', '西藏自治区/阿里地区/噶尔县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('542524', '542500', '540000,542500', '日土县', '西藏自治区/阿里地区/日土县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('542525', '542500', '540000,542500', '革吉县', '西藏自治区/阿里地区/革吉县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('542526', '542500', '540000,542500', '改则县', '西藏自治区/阿里地区/改则县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('542527', '542500', '540000,542500', '措勤县', '西藏自治区/阿里地区/措勤县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610000', '86', '', '陕西省', '陕西省', 1, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610100', '610000', '610000', '西安市', '陕西省/西安市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610101', '610100', '610000,610100', '市辖区', '陕西省/西安市/市辖区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610102', '610100', '610000,610100', '新城区', '陕西省/西安市/新城区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610103', '610100', '610000,610100', '碑林区', '陕西省/西安市/碑林区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610104', '610100', '610000,610100', '莲湖区', '陕西省/西安市/莲湖区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610111', '610100', '610000,610100', '灞桥区', '陕西省/西安市/灞桥区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610112', '610100', '610000,610100', '未央区', '陕西省/西安市/未央区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610113', '610100', '610000,610100', '雁塔区', '陕西省/西安市/雁塔区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610114', '610100', '610000,610100', '阎良区', '陕西省/西安市/阎良区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610115', '610100', '610000,610100', '临潼区', '陕西省/西安市/临潼区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610116', '610100', '610000,610100', '长安区', '陕西省/西安市/长安区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610117', '610100', '610000,610100', '高陵区', '陕西省/西安市/高陵区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610118', '610100', '610000,610100', '鄠邑区', '陕西省/西安市/鄠邑区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610122', '610100', '610000,610100', '蓝田县', '陕西省/西安市/蓝田县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610124', '610100', '610000,610100', '周至县', '陕西省/西安市/周至县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610200', '610000', '610000', '铜川市', '陕西省/铜川市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610201', '610200', '610000,610200', '市辖区', '陕西省/铜川市/市辖区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610202', '610200', '610000,610200', '王益区', '陕西省/铜川市/王益区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610203', '610200', '610000,610200', '印台区', '陕西省/铜川市/印台区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610204', '610200', '610000,610200', '耀州区', '陕西省/铜川市/耀州区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610222', '610200', '610000,610200', '宜君县', '陕西省/铜川市/宜君县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610300', '610000', '610000', '宝鸡市', '陕西省/宝鸡市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610301', '610300', '610000,610300', '市辖区', '陕西省/宝鸡市/市辖区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610302', '610300', '610000,610300', '渭滨区', '陕西省/宝鸡市/渭滨区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610303', '610300', '610000,610300', '金台区', '陕西省/宝鸡市/金台区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610304', '610300', '610000,610300', '陈仓区', '陕西省/宝鸡市/陈仓区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610322', '610300', '610000,610300', '凤翔县', '陕西省/宝鸡市/凤翔县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610323', '610300', '610000,610300', '岐山县', '陕西省/宝鸡市/岐山县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610324', '610300', '610000,610300', '扶风县', '陕西省/宝鸡市/扶风县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610326', '610300', '610000,610300', '眉县', '陕西省/宝鸡市/眉县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610327', '610300', '610000,610300', '陇县', '陕西省/宝鸡市/陇县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610328', '610300', '610000,610300', '千阳县', '陕西省/宝鸡市/千阳县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610329', '610300', '610000,610300', '麟游县', '陕西省/宝鸡市/麟游县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610330', '610300', '610000,610300', '凤县', '陕西省/宝鸡市/凤县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610331', '610300', '610000,610300', '太白县', '陕西省/宝鸡市/太白县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610400', '610000', '610000', '咸阳市', '陕西省/咸阳市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610401', '610400', '610000,610400', '市辖区', '陕西省/咸阳市/市辖区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610402', '610400', '610000,610400', '秦都区', '陕西省/咸阳市/秦都区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610403', '610400', '610000,610400', '杨陵区', '陕西省/咸阳市/杨陵区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610404', '610400', '610000,610400', '渭城区', '陕西省/咸阳市/渭城区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610422', '610400', '610000,610400', '三原县', '陕西省/咸阳市/三原县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610423', '610400', '610000,610400', '泾阳县', '陕西省/咸阳市/泾阳县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610424', '610400', '610000,610400', '乾县', '陕西省/咸阳市/乾县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610425', '610400', '610000,610400', '礼泉县', '陕西省/咸阳市/礼泉县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610426', '610400', '610000,610400', '永寿县', '陕西省/咸阳市/永寿县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610428', '610400', '610000,610400', '长武县', '陕西省/咸阳市/长武县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610429', '610400', '610000,610400', '旬邑县', '陕西省/咸阳市/旬邑县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610430', '610400', '610000,610400', '淳化县', '陕西省/咸阳市/淳化县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610431', '610400', '610000,610400', '武功县', '陕西省/咸阳市/武功县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610481', '610400', '610000,610400', '兴平市', '陕西省/咸阳市/兴平市', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610482', '610400', '610000,610400', '彬州市', '陕西省/咸阳市/彬州市', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610500', '610000', '610000', '渭南市', '陕西省/渭南市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610501', '610500', '610000,610500', '市辖区', '陕西省/渭南市/市辖区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610502', '610500', '610000,610500', '临渭区', '陕西省/渭南市/临渭区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610503', '610500', '610000,610500', '华州区', '陕西省/渭南市/华州区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610522', '610500', '610000,610500', '潼关县', '陕西省/渭南市/潼关县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610523', '610500', '610000,610500', '大荔县', '陕西省/渭南市/大荔县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610524', '610500', '610000,610500', '合阳县', '陕西省/渭南市/合阳县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610525', '610500', '610000,610500', '澄城县', '陕西省/渭南市/澄城县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610526', '610500', '610000,610500', '蒲城县', '陕西省/渭南市/蒲城县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610527', '610500', '610000,610500', '白水县', '陕西省/渭南市/白水县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610528', '610500', '610000,610500', '富平县', '陕西省/渭南市/富平县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610581', '610500', '610000,610500', '韩城市', '陕西省/渭南市/韩城市', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610582', '610500', '610000,610500', '华阴市', '陕西省/渭南市/华阴市', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610600', '610000', '610000', '延安市', '陕西省/延安市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610601', '610600', '610000,610600', '市辖区', '陕西省/延安市/市辖区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610602', '610600', '610000,610600', '宝塔区', '陕西省/延安市/宝塔区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610603', '610600', '610000,610600', '安塞区', '陕西省/延安市/安塞区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610621', '610600', '610000,610600', '延长县', '陕西省/延安市/延长县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610622', '610600', '610000,610600', '延川县', '陕西省/延安市/延川县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610625', '610600', '610000,610600', '志丹县', '陕西省/延安市/志丹县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610626', '610600', '610000,610600', '吴起县', '陕西省/延安市/吴起县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610627', '610600', '610000,610600', '甘泉县', '陕西省/延安市/甘泉县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610628', '610600', '610000,610600', '富县', '陕西省/延安市/富县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610629', '610600', '610000,610600', '洛川县', '陕西省/延安市/洛川县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610630', '610600', '610000,610600', '宜川县', '陕西省/延安市/宜川县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610631', '610600', '610000,610600', '黄龙县', '陕西省/延安市/黄龙县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610632', '610600', '610000,610600', '黄陵县', '陕西省/延安市/黄陵县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610681', '610600', '610000,610600', '子长市', '陕西省/延安市/子长市', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610700', '610000', '610000', '汉中市', '陕西省/汉中市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610701', '610700', '610000,610700', '市辖区', '陕西省/汉中市/市辖区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610702', '610700', '610000,610700', '汉台区', '陕西省/汉中市/汉台区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610703', '610700', '610000,610700', '南郑区', '陕西省/汉中市/南郑区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610722', '610700', '610000,610700', '城固县', '陕西省/汉中市/城固县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610723', '610700', '610000,610700', '洋县', '陕西省/汉中市/洋县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610724', '610700', '610000,610700', '西乡县', '陕西省/汉中市/西乡县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610725', '610700', '610000,610700', '勉县', '陕西省/汉中市/勉县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610726', '610700', '610000,610700', '宁强县', '陕西省/汉中市/宁强县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610727', '610700', '610000,610700', '略阳县', '陕西省/汉中市/略阳县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610728', '610700', '610000,610700', '镇巴县', '陕西省/汉中市/镇巴县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610729', '610700', '610000,610700', '留坝县', '陕西省/汉中市/留坝县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610730', '610700', '610000,610700', '佛坪县', '陕西省/汉中市/佛坪县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610800', '610000', '610000', '榆林市', '陕西省/榆林市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610801', '610800', '610000,610800', '市辖区', '陕西省/榆林市/市辖区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610802', '610800', '610000,610800', '榆阳区', '陕西省/榆林市/榆阳区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610803', '610800', '610000,610800', '横山区', '陕西省/榆林市/横山区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610822', '610800', '610000,610800', '府谷县', '陕西省/榆林市/府谷县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610824', '610800', '610000,610800', '靖边县', '陕西省/榆林市/靖边县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610825', '610800', '610000,610800', '定边县', '陕西省/榆林市/定边县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610826', '610800', '610000,610800', '绥德县', '陕西省/榆林市/绥德县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610827', '610800', '610000,610800', '米脂县', '陕西省/榆林市/米脂县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610828', '610800', '610000,610800', '佳县', '陕西省/榆林市/佳县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610829', '610800', '610000,610800', '吴堡县', '陕西省/榆林市/吴堡县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610830', '610800', '610000,610800', '清涧县', '陕西省/榆林市/清涧县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610831', '610800', '610000,610800', '子洲县', '陕西省/榆林市/子洲县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610881', '610800', '610000,610800', '神木市', '陕西省/榆林市/神木市', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610900', '610000', '610000', '安康市', '陕西省/安康市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610901', '610900', '610000,610900', '市辖区', '陕西省/安康市/市辖区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610902', '610900', '610000,610900', '汉滨区', '陕西省/安康市/汉滨区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610921', '610900', '610000,610900', '汉阴县', '陕西省/安康市/汉阴县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610922', '610900', '610000,610900', '石泉县', '陕西省/安康市/石泉县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610923', '610900', '610000,610900', '宁陕县', '陕西省/安康市/宁陕县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610924', '610900', '610000,610900', '紫阳县', '陕西省/安康市/紫阳县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610925', '610900', '610000,610900', '岚皋县', '陕西省/安康市/岚皋县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610926', '610900', '610000,610900', '平利县', '陕西省/安康市/平利县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610927', '610900', '610000,610900', '镇坪县', '陕西省/安康市/镇坪县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610928', '610900', '610000,610900', '旬阳县', '陕西省/安康市/旬阳县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('610929', '610900', '610000,610900', '白河县', '陕西省/安康市/白河县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('611000', '610000', '610000', '商洛市', '陕西省/商洛市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('611001', '611000', '610000,611000', '市辖区', '陕西省/商洛市/市辖区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('611002', '611000', '610000,611000', '商州区', '陕西省/商洛市/商州区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('611021', '611000', '610000,611000', '洛南县', '陕西省/商洛市/洛南县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('611022', '611000', '610000,611000', '丹凤县', '陕西省/商洛市/丹凤县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('611023', '611000', '610000,611000', '商南县', '陕西省/商洛市/商南县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('611024', '611000', '610000,611000', '山阳县', '陕西省/商洛市/山阳县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('611025', '611000', '610000,611000', '镇安县', '陕西省/商洛市/镇安县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('611026', '611000', '610000,611000', '柞水县', '陕西省/商洛市/柞水县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620000', '86', '', '甘肃省', '甘肃省', 1, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620100', '620000', '620000', '兰州市', '甘肃省/兰州市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620101', '620100', '620000,620100', '市辖区', '甘肃省/兰州市/市辖区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620102', '620100', '620000,620100', '城关区', '甘肃省/兰州市/城关区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620103', '620100', '620000,620100', '七里河区', '甘肃省/兰州市/七里河区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620104', '620100', '620000,620100', '西固区', '甘肃省/兰州市/西固区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620105', '620100', '620000,620100', '安宁区', '甘肃省/兰州市/安宁区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620111', '620100', '620000,620100', '红古区', '甘肃省/兰州市/红古区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620121', '620100', '620000,620100', '永登县', '甘肃省/兰州市/永登县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620122', '620100', '620000,620100', '皋兰县', '甘肃省/兰州市/皋兰县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620123', '620100', '620000,620100', '榆中县', '甘肃省/兰州市/榆中县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620171', '620100', '620000,620100', '兰州新区', '甘肃省/兰州市/兰州新区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620200', '620000', '620000', '嘉峪关市', '甘肃省/嘉峪关市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620201', '620200', '620000,620200', '市辖区', '甘肃省/嘉峪关市/市辖区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620300', '620000', '620000', '金昌市', '甘肃省/金昌市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620301', '620300', '620000,620300', '市辖区', '甘肃省/金昌市/市辖区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620302', '620300', '620000,620300', '金川区', '甘肃省/金昌市/金川区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620321', '620300', '620000,620300', '永昌县', '甘肃省/金昌市/永昌县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620400', '620000', '620000', '白银市', '甘肃省/白银市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620401', '620400', '620000,620400', '市辖区', '甘肃省/白银市/市辖区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620402', '620400', '620000,620400', '白银区', '甘肃省/白银市/白银区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620403', '620400', '620000,620400', '平川区', '甘肃省/白银市/平川区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620421', '620400', '620000,620400', '靖远县', '甘肃省/白银市/靖远县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620422', '620400', '620000,620400', '会宁县', '甘肃省/白银市/会宁县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620423', '620400', '620000,620400', '景泰县', '甘肃省/白银市/景泰县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620500', '620000', '620000', '天水市', '甘肃省/天水市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620501', '620500', '620000,620500', '市辖区', '甘肃省/天水市/市辖区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620502', '620500', '620000,620500', '秦州区', '甘肃省/天水市/秦州区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620503', '620500', '620000,620500', '麦积区', '甘肃省/天水市/麦积区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620521', '620500', '620000,620500', '清水县', '甘肃省/天水市/清水县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620522', '620500', '620000,620500', '秦安县', '甘肃省/天水市/秦安县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620523', '620500', '620000,620500', '甘谷县', '甘肃省/天水市/甘谷县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620524', '620500', '620000,620500', '武山县', '甘肃省/天水市/武山县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620525', '620500', '620000,620500', '张家川回族自治县', '甘肃省/天水市/张家川回族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620600', '620000', '620000', '武威市', '甘肃省/武威市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620601', '620600', '620000,620600', '市辖区', '甘肃省/武威市/市辖区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620602', '620600', '620000,620600', '凉州区', '甘肃省/武威市/凉州区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620621', '620600', '620000,620600', '民勤县', '甘肃省/武威市/民勤县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620622', '620600', '620000,620600', '古浪县', '甘肃省/武威市/古浪县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620623', '620600', '620000,620600', '天祝藏族自治县', '甘肃省/武威市/天祝藏族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620700', '620000', '620000', '张掖市', '甘肃省/张掖市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620701', '620700', '620000,620700', '市辖区', '甘肃省/张掖市/市辖区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620702', '620700', '620000,620700', '甘州区', '甘肃省/张掖市/甘州区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620721', '620700', '620000,620700', '肃南裕固族自治县', '甘肃省/张掖市/肃南裕固族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620722', '620700', '620000,620700', '民乐县', '甘肃省/张掖市/民乐县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620723', '620700', '620000,620700', '临泽县', '甘肃省/张掖市/临泽县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620724', '620700', '620000,620700', '高台县', '甘肃省/张掖市/高台县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620725', '620700', '620000,620700', '山丹县', '甘肃省/张掖市/山丹县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620800', '620000', '620000', '平凉市', '甘肃省/平凉市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620801', '620800', '620000,620800', '市辖区', '甘肃省/平凉市/市辖区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620802', '620800', '620000,620800', '崆峒区', '甘肃省/平凉市/崆峒区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620821', '620800', '620000,620800', '泾川县', '甘肃省/平凉市/泾川县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620822', '620800', '620000,620800', '灵台县', '甘肃省/平凉市/灵台县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620823', '620800', '620000,620800', '崇信县', '甘肃省/平凉市/崇信县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620825', '620800', '620000,620800', '庄浪县', '甘肃省/平凉市/庄浪县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620826', '620800', '620000,620800', '静宁县', '甘肃省/平凉市/静宁县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620881', '620800', '620000,620800', '华亭市', '甘肃省/平凉市/华亭市', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620900', '620000', '620000', '酒泉市', '甘肃省/酒泉市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620901', '620900', '620000,620900', '市辖区', '甘肃省/酒泉市/市辖区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620902', '620900', '620000,620900', '肃州区', '甘肃省/酒泉市/肃州区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620921', '620900', '620000,620900', '金塔县', '甘肃省/酒泉市/金塔县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620922', '620900', '620000,620900', '瓜州县', '甘肃省/酒泉市/瓜州县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620923', '620900', '620000,620900', '肃北蒙古族自治县', '甘肃省/酒泉市/肃北蒙古族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620924', '620900', '620000,620900', '阿克塞哈萨克族自治县', '甘肃省/酒泉市/阿克塞哈萨克族自治县', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620981', '620900', '620000,620900', '玉门市', '甘肃省/酒泉市/玉门市', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('620982', '620900', '620000,620900', '敦煌市', '甘肃省/酒泉市/敦煌市', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('621000', '620000', '620000', '庆阳市', '甘肃省/庆阳市', 2, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('621001', '621000', '620000,621000', '市辖区', '甘肃省/庆阳市/市辖区', 3, 'admin', '2022-05-22 20:35:20', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('621002', '621000', '620000,621000', '西峰区', '甘肃省/庆阳市/西峰区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('621021', '621000', '620000,621000', '庆城县', '甘肃省/庆阳市/庆城县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('621022', '621000', '620000,621000', '环县', '甘肃省/庆阳市/环县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('621023', '621000', '620000,621000', '华池县', '甘肃省/庆阳市/华池县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('621024', '621000', '620000,621000', '合水县', '甘肃省/庆阳市/合水县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('621025', '621000', '620000,621000', '正宁县', '甘肃省/庆阳市/正宁县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('621026', '621000', '620000,621000', '宁县', '甘肃省/庆阳市/宁县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('621027', '621000', '620000,621000', '镇原县', '甘肃省/庆阳市/镇原县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('621100', '620000', '620000', '定西市', '甘肃省/定西市', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('621101', '621100', '620000,621100', '市辖区', '甘肃省/定西市/市辖区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('621102', '621100', '620000,621100', '安定区', '甘肃省/定西市/安定区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('621121', '621100', '620000,621100', '通渭县', '甘肃省/定西市/通渭县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('621122', '621100', '620000,621100', '陇西县', '甘肃省/定西市/陇西县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('621123', '621100', '620000,621100', '渭源县', '甘肃省/定西市/渭源县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('621124', '621100', '620000,621100', '临洮县', '甘肃省/定西市/临洮县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('621125', '621100', '620000,621100', '漳县', '甘肃省/定西市/漳县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('621126', '621100', '620000,621100', '岷县', '甘肃省/定西市/岷县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('621200', '620000', '620000', '陇南市', '甘肃省/陇南市', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('621201', '621200', '620000,621200', '市辖区', '甘肃省/陇南市/市辖区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('621202', '621200', '620000,621200', '武都区', '甘肃省/陇南市/武都区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('621221', '621200', '620000,621200', '成县', '甘肃省/陇南市/成县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('621222', '621200', '620000,621200', '文县', '甘肃省/陇南市/文县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('621223', '621200', '620000,621200', '宕昌县', '甘肃省/陇南市/宕昌县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('621224', '621200', '620000,621200', '康县', '甘肃省/陇南市/康县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('621225', '621200', '620000,621200', '西和县', '甘肃省/陇南市/西和县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('621226', '621200', '620000,621200', '礼县', '甘肃省/陇南市/礼县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('621227', '621200', '620000,621200', '徽县', '甘肃省/陇南市/徽县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('621228', '621200', '620000,621200', '两当县', '甘肃省/陇南市/两当县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('622900', '620000', '620000', '临夏回族自治州', '甘肃省/临夏回族自治州', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('622901', '622900', '620000,622900', '临夏市', '甘肃省/临夏回族自治州/临夏市', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('622921', '622900', '620000,622900', '临夏县', '甘肃省/临夏回族自治州/临夏县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('622922', '622900', '620000,622900', '康乐县', '甘肃省/临夏回族自治州/康乐县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('622923', '622900', '620000,622900', '永靖县', '甘肃省/临夏回族自治州/永靖县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('622924', '622900', '620000,622900', '广河县', '甘肃省/临夏回族自治州/广河县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('622925', '622900', '620000,622900', '和政县', '甘肃省/临夏回族自治州/和政县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('622926', '622900', '620000,622900', '东乡族自治县', '甘肃省/临夏回族自治州/东乡族自治县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('622927', '622900', '620000,622900', '积石山保安族东乡族撒拉族自治县', '甘肃省/临夏回族自治州/积石山保安族东乡族撒拉族自治县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('623000', '620000', '620000', '甘南藏族自治州', '甘肃省/甘南藏族自治州', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('623001', '623000', '620000,623000', '合作市', '甘肃省/甘南藏族自治州/合作市', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('623021', '623000', '620000,623000', '临潭县', '甘肃省/甘南藏族自治州/临潭县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('623022', '623000', '620000,623000', '卓尼县', '甘肃省/甘南藏族自治州/卓尼县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('623023', '623000', '620000,623000', '舟曲县', '甘肃省/甘南藏族自治州/舟曲县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('623024', '623000', '620000,623000', '迭部县', '甘肃省/甘南藏族自治州/迭部县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('623025', '623000', '620000,623000', '玛曲县', '甘肃省/甘南藏族自治州/玛曲县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('623026', '623000', '620000,623000', '碌曲县', '甘肃省/甘南藏族自治州/碌曲县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('623027', '623000', '620000,623000', '夏河县', '甘肃省/甘南藏族自治州/夏河县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('630000', '86', '', '青海省', '青海省', 1, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('630100', '630000', '630000', '西宁市', '青海省/西宁市', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('630101', '630100', '630000,630100', '市辖区', '青海省/西宁市/市辖区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('630102', '630100', '630000,630100', '城东区', '青海省/西宁市/城东区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('630103', '630100', '630000,630100', '城中区', '青海省/西宁市/城中区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('630104', '630100', '630000,630100', '城西区', '青海省/西宁市/城西区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('630105', '630100', '630000,630100', '城北区', '青海省/西宁市/城北区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('630121', '630100', '630000,630100', '大通回族土族自治县', '青海省/西宁市/大通回族土族自治县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('630122', '630100', '630000,630100', '湟中县', '青海省/西宁市/湟中县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('630123', '630100', '630000,630100', '湟源县', '青海省/西宁市/湟源县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('630200', '630000', '630000', '海东市', '青海省/海东市', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('630202', '630200', '630000,630200', '乐都区', '青海省/海东市/乐都区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('630203', '630200', '630000,630200', '平安区', '青海省/海东市/平安区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('630222', '630200', '630000,630200', '民和回族土族自治县', '青海省/海东市/民和回族土族自治县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('630223', '630200', '630000,630200', '互助土族自治县', '青海省/海东市/互助土族自治县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('630224', '630200', '630000,630200', '化隆回族自治县', '青海省/海东市/化隆回族自治县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('630225', '630200', '630000,630200', '循化撒拉族自治县', '青海省/海东市/循化撒拉族自治县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632200', '630000', '630000', '海北藏族自治州', '青海省/海北藏族自治州', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632221', '632200', '630000,632200', '门源回族自治县', '青海省/海北藏族自治州/门源回族自治县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632222', '632200', '630000,632200', '祁连县', '青海省/海北藏族自治州/祁连县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632223', '632200', '630000,632200', '海晏县', '青海省/海北藏族自治州/海晏县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632224', '632200', '630000,632200', '刚察县', '青海省/海北藏族自治州/刚察县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632300', '630000', '630000', '黄南藏族自治州', '青海省/黄南藏族自治州', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632321', '632300', '630000,632300', '同仁县', '青海省/黄南藏族自治州/同仁县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632322', '632300', '630000,632300', '尖扎县', '青海省/黄南藏族自治州/尖扎县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632323', '632300', '630000,632300', '泽库县', '青海省/黄南藏族自治州/泽库县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632324', '632300', '630000,632300', '河南蒙古族自治县', '青海省/黄南藏族自治州/河南蒙古族自治县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632500', '630000', '630000', '海南藏族自治州', '青海省/海南藏族自治州', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632521', '632500', '630000,632500', '共和县', '青海省/海南藏族自治州/共和县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632522', '632500', '630000,632500', '同德县', '青海省/海南藏族自治州/同德县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632523', '632500', '630000,632500', '贵德县', '青海省/海南藏族自治州/贵德县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632524', '632500', '630000,632500', '兴海县', '青海省/海南藏族自治州/兴海县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632525', '632500', '630000,632500', '贵南县', '青海省/海南藏族自治州/贵南县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632600', '630000', '630000', '果洛藏族自治州', '青海省/果洛藏族自治州', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632621', '632600', '630000,632600', '玛沁县', '青海省/果洛藏族自治州/玛沁县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632622', '632600', '630000,632600', '班玛县', '青海省/果洛藏族自治州/班玛县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632623', '632600', '630000,632600', '甘德县', '青海省/果洛藏族自治州/甘德县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632624', '632600', '630000,632600', '达日县', '青海省/果洛藏族自治州/达日县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632625', '632600', '630000,632600', '久治县', '青海省/果洛藏族自治州/久治县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632626', '632600', '630000,632600', '玛多县', '青海省/果洛藏族自治州/玛多县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632700', '630000', '630000', '玉树藏族自治州', '青海省/玉树藏族自治州', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632701', '632700', '630000,632700', '玉树市', '青海省/玉树藏族自治州/玉树市', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632722', '632700', '630000,632700', '杂多县', '青海省/玉树藏族自治州/杂多县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632723', '632700', '630000,632700', '称多县', '青海省/玉树藏族自治州/称多县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632724', '632700', '630000,632700', '治多县', '青海省/玉树藏族自治州/治多县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632725', '632700', '630000,632700', '囊谦县', '青海省/玉树藏族自治州/囊谦县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632726', '632700', '630000,632700', '曲麻莱县', '青海省/玉树藏族自治州/曲麻莱县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632800', '630000', '630000', '海西蒙古族藏族自治州', '青海省/海西蒙古族藏族自治州', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632801', '632800', '630000,632800', '格尔木市', '青海省/海西蒙古族藏族自治州/格尔木市', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632802', '632800', '630000,632800', '德令哈市', '青海省/海西蒙古族藏族自治州/德令哈市', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632803', '632800', '630000,632800', '茫崖市', '青海省/海西蒙古族藏族自治州/茫崖市', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632821', '632800', '630000,632800', '乌兰县', '青海省/海西蒙古族藏族自治州/乌兰县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632822', '632800', '630000,632800', '都兰县', '青海省/海西蒙古族藏族自治州/都兰县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632823', '632800', '630000,632800', '天峻县', '青海省/海西蒙古族藏族自治州/天峻县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('632857', '632800', '630000,632800', '大柴旦行政委员会', '青海省/海西蒙古族藏族自治州/大柴旦行政委员会', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640000', '86', '', '宁夏回族自治区', '宁夏回族自治区', 1, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640100', '640000', '640000', '银川市', '宁夏回族自治区/银川市', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640101', '640100', '640000,640100', '市辖区', '宁夏回族自治区/银川市/市辖区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640104', '640100', '640000,640100', '兴庆区', '宁夏回族自治区/银川市/兴庆区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640105', '640100', '640000,640100', '西夏区', '宁夏回族自治区/银川市/西夏区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640106', '640100', '640000,640100', '金凤区', '宁夏回族自治区/银川市/金凤区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640121', '640100', '640000,640100', '永宁县', '宁夏回族自治区/银川市/永宁县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640122', '640100', '640000,640100', '贺兰县', '宁夏回族自治区/银川市/贺兰县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640181', '640100', '640000,640100', '灵武市', '宁夏回族自治区/银川市/灵武市', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640200', '640000', '640000', '石嘴山市', '宁夏回族自治区/石嘴山市', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640201', '640200', '640000,640200', '市辖区', '宁夏回族自治区/石嘴山市/市辖区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640202', '640200', '640000,640200', '大武口区', '宁夏回族自治区/石嘴山市/大武口区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640205', '640200', '640000,640200', '惠农区', '宁夏回族自治区/石嘴山市/惠农区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640221', '640200', '640000,640200', '平罗县', '宁夏回族自治区/石嘴山市/平罗县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640300', '640000', '640000', '吴忠市', '宁夏回族自治区/吴忠市', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640301', '640300', '640000,640300', '市辖区', '宁夏回族自治区/吴忠市/市辖区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640302', '640300', '640000,640300', '利通区', '宁夏回族自治区/吴忠市/利通区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640303', '640300', '640000,640300', '红寺堡区', '宁夏回族自治区/吴忠市/红寺堡区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640323', '640300', '640000,640300', '盐池县', '宁夏回族自治区/吴忠市/盐池县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640324', '640300', '640000,640300', '同心县', '宁夏回族自治区/吴忠市/同心县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640381', '640300', '640000,640300', '青铜峡市', '宁夏回族自治区/吴忠市/青铜峡市', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640400', '640000', '640000', '固原市', '宁夏回族自治区/固原市', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640401', '640400', '640000,640400', '市辖区', '宁夏回族自治区/固原市/市辖区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640402', '640400', '640000,640400', '原州区', '宁夏回族自治区/固原市/原州区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640422', '640400', '640000,640400', '西吉县', '宁夏回族自治区/固原市/西吉县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640423', '640400', '640000,640400', '隆德县', '宁夏回族自治区/固原市/隆德县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640424', '640400', '640000,640400', '泾源县', '宁夏回族自治区/固原市/泾源县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640425', '640400', '640000,640400', '彭阳县', '宁夏回族自治区/固原市/彭阳县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640500', '640000', '640000', '中卫市', '宁夏回族自治区/中卫市', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640501', '640500', '640000,640500', '市辖区', '宁夏回族自治区/中卫市/市辖区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640502', '640500', '640000,640500', '沙坡头区', '宁夏回族自治区/中卫市/沙坡头区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640521', '640500', '640000,640500', '中宁县', '宁夏回族自治区/中卫市/中宁县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('640522', '640500', '640000,640500', '海原县', '宁夏回族自治区/中卫市/海原县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('650000', '86', '', '新疆维吾尔自治区', '新疆维吾尔自治区', 1, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('650100', '650000', '650000', '乌鲁木齐市', '新疆维吾尔自治区/乌鲁木齐市', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('650101', '650100', '650000,650100', '市辖区', '新疆维吾尔自治区/乌鲁木齐市/市辖区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('650102', '650100', '650000,650100', '天山区', '新疆维吾尔自治区/乌鲁木齐市/天山区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('650103', '650100', '650000,650100', '沙依巴克区', '新疆维吾尔自治区/乌鲁木齐市/沙依巴克区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('650104', '650100', '650000,650100', '新市区', '新疆维吾尔自治区/乌鲁木齐市/新市区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('650105', '650100', '650000,650100', '水磨沟区', '新疆维吾尔自治区/乌鲁木齐市/水磨沟区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('650106', '650100', '650000,650100', '头屯河区', '新疆维吾尔自治区/乌鲁木齐市/头屯河区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('650107', '650100', '650000,650100', '达坂城区', '新疆维吾尔自治区/乌鲁木齐市/达坂城区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('650109', '650100', '650000,650100', '米东区', '新疆维吾尔自治区/乌鲁木齐市/米东区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('650121', '650100', '650000,650100', '乌鲁木齐县', '新疆维吾尔自治区/乌鲁木齐市/乌鲁木齐县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('650200', '650000', '650000', '克拉玛依市', '新疆维吾尔自治区/克拉玛依市', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('650201', '650200', '650000,650200', '市辖区', '新疆维吾尔自治区/克拉玛依市/市辖区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('650202', '650200', '650000,650200', '独山子区', '新疆维吾尔自治区/克拉玛依市/独山子区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('650203', '650200', '650000,650200', '克拉玛依区', '新疆维吾尔自治区/克拉玛依市/克拉玛依区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('650204', '650200', '650000,650200', '白碱滩区', '新疆维吾尔自治区/克拉玛依市/白碱滩区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('650205', '650200', '650000,650200', '乌尔禾区', '新疆维吾尔自治区/克拉玛依市/乌尔禾区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('650400', '650000', '650000', '吐鲁番市', '新疆维吾尔自治区/吐鲁番市', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('650402', '650400', '650000,650400', '高昌区', '新疆维吾尔自治区/吐鲁番市/高昌区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('650421', '650400', '650000,650400', '鄯善县', '新疆维吾尔自治区/吐鲁番市/鄯善县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('650422', '650400', '650000,650400', '托克逊县', '新疆维吾尔自治区/吐鲁番市/托克逊县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('650500', '650000', '650000', '哈密市', '新疆维吾尔自治区/哈密市', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('650502', '650500', '650000,650500', '伊州区', '新疆维吾尔自治区/哈密市/伊州区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('650521', '650500', '650000,650500', '巴里坤哈萨克自治县', '新疆维吾尔自治区/哈密市/巴里坤哈萨克自治县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('650522', '650500', '650000,650500', '伊吾县', '新疆维吾尔自治区/哈密市/伊吾县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652300', '650000', '650000', '昌吉回族自治州', '新疆维吾尔自治区/昌吉回族自治州', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652301', '652300', '650000,652300', '昌吉市', '新疆维吾尔自治区/昌吉回族自治州/昌吉市', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652302', '652300', '650000,652300', '阜康市', '新疆维吾尔自治区/昌吉回族自治州/阜康市', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652323', '652300', '650000,652300', '呼图壁县', '新疆维吾尔自治区/昌吉回族自治州/呼图壁县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652324', '652300', '650000,652300', '玛纳斯县', '新疆维吾尔自治区/昌吉回族自治州/玛纳斯县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652325', '652300', '650000,652300', '奇台县', '新疆维吾尔自治区/昌吉回族自治州/奇台县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652327', '652300', '650000,652300', '吉木萨尔县', '新疆维吾尔自治区/昌吉回族自治州/吉木萨尔县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652328', '652300', '650000,652300', '木垒哈萨克自治县', '新疆维吾尔自治区/昌吉回族自治州/木垒哈萨克自治县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652700', '650000', '650000', '博尔塔拉蒙古自治州', '新疆维吾尔自治区/博尔塔拉蒙古自治州', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652701', '652700', '650000,652700', '博乐市', '新疆维吾尔自治区/博尔塔拉蒙古自治州/博乐市', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652702', '652700', '650000,652700', '阿拉山口市', '新疆维吾尔自治区/博尔塔拉蒙古自治州/阿拉山口市', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652722', '652700', '650000,652700', '精河县', '新疆维吾尔自治区/博尔塔拉蒙古自治州/精河县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652723', '652700', '650000,652700', '温泉县', '新疆维吾尔自治区/博尔塔拉蒙古自治州/温泉县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652800', '650000', '650000', '巴音郭楞蒙古自治州', '新疆维吾尔自治区/巴音郭楞蒙古自治州', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652801', '652800', '650000,652800', '库尔勒市', '新疆维吾尔自治区/巴音郭楞蒙古自治州/库尔勒市', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652822', '652800', '650000,652800', '轮台县', '新疆维吾尔自治区/巴音郭楞蒙古自治州/轮台县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652823', '652800', '650000,652800', '尉犁县', '新疆维吾尔自治区/巴音郭楞蒙古自治州/尉犁县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652824', '652800', '650000,652800', '若羌县', '新疆维吾尔自治区/巴音郭楞蒙古自治州/若羌县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652825', '652800', '650000,652800', '且末县', '新疆维吾尔自治区/巴音郭楞蒙古自治州/且末县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652826', '652800', '650000,652800', '焉耆回族自治县', '新疆维吾尔自治区/巴音郭楞蒙古自治州/焉耆回族自治县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652827', '652800', '650000,652800', '和静县', '新疆维吾尔自治区/巴音郭楞蒙古自治州/和静县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652828', '652800', '650000,652800', '和硕县', '新疆维吾尔自治区/巴音郭楞蒙古自治州/和硕县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652829', '652800', '650000,652800', '博湖县', '新疆维吾尔自治区/巴音郭楞蒙古自治州/博湖县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652871', '652800', '650000,652800', '库尔勒经济技术开发区', '新疆维吾尔自治区/巴音郭楞蒙古自治州/库尔勒经济技术开发区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652900', '650000', '650000', '阿克苏地区', '新疆维吾尔自治区/阿克苏地区', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652901', '652900', '650000,652900', '阿克苏市', '新疆维吾尔自治区/阿克苏地区/阿克苏市', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652922', '652900', '650000,652900', '温宿县', '新疆维吾尔自治区/阿克苏地区/温宿县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652923', '652900', '650000,652900', '库车县', '新疆维吾尔自治区/阿克苏地区/库车县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652924', '652900', '650000,652900', '沙雅县', '新疆维吾尔自治区/阿克苏地区/沙雅县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652925', '652900', '650000,652900', '新和县', '新疆维吾尔自治区/阿克苏地区/新和县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652926', '652900', '650000,652900', '拜城县', '新疆维吾尔自治区/阿克苏地区/拜城县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652927', '652900', '650000,652900', '乌什县', '新疆维吾尔自治区/阿克苏地区/乌什县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652928', '652900', '650000,652900', '阿瓦提县', '新疆维吾尔自治区/阿克苏地区/阿瓦提县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('652929', '652900', '650000,652900', '柯坪县', '新疆维吾尔自治区/阿克苏地区/柯坪县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('653000', '650000', '650000', '克孜勒苏柯尔克孜自治州', '新疆维吾尔自治区/克孜勒苏柯尔克孜自治州', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('653001', '653000', '650000,653000', '阿图什市', '新疆维吾尔自治区/克孜勒苏柯尔克孜自治州/阿图什市', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('653022', '653000', '650000,653000', '阿克陶县', '新疆维吾尔自治区/克孜勒苏柯尔克孜自治州/阿克陶县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('653023', '653000', '650000,653000', '阿合奇县', '新疆维吾尔自治区/克孜勒苏柯尔克孜自治州/阿合奇县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('653024', '653000', '650000,653000', '乌恰县', '新疆维吾尔自治区/克孜勒苏柯尔克孜自治州/乌恰县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('653100', '650000', '650000', '喀什地区', '新疆维吾尔自治区/喀什地区', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('653101', '653100', '650000,653100', '喀什市', '新疆维吾尔自治区/喀什地区/喀什市', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('653121', '653100', '650000,653100', '疏附县', '新疆维吾尔自治区/喀什地区/疏附县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('653122', '653100', '650000,653100', '疏勒县', '新疆维吾尔自治区/喀什地区/疏勒县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('653123', '653100', '650000,653100', '英吉沙县', '新疆维吾尔自治区/喀什地区/英吉沙县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('653124', '653100', '650000,653100', '泽普县', '新疆维吾尔自治区/喀什地区/泽普县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('653125', '653100', '650000,653100', '莎车县', '新疆维吾尔自治区/喀什地区/莎车县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('653126', '653100', '650000,653100', '叶城县', '新疆维吾尔自治区/喀什地区/叶城县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('653127', '653100', '650000,653100', '麦盖提县', '新疆维吾尔自治区/喀什地区/麦盖提县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('653128', '653100', '650000,653100', '岳普湖县', '新疆维吾尔自治区/喀什地区/岳普湖县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('653129', '653100', '650000,653100', '伽师县', '新疆维吾尔自治区/喀什地区/伽师县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('653130', '653100', '650000,653100', '巴楚县', '新疆维吾尔自治区/喀什地区/巴楚县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('653131', '653100', '650000,653100', '塔什库尔干塔吉克自治县', '新疆维吾尔自治区/喀什地区/塔什库尔干塔吉克自治县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('653200', '650000', '650000', '和田地区', '新疆维吾尔自治区/和田地区', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('653201', '653200', '650000,653200', '和田市', '新疆维吾尔自治区/和田地区/和田市', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('653221', '653200', '650000,653200', '和田县', '新疆维吾尔自治区/和田地区/和田县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('653222', '653200', '650000,653200', '墨玉县', '新疆维吾尔自治区/和田地区/墨玉县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('653223', '653200', '650000,653200', '皮山县', '新疆维吾尔自治区/和田地区/皮山县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('653224', '653200', '650000,653200', '洛浦县', '新疆维吾尔自治区/和田地区/洛浦县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('653225', '653200', '650000,653200', '策勒县', '新疆维吾尔自治区/和田地区/策勒县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('653226', '653200', '650000,653200', '于田县', '新疆维吾尔自治区/和田地区/于田县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('653227', '653200', '650000,653200', '民丰县', '新疆维吾尔自治区/和田地区/民丰县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('654000', '650000', '650000', '伊犁哈萨克自治州', '新疆维吾尔自治区/伊犁哈萨克自治州', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('654002', '654000', '650000,654000', '伊宁市', '新疆维吾尔自治区/伊犁哈萨克自治州/伊宁市', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('654003', '654000', '650000,654000', '奎屯市', '新疆维吾尔自治区/伊犁哈萨克自治州/奎屯市', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('654004', '654000', '650000,654000', '霍尔果斯市', '新疆维吾尔自治区/伊犁哈萨克自治州/霍尔果斯市', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('654021', '654000', '650000,654000', '伊宁县', '新疆维吾尔自治区/伊犁哈萨克自治州/伊宁县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('654022', '654000', '650000,654000', '察布查尔锡伯自治县', '新疆维吾尔自治区/伊犁哈萨克自治州/察布查尔锡伯自治县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('654023', '654000', '650000,654000', '霍城县', '新疆维吾尔自治区/伊犁哈萨克自治州/霍城县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('654024', '654000', '650000,654000', '巩留县', '新疆维吾尔自治区/伊犁哈萨克自治州/巩留县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('654025', '654000', '650000,654000', '新源县', '新疆维吾尔自治区/伊犁哈萨克自治州/新源县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('654026', '654000', '650000,654000', '昭苏县', '新疆维吾尔自治区/伊犁哈萨克自治州/昭苏县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('654027', '654000', '650000,654000', '特克斯县', '新疆维吾尔自治区/伊犁哈萨克自治州/特克斯县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('654028', '654000', '650000,654000', '尼勒克县', '新疆维吾尔自治区/伊犁哈萨克自治州/尼勒克县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('654200', '650000', '650000', '塔城地区', '新疆维吾尔自治区/塔城地区', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('654201', '654200', '650000,654200', '塔城市', '新疆维吾尔自治区/塔城地区/塔城市', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('654202', '654200', '650000,654200', '乌苏市', '新疆维吾尔自治区/塔城地区/乌苏市', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('654221', '654200', '650000,654200', '额敏县', '新疆维吾尔自治区/塔城地区/额敏县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('654223', '654200', '650000,654200', '沙湾县', '新疆维吾尔自治区/塔城地区/沙湾县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('654224', '654200', '650000,654200', '托里县', '新疆维吾尔自治区/塔城地区/托里县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('654225', '654200', '650000,654200', '裕民县', '新疆维吾尔自治区/塔城地区/裕民县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('654226', '654200', '650000,654200', '和布克赛尔蒙古自治县', '新疆维吾尔自治区/塔城地区/和布克赛尔蒙古自治县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('654300', '650000', '650000', '阿勒泰地区', '新疆维吾尔自治区/阿勒泰地区', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('654301', '654300', '650000,654300', '阿勒泰市', '新疆维吾尔自治区/阿勒泰地区/阿勒泰市', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('654321', '654300', '650000,654300', '布尔津县', '新疆维吾尔自治区/阿勒泰地区/布尔津县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('654322', '654300', '650000,654300', '富蕴县', '新疆维吾尔自治区/阿勒泰地区/富蕴县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('654323', '654300', '650000,654300', '福海县', '新疆维吾尔自治区/阿勒泰地区/福海县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('654324', '654300', '650000,654300', '哈巴河县', '新疆维吾尔自治区/阿勒泰地区/哈巴河县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('654325', '654300', '650000,654300', '青河县', '新疆维吾尔自治区/阿勒泰地区/青河县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('654326', '654300', '650000,654300', '吉木乃县', '新疆维吾尔自治区/阿勒泰地区/吉木乃县', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('659000', '650000', '650000', '自治区直辖县级行政区划', '新疆维吾尔自治区/自治区直辖县级行政区划', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('659001', '659000', '650000,659000', '石河子市', '新疆维吾尔自治区/自治区直辖县级行政区划/石河子市', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('659002', '659000', '650000,659000', '阿拉尔市', '新疆维吾尔自治区/自治区直辖县级行政区划/阿拉尔市', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('659003', '659000', '650000,659000', '图木舒克市', '新疆维吾尔自治区/自治区直辖县级行政区划/图木舒克市', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('659004', '659000', '650000,659000', '五家渠市', '新疆维吾尔自治区/自治区直辖县级行政区划/五家渠市', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('659006', '659000', '650000,659000', '铁门关市', '新疆维吾尔自治区/自治区直辖县级行政区划/铁门关市', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710000', '86', '', '台湾省', '台湾省', 1, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710100', '710000', '710000', '台北市', '台湾省/台北市', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710101', '710100', '710000,710100', '内湖区', '台湾省/台北市/内湖区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710102', '710100', '710000,710100', '南港区', '台湾省/台北市/南港区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710103', '710100', '710000,710100', '中正区', '台湾省/台北市/中正区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710104', '710100', '710000,710100', '松山区', '台湾省/台北市/松山区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710105', '710100', '710000,710100', '信义区', '台湾省/台北市/信义区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710106', '710100', '710000,710100', '大安区', '台湾省/台北市/大安区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710107', '710100', '710000,710100', '中山区', '台湾省/台北市/中山区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710108', '710100', '710000,710100', '文山区', '台湾省/台北市/文山区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710109', '710100', '710000,710100', '大同区', '台湾省/台北市/大同区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710110', '710100', '710000,710100', '万华区', '台湾省/台北市/万华区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710111', '710100', '710000,710100', '士林区', '台湾省/台北市/士林区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710112', '710100', '710000,710100', '北投区', '台湾省/台北市/北投区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710200', '710000', '710000', '高雄市', '台湾省/高雄市', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710201', '710200', '710000,710200', '新兴区', '台湾省/高雄市/新兴区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710202', '710200', '710000,710200', '前金区', '台湾省/高雄市/前金区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710203', '710200', '710000,710200', '芩雅区', '台湾省/高雄市/芩雅区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710204', '710200', '710000,710200', '盐埕区', '台湾省/高雄市/盐埕区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710205', '710200', '710000,710200', '鼓山区', '台湾省/高雄市/鼓山区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710206', '710200', '710000,710200', '旗津区', '台湾省/高雄市/旗津区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710207', '710200', '710000,710200', '前镇区', '台湾省/高雄市/前镇区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710208', '710200', '710000,710200', '三民区', '台湾省/高雄市/三民区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710209', '710200', '710000,710200', '左营区', '台湾省/高雄市/左营区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710210', '710200', '710000,710200', '楠梓区', '台湾省/高雄市/楠梓区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710211', '710200', '710000,710200', '小港区', '台湾省/高雄市/小港区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710300', '710000', '710000', '基隆市', '台湾省/基隆市', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710301', '710300', '710000,710300', '仁爱区', '台湾省/基隆市/仁爱区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710302', '710300', '710000,710300', '信义区', '台湾省/基隆市/信义区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710303', '710300', '710000,710300', '中正区', '台湾省/基隆市/中正区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710304', '710300', '710000,710300', '暖暖区', '台湾省/基隆市/暖暖区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710305', '710300', '710000,710300', '安乐区', '台湾省/基隆市/安乐区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710307', '710300', '710000,710300', '七堵区', '台湾省/基隆市/七堵区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710400', '710000', '710000', '台中市', '台湾省/台中市', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710401', '710400', '710000,710400', '中区', '台湾省/台中市/中区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710402', '710400', '710000,710400', '东区', '台湾省/台中市/东区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710403', '710400', '710000,710400', '南区', '台湾省/台中市/南区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710404', '710400', '710000,710400', '西区', '台湾省/台中市/西区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710405', '710400', '710000,710400', '北区', '台湾省/台中市/北区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710406', '710400', '710000,710400', '北屯区', '台湾省/台中市/北屯区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710407', '710400', '710000,710400', '西屯区', '台湾省/台中市/西屯区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710408', '710400', '710000,710400', '南屯区', '台湾省/台中市/南屯区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710500', '710000', '710000', '台南市', '台湾省/台南市', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710501', '710500', '710000,710500', '中西区', '台湾省/台南市/中西区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710502', '710500', '710000,710500', '东区', '台湾省/台南市/东区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710503', '710500', '710000,710500', '南区', '台湾省/台南市/南区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710504', '710500', '710000,710500', '北区', '台湾省/台南市/北区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710505', '710500', '710000,710500', '安平区', '台湾省/台南市/安平区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710506', '710500', '710000,710500', '安南区', '台湾省/台南市/安南区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710600', '710000', '710000', '新竹市', '台湾省/新竹市', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710601', '710600', '710000,710600', '东区', '台湾省/新竹市/东区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710602', '710600', '710000,710600', '北区', '台湾省/新竹市/北区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710603', '710600', '710000,710600', '香山区', '台湾省/新竹市/香山区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710700', '710000', '710000', '嘉义市', '台湾省/嘉义市', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710701', '710700', '710000,710700', '东区', '台湾省/嘉义市/东区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('710702', '710700', '710000,710700', '西区', '台湾省/嘉义市/西区', 3, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('810000', '86', '', '香港特别行政区', '香港特别行政区', 1, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('810001', '810000', '810000', '中西區', '香港特别行政区/中西區', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('810002', '810000', '810000', '灣仔區', '香港特别行政区/灣仔區', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('810003', '810000', '810000', '東區', '香港特别行政区/東區', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('810004', '810000', '810000', '南區', '香港特别行政区/南區', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('810005', '810000', '810000', '油尖旺區', '香港特别行政区/油尖旺區', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('810006', '810000', '810000', '深水埗區', '香港特别行政区/深水埗區', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('810007', '810000', '810000', '九龍城區', '香港特别行政区/九龍城區', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('810008', '810000', '810000', '黃大仙區', '香港特别行政区/黃大仙區', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('810009', '810000', '810000', '觀塘區', '香港特别行政区/觀塘區', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('810010', '810000', '810000', '荃灣區', '香港特别行政区/荃灣區', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('810011', '810000', '810000', '屯門區', '香港特别行政区/屯門區', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('810012', '810000', '810000', '元朗區', '香港特别行政区/元朗區', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('810013', '810000', '810000', '北區', '香港特别行政区/北區', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('810014', '810000', '810000', '大埔區', '香港特别行政区/大埔區', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('810015', '810000', '810000', '西貢區', '香港特别行政区/西貢區', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('810016', '810000', '810000', '沙田區', '香港特别行政区/沙田區', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('810017', '810000', '810000', '葵青區', '香港特别行政区/葵青區', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('810018', '810000', '810000', '離島區', '香港特别行政区/離島區', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('820000', '86', '', '澳门特别行政区', '澳门特别行政区', 1, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('820001', '820000', '820000', '花地瑪堂區', '澳门特别行政区/花地瑪堂區', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('820002', '820000', '820000', '花王堂區', '澳门特别行政区/花王堂區', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('820003', '820000', '820000', '望德堂區', '澳门特别行政区/望德堂區', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('820004', '820000', '820000', '大堂區', '澳门特别行政区/大堂區', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('820005', '820000', '820000', '風順堂區', '澳门特别行政区/風順堂區', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('820006', '820000', '820000', '嘉模堂區', '澳门特别行政区/嘉模堂區', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('820007', '820000', '820000', '路氹填海區', '澳门特别行政区/路氹填海區', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);
INSERT INTO `pv_area` VALUES ('820008', '820000', '820000', '聖方濟各堂區', '澳门特别行政区/聖方濟各堂區', 2, 'admin', '2022-05-22 20:35:21', '', NULL, NULL);

-- ----------------------------
-- Table structure for pv_build_item
-- ----------------------------
DROP TABLE IF EXISTS `pv_build_item`;
CREATE TABLE `pv_build_item`  (
  `id` bigint NOT NULL COMMENT '主键id',
  `build_id` bigint NULL DEFAULT NULL COMMENT '施工单id',
  `item_id` bigint NULL DEFAULT NULL COMMENT '物料id',
  `store_id` bigint NULL DEFAULT NULL COMMENT '仓库id',
  `item_num` int NULL DEFAULT NULL COMMENT '物料数量',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `sort_num` int NULL DEFAULT 0 COMMENT '序号',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '施工单物料明细' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pv_build_item
-- ----------------------------

-- ----------------------------
-- Table structure for pv_finish_station
-- ----------------------------
DROP TABLE IF EXISTS `pv_finish_station`;
CREATE TABLE `pv_finish_station`  (
  `id` bigint NOT NULL COMMENT '主键id',
  `ps_id` bigint NULL DEFAULT NULL COMMENT '电站id',
  `finish_id` bigint NULL DEFAULT NULL COMMENT '验收单id',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `sort_num` int NULL DEFAULT 0 COMMENT '序号',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '竣工验收单和电站关联表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pv_finish_station
-- ----------------------------

-- ----------------------------
-- Table structure for pv_item_type
-- ----------------------------
DROP TABLE IF EXISTS `pv_item_type`;
CREATE TABLE `pv_item_type`  (
  `id` bigint NOT NULL COMMENT '物料分类id',
  `parent_id` bigint NULL DEFAULT NULL COMMENT '父分类id',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '物料分类名称',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  `status` tinyint NULL DEFAULT 0 COMMENT '状态',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `sort_num` int NULL DEFAULT 0 COMMENT '序号',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '物料类型' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pv_item_type
-- ----------------------------

-- ----------------------------
-- Table structure for pv_material
-- ----------------------------
DROP TABLE IF EXISTS `pv_material`;
CREATE TABLE `pv_material`  (
  `id` bigint NOT NULL COMMENT '物料id',
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '物料名称',
  `code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '物料编号',
  `item_type_id` bigint NULL DEFAULT NULL COMMENT '物料分类id',
  `logo` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '封面',
  `profile` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '简介',
  `price` decimal(10, 2) NULL DEFAULT NULL COMMENT '单价',
  `unit` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '单位',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  `status` tinyint NULL DEFAULT 0 COMMENT '状态',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `sort_num` int NULL DEFAULT 0 COMMENT '序号',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pv_material
-- ----------------------------

-- ----------------------------
-- Table structure for pv_order
-- ----------------------------
DROP TABLE IF EXISTS `pv_order`;
CREATE TABLE `pv_order`  (
  `id` bigint NOT NULL COMMENT '订单id',
  `order_no` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '订单编号',
  `agent_id` bigint NULL DEFAULT NULL COMMENT '代理商id',
  `store_id` bigint NULL DEFAULT NULL COMMENT '总仓id（发货仓）',
  `agent_store_id` bigint NULL DEFAULT NULL COMMENT '代理仓id（收货仓）',
  `order_amount` decimal(10, 2) NULL DEFAULT NULL COMMENT '订单总金额',
  `invoice_amount` decimal(10, 2) NULL DEFAULT NULL COMMENT '开票金额',
  `pay_mode` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '支付方式',
  `pay_proof` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '支付凭证',
  `pay_remark` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '支付备注',
  `delivery_proof` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '发货凭证',
  `delivery_remark` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '发货备注',
  `station_num` int NULL DEFAULT NULL COMMENT '电站数量',
  `applicant` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '申请人',
  `apply_time` datetime NULL DEFAULT NULL COMMENT '申请时间',
  `deliverer` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '发货人',
  `delivery_time` datetime NULL DEFAULT NULL COMMENT '发货时间',
  `consignee` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '收货人',
  `receive_time` datetime NULL DEFAULT NULL COMMENT '收货时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  `status` tinyint NULL DEFAULT 0 COMMENT '状态',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `sort_num` int NULL DEFAULT 0 COMMENT '序号',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '订单' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pv_order
-- ----------------------------

-- ----------------------------
-- Table structure for pv_order_item
-- ----------------------------
DROP TABLE IF EXISTS `pv_order_item`;
CREATE TABLE `pv_order_item`  (
  `id` bigint NOT NULL COMMENT '主键id',
  `order_id` bigint NOT NULL COMMENT '订单id',
  `item_id` bigint NOT NULL COMMENT '物料id',
  `num` int NULL DEFAULT NULL COMMENT '数量',
  `append_num` int NULL DEFAULT NULL COMMENT '追加数量',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `sort_num` int NULL DEFAULT 0 COMMENT '序号',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '订单物料明细' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pv_order_item
-- ----------------------------

-- ----------------------------
-- Table structure for pv_order_station
-- ----------------------------
DROP TABLE IF EXISTS `pv_order_station`;
CREATE TABLE `pv_order_station`  (
  `id` bigint NOT NULL,
  `order_id` bigint NULL DEFAULT NULL,
  `ps_id` bigint NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '订单和电站关联表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pv_order_station
-- ----------------------------

-- ----------------------------
-- Table structure for pv_owner
-- ----------------------------
DROP TABLE IF EXISTS `pv_owner`;
CREATE TABLE `pv_owner`  (
  `id` bigint NOT NULL COMMENT '主键',
  `serial_no` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '合同编号',
  `owner_no` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '业主信息编号',
  `dev_org` bigint NULL DEFAULT NULL COMMENT '开发方',
  `dev_staff` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '开发人',
  `owner_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '业主姓名',
  `phone` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '联系电话',
  `area_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '项目地址-区域id（省、市、区）',
  `address` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '项目详情地址',
  `id_card` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '身份证地址',
  `agent_id` bigint NULL DEFAULT NULL COMMENT '代理商id',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  `status` tinyint NULL DEFAULT 0 COMMENT '状态',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `sort_num` int NULL DEFAULT 0 COMMENT '序号',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '业主信息' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pv_owner
-- ----------------------------

-- ----------------------------
-- Table structure for pv_power_station
-- ----------------------------
DROP TABLE IF EXISTS `pv_power_station`;
CREATE TABLE `pv_power_station`  (
  `id` bigint NOT NULL COMMENT '电站主键id，分布式id',
  `agent_id` bigint NULL DEFAULT NULL COMMENT '代理商id',
  `serial_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '合同编号',
  `owner_id` bigint NULL DEFAULT NULL COMMENT '业主id',
  `survey_no` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '勘察编号',
  `power_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '电站类型',
  `provider` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '服务商',
  `sale_man` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '业务员',
  `maker` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '制单人',
  `make_time` datetime NULL DEFAULT NULL COMMENT '制单日期',
  `is_record` tinyint(1) NULL DEFAULT 0 COMMENT '是否备案，0-否，1-是',
  `owner_type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '业务类型',
  `owner_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '业主名称',
  `id_card` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '身份证号码',
  `owner_phone` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '业主电话',
  `owner_email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '业主邮箱',
  `area_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '项目地址-区域id（省、市、区）',
  `project_address` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '项目地址',
  `permanent_address` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '常住地址',
  `prev_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '原电站编号',
  `prev_owner_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '原业主姓名',
  `order_desc` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '订单说明',
  `access_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '上网类型',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  `status` tinyint(1) NULL DEFAULT 0 COMMENT '电站状态，0-在建 1-正常 2-作废 3-故障',
  `survey_status` tinyint(1) NULL DEFAULT 0 COMMENT '勘察状态，0-待审批 1-审批通过 2-审批不通过',
  `design_status` tinyint(1) NULL DEFAULT 0 COMMENT '设计状态，0-待审批 1-审批通过 2-审批不通过',
  `business_status` tinyint(1) NULL DEFAULT 0 COMMENT '商务状态，0-待审批 1-审批通过 2-审批不通过',
  `engineer_status` tinyint(1) NULL DEFAULT 0 COMMENT '工程状态，0-待审批 1-审批通过 2-审批不通过',
  `connect_status` tinyint(1) NULL DEFAULT 0 COMMENT '并网状态，0-待审批 1-审批通过 2-审批不通过',
  `settlement_status` tinyint(1) NULL DEFAULT 0 COMMENT '资料归档状态，0-待审批 1-审批通过 2-审批不通过',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `sort_num` int NULL DEFAULT 0 COMMENT '序号',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '电站信息' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pv_power_station
-- ----------------------------

-- ----------------------------
-- Table structure for pv_power_station_archive
-- ----------------------------
DROP TABLE IF EXISTS `pv_power_station_archive`;
CREATE TABLE `pv_power_station_archive`  (
  `id` bigint NOT NULL COMMENT '主键id',
  `ps_id` bigint NULL DEFAULT NULL COMMENT '电站id',
  `cabinet_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '文件柜编号',
  `file_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '档案编号',
  `house_kind` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '房产证明类型',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `sort_num` int NULL DEFAULT 0 COMMENT '序号',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '电站归档' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pv_power_station_archive
-- ----------------------------

-- ----------------------------
-- Table structure for pv_power_station_bom
-- ----------------------------
DROP TABLE IF EXISTS `pv_power_station_bom`;
CREATE TABLE `pv_power_station_bom`  (
  `id` bigint NOT NULL COMMENT '主键id',
  `ps_id` bigint NULL DEFAULT NULL COMMENT '电站id',
  `item_id` bigint NULL DEFAULT NULL COMMENT '物料id',
  `biz_key` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '业务标识',
  `config_num` int NULL DEFAULT NULL COMMENT '配置数量',
  `confirm_num` int NULL DEFAULT NULL COMMENT '确认数量',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `sort_num` int NULL DEFAULT 0 COMMENT '序号',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '电站各业务BOM' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pv_power_station_bom
-- ----------------------------

-- ----------------------------
-- Table structure for pv_power_station_build
-- ----------------------------
DROP TABLE IF EXISTS `pv_power_station_build`;
CREATE TABLE `pv_power_station_build`  (
  `id` bigint NOT NULL COMMENT '主键id',
  `agent_id` bigint NULL DEFAULT NULL COMMENT '代理商id',
  `owner_id` bigint NULL DEFAULT NULL COMMENT '业主id',
  `order_id` bigint NULL DEFAULT NULL COMMENT '订单id',
  `order_no` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '订单编号',
  `prepared_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '制单人',
  `plan_start_time` datetime NULL DEFAULT NULL COMMENT '计划开工时间',
  `plan_finish_time` datetime NULL DEFAULT NULL COMMENT '计划完工时间',
  `charge_person` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '工程总负责人',
  `charge_phone` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '工程总负责人电话',
  `delivery_person` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '送货人',
  `delivery_phone` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '送货人电话',
  `agent_store_id` bigint NULL DEFAULT NULL COMMENT '代理商仓库id',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  `status` tinyint NULL DEFAULT 0 COMMENT '状态',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `sort_num` int NULL DEFAULT 0 COMMENT '序号',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '电站施工管理' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pv_power_station_build
-- ----------------------------

-- ----------------------------
-- Table structure for pv_power_station_connect
-- ----------------------------
DROP TABLE IF EXISTS `pv_power_station_connect`;
CREATE TABLE `pv_power_station_connect`  (
  `id` bigint NOT NULL COMMENT '主键id',
  `ps_id` bigint NULL DEFAULT NULL COMMENT '电站id',
  `agent_id` bigint NULL DEFAULT NULL COMMENT '代理商id',
  `biz_key` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '业务标识',
  `matter` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '事项',
  `file_url` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '文件路径',
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '填写信息',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  `status` tinyint NULL DEFAULT 0 COMMENT '状态',
  `auditor` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '审核人',
  `audit_time` datetime NULL DEFAULT NULL COMMENT '审核时间',
  `opinion` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '审核意见',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `sort_num` int NULL DEFAULT 0 COMMENT '序号',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '电站并网管理' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pv_power_station_connect
-- ----------------------------

-- ----------------------------
-- Table structure for pv_power_station_contact
-- ----------------------------
DROP TABLE IF EXISTS `pv_power_station_contact`;
CREATE TABLE `pv_power_station_contact`  (
  `id` bigint NOT NULL COMMENT '电站联系人主键id',
  `ps_id` bigint NULL DEFAULT NULL COMMENT '电站id',
  `agent_id` bigint NULL DEFAULT NULL COMMENT '代理商id',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '姓名',
  `relation` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '关系',
  `phone` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '电话',
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '邮箱',
  `qq` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'QQ',
  `wechat` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '微信',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `sort_num` int NULL DEFAULT 0 COMMENT '序号',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '电站联系人' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pv_power_station_contact
-- ----------------------------

-- ----------------------------
-- Table structure for pv_power_station_design
-- ----------------------------
DROP TABLE IF EXISTS `pv_power_station_design`;
CREATE TABLE `pv_power_station_design`  (
  `id` bigint NOT NULL COMMENT '主键id',
  `ps_id` bigint NULL DEFAULT NULL COMMENT '电站id',
  `agent_id` bigint NULL DEFAULT NULL COMMENT '代理商id',
  `module_item_id` bigint NULL DEFAULT NULL COMMENT '组件物料id',
  `module_power` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '组件功率',
  `module_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '组件类型',
  `module_frame` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '组件边框',
  `module_block` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '组件块数',
  `module_total_power` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '组件总功率',
  `module_side` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '组件单/双面',
  `inverter_item_id` bigint NULL DEFAULT NULL COMMENT '逆变器物料id',
  `inverter_power` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '逆变器功率',
  `inverter_series` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '逆变器系列',
  `box_item_id` bigint NULL DEFAULT NULL COMMENT '电表箱物料id',
  `box_material` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '电表箱材质',
  `box_func` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '电表箱功能',
  `network_mode` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '电表箱上网模式',
  `bracket_item_id` bigint NULL DEFAULT NULL COMMENT '支架物料id',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `sort_num` int NULL DEFAULT 0 COMMENT '序号',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '电站设计信息' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pv_power_station_design
-- ----------------------------

-- ----------------------------
-- Table structure for pv_power_station_engineer
-- ----------------------------
DROP TABLE IF EXISTS `pv_power_station_engineer`;
CREATE TABLE `pv_power_station_engineer`  (
  `id` bigint NOT NULL COMMENT '主键id',
  `ps_id` bigint NULL DEFAULT NULL COMMENT '电站id',
  `agent_id` bigint NULL DEFAULT NULL COMMENT '代理商id',
  `charge_man` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '现场负责人',
  `charge_phone` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '现场负责人电话',
  `completion_date` datetime NULL DEFAULT NULL COMMENT '完工日期',
  `monitor` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '施工组长',
  `monitor_phone` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '施工组长电话',
  `monitor_id_card` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '施工组长身份证',
  `is_wind_resistant` tinyint(1) NULL DEFAULT NULL COMMENT '是否抗风加固',
  `roof_module_num` int NULL DEFAULT NULL COMMENT '平屋顶组件数',
  `reinforce` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '加固方式',
  `special_scheme` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '特殊方案',
  `special_scheme_num` int NULL DEFAULT NULL COMMENT '特殊方案块数',
  `approval_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '特批类型',
  `is_steel` tinyint(1) NULL DEFAULT NULL COMMENT '是否平改坡封彩钢',
  `is_record` tinyint(1) NULL DEFAULT NULL COMMENT '是否特殊备案',
  `record_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备案类型',
  `design_scheme` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '电站设计方案',
  `cable_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '电缆规格',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `sort_num` int NULL DEFAULT 0 COMMENT '序号',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '电站工程信息' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pv_power_station_engineer
-- ----------------------------

-- ----------------------------
-- Table structure for pv_power_station_finish
-- ----------------------------
DROP TABLE IF EXISTS `pv_power_station_finish`;
CREATE TABLE `pv_power_station_finish`  (
  `id` bigint NOT NULL COMMENT '主键id',
  `agent_id` bigint NULL DEFAULT NULL COMMENT '代理商id',
  `contact` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '联系人',
  `contact_phone` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '联系电话',
  `total_num` int NULL DEFAULT NULL COMMENT '总电站数',
  `prepared_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '制单人',
  `prepared_time` datetime NULL DEFAULT NULL COMMENT '制单时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  `status` tinyint NULL DEFAULT 0 COMMENT '状态',
  `auditor` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '审核人',
  `audit_time` datetime NULL DEFAULT NULL COMMENT '审核时间',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `sort_num` int NULL DEFAULT 0 COMMENT '序号',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '电站竣工验收' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pv_power_station_finish
-- ----------------------------

-- ----------------------------
-- Table structure for pv_power_station_survey
-- ----------------------------
DROP TABLE IF EXISTS `pv_power_station_survey`;
CREATE TABLE `pv_power_station_survey`  (
  `id` bigint NOT NULL COMMENT '勘察信息主键id',
  `ps_id` bigint NOT NULL COMMENT '电站id',
  `agent_id` bigint NOT NULL COMMENT '代理商id',
  `surveyor` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '勘察人',
  `survey_time` datetime NULL DEFAULT NULL COMMENT '勘察时间',
  `roof` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '屋顶情况',
  `house_situation` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '房屋整体情况',
  `house_level` int NULL DEFAULT NULL COMMENT '房屋高度-层数',
  `house_height` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '房屋高度-总高（米）',
  `house_bias` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '房屋偏向',
  `house_bias_value` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '房屋偏向值',
  `house_life` int NULL DEFAULT NULL COMMENT '房屋建筑年限',
  `lng_degree` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '东经-度',
  `lng_min` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '东经-分',
  `lng_sec` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '东经-秒',
  `lat_degree` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '北纬-度',
  `lat_min` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '北纬-分',
  `lat_sec` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '北纬-秒',
  `hgt` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '海拔（米）',
  `roof_way` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '上至屋顶通道',
  `roof_way_other` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '上至屋顶通道-其它',
  `shelter` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '周边遮挡物',
  `shelter_other` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '周边遮挡物-其它',
  `meter_location` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '电表位置',
  `prev_meter_location` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '原电表位置',
  `prev_meter_param` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '原电表参数',
  `line_material` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '进户线材质',
  `line_diam` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '进户线径',
  `line_length` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '进户线长度',
  `roof_slope` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '屋面坡度',
  `title_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '瓦面类型',
  `struc_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '结构类型',
  `mainbeam_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '主梁类型',
  `tile_bear` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '瓦片承重形式',
  `gutter` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '檐沟及平台',
  `pitched_roof` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '斜屋顶支架方案',
  `waterproof_layer` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '屋面防水层',
  `roof_plate` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '屋面板类型',
  `foundation` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '底座固定形式',
  `flat_roof_support` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '平屋顶支架方案',
  `inverter_position` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '逆变器位置预估',
  `meter_box_position` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '电表箱位置预估',
  `support_grounding` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '支架接地预估',
  `meter_box_grounding` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '电表箱接地预估',
  `daylighting_blocking_solve` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '关于邻居采光遮挡的沟通结果及措施',
  `cover_shelter` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '屋面遮挡物',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `sort_num` int NULL DEFAULT 0 COMMENT '序号',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '勘察信息' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pv_power_station_survey
-- ----------------------------

-- ----------------------------
-- Table structure for pv_stock
-- ----------------------------
DROP TABLE IF EXISTS `pv_stock`;
CREATE TABLE `pv_stock`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '库存主键id',
  `store_id` bigint NULL DEFAULT NULL COMMENT '仓库id',
  `item_id` bigint NULL DEFAULT NULL COMMENT '物料id',
  `agent_id` bigint NULL DEFAULT NULL COMMENT '代理商id',
  `store_num` int NULL DEFAULT 0 COMMENT '库存数量',
  `in_num` int NULL DEFAULT 0 COMMENT '入库中数量',
  `out_num` int NULL DEFAULT 0 COMMENT '出库中数量',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `sort_num` int NULL DEFAULT 0 COMMENT '序号',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '库存' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pv_stock
-- ----------------------------

-- ----------------------------
-- Table structure for pv_stock_change
-- ----------------------------
DROP TABLE IF EXISTS `pv_stock_change`;
CREATE TABLE `pv_stock_change`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '库存变更主键id',
  `power_station_id` bigint NULL DEFAULT NULL COMMENT '电站id',
  `serial_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '出入库单号',
  `applicant` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '申请人',
  `oper_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '操作类型',
  `in_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '入库类型',
  `in_store_id` bigint NULL DEFAULT NULL COMMENT '入库仓库id',
  `out_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '出库类型',
  `out_store_id` bigint NULL DEFAULT NULL COMMENT '出库仓库id',
  `stock_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '库存类型',
  `transfer_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '调拨类型',
  `proof_file` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '凭证附件',
  `build_id` bigint NULL DEFAULT NULL COMMENT '电站施工id',
  `order_id` bigint NULL DEFAULT NULL COMMENT '订单id',
  `order_no` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '订单编号',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  `status` tinyint NULL DEFAULT 0 COMMENT '状态',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `sort_num` int NULL DEFAULT 0 COMMENT '序号',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '仓库物料出入库信息' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pv_stock_change
-- ----------------------------

-- ----------------------------
-- Table structure for pv_stock_change_detail
-- ----------------------------
DROP TABLE IF EXISTS `pv_stock_change_detail`;
CREATE TABLE `pv_stock_change_detail`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '出入库明细id',
  `stock_change_id` bigint NULL DEFAULT NULL,
  `item_id` bigint NULL DEFAULT NULL,
  `config_num` int NULL DEFAULT 0,
  `confirm_num` int NULL DEFAULT 0,
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `sort_num` int NULL DEFAULT 0 COMMENT '序号',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pv_stock_change_detail
-- ----------------------------

-- ----------------------------
-- Table structure for pv_store
-- ----------------------------
DROP TABLE IF EXISTS `pv_store`;
CREATE TABLE `pv_store`  (
  `id` bigint NOT NULL COMMENT '仓库id',
  `store_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '仓库名称',
  `store_no` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '仓库编号',
  `store_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '仓库类型',
  `store_level` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '仓库等级',
  `if_defualt` tinyint(1) NULL DEFAULT 0 COMMENT '是否默认仓库，0-否 1-是',
  `area_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '仓库地址-区域id',
  `addr` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '仓库详细地址',
  `applicant` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '申请人',
  `contact` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '联系人',
  `contact_phone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '联系人电话',
  `agent_id` bigint NULL DEFAULT NULL COMMENT '代理商id',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  `status` tinyint NULL DEFAULT 0 COMMENT '状态',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `sort_num` int NULL DEFAULT 0 COMMENT '序号',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '仓库' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pv_store
-- ----------------------------

-- ----------------------------
-- Table structure for qrtz_blob_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_blob_triggers`;
CREATE TABLE `qrtz_blob_triggers`  (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '调度名称',
  `trigger_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'qrtz_triggers表trigger_name的外键',
  `trigger_group` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'qrtz_triggers表trigger_group的外键',
  `blob_data` blob NULL COMMENT '存放持久化Trigger对象',
  PRIMARY KEY (`sched_name`, `trigger_name`, `trigger_group`) USING BTREE,
  CONSTRAINT `qrtz_blob_triggers_ibfk_1` FOREIGN KEY (`sched_name`, `trigger_name`, `trigger_group`) REFERENCES `qrtz_triggers` (`sched_name`, `trigger_name`, `trigger_group`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = 'Blob类型的触发器表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of qrtz_blob_triggers
-- ----------------------------

-- ----------------------------
-- Table structure for qrtz_calendars
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_calendars`;
CREATE TABLE `qrtz_calendars`  (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '调度名称',
  `calendar_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '日历名称',
  `calendar` blob NOT NULL COMMENT '存放持久化calendar对象',
  PRIMARY KEY (`sched_name`, `calendar_name`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '日历信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of qrtz_calendars
-- ----------------------------

-- ----------------------------
-- Table structure for qrtz_cron_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_cron_triggers`;
CREATE TABLE `qrtz_cron_triggers`  (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '调度名称',
  `trigger_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'qrtz_triggers表trigger_name的外键',
  `trigger_group` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'qrtz_triggers表trigger_group的外键',
  `cron_expression` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'cron表达式',
  `time_zone_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '时区',
  PRIMARY KEY (`sched_name`, `trigger_name`, `trigger_group`) USING BTREE,
  CONSTRAINT `qrtz_cron_triggers_ibfk_1` FOREIGN KEY (`sched_name`, `trigger_name`, `trigger_group`) REFERENCES `qrtz_triggers` (`sched_name`, `trigger_name`, `trigger_group`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = 'Cron类型的触发器表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of qrtz_cron_triggers
-- ----------------------------

-- ----------------------------
-- Table structure for qrtz_fired_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_fired_triggers`;
CREATE TABLE `qrtz_fired_triggers`  (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '调度名称',
  `entry_id` varchar(95) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '调度器实例id',
  `trigger_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'qrtz_triggers表trigger_name的外键',
  `trigger_group` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'qrtz_triggers表trigger_group的外键',
  `instance_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '调度器实例名',
  `fired_time` bigint NOT NULL COMMENT '触发的时间',
  `sched_time` bigint NOT NULL COMMENT '定时器制定的时间',
  `priority` int NOT NULL COMMENT '优先级',
  `state` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '状态',
  `job_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '任务名称',
  `job_group` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '任务组名',
  `is_nonconcurrent` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '是否并发',
  `requests_recovery` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '是否接受恢复执行',
  PRIMARY KEY (`sched_name`, `entry_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '已触发的触发器表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of qrtz_fired_triggers
-- ----------------------------

-- ----------------------------
-- Table structure for qrtz_job_details
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_job_details`;
CREATE TABLE `qrtz_job_details`  (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '调度名称',
  `job_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '任务名称',
  `job_group` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '任务组名',
  `description` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '相关介绍',
  `job_class_name` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '执行任务类名称',
  `is_durable` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '是否持久化',
  `is_nonconcurrent` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '是否并发',
  `is_update_data` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '是否更新数据',
  `requests_recovery` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '是否接受恢复执行',
  `job_data` blob NULL COMMENT '存放持久化job对象',
  PRIMARY KEY (`sched_name`, `job_name`, `job_group`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '任务详细信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of qrtz_job_details
-- ----------------------------

-- ----------------------------
-- Table structure for qrtz_locks
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_locks`;
CREATE TABLE `qrtz_locks`  (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '调度名称',
  `lock_name` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '悲观锁名称',
  PRIMARY KEY (`sched_name`, `lock_name`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '存储的悲观锁信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of qrtz_locks
-- ----------------------------

-- ----------------------------
-- Table structure for qrtz_paused_trigger_grps
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_paused_trigger_grps`;
CREATE TABLE `qrtz_paused_trigger_grps`  (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '调度名称',
  `trigger_group` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'qrtz_triggers表trigger_group的外键',
  PRIMARY KEY (`sched_name`, `trigger_group`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '暂停的触发器表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of qrtz_paused_trigger_grps
-- ----------------------------

-- ----------------------------
-- Table structure for qrtz_scheduler_state
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_scheduler_state`;
CREATE TABLE `qrtz_scheduler_state`  (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '调度名称',
  `instance_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '实例名称',
  `last_checkin_time` bigint NOT NULL COMMENT '上次检查时间',
  `checkin_interval` bigint NOT NULL COMMENT '检查间隔时间',
  PRIMARY KEY (`sched_name`, `instance_name`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '调度器状态表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of qrtz_scheduler_state
-- ----------------------------

-- ----------------------------
-- Table structure for qrtz_simple_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_simple_triggers`;
CREATE TABLE `qrtz_simple_triggers`  (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '调度名称',
  `trigger_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'qrtz_triggers表trigger_name的外键',
  `trigger_group` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'qrtz_triggers表trigger_group的外键',
  `repeat_count` bigint NOT NULL COMMENT '重复的次数统计',
  `repeat_interval` bigint NOT NULL COMMENT '重复的间隔时间',
  `times_triggered` bigint NOT NULL COMMENT '已经触发的次数',
  PRIMARY KEY (`sched_name`, `trigger_name`, `trigger_group`) USING BTREE,
  CONSTRAINT `qrtz_simple_triggers_ibfk_1` FOREIGN KEY (`sched_name`, `trigger_name`, `trigger_group`) REFERENCES `qrtz_triggers` (`sched_name`, `trigger_name`, `trigger_group`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '简单触发器的信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of qrtz_simple_triggers
-- ----------------------------

-- ----------------------------
-- Table structure for qrtz_simprop_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_simprop_triggers`;
CREATE TABLE `qrtz_simprop_triggers`  (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '调度名称',
  `trigger_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'qrtz_triggers表trigger_name的外键',
  `trigger_group` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'qrtz_triggers表trigger_group的外键',
  `str_prop_1` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'String类型的trigger的第一个参数',
  `str_prop_2` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'String类型的trigger的第二个参数',
  `str_prop_3` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'String类型的trigger的第三个参数',
  `int_prop_1` int NULL DEFAULT NULL COMMENT 'int类型的trigger的第一个参数',
  `int_prop_2` int NULL DEFAULT NULL COMMENT 'int类型的trigger的第二个参数',
  `long_prop_1` bigint NULL DEFAULT NULL COMMENT 'long类型的trigger的第一个参数',
  `long_prop_2` bigint NULL DEFAULT NULL COMMENT 'long类型的trigger的第二个参数',
  `dec_prop_1` decimal(13, 4) NULL DEFAULT NULL COMMENT 'decimal类型的trigger的第一个参数',
  `dec_prop_2` decimal(13, 4) NULL DEFAULT NULL COMMENT 'decimal类型的trigger的第二个参数',
  `bool_prop_1` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'Boolean类型的trigger的第一个参数',
  `bool_prop_2` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'Boolean类型的trigger的第二个参数',
  PRIMARY KEY (`sched_name`, `trigger_name`, `trigger_group`) USING BTREE,
  CONSTRAINT `qrtz_simprop_triggers_ibfk_1` FOREIGN KEY (`sched_name`, `trigger_name`, `trigger_group`) REFERENCES `qrtz_triggers` (`sched_name`, `trigger_name`, `trigger_group`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '同步机制的行锁表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of qrtz_simprop_triggers
-- ----------------------------

-- ----------------------------
-- Table structure for qrtz_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_triggers`;
CREATE TABLE `qrtz_triggers`  (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '调度名称',
  `trigger_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '触发器的名字',
  `trigger_group` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '触发器所属组的名字',
  `job_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'qrtz_job_details表job_name的外键',
  `job_group` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'qrtz_job_details表job_group的外键',
  `description` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '相关介绍',
  `next_fire_time` bigint NULL DEFAULT NULL COMMENT '上一次触发时间（毫秒）',
  `prev_fire_time` bigint NULL DEFAULT NULL COMMENT '下一次触发时间（默认为-1表示不触发）',
  `priority` int NULL DEFAULT NULL COMMENT '优先级',
  `trigger_state` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '触发器状态',
  `trigger_type` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '触发器的类型',
  `start_time` bigint NOT NULL COMMENT '开始时间',
  `end_time` bigint NULL DEFAULT NULL COMMENT '结束时间',
  `calendar_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '日程表名称',
  `misfire_instr` smallint NULL DEFAULT NULL COMMENT '补偿执行的策略',
  `job_data` blob NULL COMMENT '存放持久化job对象',
  PRIMARY KEY (`sched_name`, `trigger_name`, `trigger_group`) USING BTREE,
  INDEX `sched_name`(`sched_name`, `job_name`, `job_group`) USING BTREE,
  CONSTRAINT `qrtz_triggers_ibfk_1` FOREIGN KEY (`sched_name`, `job_name`, `job_group`) REFERENCES `qrtz_job_details` (`sched_name`, `job_name`, `job_group`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '触发器详细信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of qrtz_triggers
-- ----------------------------

-- ----------------------------
-- Table structure for sys_config
-- ----------------------------
DROP TABLE IF EXISTS `sys_config`;
CREATE TABLE `sys_config`  (
  `config_id` int NOT NULL AUTO_INCREMENT COMMENT '参数主键',
  `config_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '参数名称',
  `config_key` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '参数键名',
  `config_value` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '参数键值',
  `config_type` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'N' COMMENT '系统内置（Y是 N否）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`config_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '参数配置表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_config
-- ----------------------------
INSERT INTO `sys_config` VALUES (1, '主框架页-默认皮肤样式名称', 'sys.index.skinName', 'skin-blue', 'Y', 'admin', '2022-11-12 10:24:54', '', NULL, '蓝色 skin-blue、绿色 skin-green、紫色 skin-purple、红色 skin-red、黄色 skin-yellow');
INSERT INTO `sys_config` VALUES (2, '用户管理-账号初始密码', 'sys.user.initPassword', '123456', 'Y', 'admin', '2022-11-12 10:24:54', '', NULL, '初始化密码 123456');
INSERT INTO `sys_config` VALUES (3, '主框架页-侧边栏主题', 'sys.index.sideTheme', 'theme-dark', 'Y', 'admin', '2022-11-12 10:24:54', '', NULL, '深色主题theme-dark，浅色主题theme-light');
INSERT INTO `sys_config` VALUES (4, '账号自助-验证码开关', 'sys.account.captchaEnabled', 'true', 'Y', 'admin', '2022-11-12 10:24:54', '', NULL, '是否开启验证码功能（true开启，false关闭）');
INSERT INTO `sys_config` VALUES (5, '账号自助-是否开启用户注册功能', 'sys.account.registerUser', 'false', 'Y', 'admin', '2022-11-12 10:24:54', '', NULL, '是否开启注册用户功能（true开启，false关闭）');

-- ----------------------------
-- Table structure for sys_dept
-- ----------------------------
DROP TABLE IF EXISTS `sys_dept`;
CREATE TABLE `sys_dept`  (
  `dept_id` bigint NOT NULL AUTO_INCREMENT COMMENT '部门id',
  `parent_id` bigint NULL DEFAULT 0 COMMENT '父部门id',
  `ancestors` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '祖级列表',
  `dept_name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '部门名称',
  `order_num` int NULL DEFAULT 0 COMMENT '显示顺序',
  `leader` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '负责人',
  `phone` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '联系电话',
  `email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '邮箱',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '部门状态（0正常 1停用）',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`dept_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 202 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '部门表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_dept
-- ----------------------------
INSERT INTO `sys_dept` VALUES (100, 0, '0', '总公司', 0, '', '15888888888', 'ry@qq.com', '0', '0', 'admin', '2022-11-12 10:24:54', 'admin', '2022-11-12 10:29:25');
INSERT INTO `sys_dept` VALUES (101, 100, '0,100', '总部', 1, NULL, '15888888888', 'ry@qq.com', '0', '0', 'admin', '2022-11-11 10:30:27', '', NULL);
INSERT INTO `sys_dept` VALUES (103, 101, '0,100,101', '研发部门', 1, '', '15888888888', 'ry@qq.com', '0', '0', 'admin', '2022-11-11 10:30:27', '', NULL);
INSERT INTO `sys_dept` VALUES (104, 101, '0,100,101', '市场部门', 2, '若依', '15888888888', 'ry@qq.com', '0', '0', 'admin', '2022-11-11 10:30:27', '', NULL);
INSERT INTO `sys_dept` VALUES (105, 101, '0,100,101', '测试部门', 3, '若依', '15888888888', 'ry@qq.com', '0', '0', 'admin', '2022-11-11 10:30:27', '', NULL);
INSERT INTO `sys_dept` VALUES (106, 101, '0,100,101', '财务部门', 4, '若依', '15888888888', 'ry@qq.com', '0', '0', 'admin', '2022-11-11 10:30:27', '', NULL);
INSERT INTO `sys_dept` VALUES (200, 0, '0', '代理商', 1, NULL, NULL, NULL, '0', '0', 'admin', '2022-11-12 10:37:00', '', NULL);

-- ----------------------------
-- Table structure for sys_dict_data
-- ----------------------------
DROP TABLE IF EXISTS `sys_dict_data`;
CREATE TABLE `sys_dict_data`  (
  `dict_code` bigint NOT NULL AUTO_INCREMENT COMMENT '字典编码',
  `dict_sort` int NULL DEFAULT 0 COMMENT '字典排序',
  `dict_label` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '字典标签',
  `dict_value` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '字典键值',
  `dict_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '字典类型',
  `css_class` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '样式属性（其他样式扩展）',
  `list_class` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '表格回显样式',
  `is_default` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'N' COMMENT '是否默认（Y是 N否）',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '状态（0正常 1停用）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`dict_code`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 29 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '字典数据表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_dict_data
-- ----------------------------
INSERT INTO `sys_dict_data` VALUES (1, 1, '男', '0', 'sys_user_sex', '', '', 'Y', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '性别男');
INSERT INTO `sys_dict_data` VALUES (2, 2, '女', '1', 'sys_user_sex', '', '', 'N', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '性别女');
INSERT INTO `sys_dict_data` VALUES (3, 3, '未知', '2', 'sys_user_sex', '', '', 'N', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '性别未知');
INSERT INTO `sys_dict_data` VALUES (4, 1, '显示', '0', 'sys_show_hide', '', 'primary', 'Y', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '显示菜单');
INSERT INTO `sys_dict_data` VALUES (5, 2, '隐藏', '1', 'sys_show_hide', '', 'danger', 'N', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '隐藏菜单');
INSERT INTO `sys_dict_data` VALUES (6, 1, '正常', '0', 'sys_normal_disable', '', 'primary', 'Y', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '正常状态');
INSERT INTO `sys_dict_data` VALUES (7, 2, '停用', '1', 'sys_normal_disable', '', 'danger', 'N', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '停用状态');
INSERT INTO `sys_dict_data` VALUES (8, 1, '正常', '0', 'sys_job_status', '', 'primary', 'Y', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '正常状态');
INSERT INTO `sys_dict_data` VALUES (9, 2, '暂停', '1', 'sys_job_status', '', 'danger', 'N', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '停用状态');
INSERT INTO `sys_dict_data` VALUES (10, 1, '默认', 'DEFAULT', 'sys_job_group', '', '', 'Y', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '默认分组');
INSERT INTO `sys_dict_data` VALUES (11, 2, '系统', 'SYSTEM', 'sys_job_group', '', '', 'N', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '系统分组');
INSERT INTO `sys_dict_data` VALUES (12, 1, '是', 'Y', 'sys_yes_no', '', 'primary', 'Y', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '系统默认是');
INSERT INTO `sys_dict_data` VALUES (13, 2, '否', 'N', 'sys_yes_no', '', 'danger', 'N', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '系统默认否');
INSERT INTO `sys_dict_data` VALUES (14, 1, '通知', '1', 'sys_notice_type', '', 'warning', 'Y', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '通知');
INSERT INTO `sys_dict_data` VALUES (15, 2, '公告', '2', 'sys_notice_type', '', 'success', 'N', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '公告');
INSERT INTO `sys_dict_data` VALUES (16, 1, '正常', '0', 'sys_notice_status', '', 'primary', 'Y', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '正常状态');
INSERT INTO `sys_dict_data` VALUES (17, 2, '关闭', '1', 'sys_notice_status', '', 'danger', 'N', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '关闭状态');
INSERT INTO `sys_dict_data` VALUES (18, 99, '其他', '0', 'sys_oper_type', '', 'info', 'N', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '其他操作');
INSERT INTO `sys_dict_data` VALUES (19, 1, '新增', '1', 'sys_oper_type', '', 'info', 'N', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '新增操作');
INSERT INTO `sys_dict_data` VALUES (20, 2, '修改', '2', 'sys_oper_type', '', 'info', 'N', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '修改操作');
INSERT INTO `sys_dict_data` VALUES (21, 3, '删除', '3', 'sys_oper_type', '', 'danger', 'N', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '删除操作');
INSERT INTO `sys_dict_data` VALUES (22, 4, '授权', '4', 'sys_oper_type', '', 'primary', 'N', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '授权操作');
INSERT INTO `sys_dict_data` VALUES (23, 5, '导出', '5', 'sys_oper_type', '', 'warning', 'N', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '导出操作');
INSERT INTO `sys_dict_data` VALUES (24, 6, '导入', '6', 'sys_oper_type', '', 'warning', 'N', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '导入操作');
INSERT INTO `sys_dict_data` VALUES (25, 7, '强退', '7', 'sys_oper_type', '', 'danger', 'N', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '强退操作');
INSERT INTO `sys_dict_data` VALUES (26, 8, '生成代码', '8', 'sys_oper_type', '', 'warning', 'N', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '生成操作');
INSERT INTO `sys_dict_data` VALUES (27, 9, '清空数据', '9', 'sys_oper_type', '', 'danger', 'N', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '清空操作');
INSERT INTO `sys_dict_data` VALUES (28, 1, '成功', '0', 'sys_common_status', '', 'primary', 'N', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '正常状态');
INSERT INTO `sys_dict_data` VALUES (29, 2, '失败', '1', 'sys_common_status', '', 'danger', 'N', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '停用状态');

-- ----------------------------
-- Table structure for sys_dict_type
-- ----------------------------
DROP TABLE IF EXISTS `sys_dict_type`;
CREATE TABLE `sys_dict_type`  (
  `dict_id` bigint NOT NULL AUTO_INCREMENT COMMENT '字典主键',
  `dict_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '字典名称',
  `dict_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '字典类型',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '状态（0正常 1停用）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`dict_id`) USING BTREE,
  UNIQUE INDEX `dict_type`(`dict_type`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '字典类型表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_dict_type
-- ----------------------------
INSERT INTO `sys_dict_type` VALUES (1, '用户性别', 'sys_user_sex', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '用户性别列表');
INSERT INTO `sys_dict_type` VALUES (2, '菜单状态', 'sys_show_hide', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '菜单状态列表');
INSERT INTO `sys_dict_type` VALUES (3, '系统开关', 'sys_normal_disable', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '系统开关列表');
INSERT INTO `sys_dict_type` VALUES (4, '任务状态', 'sys_job_status', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '任务状态列表');
INSERT INTO `sys_dict_type` VALUES (5, '任务分组', 'sys_job_group', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '任务分组列表');
INSERT INTO `sys_dict_type` VALUES (6, '系统是否', 'sys_yes_no', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '系统是否列表');
INSERT INTO `sys_dict_type` VALUES (7, '通知类型', 'sys_notice_type', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '通知类型列表');
INSERT INTO `sys_dict_type` VALUES (8, '通知状态', 'sys_notice_status', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '通知状态列表');
INSERT INTO `sys_dict_type` VALUES (9, '操作类型', 'sys_oper_type', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '操作类型列表');
INSERT INTO `sys_dict_type` VALUES (10, '系统状态', 'sys_common_status', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '登录状态列表');

-- ----------------------------
-- Table structure for sys_job
-- ----------------------------
DROP TABLE IF EXISTS `sys_job`;
CREATE TABLE `sys_job`  (
  `job_id` bigint NOT NULL AUTO_INCREMENT COMMENT '任务ID',
  `job_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '任务名称',
  `job_group` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'DEFAULT' COMMENT '任务组名',
  `invoke_target` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '调用目标字符串',
  `cron_expression` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT 'cron执行表达式',
  `misfire_policy` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '3' COMMENT '计划执行错误策略（1立即执行 2执行一次 3放弃执行）',
  `concurrent` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '1' COMMENT '是否并发执行（0允许 1禁止）',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '状态（0正常 1暂停）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '备注信息',
  PRIMARY KEY (`job_id`, `job_name`, `job_group`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '定时任务调度表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_job
-- ----------------------------
INSERT INTO `sys_job` VALUES (1, '系统默认（无参）', 'DEFAULT', 'ryTask.ryNoParams', '0/10 * * * * ?', '3', '1', '1', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_job` VALUES (2, '系统默认（有参）', 'DEFAULT', 'ryTask.ryParams(\'ry\')', '0/15 * * * * ?', '3', '1', '1', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_job` VALUES (3, '系统默认（多参）', 'DEFAULT', 'ryTask.ryMultipleParams(\'ry\', true, 2000L, 316.50D, 100)', '0/20 * * * * ?', '3', '1', '1', 'admin', '2022-11-12 10:24:54', '', NULL, '');

-- ----------------------------
-- Table structure for sys_job_log
-- ----------------------------
DROP TABLE IF EXISTS `sys_job_log`;
CREATE TABLE `sys_job_log`  (
  `job_log_id` bigint NOT NULL AUTO_INCREMENT COMMENT '任务日志ID',
  `job_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '任务名称',
  `job_group` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '任务组名',
  `invoke_target` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '调用目标字符串',
  `job_message` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '日志信息',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '执行状态（0正常 1失败）',
  `exception_info` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '异常信息',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`job_log_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '定时任务调度日志表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_job_log
-- ----------------------------

-- ----------------------------
-- Table structure for sys_logininfor
-- ----------------------------
DROP TABLE IF EXISTS `sys_logininfor`;
CREATE TABLE `sys_logininfor`  (
  `info_id` bigint NOT NULL AUTO_INCREMENT COMMENT '访问ID',
  `user_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '用户账号',
  `ipaddr` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '登录IP地址',
  `login_location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '登录地点',
  `browser` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '浏览器类型',
  `os` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '操作系统',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '登录状态（0成功 1失败）',
  `msg` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '提示消息',
  `login_time` datetime NULL DEFAULT NULL COMMENT '访问时间',
  PRIMARY KEY (`info_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 103 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '系统访问记录' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_logininfor
-- ----------------------------
INSERT INTO `sys_logininfor` VALUES (100, 'admin', '127.0.0.1', '内网IP', 'Chrome 9', 'Windows 10', '1', '验证码错误', '2022-11-12 10:26:34');
INSERT INTO `sys_logininfor` VALUES (101, 'admin', '127.0.0.1', '内网IP', 'Chrome 9', 'Windows 10', '0', '登录成功', '2022-11-12 10:26:41');
INSERT INTO `sys_logininfor` VALUES (102, 'admin', '127.0.0.1', '内网IP', 'Chrome 9', 'Windows 10', '1', '验证码已失效', '2022-11-12 14:10:05');
INSERT INTO `sys_logininfor` VALUES (103, 'admin', '127.0.0.1', '内网IP', 'Chrome 9', 'Windows 10', '0', '登录成功', '2022-11-12 14:10:09');

-- ----------------------------
-- Table structure for sys_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_menu`;
CREATE TABLE `sys_menu`  (
  `menu_id` bigint NOT NULL AUTO_INCREMENT COMMENT '菜单ID',
  `menu_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '菜单名称',
  `parent_id` bigint NULL DEFAULT 0 COMMENT '父菜单ID',
  `order_num` int NULL DEFAULT 0 COMMENT '显示顺序',
  `path` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '路由地址',
  `component` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '组件路径',
  `query` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '路由参数',
  `is_frame` int NULL DEFAULT 1 COMMENT '是否为外链（0是 1否）',
  `is_cache` int NULL DEFAULT 0 COMMENT '是否缓存（0缓存 1不缓存）',
  `menu_type` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '菜单类型（M目录 C菜单 F按钮）',
  `visible` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '菜单状态（0显示 1隐藏）',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '菜单状态（0正常 1停用）',
  `perms` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '权限标识',
  `icon` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '#' COMMENT '菜单图标',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '备注',
  PRIMARY KEY (`menu_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2003 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '菜单权限表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_menu
-- ----------------------------
INSERT INTO `sys_menu` VALUES (1, '系统管理', 0, 1, 'system', NULL, '', 1, 0, 'M', '0', '0', '', 'system', 'admin', '2022-11-12 10:24:54', '', NULL, '系统管理目录');
INSERT INTO `sys_menu` VALUES (2, '系统监控', 0, 6, 'monitor', NULL, '', 1, 0, 'M', '0', '0', '', 'monitor', 'admin', '2022-11-12 10:24:54', 'admin', '2022-11-12 10:58:50', '系统监控目录');
INSERT INTO `sys_menu` VALUES (3, '系统工具', 0, 7, 'tool', NULL, '', 1, 0, 'M', '0', '0', '', 'tool', 'admin', '2022-11-12 10:24:54', 'admin', '2022-11-12 10:58:54', '系统工具目录');
INSERT INTO `sys_menu` VALUES (100, '用户管理', 1, 1, 'user', 'system/user/index', '', 1, 0, 'C', '0', '0', 'system:user:list', 'user', 'admin', '2022-11-12 10:24:54', '', NULL, '用户管理菜单');
INSERT INTO `sys_menu` VALUES (101, '角色管理', 1, 2, 'role', 'system/role/index', '', 1, 0, 'C', '0', '0', 'system:role:list', 'peoples', 'admin', '2022-11-12 10:24:54', '', NULL, '角色管理菜单');
INSERT INTO `sys_menu` VALUES (102, '菜单管理', 1, 3, 'menu', 'system/menu/index', '', 1, 0, 'C', '0', '0', 'system:menu:list', 'tree-table', 'admin', '2022-11-12 10:24:54', '', NULL, '菜单管理菜单');
INSERT INTO `sys_menu` VALUES (103, '部门管理', 1, 4, 'dept', 'system/dept/index', '', 1, 0, 'C', '0', '0', 'system:dept:list', 'tree', 'admin', '2022-11-12 10:24:54', '', NULL, '部门管理菜单');
INSERT INTO `sys_menu` VALUES (104, '岗位管理', 1, 5, 'post', 'system/post/index', '', 1, 0, 'C', '0', '0', 'system:post:list', 'post', 'admin', '2022-11-12 10:24:54', '', NULL, '岗位管理菜单');
INSERT INTO `sys_menu` VALUES (105, '字典管理', 1, 6, 'dict', 'system/dict/index', '', 1, 0, 'C', '0', '0', 'system:dict:list', 'dict', 'admin', '2022-11-12 10:24:54', '', NULL, '字典管理菜单');
INSERT INTO `sys_menu` VALUES (106, '参数设置', 1, 7, 'config', 'system/config/index', '', 1, 0, 'C', '0', '0', 'system:config:list', 'edit', 'admin', '2022-11-12 10:24:54', '', NULL, '参数设置菜单');
INSERT INTO `sys_menu` VALUES (107, '通知公告', 1, 8, 'notice', 'system/notice/index', '', 1, 0, 'C', '0', '0', 'system:notice:list', 'message', 'admin', '2022-11-12 10:24:54', '', NULL, '通知公告菜单');
INSERT INTO `sys_menu` VALUES (108, '日志管理', 1, 9, 'log', '', '', 1, 0, 'M', '0', '0', '', 'log', 'admin', '2022-11-12 10:24:54', '', NULL, '日志管理菜单');
INSERT INTO `sys_menu` VALUES (109, '在线用户', 2, 1, 'online', 'monitor/online/index', '', 1, 0, 'C', '0', '0', 'monitor:online:list', 'online', 'admin', '2022-11-12 10:24:54', '', NULL, '在线用户菜单');
INSERT INTO `sys_menu` VALUES (110, '定时任务', 2, 2, 'job', 'monitor/job/index', '', 1, 0, 'C', '0', '0', 'monitor:job:list', 'job', 'admin', '2022-11-12 10:24:54', '', NULL, '定时任务菜单');
INSERT INTO `sys_menu` VALUES (111, '数据监控', 2, 3, 'druid', 'monitor/druid/index', '', 1, 0, 'C', '0', '0', 'monitor:druid:list', 'druid', 'admin', '2022-11-12 10:24:54', '', NULL, '数据监控菜单');
INSERT INTO `sys_menu` VALUES (112, '服务监控', 2, 4, 'server', 'monitor/server/index', '', 1, 0, 'C', '0', '0', 'monitor:server:list', 'server', 'admin', '2022-11-12 10:24:54', '', NULL, '服务监控菜单');
INSERT INTO `sys_menu` VALUES (113, '缓存监控', 2, 5, 'cache', 'monitor/cache/index', '', 1, 0, 'C', '0', '0', 'monitor:cache:list', 'redis', 'admin', '2022-11-12 10:24:54', '', NULL, '缓存监控菜单');
INSERT INTO `sys_menu` VALUES (114, '缓存列表', 2, 6, 'cacheList', 'monitor/cache/list', '', 1, 0, 'C', '0', '0', 'monitor:cache:list', 'redis-list', 'admin', '2022-11-12 10:24:54', '', NULL, '缓存列表菜单');
INSERT INTO `sys_menu` VALUES (115, '表单构建', 3, 1, 'build', 'tool/build/index', '', 1, 0, 'C', '0', '0', 'tool:build:list', 'build', 'admin', '2022-11-12 10:24:54', '', NULL, '表单构建菜单');
INSERT INTO `sys_menu` VALUES (116, '代码生成', 3, 2, 'gen', 'tool/gen/index', '', 1, 0, 'C', '0', '0', 'tool:gen:list', 'code', 'admin', '2022-11-12 10:24:54', '', NULL, '代码生成菜单');
INSERT INTO `sys_menu` VALUES (117, '系统接口', 3, 3, 'swagger', 'tool/swagger/index', '', 1, 0, 'C', '0', '0', 'tool:swagger:list', 'swagger', 'admin', '2022-11-12 10:24:54', '', NULL, '系统接口菜单');
INSERT INTO `sys_menu` VALUES (500, '操作日志', 108, 1, 'operlog', 'monitor/operlog/index', '', 1, 0, 'C', '0', '0', 'monitor:operlog:list', 'form', 'admin', '2022-11-12 10:24:54', '', NULL, '操作日志菜单');
INSERT INTO `sys_menu` VALUES (501, '登录日志', 108, 2, 'logininfor', 'monitor/logininfor/index', '', 1, 0, 'C', '0', '0', 'monitor:logininfor:list', 'logininfor', 'admin', '2022-11-12 10:24:54', '', NULL, '登录日志菜单');
INSERT INTO `sys_menu` VALUES (1000, '用户查询', 100, 1, '', '', '', 1, 0, 'F', '0', '0', 'system:user:query', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1001, '用户新增', 100, 2, '', '', '', 1, 0, 'F', '0', '0', 'system:user:add', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1002, '用户修改', 100, 3, '', '', '', 1, 0, 'F', '0', '0', 'system:user:edit', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1003, '用户删除', 100, 4, '', '', '', 1, 0, 'F', '0', '0', 'system:user:remove', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1004, '用户导出', 100, 5, '', '', '', 1, 0, 'F', '0', '0', 'system:user:export', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1005, '用户导入', 100, 6, '', '', '', 1, 0, 'F', '0', '0', 'system:user:import', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1006, '重置密码', 100, 7, '', '', '', 1, 0, 'F', '0', '0', 'system:user:resetPwd', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1007, '角色查询', 101, 1, '', '', '', 1, 0, 'F', '0', '0', 'system:role:query', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1008, '角色新增', 101, 2, '', '', '', 1, 0, 'F', '0', '0', 'system:role:add', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1009, '角色修改', 101, 3, '', '', '', 1, 0, 'F', '0', '0', 'system:role:edit', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1010, '角色删除', 101, 4, '', '', '', 1, 0, 'F', '0', '0', 'system:role:remove', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1011, '角色导出', 101, 5, '', '', '', 1, 0, 'F', '0', '0', 'system:role:export', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1012, '菜单查询', 102, 1, '', '', '', 1, 0, 'F', '0', '0', 'system:menu:query', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1013, '菜单新增', 102, 2, '', '', '', 1, 0, 'F', '0', '0', 'system:menu:add', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1014, '菜单修改', 102, 3, '', '', '', 1, 0, 'F', '0', '0', 'system:menu:edit', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1015, '菜单删除', 102, 4, '', '', '', 1, 0, 'F', '0', '0', 'system:menu:remove', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1016, '部门查询', 103, 1, '', '', '', 1, 0, 'F', '0', '0', 'system:dept:query', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1017, '部门新增', 103, 2, '', '', '', 1, 0, 'F', '0', '0', 'system:dept:add', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1018, '部门修改', 103, 3, '', '', '', 1, 0, 'F', '0', '0', 'system:dept:edit', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1019, '部门删除', 103, 4, '', '', '', 1, 0, 'F', '0', '0', 'system:dept:remove', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1020, '岗位查询', 104, 1, '', '', '', 1, 0, 'F', '0', '0', 'system:post:query', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1021, '岗位新增', 104, 2, '', '', '', 1, 0, 'F', '0', '0', 'system:post:add', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1022, '岗位修改', 104, 3, '', '', '', 1, 0, 'F', '0', '0', 'system:post:edit', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1023, '岗位删除', 104, 4, '', '', '', 1, 0, 'F', '0', '0', 'system:post:remove', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1024, '岗位导出', 104, 5, '', '', '', 1, 0, 'F', '0', '0', 'system:post:export', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1025, '字典查询', 105, 1, '#', '', '', 1, 0, 'F', '0', '0', 'system:dict:query', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1026, '字典新增', 105, 2, '#', '', '', 1, 0, 'F', '0', '0', 'system:dict:add', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1027, '字典修改', 105, 3, '#', '', '', 1, 0, 'F', '0', '0', 'system:dict:edit', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1028, '字典删除', 105, 4, '#', '', '', 1, 0, 'F', '0', '0', 'system:dict:remove', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1029, '字典导出', 105, 5, '#', '', '', 1, 0, 'F', '0', '0', 'system:dict:export', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1030, '参数查询', 106, 1, '#', '', '', 1, 0, 'F', '0', '0', 'system:config:query', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1031, '参数新增', 106, 2, '#', '', '', 1, 0, 'F', '0', '0', 'system:config:add', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1032, '参数修改', 106, 3, '#', '', '', 1, 0, 'F', '0', '0', 'system:config:edit', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1033, '参数删除', 106, 4, '#', '', '', 1, 0, 'F', '0', '0', 'system:config:remove', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1034, '参数导出', 106, 5, '#', '', '', 1, 0, 'F', '0', '0', 'system:config:export', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1035, '公告查询', 107, 1, '#', '', '', 1, 0, 'F', '0', '0', 'system:notice:query', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1036, '公告新增', 107, 2, '#', '', '', 1, 0, 'F', '0', '0', 'system:notice:add', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1037, '公告修改', 107, 3, '#', '', '', 1, 0, 'F', '0', '0', 'system:notice:edit', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1038, '公告删除', 107, 4, '#', '', '', 1, 0, 'F', '0', '0', 'system:notice:remove', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1039, '操作查询', 500, 1, '#', '', '', 1, 0, 'F', '0', '0', 'monitor:operlog:query', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1040, '操作删除', 500, 2, '#', '', '', 1, 0, 'F', '0', '0', 'monitor:operlog:remove', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1041, '日志导出', 500, 3, '#', '', '', 1, 0, 'F', '0', '0', 'monitor:operlog:export', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1042, '登录查询', 501, 1, '#', '', '', 1, 0, 'F', '0', '0', 'monitor:logininfor:query', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1043, '登录删除', 501, 2, '#', '', '', 1, 0, 'F', '0', '0', 'monitor:logininfor:remove', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1044, '日志导出', 501, 3, '#', '', '', 1, 0, 'F', '0', '0', 'monitor:logininfor:export', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1045, '账户解锁', 501, 4, '#', '', '', 1, 0, 'F', '0', '0', 'monitor:logininfor:unlock', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1046, '在线查询', 109, 1, '#', '', '', 1, 0, 'F', '0', '0', 'monitor:online:query', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1047, '批量强退', 109, 2, '#', '', '', 1, 0, 'F', '0', '0', 'monitor:online:batchLogout', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1048, '单条强退', 109, 3, '#', '', '', 1, 0, 'F', '0', '0', 'monitor:online:forceLogout', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1049, '任务查询', 110, 1, '#', '', '', 1, 0, 'F', '0', '0', 'monitor:job:query', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1050, '任务新增', 110, 2, '#', '', '', 1, 0, 'F', '0', '0', 'monitor:job:add', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1051, '任务修改', 110, 3, '#', '', '', 1, 0, 'F', '0', '0', 'monitor:job:edit', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1052, '任务删除', 110, 4, '#', '', '', 1, 0, 'F', '0', '0', 'monitor:job:remove', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1053, '状态修改', 110, 5, '#', '', '', 1, 0, 'F', '0', '0', 'monitor:job:changeStatus', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1054, '任务导出', 110, 6, '#', '', '', 1, 0, 'F', '0', '0', 'monitor:job:export', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1055, '生成查询', 116, 1, '#', '', '', 1, 0, 'F', '0', '0', 'tool:gen:query', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1056, '生成修改', 116, 2, '#', '', '', 1, 0, 'F', '0', '0', 'tool:gen:edit', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1057, '生成删除', 116, 3, '#', '', '', 1, 0, 'F', '0', '0', 'tool:gen:remove', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1058, '导入代码', 116, 4, '#', '', '', 1, 0, 'F', '0', '0', 'tool:gen:import', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1059, '预览代码', 116, 5, '#', '', '', 1, 0, 'F', '0', '0', 'tool:gen:preview', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1060, '生成代码', 116, 6, '#', '', '', 1, 0, 'F', '0', '0', 'tool:gen:code', '#', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_menu` VALUES (2000, '户用电站管理', 0, 2, 'station', NULL, NULL, 1, 0, 'M', '0', '0', '', 'druid', 'admin', '2022-11-12 10:54:57', 'admin', '2022-11-12 10:55:26', '');
INSERT INTO `sys_menu` VALUES (2001, '仓库管理', 0, 3, 'warehouse', NULL, NULL, 1, 0, 'M', '0', '0', NULL, 'chart', 'admin', '2022-11-12 10:57:40', '', NULL, '');
INSERT INTO `sys_menu` VALUES (2002, '财务管理', 0, 4, 'finance', NULL, NULL, 1, 0, 'M', '0', '0', NULL, 'money', 'admin', '2022-11-12 10:58:45', '', NULL, '');
INSERT INTO `sys_menu` VALUES (2003, '数据监控中心', 0, 5, 'data', NULL, NULL, 1, 0, 'M', '0', '0', NULL, 'monitor', 'admin', '2022-11-12 11:00:29', '', NULL, '');

-- ----------------------------
-- Table structure for sys_notice
-- ----------------------------
DROP TABLE IF EXISTS `sys_notice`;
CREATE TABLE `sys_notice`  (
  `notice_id` int NOT NULL AUTO_INCREMENT COMMENT '公告ID',
  `notice_title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '公告标题',
  `notice_type` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '公告类型（1通知 2公告）',
  `notice_content` longblob NULL COMMENT '公告内容',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '公告状态（0正常 1关闭）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`notice_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '通知公告表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_notice
-- ----------------------------
INSERT INTO `sys_notice` VALUES (1, '温馨提醒：2018-07-01 若依新版本发布啦', '2', 0xE696B0E78988E69CACE58685E5AEB9, '0', 'admin', '2022-11-12 10:24:55', '', NULL, '管理员');
INSERT INTO `sys_notice` VALUES (2, '维护通知：2018-07-01 若依系统凌晨维护', '1', 0xE7BBB4E68AA4E58685E5AEB9, '0', 'admin', '2022-11-12 10:24:55', '', NULL, '管理员');

-- ----------------------------
-- Table structure for sys_oper_log
-- ----------------------------
DROP TABLE IF EXISTS `sys_oper_log`;
CREATE TABLE `sys_oper_log`  (
  `oper_id` bigint NOT NULL AUTO_INCREMENT COMMENT '日志主键',
  `title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '模块标题',
  `business_type` int NULL DEFAULT 0 COMMENT '业务类型（0其它 1新增 2修改 3删除）',
  `method` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '方法名称',
  `request_method` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '请求方式',
  `operator_type` int NULL DEFAULT 0 COMMENT '操作类别（0其它 1后台用户 2手机端用户）',
  `oper_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '操作人员',
  `dept_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '部门名称',
  `oper_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '请求URL',
  `oper_ip` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '主机地址',
  `oper_location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '操作地点',
  `oper_param` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '请求参数',
  `json_result` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '返回参数',
  `status` int NULL DEFAULT 0 COMMENT '操作状态（0正常 1异常）',
  `error_msg` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '错误消息',
  `oper_time` datetime NULL DEFAULT NULL COMMENT '操作时间',
  PRIMARY KEY (`oper_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 136 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '操作日志记录' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_oper_log
-- ----------------------------
INSERT INTO `sys_oper_log` VALUES (100, '部门管理', 3, 'com.zcty.web.controller.system.SysDeptController.remove()', 'DELETE', 1, 'admin', NULL, '/system/dept/109', '127.0.0.1', '内网IP', '{deptId=109}', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 10:27:43');
INSERT INTO `sys_oper_log` VALUES (101, '部门管理', 3, 'com.zcty.web.controller.system.SysDeptController.remove()', 'DELETE', 1, 'admin', NULL, '/system/dept/108', '127.0.0.1', '内网IP', '{deptId=108}', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 10:27:45');
INSERT INTO `sys_oper_log` VALUES (102, '部门管理', 3, 'com.zcty.web.controller.system.SysDeptController.remove()', 'DELETE', 1, 'admin', NULL, '/system/dept/102', '127.0.0.1', '内网IP', '{deptId=102}', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 10:27:47');
INSERT INTO `sys_oper_log` VALUES (103, '部门管理', 3, 'com.zcty.web.controller.system.SysDeptController.remove()', 'DELETE', 1, 'admin', NULL, '/system/dept/107', '127.0.0.1', '内网IP', '{deptId=107}', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 10:28:19');
INSERT INTO `sys_oper_log` VALUES (104, '部门管理', 3, 'com.zcty.web.controller.system.SysDeptController.remove()', 'DELETE', 1, 'admin', NULL, '/system/dept/106', '127.0.0.1', '内网IP', '{deptId=106}', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 10:28:21');
INSERT INTO `sys_oper_log` VALUES (105, '部门管理', 3, 'com.zcty.web.controller.system.SysDeptController.remove()', 'DELETE', 1, 'admin', NULL, '/system/dept/105', '127.0.0.1', '内网IP', '{deptId=105}', '{\"msg\":\"部门存在用户,不允许删除\",\"code\":601}', 0, NULL, '2022-11-12 10:28:23');
INSERT INTO `sys_oper_log` VALUES (106, '部门管理', 3, 'com.zcty.web.controller.system.SysDeptController.remove()', 'DELETE', 1, 'admin', NULL, '/system/dept/104', '127.0.0.1', '内网IP', '{deptId=104}', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 10:28:26');
INSERT INTO `sys_oper_log` VALUES (107, '部门管理', 3, 'com.zcty.web.controller.system.SysDeptController.remove()', 'DELETE', 1, 'admin', NULL, '/system/dept/103', '127.0.0.1', '内网IP', '{deptId=103}', '{\"msg\":\"部门存在用户,不允许删除\",\"code\":601}', 0, NULL, '2022-11-12 10:28:30');
INSERT INTO `sys_oper_log` VALUES (108, '部门管理', 2, 'com.zcty.web.controller.system.SysDeptController.edit()', 'PUT', 1, 'admin', NULL, '/system/dept', '127.0.0.1', '内网IP', '{\"ancestors\":\"0\",\"children\":[],\"deptId\":100,\"deptName\":\"总公司\",\"email\":\"ry@qq.com\",\"leader\":\"\",\"orderNum\":0,\"params\":{},\"parentId\":0,\"phone\":\"15888888888\",\"status\":\"0\",\"updateBy\":\"admin\"}', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 10:29:25');
INSERT INTO `sys_oper_log` VALUES (109, '部门管理', 2, 'com.zcty.web.controller.system.SysDeptController.edit()', 'PUT', 1, 'admin', NULL, '/system/dept', '127.0.0.1', '内网IP', '{\"ancestors\":\"0,100\",\"children\":[],\"deptId\":101,\"deptName\":\"总部\",\"email\":\"ry@qq.com\",\"leader\":\"\",\"orderNum\":1,\"params\":{},\"parentId\":100,\"parentName\":\"总公司\",\"phone\":\"15888888888\",\"status\":\"0\",\"updateBy\":\"admin\"}', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 10:29:43');
INSERT INTO `sys_oper_log` VALUES (110, '部门管理', 3, 'com.zcty.web.controller.system.SysDeptController.remove()', 'DELETE', 1, 'admin', NULL, '/system/dept/105', '127.0.0.1', '内网IP', '{deptId=105}', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 10:32:15');
INSERT INTO `sys_oper_log` VALUES (111, '部门管理', 3, 'com.zcty.web.controller.system.SysDeptController.remove()', 'DELETE', 1, 'admin', NULL, '/system/dept/103', '127.0.0.1', '内网IP', '{deptId=103}', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 10:34:04');
INSERT INTO `sys_oper_log` VALUES (112, '部门管理', 3, 'com.zcty.web.controller.system.SysDeptController.remove()', 'DELETE', 1, 'admin', NULL, '/system/dept/101', '127.0.0.1', '内网IP', '{deptId=101}', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 10:34:07');
INSERT INTO `sys_oper_log` VALUES (113, '部门管理', 1, 'com.zcty.web.controller.system.SysDeptController.add()', 'POST', 1, 'admin', NULL, '/system/dept', '127.0.0.1', '内网IP', '{\"ancestors\":\"0,100\",\"children\":[],\"createBy\":\"admin\",\"deptName\":\"代理商\",\"orderNum\":2,\"params\":{},\"parentId\":100,\"status\":\"0\"}', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 10:37:00');
INSERT INTO `sys_oper_log` VALUES (114, '部门管理', 1, 'com.zcty.web.controller.system.SysDeptController.add()', 'POST', 1, 'admin', NULL, '/system/dept', '127.0.0.1', '内网IP', '{\"ancestors\":\"0,100\",\"children\":[],\"createBy\":\"admin\",\"deptName\":\"总部\",\"orderNum\":1,\"params\":{},\"parentId\":100,\"status\":\"0\"}', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 10:39:18');
INSERT INTO `sys_oper_log` VALUES (115, '菜单管理', 3, 'com.zcty.web.controller.system.SysMenuController.remove()', 'DELETE', 1, 'admin', NULL, '/system/menu/4', '127.0.0.1', '内网IP', '{menuId=4}', '{\"msg\":\"菜单已分配,不允许删除\",\"code\":601}', 0, NULL, '2022-11-12 10:50:44');
INSERT INTO `sys_oper_log` VALUES (116, '角色管理', 2, 'com.zcty.web.controller.system.SysRoleController.edit()', 'PUT', 1, 'admin', NULL, '/system/role', '127.0.0.1', '内网IP', '{\"admin\":false,\"createTime\":\"2022-11-12 10:24:54\",\"dataScope\":\"2\",\"delFlag\":\"0\",\"deptCheckStrictly\":true,\"flag\":false,\"menuCheckStrictly\":true,\"menuIds\":[1,100,1000,1001,1002,1003,1004,1005,1006,101,1007,1008,1009,1010,1011,102,1012,1013,1014,1015,103,1016,1017,1018,1019,104,1020,1021,1022,1023,1024,105,1025,1026,1027,1028,1029,106,1030,1031,1032,1033,1034,107,1035,1036,1037,1038,108,500,1039,1040,1041,501,1042,1043,1044,1045,2,109,1046,1047,1048,110,1049,1050,1051,1052,1053,1054,111,112,113,114,3,115,116,1055,1056,1057,1058,1059,1060,117],\"params\":{},\"remark\":\"普通角色\",\"roleId\":2,\"roleKey\":\"common\",\"roleName\":\"普通角色\",\"roleSort\":\"2\",\"status\":\"0\",\"updateBy\":\"admin\"}', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 10:50:57');
INSERT INTO `sys_oper_log` VALUES (117, '菜单管理', 3, 'com.zcty.web.controller.system.SysMenuController.remove()', 'DELETE', 1, 'admin', NULL, '/system/menu/4', '127.0.0.1', '内网IP', '{menuId=4}', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 10:51:04');
INSERT INTO `sys_oper_log` VALUES (118, '菜单管理', 2, 'com.zcty.web.controller.system.SysMenuController.edit()', 'PUT', 1, 'admin', NULL, '/system/menu', '127.0.0.1', '内网IP', '{\"children\":[],\"createTime\":\"2022-11-12 10:24:54\",\"icon\":\"monitor\",\"isCache\":\"0\",\"isFrame\":\"1\",\"menuId\":2,\"menuName\":\"系统监控\",\"menuType\":\"M\",\"orderNum\":5,\"params\":{},\"parentId\":0,\"path\":\"monitor\",\"perms\":\"\",\"query\":\"\",\"status\":\"0\",\"updateBy\":\"admin\",\"visible\":\"0\"}', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 10:52:26');
INSERT INTO `sys_oper_log` VALUES (119, '菜单管理', 2, 'com.zcty.web.controller.system.SysMenuController.edit()', 'PUT', 1, 'admin', NULL, '/system/menu', '127.0.0.1', '内网IP', '{\"children\":[],\"createTime\":\"2022-11-12 10:24:54\",\"icon\":\"tool\",\"isCache\":\"0\",\"isFrame\":\"1\",\"menuId\":3,\"menuName\":\"系统工具\",\"menuType\":\"M\",\"orderNum\":5,\"params\":{},\"parentId\":0,\"path\":\"tool\",\"perms\":\"\",\"query\":\"\",\"status\":\"0\",\"updateBy\":\"admin\",\"visible\":\"0\"}', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 10:52:50');
INSERT INTO `sys_oper_log` VALUES (120, '菜单管理', 2, 'com.zcty.web.controller.system.SysMenuController.edit()', 'PUT', 1, 'admin', NULL, '/system/menu', '127.0.0.1', '内网IP', '{\"children\":[],\"createTime\":\"2022-11-12 10:24:54\",\"icon\":\"tool\",\"isCache\":\"0\",\"isFrame\":\"1\",\"menuId\":3,\"menuName\":\"系统工具\",\"menuType\":\"M\",\"orderNum\":6,\"params\":{},\"parentId\":0,\"path\":\"tool\",\"perms\":\"\",\"query\":\"\",\"status\":\"0\",\"updateBy\":\"admin\",\"visible\":\"0\"}', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 10:52:55');
INSERT INTO `sys_oper_log` VALUES (121, '菜单管理', 1, 'com.zcty.web.controller.system.SysMenuController.add()', 'POST', 1, 'admin', NULL, '/system/menu', '127.0.0.1', '内网IP', '{\"children\":[],\"createBy\":\"admin\",\"icon\":\"druid\",\"isCache\":\"0\",\"isFrame\":\"1\",\"menuName\":\"户用电站管理\",\"menuType\":\"M\",\"orderNum\":2,\"params\":{},\"parentId\":0,\"path\":\"powerStation\",\"status\":\"0\",\"visible\":\"0\"}', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 10:54:57');
INSERT INTO `sys_oper_log` VALUES (122, '菜单管理', 2, 'com.zcty.web.controller.system.SysMenuController.edit()', 'PUT', 1, 'admin', NULL, '/system/menu', '127.0.0.1', '内网IP', '{\"children\":[],\"createTime\":\"2022-11-12 10:54:57\",\"icon\":\"druid\",\"isCache\":\"0\",\"isFrame\":\"1\",\"menuId\":2000,\"menuName\":\"户用电站管理\",\"menuType\":\"M\",\"orderNum\":2,\"params\":{},\"parentId\":0,\"path\":\"station\",\"perms\":\"\",\"status\":\"0\",\"updateBy\":\"admin\",\"visible\":\"0\"}', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 10:55:26');
INSERT INTO `sys_oper_log` VALUES (123, '菜单管理', 1, 'com.zcty.web.controller.system.SysMenuController.add()', 'POST', 1, 'admin', NULL, '/system/menu', '127.0.0.1', '内网IP', '{\"children\":[],\"createBy\":\"admin\",\"icon\":\"chart\",\"isCache\":\"0\",\"isFrame\":\"1\",\"menuName\":\"仓库管理\",\"menuType\":\"M\",\"orderNum\":3,\"params\":{},\"parentId\":0,\"path\":\"warehouse\",\"status\":\"0\",\"visible\":\"0\"}', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 10:57:40');
INSERT INTO `sys_oper_log` VALUES (124, '菜单管理', 1, 'com.zcty.web.controller.system.SysMenuController.add()', 'POST', 1, 'admin', NULL, '/system/menu', '127.0.0.1', '内网IP', '{\"children\":[],\"createBy\":\"admin\",\"icon\":\"money\",\"isCache\":\"0\",\"isFrame\":\"1\",\"menuName\":\"财务管理\",\"menuType\":\"M\",\"orderNum\":4,\"params\":{},\"parentId\":0,\"path\":\"finance\",\"status\":\"0\",\"visible\":\"0\"}', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 10:58:45');
INSERT INTO `sys_oper_log` VALUES (125, '菜单管理', 2, 'com.zcty.web.controller.system.SysMenuController.edit()', 'PUT', 1, 'admin', NULL, '/system/menu', '127.0.0.1', '内网IP', '{\"children\":[],\"createTime\":\"2022-11-12 10:24:54\",\"icon\":\"monitor\",\"isCache\":\"0\",\"isFrame\":\"1\",\"menuId\":2,\"menuName\":\"系统监控\",\"menuType\":\"M\",\"orderNum\":6,\"params\":{},\"parentId\":0,\"path\":\"monitor\",\"perms\":\"\",\"query\":\"\",\"status\":\"0\",\"updateBy\":\"admin\",\"visible\":\"0\"}', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 10:58:50');
INSERT INTO `sys_oper_log` VALUES (126, '菜单管理', 2, 'com.zcty.web.controller.system.SysMenuController.edit()', 'PUT', 1, 'admin', NULL, '/system/menu', '127.0.0.1', '内网IP', '{\"children\":[],\"createTime\":\"2022-11-12 10:24:54\",\"icon\":\"tool\",\"isCache\":\"0\",\"isFrame\":\"1\",\"menuId\":3,\"menuName\":\"系统工具\",\"menuType\":\"M\",\"orderNum\":7,\"params\":{},\"parentId\":0,\"path\":\"tool\",\"perms\":\"\",\"query\":\"\",\"status\":\"0\",\"updateBy\":\"admin\",\"visible\":\"0\"}', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 10:58:54');
INSERT INTO `sys_oper_log` VALUES (127, '菜单管理', 1, 'com.zcty.web.controller.system.SysMenuController.add()', 'POST', 1, 'admin', NULL, '/system/menu', '127.0.0.1', '内网IP', '{\"children\":[],\"createBy\":\"admin\",\"icon\":\"monitor\",\"isCache\":\"0\",\"isFrame\":\"1\",\"menuName\":\"数据监控中心\",\"menuType\":\"M\",\"orderNum\":5,\"params\":{},\"parentId\":0,\"path\":\"data\",\"status\":\"0\",\"visible\":\"0\"}', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 11:00:29');
INSERT INTO `sys_oper_log` VALUES (128, '角色管理', 1, 'com.zcty.web.controller.system.SysRoleController.add()', 'POST', 1, 'admin', NULL, '/system/role', '127.0.0.1', '内网IP', '{\"admin\":false,\"createBy\":\"admin\",\"deptCheckStrictly\":true,\"deptIds\":[],\"flag\":false,\"menuCheckStrictly\":true,\"menuIds\":[],\"params\":{},\"roleId\":100,\"roleKey\":\"agentAdmin\",\"roleName\":\"代理商管理员\",\"roleSort\":\"3\",\"status\":\"0\"}', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 11:06:09');
INSERT INTO `sys_oper_log` VALUES (129, '角色管理', 1, 'com.zcty.web.controller.system.SysRoleController.add()', 'POST', 1, 'admin', NULL, '/system/role', '127.0.0.1', '内网IP', '{\"admin\":false,\"createBy\":\"admin\",\"deptCheckStrictly\":true,\"deptIds\":[],\"flag\":false,\"menuCheckStrictly\":true,\"menuIds\":[],\"params\":{},\"roleId\":101,\"roleKey\":\"agentStaff\",\"roleName\":\"代理商员工\",\"roleSort\":\"4\",\"status\":\"0\"}', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 11:06:48');
INSERT INTO `sys_oper_log` VALUES (130, '代码生成', 6, 'com.zcty.generator.controller.GenController.importTableSave()', 'POST', 1, 'admin', NULL, '/tool/gen/importTable', '127.0.0.1', '内网IP', '\"sys_dept\"', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 11:16:45');
INSERT INTO `sys_oper_log` VALUES (131, '代码生成', 3, 'com.zcty.generator.controller.GenController.remove()', 'DELETE', 1, 'admin', NULL, '/tool/gen/1', '127.0.0.1', '内网IP', '{tableIds=1}', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 11:21:33');
INSERT INTO `sys_oper_log` VALUES (132, '代码生成', 6, 'com.zcty.generator.controller.GenController.importTableSave()', 'POST', 1, 'admin', NULL, '/tool/gen/importTable', '127.0.0.1', '内网IP', '\"pv_area\"', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 14:10:29');
INSERT INTO `sys_oper_log` VALUES (133, '代码生成', 3, 'com.zcty.generator.controller.GenController.remove()', 'DELETE', 1, 'admin', NULL, '/tool/gen/2', '127.0.0.1', '内网IP', '{tableIds=2}', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 14:12:26');
INSERT INTO `sys_oper_log` VALUES (134, '代码生成', 6, 'com.zcty.generator.controller.GenController.importTableSave()', 'POST', 1, 'admin', NULL, '/tool/gen/importTable', '127.0.0.1', '内网IP', '\"pv_area\"', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 14:12:30');
INSERT INTO `sys_oper_log` VALUES (135, '代码生成', 2, 'com.zcty.generator.controller.GenController.editSave()', 'PUT', 1, 'admin', NULL, '/tool/gen', '127.0.0.1', '内网IP', '{\"businessName\":\"area\",\"className\":\"PvArea\",\"columns\":[{\"capJavaField\":\"AreaId\",\"columnComment\":\"区域id\",\"columnId\":28,\"columnName\":\"area_id\",\"columnType\":\"varchar(20)\",\"createBy\":\"admin\",\"createTime\":\"2022-11-12 14:12:30\",\"dictType\":\"\",\"edit\":false,\"htmlType\":\"input\",\"increment\":false,\"insert\":true,\"isIncrement\":\"0\",\"isInsert\":\"1\",\"isPk\":\"1\",\"javaField\":\"areaId\",\"javaType\":\"String\",\"list\":false,\"params\":{},\"pk\":true,\"query\":false,\"queryType\":\"EQ\",\"required\":false,\"sort\":1,\"superColumn\":false,\"tableId\":3,\"updateBy\":\"\",\"usableColumn\":false},{\"capJavaField\":\"ParentId\",\"columnComment\":\"上级区域id\",\"columnId\":29,\"columnName\":\"parent_id\",\"columnType\":\"varchar(20)\",\"createBy\":\"admin\",\"createTime\":\"2022-11-12 14:12:30\",\"dictType\":\"\",\"edit\":true,\"htmlType\":\"input\",\"increment\":false,\"insert\":true,\"isEdit\":\"1\",\"isIncrement\":\"0\",\"isInsert\":\"1\",\"isList\":\"1\",\"isPk\":\"0\",\"isQuery\":\"1\",\"javaField\":\"parentId\",\"javaType\":\"String\",\"list\":true,\"params\":{},\"pk\":false,\"query\":true,\"queryType\":\"EQ\",\"required\":false,\"sort\":2,\"superColumn\":true,\"tableId\":3,\"updateBy\":\"\",\"usableColumn\":true},{\"capJavaField\":\"Ancestors\",\"columnComment\":\"祖级列表\",\"columnId\":30,\"columnName\":\"ancestors\",\"columnType\":\"varchar(100)\",\"createBy\":\"admin\",\"createTime\":\"2022-11-12 14:12:30\",\"dictType\":\"\",\"edit\":true,\"htmlType\":\"input\",\"increment\":false,\"insert\":true,\"isEdit\":\"1\",\"isIncrement\":\"0\",\"isInsert\":\"1\",\"isList\":\"1\",\"isPk\":\"0\",\"isQuery\":\"1\",\"javaField\":\"ancestors\",\"javaType\":\"String\",\"list\":true,\"params\":{},\"pk\":false,\"query\":true,\"queryType\":\"EQ\",\"required\":false,\"sort\":3,\"superColumn\":true,\"tableId\":3,\"updateBy\":\"\",\"usableColumn\":false},{\"capJavaField\":\"ShortName\",\"columnComment\":\"省市区名称\",\"columnId\":31,\"columnName\":\"short_name\",\"columnType\":\"varchar(100)\",\"createBy\":\"admin\",\"createTime\":\"2022-11-12 14:12:30\",\"dictType\":\"\",\"edit\":true,\"htmlType\":\"input\",\"increment\":false,\"insert\":true,\"isEdit\":\"1\",\"isIncrement\":\"0\",\"isInsert\":\"1\",\"isList\":\"1\",\"isPk\":\"0\",\"isQuery\":\"1\",\"javaField\":\"shortName\",\"javaType\":\"String\",\"list\":tr', '{\"msg\":\"操作成功\",\"code\":200}', 0, NULL, '2022-11-12 14:12:46');
INSERT INTO `sys_oper_log` VALUES (136, '代码生成', 8, 'com.zcty.generator.controller.GenController.batchGenCode()', 'GET', 1, 'admin', NULL, '/tool/gen/batchGenCode', '127.0.0.1', '内网IP', '{}', NULL, 0, NULL, '2022-11-12 14:13:03');

-- ----------------------------
-- Table structure for sys_post
-- ----------------------------
DROP TABLE IF EXISTS `sys_post`;
CREATE TABLE `sys_post`  (
  `post_id` bigint NOT NULL AUTO_INCREMENT COMMENT '岗位ID',
  `post_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '岗位编码',
  `post_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '岗位名称',
  `post_sort` int NOT NULL COMMENT '显示顺序',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '状态（0正常 1停用）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`post_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '岗位信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_post
-- ----------------------------
INSERT INTO `sys_post` VALUES (1, 'ceo', '董事长', 1, '0', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_post` VALUES (2, 'se', '项目经理', 2, '0', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_post` VALUES (3, 'hr', '人力资源', 3, '0', 'admin', '2022-11-12 10:24:54', '', NULL, '');
INSERT INTO `sys_post` VALUES (4, 'user', '普通员工', 4, '0', 'admin', '2022-11-12 10:24:54', '', NULL, '');

-- ----------------------------
-- Table structure for sys_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_role`;
CREATE TABLE `sys_role`  (
  `role_id` bigint NOT NULL AUTO_INCREMENT COMMENT '角色ID',
  `role_name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '角色名称',
  `role_key` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '角色权限字符串',
  `role_sort` int NOT NULL COMMENT '显示顺序',
  `data_scope` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '1' COMMENT '数据范围（1：全部数据权限 2：自定数据权限 3：本部门数据权限 4：本部门及以下数据权限）',
  `menu_check_strictly` tinyint(1) NULL DEFAULT 1 COMMENT '菜单树选择项是否关联显示',
  `dept_check_strictly` tinyint(1) NULL DEFAULT 1 COMMENT '部门树选择项是否关联显示',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '角色状态（0正常 1停用）',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`role_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 101 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '角色信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_role
-- ----------------------------
INSERT INTO `sys_role` VALUES (1, '超级管理员', 'admin', 1, '1', 1, 1, '0', '0', 'admin', '2022-11-12 10:24:54', '', NULL, '超级管理员');
INSERT INTO `sys_role` VALUES (2, '普通角色', 'common', 2, '2', 1, 1, '0', '0', 'admin', '2022-11-12 10:24:54', 'admin', '2022-11-12 10:50:57', '普通角色');
INSERT INTO `sys_role` VALUES (100, '代理商管理员', 'agentAdmin', 3, '1', 1, 1, '0', '0', 'admin', '2022-11-12 11:06:09', '', NULL, NULL);
INSERT INTO `sys_role` VALUES (101, '代理商员工', 'agentStaff', 4, '1', 1, 1, '0', '0', 'admin', '2022-11-12 11:06:48', '', NULL, NULL);

-- ----------------------------
-- Table structure for sys_role_dept
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_dept`;
CREATE TABLE `sys_role_dept`  (
  `role_id` bigint NOT NULL COMMENT '角色ID',
  `dept_id` bigint NOT NULL COMMENT '部门ID',
  PRIMARY KEY (`role_id`, `dept_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '角色和部门关联表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_role_dept
-- ----------------------------
INSERT INTO `sys_role_dept` VALUES (2, 100);
INSERT INTO `sys_role_dept` VALUES (2, 101);
INSERT INTO `sys_role_dept` VALUES (2, 105);

-- ----------------------------
-- Table structure for sys_role_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_menu`;
CREATE TABLE `sys_role_menu`  (
  `role_id` bigint NOT NULL COMMENT '角色ID',
  `menu_id` bigint NOT NULL COMMENT '菜单ID',
  PRIMARY KEY (`role_id`, `menu_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '角色和菜单关联表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_role_menu
-- ----------------------------
INSERT INTO `sys_role_menu` VALUES (2, 1);
INSERT INTO `sys_role_menu` VALUES (2, 2);
INSERT INTO `sys_role_menu` VALUES (2, 3);
INSERT INTO `sys_role_menu` VALUES (2, 100);
INSERT INTO `sys_role_menu` VALUES (2, 101);
INSERT INTO `sys_role_menu` VALUES (2, 102);
INSERT INTO `sys_role_menu` VALUES (2, 103);
INSERT INTO `sys_role_menu` VALUES (2, 104);
INSERT INTO `sys_role_menu` VALUES (2, 105);
INSERT INTO `sys_role_menu` VALUES (2, 106);
INSERT INTO `sys_role_menu` VALUES (2, 107);
INSERT INTO `sys_role_menu` VALUES (2, 108);
INSERT INTO `sys_role_menu` VALUES (2, 109);
INSERT INTO `sys_role_menu` VALUES (2, 110);
INSERT INTO `sys_role_menu` VALUES (2, 111);
INSERT INTO `sys_role_menu` VALUES (2, 112);
INSERT INTO `sys_role_menu` VALUES (2, 113);
INSERT INTO `sys_role_menu` VALUES (2, 114);
INSERT INTO `sys_role_menu` VALUES (2, 115);
INSERT INTO `sys_role_menu` VALUES (2, 116);
INSERT INTO `sys_role_menu` VALUES (2, 117);
INSERT INTO `sys_role_menu` VALUES (2, 500);
INSERT INTO `sys_role_menu` VALUES (2, 501);
INSERT INTO `sys_role_menu` VALUES (2, 1000);
INSERT INTO `sys_role_menu` VALUES (2, 1001);
INSERT INTO `sys_role_menu` VALUES (2, 1002);
INSERT INTO `sys_role_menu` VALUES (2, 1003);
INSERT INTO `sys_role_menu` VALUES (2, 1004);
INSERT INTO `sys_role_menu` VALUES (2, 1005);
INSERT INTO `sys_role_menu` VALUES (2, 1006);
INSERT INTO `sys_role_menu` VALUES (2, 1007);
INSERT INTO `sys_role_menu` VALUES (2, 1008);
INSERT INTO `sys_role_menu` VALUES (2, 1009);
INSERT INTO `sys_role_menu` VALUES (2, 1010);
INSERT INTO `sys_role_menu` VALUES (2, 1011);
INSERT INTO `sys_role_menu` VALUES (2, 1012);
INSERT INTO `sys_role_menu` VALUES (2, 1013);
INSERT INTO `sys_role_menu` VALUES (2, 1014);
INSERT INTO `sys_role_menu` VALUES (2, 1015);
INSERT INTO `sys_role_menu` VALUES (2, 1016);
INSERT INTO `sys_role_menu` VALUES (2, 1017);
INSERT INTO `sys_role_menu` VALUES (2, 1018);
INSERT INTO `sys_role_menu` VALUES (2, 1019);
INSERT INTO `sys_role_menu` VALUES (2, 1020);
INSERT INTO `sys_role_menu` VALUES (2, 1021);
INSERT INTO `sys_role_menu` VALUES (2, 1022);
INSERT INTO `sys_role_menu` VALUES (2, 1023);
INSERT INTO `sys_role_menu` VALUES (2, 1024);
INSERT INTO `sys_role_menu` VALUES (2, 1025);
INSERT INTO `sys_role_menu` VALUES (2, 1026);
INSERT INTO `sys_role_menu` VALUES (2, 1027);
INSERT INTO `sys_role_menu` VALUES (2, 1028);
INSERT INTO `sys_role_menu` VALUES (2, 1029);
INSERT INTO `sys_role_menu` VALUES (2, 1030);
INSERT INTO `sys_role_menu` VALUES (2, 1031);
INSERT INTO `sys_role_menu` VALUES (2, 1032);
INSERT INTO `sys_role_menu` VALUES (2, 1033);
INSERT INTO `sys_role_menu` VALUES (2, 1034);
INSERT INTO `sys_role_menu` VALUES (2, 1035);
INSERT INTO `sys_role_menu` VALUES (2, 1036);
INSERT INTO `sys_role_menu` VALUES (2, 1037);
INSERT INTO `sys_role_menu` VALUES (2, 1038);
INSERT INTO `sys_role_menu` VALUES (2, 1039);
INSERT INTO `sys_role_menu` VALUES (2, 1040);
INSERT INTO `sys_role_menu` VALUES (2, 1041);
INSERT INTO `sys_role_menu` VALUES (2, 1042);
INSERT INTO `sys_role_menu` VALUES (2, 1043);
INSERT INTO `sys_role_menu` VALUES (2, 1044);
INSERT INTO `sys_role_menu` VALUES (2, 1045);
INSERT INTO `sys_role_menu` VALUES (2, 1046);
INSERT INTO `sys_role_menu` VALUES (2, 1047);
INSERT INTO `sys_role_menu` VALUES (2, 1048);
INSERT INTO `sys_role_menu` VALUES (2, 1049);
INSERT INTO `sys_role_menu` VALUES (2, 1050);
INSERT INTO `sys_role_menu` VALUES (2, 1051);
INSERT INTO `sys_role_menu` VALUES (2, 1052);
INSERT INTO `sys_role_menu` VALUES (2, 1053);
INSERT INTO `sys_role_menu` VALUES (2, 1054);
INSERT INTO `sys_role_menu` VALUES (2, 1055);
INSERT INTO `sys_role_menu` VALUES (2, 1056);
INSERT INTO `sys_role_menu` VALUES (2, 1057);
INSERT INTO `sys_role_menu` VALUES (2, 1058);
INSERT INTO `sys_role_menu` VALUES (2, 1059);
INSERT INTO `sys_role_menu` VALUES (2, 1060);

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user`  (
  `user_id` bigint NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `dept_id` bigint NULL DEFAULT NULL COMMENT '部门ID',
  `user_name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户账号',
  `nick_name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户昵称',
  `user_type` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '00' COMMENT '用户类型（00系统用户）',
  `email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '用户邮箱',
  `phonenumber` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '手机号码',
  `sex` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '用户性别（0男 1女 2未知）',
  `avatar` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '头像地址',
  `password` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '密码',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '帐号状态（0正常 1停用）',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `login_ip` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '最后登录IP',
  `login_date` datetime NULL DEFAULT NULL COMMENT '最后登录时间',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`user_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '用户信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_user
-- ----------------------------
INSERT INTO `sys_user` VALUES (1, 100, 'admin', '管理员', '00', 'ry@163.com', '15888888888', '1', '', '$2a$10$7JB720yubVSZvUI0rEqK/.VqGOZTH.ulu33dHOiBE8ByOhJIrdAu2', '0', '0', '127.0.0.1', '2022-11-12 14:10:10', 'admin', '2022-11-12 10:24:54', '', '2022-11-12 14:10:09', '管理员');

-- ----------------------------
-- Table structure for sys_user_post
-- ----------------------------
DROP TABLE IF EXISTS `sys_user_post`;
CREATE TABLE `sys_user_post`  (
  `user_id` bigint NOT NULL COMMENT '用户ID',
  `post_id` bigint NOT NULL COMMENT '岗位ID',
  PRIMARY KEY (`user_id`, `post_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '用户与岗位关联表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_user_post
-- ----------------------------
INSERT INTO `sys_user_post` VALUES (1, 1);
INSERT INTO `sys_user_post` VALUES (2, 2);

-- ----------------------------
-- Table structure for sys_user_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_user_role`;
CREATE TABLE `sys_user_role`  (
  `user_id` bigint NOT NULL COMMENT '用户ID',
  `role_id` bigint NOT NULL COMMENT '角色ID',
  PRIMARY KEY (`user_id`, `role_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '用户和角色关联表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_user_role
-- ----------------------------
INSERT INTO `sys_user_role` VALUES (1, 1);
INSERT INTO `sys_user_role` VALUES (2, 2);

SET FOREIGN_KEY_CHECKS = 1;
