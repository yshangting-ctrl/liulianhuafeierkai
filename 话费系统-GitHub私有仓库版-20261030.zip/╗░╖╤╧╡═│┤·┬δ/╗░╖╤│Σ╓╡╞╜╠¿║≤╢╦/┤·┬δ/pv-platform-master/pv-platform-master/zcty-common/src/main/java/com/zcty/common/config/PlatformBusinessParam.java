package com.zcty.common.config;

public class PlatformBusinessParam {

    //充值平台充值步奏
    //创建订单（不一定有，主要针对平台）
    public final static Integer createOrder= 1;
    //发送前置码
    public final static Integer sendPreCode = 2;
    //提交前置码
    public final static Integer submitPreCode = 3;
    //发送业务验证码
    public final static Integer sendSmsCode = 4;
    //提交业务验证码
    public final static Integer submitSmsCode = 5;


}
