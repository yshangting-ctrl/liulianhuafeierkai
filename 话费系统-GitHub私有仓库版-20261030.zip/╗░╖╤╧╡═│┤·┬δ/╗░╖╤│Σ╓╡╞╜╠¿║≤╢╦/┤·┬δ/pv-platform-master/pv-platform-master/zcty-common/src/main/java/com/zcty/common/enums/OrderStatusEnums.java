package com.zcty.common.enums;

/**
 * @Author: chushengkun
 * @Date: 2022/7/28 16:27
 */
public enum OrderStatusEnums {

    /**
     * 订单状态 0、待付款 1、待发货 2、待收货 3、已收货 4、交易关闭 5、退款 6、取消 7、交易完成
     */
    PENDING_PAYMENT("0", "待付款"),
    TO_BE_DELIVERED("1", "待发货"),
    PENDING_RECEIPT("2", "待收货"),
    TRANSACTION_RECEIPT("3", "已收货"),
    TRADING_CLOSED("4", "交易关闭"),
    REFUND("5", "退款中"),
    CANCEL("6", "已取消"),
    TRANSACTION_COMPLETE("7", "交易完成");

    OrderStatusEnums(String status, String name) {
        this.status = status;
        this.name = name;
    }

    private final String status;
    private final String name;

    public String getStatus() {
        return status;
    }

    public String getName() {
        return name;
    }

    public static String getByStatus(String status) {
        if (status != null){
            for (OrderStatusEnums value : OrderStatusEnums.values()) {
                if (value.getStatus().equals(status)){
                    return value.name;
                }
            }
        }
        return "-";
    }
}
