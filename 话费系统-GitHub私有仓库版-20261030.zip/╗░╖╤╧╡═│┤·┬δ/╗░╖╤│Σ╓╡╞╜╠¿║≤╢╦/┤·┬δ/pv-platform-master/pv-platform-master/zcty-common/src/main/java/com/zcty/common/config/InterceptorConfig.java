package com.zcty.common.config;

/**
 * http请求参数处理变量
 */
public class InterceptorConfig {

    public static final String timeStamps = "timestamps";

    public static final String accessToken = "accesstoken";
}
