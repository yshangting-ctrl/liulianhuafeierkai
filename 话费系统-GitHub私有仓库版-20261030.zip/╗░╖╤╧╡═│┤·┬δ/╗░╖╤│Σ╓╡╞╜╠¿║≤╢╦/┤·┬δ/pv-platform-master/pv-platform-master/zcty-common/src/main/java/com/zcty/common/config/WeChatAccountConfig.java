package com.zcty.common.config;

public class WeChatAccountConfig {

     //授权登陆地址更换，不同于普通公众号的授权地址
     //https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx0b07ebb93f97e3da&redirect_uri=REDIRECT_URI&response_type=code&scope=SCOPE&state=wx0b07ebb93f97e3da&component_appid=wx5935f6bb4ea98be9#wechat_redirect;
     private final static String oauthUrl = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=APPID&redirect_uri=REDIRECT_URI&response_type=code&scope=SCOPE&state=STATE&component_appid=component_appid#wechat_redirect";

    //获取第一步的 code 后，请求以下链接获取 access_token
    //https://api.weixin.qq.com/sns/oauth2/component/access_token?appid=APPID&code=CODE&grant_type=authorization_code&component_appid=COMPONENT_APPID&component_access_token=COMPONENT_ACCESS_TOKEN
    public  static String accessTokenUrl = "https://api.weixin.qq.com/sns/oauth2/component/access_token?appid=%s&code=%s&grant_type=authorization_code&component_appid=%s&component_access_token=%s";


    public static void main(String[] args) {
        String accessTokenUrl = "https://api.weixin.qq.com/sns/oauth2/component/access_token?appid=%s&code=%s&grant_type=authorization_code&component_appid=%s&component_access_token=%s";
        System.out.println(accessTokenUrl);
        accessTokenUrl = String.format(accessTokenUrl,"ddd","fff","eee","ggg");
        System.out.println(accessTokenUrl);
    }



}
