package com.zcty.common.constant;

/**
 * 订单参数
 * @Author: chushengkun
 * @Date: 2022/7/27 9:33
 */
public class OrderConstants {
    /** 订单总金额 */
    public static final String TOTAL_FEE = "totalFee";
    /** 订单应支付金额 */
    public static final String PAY_FEE = "payFee";
    /** 30分钟的毫秒 */
    public static final Long ORDER_AUTO_CANCEL_TIME = 1800000L;
    /** 7天的毫秒 */
    public static final Long ORDER_AUTO_CONFIRM_TIME = 604800000L;
    /** 30天的毫秒 */
    public static final Long ORDER_AUTO_COMPLETE_TIME = 2592000000L;
    /** 订单状态 0、待付款 1、待发货 2、待收货 3、确认收货 4、交易关闭 5、退款 6、取消 7、交易完成*/
    public static final Integer ORDER_STATUS_PENDING_PAYMENT = 0;
    public static final Integer ORDER_STATUS_TO_BE_DELIVERED = 1;
    public static final Integer ORDER_STATUS_PENDING_RECEIPT = 2;
    public static final Integer ORDER_STATUS_RECEIPT = 3;
    public static final Integer ORDER_STATUS_TRADING_CLOSED = 4;
    public static final Integer ORDER_STATUS_REFUND = 5;
    public static final Integer ORDER_STATUS_CANCEL = 6;
    public static final Integer ORDER_STATUS_TRANSACTION_COMPLETE = 7;
    /** 是否已经发货 0、未发货 1、已发货 */
    public static final Integer SEND_PRODUCT_NOT_SHIPPED = 0;
    public static final Integer SEND_PRODUCT_SHIPPED = 1;
    /** 订单支付状态 SUCCESS—支付成功 NOTPAY—未支付 CLOSED—已关闭 */
    public static final String PAY_STATUS_NOT_PAY = "NOTPAY";
    public static final String PAY_STATUS_SUCCESS = "SUCCESS";
    /** 第三方支付状态 SUCCESS—支付成功 REFUND—转入退款 NOTPAY—未支付 CLOSED—已关闭 REVOKED—已撤销（付款码支付） USERPAYING--用户支付中（付款码支付） PAYERROR--支付失败(其他原因，如银行返回失败) */
    public static final String THIRD_PAY_STATUS_NOT_PAY = "NOTPAY";
    /** 版本号 */
    public static final Integer SYS_VERSION = 1001;

    /** 创建订单返回的订单信息 */
    public static final String CREATE_ORDER_INFO = "orderInfo";
    /** 创建订单结果 */
    public static final String CREATE_ORDER_FLAG = "flag";

    public static final String OPEN_ID = "openId";

    public static final String ORDER_ID = "orderId";
    public static final String ORDER_NO = "orderNO";

    public static final String ORDER_STATUS = "orderStatus";
    /** 删除状态 */
    public static final String CHECK_DELETE = "checkDelete";
    /** 删除状态 删除*/
    public static final Integer CHECK_DELETE_TRUE = 1;
    /** 删除状态 正常*/
    public static final Integer CHECK_DELETE_FALSE = 0;

    public static final String CANCEL_TIME = "cancelTime";
    public static final String PAY_TIME = "payTime";
    public static final String SEND_PRODUCT_TIME = "sendProductTime";
    public static final String CONFIRM_TIME = "confirmTime";
    public static final String UPDATE_TIME = "updateTime";

    public static final String SYS_VERSION_STR = "sysVersion";

    public static final String ORDER_GOODS_ID = "goodsId";
    public static final String ORDER_NUM = "num";


}
