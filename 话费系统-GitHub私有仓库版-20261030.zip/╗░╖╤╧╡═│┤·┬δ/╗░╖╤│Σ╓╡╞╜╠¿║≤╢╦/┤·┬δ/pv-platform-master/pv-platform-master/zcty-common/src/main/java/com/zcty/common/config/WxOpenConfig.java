package com.zcty.common.config;

/**
 * 第三放开放平台信息
 */
public class WxOpenConfig {

    //公众号第三方平台的appid
    public final static String appId=System.getenv().getOrDefault("WX_OPEN_APP_ID", "");

    //公众号第三方平台的appSecret
    public final static String appSecret=System.getenv().getOrDefault("WX_OPEN_APP_SECRET", "");

    //消息与事件接收


    //消息校验Token第三方平台申请时填写的接收消息的校验token
    public final static String appToken=System.getenv().getOrDefault("WX_OPEN_TOKEN", "");
    //消息加解密Key第三方平台申请时填写的接收消息的加密symmetric_key
    //在代替公众号或小程序收发消息过程中使用。必须是长度为43位的字符串，只能是字母和数字
    public final static String encodingAesKey=System.getenv().getOrDefault("WX_OPEN_AES_KEY", "");


    /**
     * 全局公众号服务第三方平台接口的调用凭据
     */
    public final static String COMPONENT_ACCESS_TOKEN="component_access_token";

    /**
     * 第三方平台接口的调用凭据存活时间 redis的key
     */
    public final static String   COMPONENT_ACCESS_TOKEN_EXPIRES_IN="component_access_token_redis_expires_in";


    /**
     * 全局公众号服务第三方平台接口的验证票据
     */
    public final static String COMPONENT_VERIFY_TICKET = "component_verify_ticket";

    /**
     * 验证票据存活时间 redis的key
     */
    public final static String   COMPONENT_VERIFY_TICKET_EXPIRES_IN="component_verify_ticket_redis_expires_in";

    /**
     * 换取令牌（component_access_token）的路径
     */
    public final static String  API_COMPONENT_TOKEN_URL = "https://api.weixin.qq.com/cgi-bin/component/api_component_token";


//    public final static String  pre_auth_code =  "https://mp.weixin.qq.com/cgi-bin/componentloginpage?component_appid=xxxx&pre_auth_code=xxxxx&redirect_uri=xxxx&auth_type=xxx";
    /**
     * 授权链接，筛二维码
     */
    public final static String  PRE_AUTH_CODE_URL =  "https://mp.weixin.qq.com/cgi-bin/componentloginpage";

    /**
     * 预授权授权链接码
     */
    public final static String PRE_AUTH_CODE = "pre_auth_code";
    /**
     * 获取授权链接码的url
     * https://api.weixin.qq.com/cgi-bin/component/api_create_preauthcode?component_access_token=COMPONENT_ACCESS_TOKEN
     */
    public final static String  GET_PRE_AUTH_CODE_URL =  "https://api.weixin.qq.com/cgi-bin/component/api_create_preauthcode?component_access_token=";

    /**
     * 第一次调取令牌，获取公众号的appid，授权码
     */
//    POST https://api.weixin.qq.com/cgi-bin/component/api_query_auth?access_token=ACCESS_TOKEN
   public final static String API_QUERY_AUTH = "https://api.weixin.qq.com/cgi-bin/component/api_query_auth?access_token=";

   public final static String authorizer_access_token=System.getenv().getOrDefault("WX_AUTHORIZER_ACCESS_TOKEN", "");


//    POST https://api.weixin.qq.com/cgi-bin/component/api_authorizer_token?component_access_token=ACCESS_TOKEN
   public final static String API_AUTHORIZER_TOKEN = "https://api.weixin.qq.com/cgi-bin/component/api_authorizer_token?component_access_token=";
    //https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token="+accessToken+"&type=jsapi
    public final static String Jsapi_Ticket_Url = "https://api.weixin.qq.com/cgi-bin/ticket/getticket";

    //公众号id字符串替换
    public final static String appIdUrlKey = "${appId}";
    //平台第三方id字符串替换
    public final static String componentappidUrlKey="${componentappid}";

    public final static Integer ADD_TYPE = 1;
    public final static Integer SUB_TYPE = 0;

}
