package com.zcty.common.config;

/**
 *  程序配置信息
 */
public class LuckqunxinConfig {
    /** 加解密的头部**/
    public final static String aeskey=System.getenv().getOrDefault("WX_AES_KEY", "");
    /** 加解密需要封装的文件**/
//    public final static String KEYFile=System.getenv().getOrDefault("WX_KEY_FILE", "/data/business/luckqunxin/qunxin/keyFile.txt");
    public final static String KEYFile=System.getenv().getOrDefault("WX_KEY_FILE", "/data/business/luckqunxin/qunxin/keyFile.txt");

    //开发者ID
    public final static String appId=System.getenv().getOrDefault("WX_APP_ID", "");
    //appSecret
    public final static String appSecret=System.getenv().getOrDefault("WX_APP_SECRET", "");

    /** 加解密需要封装的文件**/
    public final static String PayFile=System.getenv().getOrDefault("WX_PAY_FILE", "/data/business/swrechargepay");


    //交易类型JSAPI -JSAPI支付 NATIVE -Native支付 APP -APP支付
    public static final String TRADE_TYPE = "JSAPI";
    //标价币种，默认人民币：CNY
    public static final String FEE_TYPE = "CNY";

    //商品描述
    public final static String PARAM_DESCRIPTION = "description";
    //订单编号
    public final static String PARAM_OUT_TRADE_NO = "out_trade_no";
    //订单实付金额
    public final static String PARAM_TOTAL = "total";
    //购买的用户openid
    public final static String PARAM_OPEN_ID = "openid";

    public final static String RESULT_TIME_STAMP = "timeStamp";
    public final static String RESULT_NONCE_STR = "nonceStr";
    public final static String RESULT_PACKAGE = "package";
    public final static String RESULT_PAY_SIGN = "paySign";
    public final static String RESULT_PREPAY_ID = "prepay_id";
    public final static String RESULT_SIGN_TYPE = "signType";
    public final static String RESULT_SIGN_TYPE_RSA = "RSA";

    public final static String RESULT_CODE = "code";
    public final static String RESULT_MSG = "message";

    //微信统一下单入口url V3版本
    public final static String UNIFIED_ORDER_WEBSITE="https://api.mch.weixin.qq.com/v3/pay/transactions/jsapi";
    //微信查询订单状态接口V3版本，根据orderNo
    public final static String CHECK_ORDER_STATUS_OUT_TRADE_NO="https://api.mch.weixin.qq.com/v3/pay/transactions/out-trade-no/";
    //微信查询退款订单状态的接口V3版本，根据我们系统的退款单号refundNo
    public final static String CHECK_ORDER_STATUS_REFUND_NO="https://api.mch.weixin.qq.com/v3/refund/domestic/refunds";

    //小程序退款申请的访问网址
    public final static String weChatRefundUrl="https://api.mch.weixin.qq.com/v3/refund/domestic/refunds";

    //服务器访问地址
    public static final String mallWebsite=System.getenv().getOrDefault("PUBLIC_API_URL", "http://localhost:8980");
    //支付异步回调
    public static final String payNotifyUrl =mallWebsite+"/weChat/pay/payNotifyUrl";
    //退款异步回调
    public static final String refundNotifyUrl=mallWebsite+"/weChat/pay/refundNotifyUrl";

}
