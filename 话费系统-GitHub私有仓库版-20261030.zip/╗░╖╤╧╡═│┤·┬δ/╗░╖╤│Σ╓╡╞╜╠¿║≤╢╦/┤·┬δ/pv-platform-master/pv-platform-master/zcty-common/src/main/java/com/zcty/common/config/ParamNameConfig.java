package com.zcty.common.config;

public class ParamNameConfig {

    /**
     * 全局公众号服务access_token
     */
    public final static String ACCESS_TOKEN="access_token";

    /**
     * 存活时间
     */
    public final static String   EXPIRES_IN="expires_in";
    /**
     * 延迟队列
     */
    public final static String   Delay_Queue="delayQueue";

    /**
     * 换取js接口信息的凭证
     */
    public final static String TICKET="ticket";

    public final static String ACTIVITY = "activity";



    /**
     * 订单延迟队列
     */
    public final static String DELAY_ORDER = "delayOrder";





}
