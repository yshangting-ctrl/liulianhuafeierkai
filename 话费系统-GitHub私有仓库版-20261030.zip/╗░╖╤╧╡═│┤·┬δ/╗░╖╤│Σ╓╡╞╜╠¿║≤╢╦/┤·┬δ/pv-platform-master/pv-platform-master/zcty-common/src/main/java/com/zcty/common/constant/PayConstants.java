package com.zcty.common.constant;

/**
 * @Author: chushengkun
 * @Date: 2022/7/29 17:43
 */
public class PayConstants {
    // 通知ID - 必填
    public static final String PAY_NOTIFY_ID = "id";
    // 通知创建时间 - 必填
    public static final String PAY_NOTIFY_CREATE_TIME = "create_time";
    // 通知类型 - 必填
    public static final String PAY_NOTIFY_EVENT_TYPE = "event_type";
    // 通知数据类型 - 必填
    public static final String PAY_NOTIFY_RESOURCE_TYPE = "resource_type";
    // 通知数据 - 必填
    public static final String PAY_NOTIFY_RESOURCE = "resource";
    // 回调摘要 - 必填
    public static final String PAY_NOTIFY_SUMMARY = "summary";
    // 加密算法类型 - 必填
    public static final String PAY_NOTIFY_ALGORITHM = "algorithm";
    // 数据密文 - 必填
    public static final String PAY_NOTIFY_CIPHER_TEXT = "ciphertext";
    // 附加数据 - 非必填
    public static final String PAY_NOTIFY_ASSOCIATED_DATA = "associated_data";
    // 原始类型 - 必填
    public static final String PAY_NOTIFY_ORIGINAL_TYPE = "original_type";
    // 随机串 - 必填
    public static final String PAY_NOTIFY_NONCE = "nonce";

    // 商户订单号
    public static final String PAY_NOTIFY_OUT_TRADE_NO = "out_trade_no";
    //商户退款单号
    public static final String PAY_NOTIFY_OUT_REFUND_NO ="out_refund_no";
    // 微信支付订单号
    public static final String PAY_NOTIFY_TRANSACTION_ID = "transaction_id";
    //微信退款订单号
    public static final String PAY_NOTIFY_REFUND_ID = "refund_id";
    // 交易类型，枚举值：
    // JSAPI：公众号支付
    // NATIVE：扫码支付
    // APP：APP支付
    // MICROPAY：付款码支付
    // MWEB：H5支付
    // FACEPAY：刷脸支付
    public static final String PAY_NOTIFY_TRADE_TYPE = "trade_type";
    // 交易状态，枚举值：
    // SUCCESS：支付成功
    // REFUND：转入退款
    // NOTPAY：未支付
    // CLOSED：已关闭
    // REVOKED：已撤销（付款码支付）
    // USERPAYING：用户支付中（付款码支付）
    // PAYERROR：支付失败(其他原因，如银行返回失败)
    public static final String PAY_NOTIFY_TRADE_STATE = "trade_state";
    public static final String PAY_NOTIFY_TRADE_STATE_DESC = "trade_state_desc";
    // 支付完成时间
    public static final String PAY_NOTIFY_SUCCESS_TIME = "success_time";
    // 支付者
    public static final String PAY_NOTIFY_PAYER = "payer";
    // 用户标识
    public static final String PAY_NOTIFY_OPEN_ID = "openid";


    // 退款结果
    public static final String PAY_NOTIFY_REFUND_STATUS = "refund_status";
    // 回调结果 -- 返回给微信
    public static final String PAY_NOTIFY_RESULT = "resultMessage";

    public static final String PAY_NOTIFY_ERROR = "{\"code\": \"FAIL\",\"message\": \"失败\"}";
    public static final String PAY_NOTIFY_SUCCESS = "{\"code\": \"SUCCESS\",\"message\": \"\"}";
}
