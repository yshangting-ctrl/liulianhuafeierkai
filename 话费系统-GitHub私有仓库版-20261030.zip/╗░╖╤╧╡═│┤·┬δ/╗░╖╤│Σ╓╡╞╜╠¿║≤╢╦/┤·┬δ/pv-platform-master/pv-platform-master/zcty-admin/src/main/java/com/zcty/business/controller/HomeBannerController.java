package com.zcty.business.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.zcty.common.annotation.Log;
import com.zcty.common.core.controller.BaseController;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.enums.BusinessType;
import com.zcty.business.domain.HomeBanner;
import com.zcty.business.service.IHomeBannerService;
import com.zcty.common.utils.poi.ExcelUtil;
import com.zcty.common.core.page.TableDataInfo;

/**
 * 首页轮播图Controller
 * 
 * @author lsw
 * @date 2024-03-15
 */
@RestController
@RequestMapping("/business/banner")
public class HomeBannerController extends BaseController
{
    @Autowired
    private IHomeBannerService homeBannerService;

    /**
     * 查询首页轮播图列表
     */
    @PreAuthorize("@ss.hasPermi('business:banner:list')")
    @GetMapping("/list")
    public TableDataInfo list(HomeBanner homeBanner)
    {
        startPage();
        List<HomeBanner> list = homeBannerService.selectHomeBannerList(homeBanner);
        return getDataTable(list);
    }

    /**
     * 导出首页轮播图列表
     */
    @PreAuthorize("@ss.hasPermi('business:banner:export')")
    @Log(title = "首页轮播图", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, HomeBanner homeBanner)
    {
        List<HomeBanner> list = homeBannerService.selectHomeBannerList(homeBanner);
        ExcelUtil<HomeBanner> util = new ExcelUtil<HomeBanner>(HomeBanner.class);
        util.exportExcel(response, list, "首页轮播图数据");
    }

    /**
     * 获取首页轮播图详细信息
     */
    @PreAuthorize("@ss.hasPermi('business:banner:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") String id)
    {
        return success(homeBannerService.selectHomeBannerById(id));
    }

    /**
     * 新增首页轮播图
     */
    @PreAuthorize("@ss.hasPermi('business:banner:add')")
    @Log(title = "首页轮播图", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody HomeBanner homeBanner)
    {
        return (homeBannerService.insertHomeBanner(homeBanner));
    }

    /**
     * 修改首页轮播图
     */
    @PreAuthorize("@ss.hasPermi('business:banner:edit')")
    @Log(title = "首页轮播图", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody HomeBanner homeBanner)
    {
        return (homeBannerService.updateHomeBanner(homeBanner));
    }

    /**
     * 删除首页轮播图
     */
    @PreAuthorize("@ss.hasPermi('business:banner:remove')")
    @Log(title = "首页轮播图", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable String[] ids)
    {
        return toAjax(homeBannerService.deleteHomeBannerByIds(ids));
    }
}
