package com.zcty.business.service.impl;

import java.util.List;
import com.zcty.common.utils.DateUtils;
import com.zcty.web.utlis.IdGen;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zcty.business.mapper.PrivacyInfoMapper;
import com.zcty.business.domain.PrivacyInfo;
import com.zcty.business.service.IPrivacyInfoService;

/**
 * 隐私政策Service业务层处理
 * 
 * @author lsw
 * @date 2024-03-22
 */
@Service
public class PrivacyInfoServiceImpl implements IPrivacyInfoService 
{
    @Autowired
    private PrivacyInfoMapper privacyInfoMapper;

    /**
     * 查询隐私政策
     * 
     * @param id 隐私政策主键
     * @return 隐私政策
     */
    @Override
    public PrivacyInfo selectPrivacyInfoById(String id)
    {
        return privacyInfoMapper.selectPrivacyInfoById(id);
    }

    /**
     * 查询隐私政策列表
     * 
     * @param privacyInfo 隐私政策
     * @return 隐私政策
     */
    @Override
    public List<PrivacyInfo> selectPrivacyInfoList(PrivacyInfo privacyInfo)
    {
        return privacyInfoMapper.selectPrivacyInfoList(privacyInfo);
    }

    /**
     * 新增隐私政策
     * 
     * @param privacyInfo 隐私政策
     * @return 结果
     */
    @Override
    public int insertPrivacyInfo(PrivacyInfo privacyInfo)
    {
        String id = IdGen.uuid();
        privacyInfo.setId(id);
        privacyInfo.setCreateTime(DateUtils.getNowDate());
        return privacyInfoMapper.insertPrivacyInfo(privacyInfo);
    }

    /**
     * 修改隐私政策
     * 
     * @param privacyInfo 隐私政策
     * @return 结果
     */
    @Override
    public int updatePrivacyInfo(PrivacyInfo privacyInfo)
    {
        return privacyInfoMapper.updatePrivacyInfo(privacyInfo);
    }

    /**
     * 批量删除隐私政策
     * 
     * @param ids 需要删除的隐私政策主键
     * @return 结果
     */
    @Override
    public int deletePrivacyInfoByIds(String[] ids)
    {
        return privacyInfoMapper.deletePrivacyInfoByIds(ids);
    }

    /**
     * 删除隐私政策信息
     * 
     * @param id 隐私政策主键
     * @return 结果
     */
    @Override
    public int deletePrivacyInfoById(String id)
    {
        return privacyInfoMapper.deletePrivacyInfoById(id);
    }
}
