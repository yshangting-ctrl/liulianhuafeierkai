package com.zcty.business.mapper;

import java.util.List;
import com.zcty.business.domain.Product;
/**
 * 产品项目Mapper接口
 * 
 * @author lsw
 * @date 2024-03-13
 */
public interface ProductMapper 
{
    /**
     * 查询产品项目
     * 
     * @param id 产品项目主键
     * @return 产品项目
     */
    public Product selectProductById(String id);

    /**
     * 查询产品项目列表
     * 
     * @param product 产品项目
     * @return 产品项目集合
     */
    public List<Product> selectProductList(Product product);

    /**
     * 新增产品项目
     * 
     * @param product 产品项目
     * @return 结果
     */
    public int insertProduct(Product product);

    /**
     * 修改产品项目
     * 
     * @param product 产品项目
     * @return 结果
     */
    public int updateProduct(Product product);

    /**
     * 删除产品项目
     * 
     * @param id 产品项目主键
     * @return 结果
     */
    public int deleteProductById(String id);

    /**
     * 批量删除产品项目
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteProductByIds(String[] ids);

    /**
     * 添加销量
     * @param product
     * @return
     */
    public int addSales(Product product);

    public int updateProductStatus(Product product);
}
