package com.zcty.pv.domain;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.zcty.common.annotation.Excel;
import com.zcty.common.core.domain.BaseEntity;

import javax.validation.constraints.NotBlank;

/**
 * 代理商对象 pv_agent
 * 
 * @author luohui
 * @date 2022-11-29
 */
@ApiModel("代理商对象")
public class PvAgent extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 代理商ID，使用分布式id */
    @JsonSerialize(using = ToStringSerializer.class)
    @ApiModelProperty("代理商ID，使用分布式id")
    private Long agentId;

    /** 单位名称 */
    @ApiModelProperty("单位名称")
    @Excel(name = "单位名称")
    private String agentName;

    /** 统一社会信用代码 */
    @ApiModelProperty("统一社会信用代码")
    @Excel(name = "统一社会信用代码")
    private String creditCode;

    /** 法人 */
    @ApiModelProperty("法人")
    @Excel(name = "法人")
    private String legalPerson;

    /** 联络人 */
    @ApiModelProperty("联络人")
    @Excel(name = "联络人")
    private String contacts;

    /** 联络人手机 */
    @ApiModelProperty("联络人手机")
    @Excel(name = "联络人手机")
    private String phone;

    /** 信用额（单位：元） */
    @ApiModelProperty("信用额（单位：元）")
    @Excel(name = "信用额", readConverterExp = "单=位：元")
    private Integer credit;

    /** 对应部门id */
    @JsonSerialize(using = ToStringSerializer.class)
    @ApiModelProperty("对应部门id")
    @Excel(name = "对应部门id")
    private Long deptId;

    /** 状态 */
    @ApiModelProperty("状态")
    @Excel(name = "状态")
    private Integer status;

    /** 序号 */
    @ApiModelProperty("序号")
    @Excel(name = "序号")
    private Integer sortNum;

    /** 删除标志（0代表存在 2代表删除） */
    @ApiModelProperty("删除标志（0代表存在 2代表删除）")
    private String delFlag;

    public void setAgentId(Long agentId) 
    {
        this.agentId = agentId;
    }

    public Long getAgentId() 
    {
        return agentId;
    }
    public void setAgentName(String agentName) 
    {
        this.agentName = agentName;
    }

    @NotBlank(message = "代理商名称不能为空")
    public String getAgentName() 
    {
        return agentName;
    }
    public void setCreditCode(String creditCode) 
    {
        this.creditCode = creditCode;
    }

    public String getCreditCode() 
    {
        return creditCode;
    }
    public void setLegalPerson(String legalPerson) 
    {
        this.legalPerson = legalPerson;
    }

    public String getLegalPerson() 
    {
        return legalPerson;
    }
    public void setContacts(String contacts) 
    {
        this.contacts = contacts;
    }

    public String getContacts() 
    {
        return contacts;
    }
    public void setPhone(String phone) 
    {
        this.phone = phone;
    }

    public String getPhone() 
    {
        return phone;
    }
    public void setCredit(Integer credit) 
    {
        this.credit = credit;
    }

    public Integer getCredit() 
    {
        return credit;
    }
    public void setDeptId(Long deptId) 
    {
        this.deptId = deptId;
    }

    public Long getDeptId() 
    {
        return deptId;
    }
    public void setStatus(Integer status) 
    {
        this.status = status;
    }

    public Integer getStatus() 
    {
        return status;
    }
    public void setSortNum(Integer sortNum) 
    {
        this.sortNum = sortNum;
    }

    public Integer getSortNum() 
    {
        return sortNum;
    }
    public void setDelFlag(String delFlag) 
    {
        this.delFlag = delFlag;
    }

    public String getDelFlag() 
    {
        return delFlag;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("agentId", getAgentId())
            .append("agentName", getAgentName())
            .append("creditCode", getCreditCode())
            .append("legalPerson", getLegalPerson())
            .append("contacts", getContacts())
            .append("phone", getPhone())
            .append("credit", getCredit())
            .append("deptId", getDeptId())
            .append("remark", getRemark())
            .append("status", getStatus())
            .append("createBy", getCreateBy())
            .append("createTime", getCreateTime())
            .append("updateBy", getUpdateBy())
            .append("updateTime", getUpdateTime())
            .append("sortNum", getSortNum())
            .append("delFlag", getDelFlag())
            .toString();
    }
}
