package com.zcty.business.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.zcty.common.annotation.Excel;
import com.zcty.common.core.domain.BaseEntity;

/**
 * 业务发货对象 t_order_send_product
 * 
 * @author lsw
 * @date 2024-07-09
 */
public class OrderSendProduct extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 主键id */
    private String id;

    /** 订单编号 */
    private String orderNo;

    /** 上级订单编号 */
    private String parentOrderNo;

    /** 订单发货模式 1、 一码 2、二码 */
    private Integer orderModel;

    /** 发送订单状态 0未完成 1已完成 2取消 */
    private Integer sendStatus;

    /** 手机号码 */
    private String phone;

    /** 业务id */
    private String activityid;

    public void setId(String id) 
    {
        this.id = id;
    }

    public String getId() 
    {
        return id;
    }
    public void setOrderNo(String orderNo) 
    {
        this.orderNo = orderNo;
    }

    public String getOrderNo() 
    {
        return orderNo;
    }
    public void setOrderModel(Integer orderModel) 
    {
        this.orderModel = orderModel;
    }

    public Integer getOrderModel() 
    {
        return orderModel;
    }
    public void setSendStatus(Integer sendStatus) 
    {
        this.sendStatus = sendStatus;
    }

    public Integer getSendStatus() 
    {
        return sendStatus;
    }
    public void setPhone(String phone) 
    {
        this.phone = phone;
    }

    public String getPhone() 
    {
        return phone;
    }
    public void setActivityid(String activityid) 
    {
        this.activityid = activityid;
    }

    public String getActivityid() 
    {
        return activityid;
    }

    public String getParentOrderNo() {
        return parentOrderNo;
    }

    public void setParentOrderNo(String parentOrderNo) {
        this.parentOrderNo = parentOrderNo;
    }


    @Override
    public String toString() {
        return "OrderSendProduct{" +
                "id='" + id + '\'' +
                ", orderNo='" + orderNo + '\'' +
                ", parentOrderNo='" + parentOrderNo + '\'' +
                ", orderModel=" + orderModel +
                ", sendStatus=" + sendStatus +
                ", phone='" + phone + '\'' +
                ", activityid='" + activityid + '\'' +
                '}';
    }
}
