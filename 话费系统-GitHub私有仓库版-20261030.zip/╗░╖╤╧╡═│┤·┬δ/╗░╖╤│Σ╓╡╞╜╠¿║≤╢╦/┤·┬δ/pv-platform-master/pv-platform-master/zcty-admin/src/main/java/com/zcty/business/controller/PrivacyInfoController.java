package com.zcty.business.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.zcty.common.annotation.Log;
import com.zcty.common.core.controller.BaseController;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.enums.BusinessType;
import com.zcty.business.domain.PrivacyInfo;
import com.zcty.business.service.IPrivacyInfoService;
import com.zcty.common.utils.poi.ExcelUtil;
import com.zcty.common.core.page.TableDataInfo;

/**
 * 隐私政策Controller
 * 
 * @author lsw
 * @date 2024-03-22
 */
@RestController
@RequestMapping("/business/privacy")
public class PrivacyInfoController extends BaseController
{
    @Autowired
    private IPrivacyInfoService privacyInfoService;

    /**
     * 查询隐私政策列表
     */
    @PreAuthorize("@ss.hasPermi('business:privacy:list')")
    @GetMapping("/list")
    public TableDataInfo list(PrivacyInfo privacyInfo)
    {
        startPage();
        List<PrivacyInfo> list = privacyInfoService.selectPrivacyInfoList(privacyInfo);
        return getDataTable(list);
    }

    /**
     * 导出隐私政策列表
     */
    @PreAuthorize("@ss.hasPermi('business:privacy:export')")
    @Log(title = "隐私政策", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, PrivacyInfo privacyInfo)
    {
        List<PrivacyInfo> list = privacyInfoService.selectPrivacyInfoList(privacyInfo);
        ExcelUtil<PrivacyInfo> util = new ExcelUtil<PrivacyInfo>(PrivacyInfo.class);
        util.exportExcel(response, list, "隐私政策数据");
    }

    /**
     * 获取隐私政策详细信息
     */
    @PreAuthorize("@ss.hasPermi('business:privacy:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") String id)
    {
        return success(privacyInfoService.selectPrivacyInfoById(id));
    }

    /**
     * 新增隐私政策
     */
    @PreAuthorize("@ss.hasPermi('business:privacy:add')")
    @Log(title = "隐私政策", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody PrivacyInfo privacyInfo)
    {
        return toAjax(privacyInfoService.insertPrivacyInfo(privacyInfo));
    }

    /**
     * 修改隐私政策
     */
    @PreAuthorize("@ss.hasPermi('business:privacy:edit')")
    @Log(title = "隐私政策", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody PrivacyInfo privacyInfo)
    {
        return toAjax(privacyInfoService.updatePrivacyInfo(privacyInfo));
    }

    /**
     * 删除隐私政策
     */
    @PreAuthorize("@ss.hasPermi('business:privacy:remove')")
    @Log(title = "隐私政策", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable String[] ids)
    {
        return toAjax(privacyInfoService.deletePrivacyInfoByIds(ids));
    }
}
