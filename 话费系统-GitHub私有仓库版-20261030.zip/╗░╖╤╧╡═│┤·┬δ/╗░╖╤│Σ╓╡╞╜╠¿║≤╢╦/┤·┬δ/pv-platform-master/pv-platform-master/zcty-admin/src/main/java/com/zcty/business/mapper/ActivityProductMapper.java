package com.zcty.business.mapper;

import java.util.List;
import com.zcty.business.domain.ActivityProduct;

/**
 * 第三方业务商品Mapper接口
 * 
 * @author LSW
 * @date 2024-07-01
 */
public interface ActivityProductMapper 
{
    /**
     * 查询第三方业务商品
     * 
     * @param id 第三方业务商品主键
     * @return 第三方业务商品
     */
    public ActivityProduct selectActivityProductById(String id);

    /**
     * 查询第三方业务商品列表
     * 
     * @param activityProduct 第三方业务商品
     * @return 第三方业务商品集合
     */
    public List<ActivityProduct> selectActivityProductList(ActivityProduct activityProduct);

    public List<ActivityProduct> selectActivityPlatProductList(ActivityProduct activityProduct);

    /**
     * 新增第三方业务商品
     * 
     * @param activityProduct 第三方业务商品
     * @return 结果
     */
    public int insertActivityProduct(ActivityProduct activityProduct);

    /**
     * 修改第三方业务商品
     * 
     * @param activityProduct 第三方业务商品
     * @return 结果
     */
    public int updateActivityProduct(ActivityProduct activityProduct);

    /**
     * 删除第三方业务商品
     * 
     * @param id 第三方业务商品主键
     * @return 结果
     */
    public int deleteActivityProductById(String id);

    /**
     * 批量删除第三方业务商品
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteActivityProductByIds(String[] ids);
}
