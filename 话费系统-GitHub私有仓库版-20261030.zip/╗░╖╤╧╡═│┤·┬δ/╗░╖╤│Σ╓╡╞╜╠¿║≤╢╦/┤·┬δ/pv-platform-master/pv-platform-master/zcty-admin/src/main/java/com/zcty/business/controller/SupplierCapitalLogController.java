package com.zcty.business.controller;

import java.util.List;

import com.zcty.business.domain.SupplierCapitalLogVo;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.zcty.common.annotation.Log;
import com.zcty.common.core.controller.BaseController;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.enums.BusinessType;
import com.zcty.business.domain.SupplierCapitalLog;
import com.zcty.business.service.ISupplierCapitalLogService;

import com.zcty.common.core.page.TableDataInfo;

/**
 * 代理商资金使用记录Controller
 * 
 * @author ruoyi
 * @date 2024-06-24
 */
@RestController
@RequestMapping("/business/log")
public class SupplierCapitalLogController extends BaseController
{
    @Autowired
    private ISupplierCapitalLogService supplierCapitalLogService;

    /**
     * 查询代理商资金使用记录列表
     */
    @PreAuthorize("@ss.hasPermi('business:log:list')")
    @GetMapping("/list")
    public TableDataInfo list(SupplierCapitalLog supplierCapitalLog)
    {
        startPage();
        List<SupplierCapitalLog> list = supplierCapitalLogService.selectSupplierCapitalLogList(supplierCapitalLog);
        return getDataTable(list);
    }

    /**
     * 查询代理商资金使用记录列表
     */
    @GetMapping("/showList")
    public TableDataInfo showList(SupplierCapitalLogVo supplierCapitalLogVo)
    {
        startPage();
        List<SupplierCapitalLogVo> list = supplierCapitalLogService.selectSupplierCapitalLogVoList(supplierCapitalLogVo);
        return getDataTable(list);
    }



    /**
     * 获取代理商资金使用记录详细信息
     */
    @PreAuthorize("@ss.hasPermi('business:log:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") String id)
    {
        return success(supplierCapitalLogService.selectSupplierCapitalLogById(id));
    }

    /**
     * 新增代理商资金使用记录
     */
    @PreAuthorize("@ss.hasPermi('business:log:add')")
    @Log(title = "代理商资金使用记录", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody SupplierCapitalLog supplierCapitalLog)
    {
        return toAjax(supplierCapitalLogService.insertSupplierCapitalLog(supplierCapitalLog));
    }

    /**
     * 修改代理商资金使用记录
     */
    @PreAuthorize("@ss.hasPermi('business:log:edit')")
    @Log(title = "代理商资金使用记录", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody SupplierCapitalLog supplierCapitalLog)
    {
        return toAjax(supplierCapitalLogService.updateSupplierCapitalLog(supplierCapitalLog));
    }

    /**
     * 删除代理商资金使用记录
     */
    @PreAuthorize("@ss.hasPermi('business:log:remove')")
    @Log(title = "代理商资金使用记录", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable String[] ids)
    {
        return toAjax(supplierCapitalLogService.deleteSupplierCapitalLogByIds(ids));
    }
}
