package com.zcty.pv.enums;

/**
 * 电站各阶段审核状态枚举
 */
public enum StationAuditStatusEnum {
    /** 待提交 */
    INITIAL(0, "待提交"),
    /** 待审核 */
    PENDING(1, "待审核"),
    /** 审核通过 */
    AUDITED(2, "审核通过"),
    /** 审核不通过 */
    FAIL(3, "审核不通过");

    private Integer value;
    private String text;

    StationAuditStatusEnum(Integer value, String text) {
        this.value = value;
        this.text = text;
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
