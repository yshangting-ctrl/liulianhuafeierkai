package com.zcty.business.service;

/**
 * @authour:linxiaohan
 * @date:2018/12/13
 * @description:
 */
public interface NumberService {

    public String getYHNumber();
    public String getODNumber();
    public String getXMNumber();
    public String getTKNumber();
    public String getPLNumber();
    public String getHFNumber();
    public String getLLNumber();
    public String getNumber(int type);
    public void updateNumber(String num);

}
