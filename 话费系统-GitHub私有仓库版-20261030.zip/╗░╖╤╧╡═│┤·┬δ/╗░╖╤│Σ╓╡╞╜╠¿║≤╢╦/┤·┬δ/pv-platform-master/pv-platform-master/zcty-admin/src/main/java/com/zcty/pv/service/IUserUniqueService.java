package com.zcty.pv.service;


import com.zcty.pv.domain.UserUnique;

/**
 * 用户唯一编号记录 服务层
 * 
 * @author liuruibin
 * @date 2020-12-10
 */
public interface IUserUniqueService 
{
	/**
     * 查询用户唯一编号记录信息
     * 
     * @param id 用户唯一编号记录ID
     * @return 用户唯一编号记录信息
     */
	public UserUnique selectUserUniqueById(String id);

	/**
     * 新增用户唯一编号记录
     * 
     * @param userUnique 用户唯一编号记录信息
     * @return 结果
     */
	public int insertUserUnique(UserUnique userUnique);
}
