package com.zcty.business.domain;


/**
 * @Author: chushengkun
 * @Date: 2022/8/3 11:10
 */
public class OrderShippedInfoVO {

    /** 订单编号 */
    private String orderNo;
    /** 联系电话 */
    private String phone;
    /** 联系人 */
    private String nickName;
    /** 发货时间 */
    private String sendProductTime;
    /** 发货备注 */
    private String sendRemark;

    /**商品类型 1 话费商品 2 流量商品 */
    private Integer goodsType;


    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }


    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getSendProductTime() {
        return sendProductTime;
    }

    public void setSendProductTime(String sendProductTime) {
        this.sendProductTime = sendProductTime;
    }

    public String getSendRemark() {
        return sendRemark;
    }

    public void setSendRemark(String sendRemark) {
        this.sendRemark = sendRemark;
    }

    public Integer getGoodsType() {
        return goodsType;
    }

    public void setGoodsType(Integer goodsType) {
        this.goodsType = goodsType;
    }
}
