package com.zcty.business.domain;


import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * 订单列表
 * @Author: chushengkun
 * @Date: 2022/7/27 17:01
 */
public class WeOrderVO {
//    /** id信息 */
//    private  String id;
    /** 订单ID */
    private String orderId;
    /** 订单编号 */
    private String orderNo;
    /** 订单title */
    private String remarkBody;

    /** 订单金额 */
    private BigDecimal totalFee;

    /** 订单支付金额*/
    private BigDecimal payFee;

    /** 创建时间 */
    private Date createTime;

    /** 订单状态 0、待付款 1、待发货 2、待收货 3、交易完成 4、交易关闭 5、退款 6、取消 */
    private Integer orderStatus;
    //'退货状态 0、发起退货申请 1、同意退货申请 2、拒绝退货  3、退货申请关闭'
    private Integer refundStatus;

    private String phone;

    /**商品类型 1 话费商品 2 流量商品 */
    private Integer goodsType;

    private List<WeOrderGoodsVO> orderGoodsVOList;

//    public String getId() {
//        return id;
//    }
//
//    public void setId(String id) {
//        this.id = id;
//    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getRemarkBody() {
        return remarkBody;
    }

    public void setRemarkBody(String remarkBody) {
        this.remarkBody = remarkBody;
    }

    public BigDecimal getTotalFee() {
        return totalFee;
    }

    public void setTotalFee(BigDecimal totalFee) {
        this.totalFee = totalFee;
    }



    public BigDecimal getPayFee() {
        return payFee;
    }

    public void setPayFee(BigDecimal payFee) {
        this.payFee = payFee;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(Integer orderStatus) {
        this.orderStatus = orderStatus;
    }

    public Integer getRefundStatus() {
        return refundStatus;
    }

    public void setRefundStatus(Integer refundStatus) {
        this.refundStatus = refundStatus;
    }

    public List<WeOrderGoodsVO> getOrderGoodsVOList() {
        return orderGoodsVOList;
    }

    public void setOrderGoodsVOList(List<WeOrderGoodsVO> orderGoodsVOList) {
        this.orderGoodsVOList = orderGoodsVOList;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Integer getGoodsType() {
        return goodsType;
    }

    public void setGoodsType(Integer goodsType) {
        this.goodsType = goodsType;
    }
}
