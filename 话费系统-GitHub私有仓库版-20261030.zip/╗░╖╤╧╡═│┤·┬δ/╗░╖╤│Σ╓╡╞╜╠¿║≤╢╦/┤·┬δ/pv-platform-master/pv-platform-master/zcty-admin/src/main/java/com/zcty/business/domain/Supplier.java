package com.zcty.business.domain;

import com.zcty.common.annotation.Excel;
import com.zcty.common.core.domain.BaseEntity;
/**
 * supplier对象 t_supplier
 * 
 * @author lsw
 * @date 2024-03-09
 */
public class Supplier extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 主键id */
    private String id;

    /** 代理商编号 */
    @Excel(name = "代理商编号")
    private String supNo;

    /** 代理商名称 */
    @Excel(name = "代理商名称")
    private String supName;

    /** 联系人 */
    @Excel(name = "联系人")
    private String contactPeople;

    /** 说明 */
    @Excel(name = "说明")
    private String phone;

    /** 联系方式 */
    @Excel(name = "联系方式")
    private String remarks;

    /** 地址 */
    @Excel(name = "地址")
    private String localtion;

    /** 删除标示0：表示正常使用的数据 1：表示已删除的数据 */
    private Integer delFlag;

    /** 公众号id */
    @Excel(name = "公众号id")
    private String appId;

    /** 公众号秘钥 */
    @Excel(name = "公众号秘钥")
    private String appSecret;

    /** 公众号分配的域名 */
    @Excel(name = "公众号分配的域名")
    private String appUrl;

    /**
     * 用户登陆账号
     */
    private String userName;

    public void setId(String id) 
    {
        this.id = id;
    }

    public String getId() 
    {
        return id;
    }
    public void setSupNo(String supNo) 
    {
        this.supNo = supNo;
    }

    public String getSupNo() 
    {
        return supNo;
    }
    public void setSupName(String supName) 
    {
        this.supName = supName;
    }

    public String getSupName() 
    {
        return supName;
    }
    public void setContactPeople(String contactPeople) 
    {
        this.contactPeople = contactPeople;
    }

    public String getContactPeople() 
    {
        return contactPeople;
    }
    public void setPhone(String phone) 
    {
        this.phone = phone;
    }

    public String getPhone() 
    {
        return phone;
    }
    public void setRemarks(String remarks) 
    {
        this.remarks = remarks;
    }

    public String getRemarks() 
    {
        return remarks;
    }
    public void setLocaltion(String localtion) 
    {
        this.localtion = localtion;
    }

    public String getLocaltion() 
    {
        return localtion;
    }
    public void setDelFlag(Integer delFlag) 
    {
        this.delFlag = delFlag;
    }

    public Integer getDelFlag() 
    {
        return delFlag;
    }
    public void setAppId(String appId) 
    {
        this.appId = appId;
    }

    public String getAppId() 
    {
        return appId;
    }
    public void setAppSecret(String appSecret) 
    {
        this.appSecret = appSecret;
    }

    public String getAppSecret() 
    {
        return appSecret;
    }
    public void setAppUrl(String appUrl) 
    {
        this.appUrl = appUrl;
    }

    public String getAppUrl() 
    {
        return appUrl;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    @Override
    public String toString() {
        return "Supplier{" +
                "id='" + id + '\'' +
                ", supNo='" + supNo + '\'' +
                ", supName='" + supName + '\'' +
                ", contactPeople='" + contactPeople + '\'' +
                ", phone='" + phone + '\'' +
                ", remarks='" + remarks + '\'' +
                ", localtion='" + localtion + '\'' +
                ", delFlag=" + delFlag +
                ", appId='" + appId + '\'' +
                ", appSecret='" + appSecret + '\'' +
                ", appUrl='" + appUrl + '\'' +
                ", userName='" + userName + '\'' +
                '}';
    }
}
