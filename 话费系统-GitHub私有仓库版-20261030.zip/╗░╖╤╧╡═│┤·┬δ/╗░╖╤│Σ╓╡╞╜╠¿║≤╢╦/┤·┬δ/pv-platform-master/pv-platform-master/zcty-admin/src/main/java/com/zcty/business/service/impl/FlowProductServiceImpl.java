package com.zcty.business.service.impl;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.zcty.business.domain.ActivityProduct;
import com.zcty.business.service.IActivityProductService;
import com.zcty.business.service.NumberService;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.utils.DateUtils;
import com.zcty.common.utils.StringUtils;
import com.zcty.web.utlis.IdGen;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zcty.business.mapper.FlowProductMapper;
import com.zcty.business.domain.FlowProduct;
import com.zcty.business.service.IFlowProductService;

/**
 * 流量商品Service业务层处理
 * 
 * @author lsw
 * @date 2024-03-20
 */
@Service
public class FlowProductServiceImpl implements IFlowProductService 
{
    @Autowired
    private FlowProductMapper flowProductMapper;
    @Autowired
    private NumberService numberService;
    @Autowired
    private IActivityProductService activityProductService;

    /**
     * 查询流量商品
     * 
     * @param id 流量商品主键
     * @return 流量商品
     */
    @Override
    public FlowProduct selectFlowProductById(String id)
    {
        return flowProductMapper.selectFlowProductById(id);
    }

    /**
     * 查询流量商品列表
     * 
     * @param flowProduct 流量商品
     * @return 流量商品
     */
    @Override
    public List<FlowProduct> selectFlowProductList(FlowProduct flowProduct)
    {
        return flowProductMapper.selectFlowProductList(flowProduct);
    }

    /**
     * 新增流量商品
     * 
     * @param product 流量商品
     * @return 结果
     */
    @Override
    public AjaxResult insertFlowProduct(FlowProduct product)
    {

        //判断数据空值问题
        if(product==null){
            return  AjaxResult.error("未找到操作数据");
        }

        //先对必填项进行校验
        //商品名称
        String productName=product.getProductName();
        if(StringUtils.isEmpty(productName)){
            return AjaxResult.error("请输入项目名称");
        }
        //排序
        Integer orderBy=product.getOrderBy();
        if(orderBy==null){
            return  AjaxResult.error("请填写排序号");
        }
        //初始销售数量
        Integer salesTotal=product.getSalesTotal();
        if(salesTotal==null){
            return  AjaxResult.error("请填写初始销售数量");
        }
        //单价
        BigDecimal price=product.getPrice();
        if(price==null||price.compareTo(BigDecimal.ZERO)<=0){
            return AjaxResult.error("请填写项目价格，请金额大于0");
        }

        //平台商品信息
        ActivityProduct activityProduct= activityProductService.selectActivityProductById(product.getActivityProductId());
        if(activityProduct == null){
            return AjaxResult.error("请绑定充值业务");
        }
        product.setActivityDescribes(activityProduct.getActivityDescribes());
        product.setActivityid(activityProduct.getActivityid());
        product.setCity(activityProduct.getCity());
        product.setProvince(activityProduct.getProvince());
        product.setPlatformInfosId(activityProduct.getPlatformInfosId());
        product.setActivityProductId(activityProduct.getId());
        product.setYys(activityProduct.getYys());


        product.setCreateTime(DateUtils.getNowDate());


        //获取流量商品编号
        String busNo=numberService.getLLNumber();
        //自动填写必要的数据,主键id，创建时间
        String id= IdGen.uuid();
        Date date=new Date();

        product.setId(id);
        product.setCreateTime(date);
        product.setUpdateTime(date);
        product.setDelFlag(0);
        product.setProductNo(busNo);

        //更新编号
        numberService.updateNumber(busNo);

        int i =flowProductMapper.insertFlowProduct(product);

        return AjaxResult.switchOne(i);

    }

    /**
     * 修改流量商品
     * 
     * @param product 流量商品
     * @return 结果
     */
    @Override
    public AjaxResult updateFlowProduct(FlowProduct product)
    {
        //判断数据空值问题
        if(product==null){
            return  AjaxResult.error("未找到操作数据");
        }
        //判断ID信息
        String id=product.getId();
        if(StringUtils.isEmpty(id)){
            return AjaxResult.error("未找到编辑的项目Id信息");
        }

        //先对必填项进行校验
        //商品名称
        String productName=product.getProductName();
        if(StringUtils.isEmpty(productName)){
            return AjaxResult.error("请输入项目名称");
        }
        //排序
        Integer orderBy=product.getOrderBy();
        if(orderBy==null){
            return  AjaxResult.error("请填写排序号");
        }
        //单价
        BigDecimal price=product.getPrice();
        if(price==null&&price.compareTo(BigDecimal.ZERO)<=0){
            return AjaxResult.error("请填写项目价格，请金额大于0");
        }

        //初始销售数量
        Integer salesTotal=product.getSalesTotal();
        if(salesTotal==null){
            return  AjaxResult.error("请填写初始销售数量");
        }
        //平台商品信息
        ActivityProduct activityProduct= activityProductService.selectActivityProductById(product.getActivityProductId());
        if(activityProduct == null){
            return AjaxResult.error("请绑定充值业务");
        }
        product.setActivityDescribes(activityProduct.getActivityDescribes());
        product.setActivityid(activityProduct.getActivityid());
        product.setCity(activityProduct.getCity());
        product.setProvince(activityProduct.getProvince());
        product.setPlatformInfosId(activityProduct.getPlatformInfosId());
        product.setActivityProductId(activityProduct.getId());


        product.setYys(activityProduct.getYys());

        product.setUpdateTime(DateUtils.getNowDate());
        int i =flowProductMapper.updateFlowProduct(product);
        return AjaxResult.switchOne(i);

    }

    /**
     * 批量删除流量商品
     * 
     * @param ids 需要删除的流量商品主键
     * @return 结果
     */
    @Override
    public int deleteFlowProductByIds(String[] ids)
    {
        return flowProductMapper.deleteFlowProductByIds(ids);
    }

    /**
     * 删除流量商品信息
     * 
     * @param id 流量商品主键
     * @return 结果
     */
    @Override
    public int deleteFlowProductById(String id)
    {
        return flowProductMapper.deleteFlowProductById(id);
    }

    /**
     * 添加销量
     * @return
     */
    @Override
    public int addSales(String commonId, Integer num) {
        FlowProduct goodsCommon = flowProductMapper.selectFlowProductById(commonId);
        goodsCommon.setUpdateTime(new Date());
        goodsCommon.setSalesTotal(num);
        return flowProductMapper.addSales(goodsCommon);
    }

    @Override
    public AjaxResult updateFlowProductStatus(FlowProduct flowProduct) {
        return AjaxResult.switchOne(flowProductMapper.updateFlowProductStatus(flowProduct));
    }
}
