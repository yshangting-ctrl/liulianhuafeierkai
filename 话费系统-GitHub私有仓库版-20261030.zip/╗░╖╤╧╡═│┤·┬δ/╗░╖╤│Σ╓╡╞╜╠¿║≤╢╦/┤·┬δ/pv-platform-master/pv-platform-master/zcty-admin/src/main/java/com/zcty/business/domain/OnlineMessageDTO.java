package com.zcty.business.domain;

import com.zcty.common.exception.base.BaseException;
import org.apache.commons.lang3.StringUtils;

/**
 * 在线留言表 t_online_message
 * 
 * @author liuruibin
 * @date 2022-11-28
 */
public class OnlineMessageDTO
{

	/** 留言内容 富文本 */
	private String imageText;

	/** 微信号 */
	private String contacts;
	/** 联系电话 */
	private String contactNumber;

	/** 订单号 */
	private String orderNo;
	/** 产品名称 */
	private String productName;

	public String getImageText() {
		return imageText;
	}

	public void setImageText(String imageText) {
		this.imageText = imageText;
	}

	public String getContacts() {
		return contacts;
	}

	public void setContacts(String contacts) {
		this.contacts = contacts;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public void checkParams(){
		if (StringUtils.isEmpty(imageText)){
			throw new BaseException("请填留言内容！");
		}
	}
}
