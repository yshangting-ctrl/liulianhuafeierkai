package com.zcty.business.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.zcty.common.annotation.Excel;
import org.springframework.format.annotation.DateTimeFormat;


/**
 * 流量商品对象 t_flow_product
 * 
 * @author lsw
 * @date 2024-03-20
 */
public class FlowProduct implements Serializable
{
    private static final long serialVersionUID = 1L;

    /** 主键id */
    private String id;

    /** 流量商品名称 */
    @Excel(name = "流量商品名称")
    private String productName;

    /** 流量商品副名称 */
    @Excel(name = "流量商品副名称")
    private String productSname;

    /** 单价 */
    @Excel(name = "单价")
    private BigDecimal price;

    /** 排序号码 */
    @Excel(name = "排序号码")
    private Integer orderBy;

    /** 流量商品标签 */
    @Excel(name = "流量商品标签")
    private String productTitle;

    /** 删除标识 0 未删除 1已删除 */
    private Integer delFlag;

    /** 上架状态 0下架 1上架 */
    @Excel(name = "上架状态 0下架 1上架")
    private Integer status;

    /** 项目编号 */
    @Excel(name = "项目编号")
    private String productNo;

    /** 初始销售数量 */
    @Excel(name = "初始销售数量")
    private Integer salesTotal;

    /** 创建时间 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;

    /** 更新时间 */
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss" ,  timezone="GMT+8")
    private Date updateTime;

    /** 备注 */
    private String remark;


    /**  运营商  1 、移动 2、联通 3、电信 */
    @Excel(name = " 运营商  1 、移动 2、联通 3、电信")
    private Integer yys;

    /** 省份 */
    @Excel(name = "省份")
    private Integer province;

    /** 城市 */
    @Excel(name = "城市")
    private Integer city;

    /** 业务商品描述 */
    @Excel(name = "业务商品描述")
    private String activityDescribes;

    /**
     * 平台id
     */
    private String platformInfosId;


    /** 业务产品id */
    @Excel(name = "业务id")
    private String activityProductId;

    /** 业务id */
    @Excel(name = "业务id")
    private String activityid;

    private String platformName;



    public void setId(String id) 
    {
        this.id = id;
    }

    public String getId() 
    {
        return id;
    }
    public void setProductName(String productName) 
    {
        this.productName = productName;
    }

    public String getProductName() 
    {
        return productName;
    }
    public void setProductSname(String productSname) 
    {
        this.productSname = productSname;
    }

    public String getProductSname() 
    {
        return productSname;
    }
    public void setPrice(BigDecimal price) 
    {
        this.price = price;
    }

    public BigDecimal getPrice() 
    {
        return price;
    }
    public void setOrderBy(Integer orderBy) 
    {
        this.orderBy = orderBy;
    }

    public Integer getOrderBy() 
    {
        return orderBy;
    }
    public void setProductTitle(String productTitle) 
    {
        this.productTitle = productTitle;
    }

    public String getProductTitle() 
    {
        return productTitle;
    }
    public void setDelFlag(Integer delFlag) 
    {
        this.delFlag = delFlag;
    }

    public Integer getDelFlag() 
    {
        return delFlag;
    }
    public void setStatus(Integer status) 
    {
        this.status = status;
    }

    public Integer getStatus() 
    {
        return status;
    }
    public void setProductNo(String productNo) 
    {
        this.productNo = productNo;
    }

    public String getProductNo() 
    {
        return productNo;
    }
    public void setSalesTotal(Integer salesTotal) 
    {
        this.salesTotal = salesTotal;
    }

    public Integer getSalesTotal() 
    {
        return salesTotal;
    }


    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Integer getYys() {
        return yys;
    }

    public void setYys(Integer yys) {
        this.yys = yys;
    }

    public Integer getProvince() {
        return province;
    }

    public void setProvince(Integer province) {
        this.province = province;
    }

    public Integer getCity() {
        return city;
    }

    public void setCity(Integer city) {
        this.city = city;
    }

    public String getActivityDescribes() {
        return activityDescribes;
    }

    public void setActivityDescribes(String activityDescribes) {
        this.activityDescribes = activityDescribes;
    }

    public String getActivityProductId() {
        return activityProductId;
    }

    public void setActivityProductId(String activityProductId) {
        this.activityProductId = activityProductId;
    }

    public String getActivityid() {
        return activityid;
    }

    public void setActivityid(String activityid) {
        this.activityid = activityid;
    }

    public String getPlatformInfosId() {
        return platformInfosId;
    }

    public void setPlatformInfosId(String platformInfosId) {
        this.platformInfosId = platformInfosId;
    }

    public String getPlatformName() {
        return platformName;
    }

    public void setPlatformName(String platformName) {
        this.platformName = platformName;
    }
}
