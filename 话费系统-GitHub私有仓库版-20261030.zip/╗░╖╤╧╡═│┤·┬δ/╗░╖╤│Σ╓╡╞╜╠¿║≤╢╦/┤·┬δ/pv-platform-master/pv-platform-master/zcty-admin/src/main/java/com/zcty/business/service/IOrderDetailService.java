package com.zcty.business.service;



import com.zcty.business.domain.OrderDetail;

import java.util.List;

/**
 * 订单详情 服务层
 * 
 * @author liuruibin
 * @date 2022-07-25
 */
public interface IOrderDetailService
{
	
	/**
     * 查询订单详情列表
     * 
     * @param orderDetail 订单详情信息
     * @return 订单详情集合
     */
	public List<OrderDetail> selectOrderDetailList(OrderDetail orderDetail);
	/**
	 * 新增订单详情
	 *
	 * @param orderDetailList 订单详情信息
	 * @return 结果
	 */
	public int insertOrderDetailList(List<OrderDetail> orderDetailList);
	
}
