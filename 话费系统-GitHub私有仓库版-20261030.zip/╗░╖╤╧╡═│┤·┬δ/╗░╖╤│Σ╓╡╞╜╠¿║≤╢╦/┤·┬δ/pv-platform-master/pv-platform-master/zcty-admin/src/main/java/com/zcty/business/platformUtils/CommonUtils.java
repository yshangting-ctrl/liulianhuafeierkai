package com.zcty.business.platformUtils;

import org.apache.http.HttpResponse;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;

import java.security.MessageDigest;
import java.util.UUID;

/**
 * 常用工具类的封装，md5,uuid等
 */
public class CommonUtils {


    /**
     * 生成 uuid， 即用来标识一笔单，也用做 nonce_str
     * @return
     */
    public static String generateUUID(){
        String uuid = UUID.randomUUID().toString().
                replaceAll("-","").substring(0,32);

        return uuid;
    }


    /**
     * md5常用工具类
     * @param data
     * @return
     */
    public static String MD5(String data){
        try {

            MessageDigest md5 = MessageDigest.getInstance("MD5");
            byte [] array = md5.digest(data.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte item : array) {
                sb.append(Integer.toHexString((item & 0xFF) | 0x100).substring(1, 3));
            }
            return sb.toString();

        }catch (Exception e){
            e.printStackTrace();
        }
        return null;

    }

    public static String sendPostBusiness(String url , String param, CloseableHttpClient httpClient){


        int timeout =5000;

        try {
            //超时设置

            RequestConfig requestConfig =  RequestConfig.custom().setConnectTimeout(timeout) //连接超时
                    .setConnectionRequestTimeout(timeout)//请求超时
                    .setSocketTimeout(timeout)
                    .setRedirectsEnabled(true)  //允许自动重定向
                    .build();

            HttpPost httpPost = new HttpPost(url);

            StringEntity stringEntity = new StringEntity(param);

            httpPost.setHeader("Content-Type","application/x-www-form-urlencoded");
            httpPost.setConfig(requestConfig);
            httpPost.setEntity(stringEntity);

            HttpResponse httpResponse = httpClient.execute(httpPost);

            String result = EntityUtils.toString(httpResponse.getEntity(), "UTF-8");

            return result;

        }catch (Exception e){
            e.printStackTrace();
            return null;
        }

    }


}
