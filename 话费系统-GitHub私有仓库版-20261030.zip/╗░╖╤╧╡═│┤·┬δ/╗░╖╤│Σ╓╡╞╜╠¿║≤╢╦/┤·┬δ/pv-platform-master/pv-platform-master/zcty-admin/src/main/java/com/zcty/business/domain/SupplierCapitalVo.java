package com.zcty.business.domain;

import java.io.Serializable;
import java.math.BigDecimal;

public class SupplierCapitalVo implements Serializable {

    /** 主键id */
    private String id;

    /** 代理商编号 */
    private String supNo;

    /** 代理商名称 */
    private String supName;

    /** 资金总数 */
    private BigDecimal capitalTotal;



    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSupNo() {
        return supNo;
    }

    public void setSupNo(String supNo) {
        this.supNo = supNo;
    }

    public String getSupName() {
        return supName;
    }

    public void setSupName(String supName) {
        this.supName = supName;
    }

    public BigDecimal getCapitalTotal() {
        return capitalTotal;
    }

    public void setCapitalTotal(BigDecimal capitalTotal) {
        this.capitalTotal = capitalTotal;
    }
}
