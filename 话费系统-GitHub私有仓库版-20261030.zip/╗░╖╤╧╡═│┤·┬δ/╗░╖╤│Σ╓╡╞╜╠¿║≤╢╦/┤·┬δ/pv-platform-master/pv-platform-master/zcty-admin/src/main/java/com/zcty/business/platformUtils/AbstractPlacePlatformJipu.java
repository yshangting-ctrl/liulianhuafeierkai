package com.zcty.business.platformUtils;

import com.alibaba.fastjson2.JSONObject;
import com.zcty.business.domain.ActivityProduct;
import com.zcty.business.domain.Order;
import com.zcty.business.domain.OrderSendProduct;
import com.zcty.business.domain.PlatformInfos;
import com.zcty.business.service.IActivityProductService;
import com.zcty.business.service.IPlatformInfosService;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.utils.StringUtils;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;

@Component
@Service
public class AbstractPlacePlatformJipu extends AbstractPlacePlatformBusiness {

    public static String keyWord = "jipu";

    public static String createOrder =  "/act/api/linkapi/createOrder";

    public static String sendFirstCode  =  "/act/api/linkapi/sendFirstCode";

    public static String submitFirstCode  =  "/act/api/linkapi/submitFirstCode";

    public static String ip = "120.25.74.61";




    @Autowired
    private IPlatformInfosService platformInfosService;

    @Autowired
    private IActivityProductService activityProductService;


    @Override
    public AjaxResult createPlatformBusiness(String activityProductId,String phone,String orderNo) {
        //数据校验
        PlatformInfos platformInfos = platformInfosService.selectPlatformInfosByKeyWord(keyWord);

        //平台校验，用于获取当前平台的token，和secreat
        if(platformInfos == null){
            return AjaxResult.error("充值平台设置一次，未找到jipu平台信息");
        }
        System.out.println("-------platformInfos-----------"+platformInfos.toString());
        String url = platformInfos.getPlaformUrl();
        if(StringUtils.isEmpty(url) ){
            return AjaxResult.error("充值平台未设置访问地址");
        }
        String token = platformInfos.getUserToken();
        String secret = platformInfos.getUserSecrect();

        ActivityProduct activityProduct = activityProductService.selectActivityProductById(activityProductId);

        if(activityProduct == null ){
            return AjaxResult.error("未找到充值商品业务信息");
        }

        String activityId = activityProduct.getActivityid();
        System.out.println("-------activityProduct-----------"+activityProduct.toString());

//        String activityid = activityProduct.getActivityid();

        if(StringUtils.isEmpty(activityId) ){
            return AjaxResult.error("充值商品业务未设置业务id");
        }

        Integer smscodenum= activityProduct.getSmscodenum();

        if(smscodenum==null){
            return AjaxResult.error("未设置验证次数");
        }

        if(!smscodenum.equals(1)&&!smscodenum.equals(2)){
            return AjaxResult.error("设置验证次数错误");
        }


        //做字典排序和md5加密
        //sign签名方法
        ///**
        // * @function sign签名方法
        // * @param arr {Array} 接口需要的加密参数数组
        // * @returns
        // */
        //        function getSign(arr) {
        //                //1）将提交的参数进行字典序排序
        //                arr.sort();
        //
        //        //2）将排序后的参数拼接成一个字符串进行md5加密
        //        var arrJoinString = arr.join('');
        //        return md5(arrJoinString);
        //}

         //示例:创建订单(createOrder) 接口 sign 计算方法

         //根据文档 获取 createOrder 接口 sign 加密的参数
       //32位数据签名(secrect,token,activity,[outorderno])   outorderno为可选参数

        //模拟参数的值:
        //        var secrect = "ul890768" //32位
        //        var token = "85liyudj" //32位 用户Token
        // Activity example removed from repository package.
        //        var outorderno = "lk987893" //外部订单号  可以为空
        //
        //        function getCreateOrder() {
        //            //将需要的参数存入一个数组中
        //            var arr = [secrect, token, outorderno, activity]
        //            //调用 getSign 获取sign
        //            var sign = getSign(arr)
        //            return sign;
        //        }


        List<String> list = new ArrayList<>();
        list.add(secret);
        list.add(token);
        list.add(activityId);
        list.add(orderNo);

        String sign = DictSortUtils.dictSort(list);
        sign =  CommonUtils.MD5(sign);

        System.out.println("----------activityId------"+activityId);
        System.out.println("----------phone------"+phone);
        System.out.println("----------orderNo------"+orderNo);
        System.out.println("----------token------"+token);
        System.out.println("----------secret------"+secret);
        System.out.println("----------sign------"+sign);

        //生成订单
        CloseableHttpClient httpClient = null;

        System.out.println(orderNo + "：第三方充值平台订单下单开始");

        try {
            //http客户端创建
            httpClient = HttpClients.createDefault();
            //第一步创建平台订单
            String createOrderUrl = url + createOrder;
            //平台订单参数
            String param1 = "activity="+activityId+"&token="+token+"&outorderno="+orderNo+"&sign="+sign;
            //回调结果{"code":1,"msg":"创建订单成功","data":"WRFPJ0A38WTO15UK"}
            String result = CommonUtils.sendPostBusiness(createOrderUrl,param1,httpClient);
            System.out.println(result);
            //json数据处理
            JSONObject jsonObject = JSONObject.parseObject(result);
            System.out.println(jsonObject);
            //业务结果校验
            String code = jsonObject.getString("code");
            System.out.println("---------------code-------"+code);
            if(StringUtils.isEmpty(code)){
                System.out.println("code值为空，请检查code");
                AjaxResult.error("code值为空，请检查code");
            }

            if(!code.equals("1")){
                System.out.println("code值校验异常");
                AjaxResult.error("code值校验异常");
            }
            String orderId = jsonObject.getString("data");

            System.out.println("---------------orderId-------"+orderId);

            if(StringUtils.isEmpty(orderId)){
                System.out.println("订单号生产失败");
                return AjaxResult.error("订单号生产失败");
            }

            //第二步获取验证码
            String sendFirstCodeUrl = url +sendFirstCode;
            //获取第一个验证码参数
            String param2 = "phone="+phone+"&orderid="+orderId+"&outorderno="+orderNo;
            //访问线上接口
            String resultSendFirst = CommonUtils.sendPostBusiness(sendFirstCodeUrl,param2,httpClient);

            System.out.println(resultSendFirst);
            //第二步获取验证码数据处理
            JSONObject jsonObjectSendFirst = JSONObject.parseObject(resultSendFirst);

            System.out.println(jsonObjectSendFirst);

            String codeSendFirst = jsonObjectSendFirst.getString("code");

            System.out.println("---------------codeSendFirst-------"+codeSendFirst);

            String smscode = jsonObjectSendFirst.getString("data");

            System.out.println("---------------smscode-------"+smscode);

            if(StringUtils.isEmpty(codeSendFirst)){
                System.out.println("codeSendFirst值为空，请检查codeSendFirst");
                return AjaxResult.error("codeSendFirst值为空，请检查codeSendFirst");
            }

            if(!codeSendFirst.equals("1")){
                System.out.println("codeSendFirst值校验异常");
                return AjaxResult.error("codeSendFirst值校验异常");
            }


            //第三步：提交第一次的验证码
            String submitFirstCodeUrl = url + submitFirstCode;
            //提交第一次的验证码参数
            String param3 = "phone="+phone+"&smscode="+smscode+"&orderid="+orderId+"&outorderno="+orderNo;

            String resultSubmitFirstCode = CommonUtils.sendPostBusiness(submitFirstCodeUrl,param3,httpClient);
            System.out.println("------------resultSubmitFirstCode--------"+resultSubmitFirstCode);
            //回调处理
            JSONObject jsonObjectSubmitFirstCode = JSONObject.parseObject(resultSubmitFirstCode);

            System.out.println(jsonObjectSubmitFirstCode);

            String codeSubmitFirstCode = jsonObjectSubmitFirstCode.getString("code");

            System.out.println("---------------codeSubmitFirstCode-------"+codeSubmitFirstCode);


            if(StringUtils.isEmpty(codeSubmitFirstCode)){
                System.out.println("codeSubmitFirstCode值为空，请检查codeSubmitFirstCode");
                return AjaxResult.error("codeSubmitFirstCode值为空，请检查codeSubmitFirstCode\"");
            }

            if(!codeSubmitFirstCode.equals("1")){
                System.out.println("codeSubmitFirstCode值校验异常");
                return AjaxResult.error("codeSubmitFirstCode值校验异常");
            }


        }catch (Exception e){
            e.printStackTrace();
            return AjaxResult.error("业务处理失败");
        }


        return AjaxResult.success();
    }

    @Override
    public AjaxResult sendFirstSmsCode(String activityProductId, String phone, String orderNo, String third_order_no, Order order) {
        return null;
    }

    public static void main(String[] args) {

        String secret = System.getenv().getOrDefault("JIPU_API_SECRET", "");
        String token = System.getenv().getOrDefault("JIPU_API_TOKEN", "");
        String activityId = System.getenv().getOrDefault("JIPU_ACTIVITY_ID", "");
        String orderNo =  "OD202007051103123456";
        String phone = "13527729761";
        List<String> list = new ArrayList<>();
        list.add(secret);
        list.add(token);
        list.add(activityId);
        list.add(orderNo);
        String sign = DictSortUtils.dictSort(list);
        sign =  CommonUtils.MD5(sign);
        System.out.println(sign);
//        sign =  CommonUtils.MD5(sign);
//        System.out.println(sign);
        String url = "http://www.jipu.ltd:8000";

        if (true){
            return;
        }

        //生成订单
        CloseableHttpClient httpClient ;

        System.out.println(orderNo + "：第三方充值平台订单下单开始");


        try {
            //http客户端创建
            httpClient = HttpClients.createDefault();

//            HttpPost httpPost = new HttpPost(createOrderUrl);

            String createOrderUrl = url + createOrder;
            String param1 = "activity="+activityId+"&token="+token+"&outorderno="+orderNo+"&sign="+sign;

//            StringEntity stringEntity = new StringEntity(param1);

//            httpPost.setEntity(stringEntity);

//            HttpResponse httpResponse = httpClient.execute(httpPost);
            //回调结果{"code":1,"msg":"创建订单成功","data":"WRFPJ0A38WTO15UK"}
            String result = CommonUtils.sendPostBusiness(createOrderUrl,param1,httpClient);
//                    EntityUtils.toString(httpResponse.getEntity(), "UTF-8");

            System.out.println(result);

            JSONObject jsonObject = JSONObject.parseObject(result);

            System.out.println(jsonObject);

            String code = jsonObject.getString("code");


            System.out.println("---------------code-------"+code);

            if(StringUtils.isEmpty(code)){
                System.out.println("code值为空，请检查code");
                return;
            }

            if(!code.equals("1")){
                System.out.println("code值校验异常");
                return;
            }

            String orderId = jsonObject.getString("data");

            System.out.println("---------------orderId-------"+orderId);

            if(StringUtils.isEmpty(orderId)){
                System.out.println("订单号生产失败");
                return;
            }

            //获取验证码
            String sendFirstCodeUrl = url +sendFirstCode;

//            HttpPost sendFirsthttpPost = new HttpPost(sendFirstCodeUrl);

            String param2 = "phone="+phone+"&orderid="+orderId+"&outorderno="+orderNo;

//            StringEntity stringEntitySendFirst = new StringEntity(param2);

//            sendFirsthttpPost.setEntity(stringEntitySendFirst);

//            HttpResponse httpResponseSendFirst = httpClient.execute(sendFirsthttpPost);

            String resultSendFirst = CommonUtils.sendPostBusiness(sendFirstCodeUrl,param2,httpClient);
//                    EntityUtils.toString(httpResponseSendFirst.getEntity(), "UTF-8");
            //回调结果{"code":1,"message":"获取验证码成功","data":{"reg1":"^\\d{4}$"},"data2":null}
            System.out.println(resultSendFirst);

            JSONObject jsonObjectSendFirst = JSONObject.parseObject(resultSendFirst);

            System.out.println(jsonObjectSendFirst);

            String codeSendFirst = jsonObjectSendFirst.getString("code");

            System.out.println("---------------codeSendFirst-------"+codeSendFirst);

            String smscode = jsonObjectSendFirst.getString("data");

            System.out.println("---------------smscode-------"+smscode);

            if(StringUtils.isEmpty(codeSendFirst)){
                System.out.println("codeSendFirst值为空，请检查codeSendFirst");
                return;
            }

            if(!codeSendFirst.equals("1")){
                System.out.println("codeSendFirst值校验异常");
                return;
            }

            //提交第一次的验证码
            String submitFirstCodeUrl = url + submitFirstCode;

//            HttpPost submitFirstCodehttpPost = new HttpPost(submitFirstCodeUrl);

            String param3 = "phone="+phone+"&smscode="+smscode+"&orderid="+orderId+"&outorderno="+orderNo;

//            StringEntity stringEntitySubmitFirstCode = new StringEntity(param3);

//            submitFirstCodehttpPost.setEntity(stringEntitySubmitFirstCode);

//            HttpResponse resultSubmithttpResponse = httpClient.execute(submitFirstCodehttpPost);

            String resultSubmitFirstCode = CommonUtils.sendPostBusiness(submitFirstCodeUrl,param3,httpClient);
//                    EntityUtils.toString(resultSubmithttpResponse.getEntity(), "UTF-8");

            //回调处理
            JSONObject jsonObjectSubmitFirstCode = JSONObject.parseObject(resultSubmitFirstCode);

            System.out.println(jsonObjectSubmitFirstCode);

            String codeSubmitFirstCode = jsonObjectSubmitFirstCode.getString("code");

            System.out.println("---------------codeSubmitFirstCode-------"+codeSubmitFirstCode);


            if(StringUtils.isEmpty(codeSubmitFirstCode)){
                System.out.println("codeSubmitFirstCode值为空，请检查codeSubmitFirstCode");
                return;
            }

            if(!codeSubmitFirstCode.equals("1")){
                System.out.println("codeSubmitFirstCode值校验异常");
                return;
            }



        }catch (Exception e){
            e.printStackTrace();

        }

    }

//
//    public static String sendPostBusiness(String url , String param, CloseableHttpClient httpClient){
//
//
//        int timeout =5000;
//
//        try {
//            //超时设置
//
//            RequestConfig requestConfig =  RequestConfig.custom().setConnectTimeout(timeout) //连接超时
//                    .setConnectionRequestTimeout(timeout)//请求超时
//                    .setSocketTimeout(timeout)
//                    .setRedirectsEnabled(true)  //允许自动重定向
//                    .build();
//
//            HttpPost httpPost = new HttpPost(url);
//
//            StringEntity stringEntity = new StringEntity(param);
//
//            httpPost.setHeader("Content-Type","application/x-www-form-urlencoded");
//            httpPost.setConfig(requestConfig);
//            httpPost.setEntity(stringEntity);
//
//            HttpResponse httpResponse = httpClient.execute(httpPost);
//
//            String result = EntityUtils.toString(httpResponse.getEntity(), "UTF-8");
//
//            return result;
//
//        }catch (Exception e){
//            e.printStackTrace();
//            return null;
//        }
//
//    }


    @Override
    public AjaxResult submitFirstSmsCode(PlatformInfos platformInfos, OrderSendProduct orderSendProduct,  ActivityProduct activityProduct ,String smsCode, String phone, String third_order_no, Order order) {
        return null;
    }

    @Override
    public AjaxResult getPreSmsCode(String activityProductId, String phone, String orderNo, String third_order_no, Order order) {
        return null;
    }

    @Override
    public AjaxResult submitPreSmsCode(PlatformInfos platformInfos, OrderSendProduct orderSendProduct, ActivityProduct activityProduct, String smsCode, String phone, String third_order_no, Order order) {
        return null;
    }
}
