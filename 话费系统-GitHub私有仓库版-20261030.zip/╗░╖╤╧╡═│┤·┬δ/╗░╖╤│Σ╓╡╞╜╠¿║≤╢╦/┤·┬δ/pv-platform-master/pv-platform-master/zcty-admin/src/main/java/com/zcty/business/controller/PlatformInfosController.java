package com.zcty.business.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.zcty.common.annotation.Log;
import com.zcty.common.core.controller.BaseController;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.enums.BusinessType;
import com.zcty.business.domain.PlatformInfos;
import com.zcty.business.service.IPlatformInfosService;
import com.zcty.common.core.page.TableDataInfo;

/**
 * 第三方充值平台管理Controller
 * 
 * @author lsw
 * @date 2024-06-29
 */
@RestController
@RequestMapping("/business/platformInfos")
public class PlatformInfosController extends BaseController
{
    @Autowired
    private IPlatformInfosService platformInfosService;

    /**
     * 查询第三方充值平台管理列表
     */
    @PreAuthorize("@ss.hasPermi('business:platformInfos:list')")
    @GetMapping("/list")
    public TableDataInfo list(PlatformInfos platformInfos)
    {
        startPage();
        List<PlatformInfos> list = platformInfosService.selectPlatformInfosList(platformInfos);
        return getDataTable(list);
    }


    /**
     * 查询第三方充值平台管理列表
     */
    @PostMapping("/selectList")
    public AjaxResult selectList()
    {
        PlatformInfos platformInfos =new PlatformInfos();
        List<PlatformInfos> list = platformInfosService.selectPlatformInfosList(platformInfos);
        return AjaxResult.success(list);
    }


    /**
     * 获取第三方充值平台管理详细信息
     */
    @PreAuthorize("@ss.hasPermi('business:platformInfos:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") String id)
    {
        return success(platformInfosService.selectPlatformInfosById(id));
    }

    /**
     * 新增第三方充值平台管理
     */
    @PreAuthorize("@ss.hasPermi('business:platformInfos:add')")
    @Log(title = "第三方充值平台管理", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody PlatformInfos platformInfos)
    {
        return toAjax(platformInfosService.insertPlatformInfos(platformInfos));
    }

    /**
     * 修改第三方充值平台管理
     */
    @PreAuthorize("@ss.hasPermi('business:platformInfos:edit')")
    @Log(title = "第三方充值平台管理", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody PlatformInfos platformInfos)
    {
        return toAjax(platformInfosService.updatePlatformInfos(platformInfos));
    }

    /**
     * 删除第三方充值平台管理
     */
    @PreAuthorize("@ss.hasPermi('business:platformInfos:remove')")
    @Log(title = "第三方充值平台管理", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable String[] ids)
    {
        return toAjax(platformInfosService.deletePlatformInfosByIds(ids));
    }
}
