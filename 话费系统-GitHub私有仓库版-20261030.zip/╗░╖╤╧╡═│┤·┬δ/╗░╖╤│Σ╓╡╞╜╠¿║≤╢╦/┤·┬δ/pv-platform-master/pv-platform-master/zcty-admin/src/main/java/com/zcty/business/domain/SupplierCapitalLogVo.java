package com.zcty.business.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 资金变更记录前端显示类
 */
public class SupplierCapitalLogVo implements Serializable {

    /** 主键id */
    private String id;

    /** 代理商编号 */
    private String supNo;

    /** 代理商名称 */
    private String supName;

    /** 资金记录类型， 1 增加 2减少 */
    private Integer capitalType;

    /** 资金数量 */
    private BigDecimal capitalTotal;

    /** 原资金 */
    private  BigDecimal oldTotal;
    /** 变动后资金 */
    private  BigDecimal newTotal;

    private Date createTime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSupNo() {
        return supNo;
    }

    public void setSupNo(String supNo) {
        this.supNo = supNo;
    }

    public String getSupName() {
        return supName;
    }

    public void setSupName(String supName) {
        this.supName = supName;
    }

    public Integer getCapitalType() {
        return capitalType;
    }

    public void setCapitalType(Integer capitalType) {
        this.capitalType = capitalType;
    }

    public BigDecimal getCapitalTotal() {
        return capitalTotal;
    }

    public void setCapitalTotal(BigDecimal capitalTotal) {
        this.capitalTotal = capitalTotal;
    }

    public BigDecimal getOldTotal() {
        return oldTotal;
    }

    public void setOldTotal(BigDecimal oldTotal) {
        this.oldTotal = oldTotal;
    }

    public BigDecimal getNewTotal() {
        return newTotal;
    }

    public void setNewTotal(BigDecimal newTotal) {
        this.newTotal = newTotal;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}
