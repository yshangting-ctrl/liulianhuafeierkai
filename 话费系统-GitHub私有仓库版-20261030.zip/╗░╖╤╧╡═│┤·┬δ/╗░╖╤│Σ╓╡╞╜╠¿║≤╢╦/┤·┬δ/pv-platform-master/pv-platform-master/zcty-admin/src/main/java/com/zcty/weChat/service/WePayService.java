package com.zcty.weChat.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 支付回调的接口
 */
public interface WePayService {


    /**
     * 支付异步回调处理
     * @param response
     * @param request
     * @return
     */
    String payNotifyUrl(HttpServletResponse response, HttpServletRequest request,String supplierId);
//
//    /**
//     * 退款异步回调处理
//     * @param response
//     * @param request
//     * @return
//     */
//    String refundNotifyUrl(HttpServletResponse response, HttpServletRequest request);

}
