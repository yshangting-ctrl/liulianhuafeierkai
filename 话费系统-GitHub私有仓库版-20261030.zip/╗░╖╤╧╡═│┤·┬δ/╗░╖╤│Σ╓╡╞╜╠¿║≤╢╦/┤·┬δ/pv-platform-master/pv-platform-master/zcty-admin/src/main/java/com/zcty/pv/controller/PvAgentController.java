package com.zcty.pv.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.zcty.common.constant.UserConstants;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.zcty.common.annotation.Log;
import com.zcty.common.core.controller.BaseController;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.enums.BusinessType;
import com.zcty.pv.domain.PvAgent;
import com.zcty.pv.service.IPvAgentService;
import com.zcty.common.utils.poi.ExcelUtil;
import com.zcty.common.core.page.TableDataInfo;

/**
 * 代理商Controller
 * 
 * @author luohui
 * @date 2022-11-20
 */
@Api(tags = "代理商管理")
@RestController
@RequestMapping("/pv/agent")
public class PvAgentController extends BaseController
{
    @Autowired
    private IPvAgentService pvAgentService;

    /**
     * 查询代理商列表
     */
    @ApiOperation("查询代理商列表")
    @PreAuthorize("@ss.hasPermi('pv:agent:list')")
    @GetMapping("/list")
    public TableDataInfo list(PvAgent pvAgent)
    {
        startPage();
        List<PvAgent> list = pvAgentService.selectPvAgentList(pvAgent);
        return getDataTable(list);
    }

    /**
     * 导出代理商列表
     */
    @ApiOperation("导出代理商列表")
    @PreAuthorize("@ss.hasPermi('pv:agent:export')")
    @Log(title = "代理商", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, PvAgent pvAgent)
    {
        List<PvAgent> list = pvAgentService.selectPvAgentList(pvAgent);
        ExcelUtil<PvAgent> util = new ExcelUtil<PvAgent>(PvAgent.class);
        util.exportExcel(response, list, "代理商数据");
    }

    /**
     * 获取代理商详细信息
     */
    @ApiOperation("获取代理商详细信息")
    @PreAuthorize("@ss.hasPermi('pv:agent:query')")
    @GetMapping(value = "/{agentId}")
    public AjaxResult getInfo(@PathVariable("agentId") Long agentId)
    {
        PvAgent pvAgent = pvAgentService.selectPvAgentByAgentId(agentId);
        return success(pvAgent);
    }

    /**
     * 新增代理商
     */
    @ApiOperation("新增代理商")
    @PreAuthorize("@ss.hasPermi('pv:agent:add')")
    @Log(title = "代理商", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody PvAgent pvAgent)
    {
        if (UserConstants.NOT_UNIQUE.equals(pvAgentService.checkAgentNameUnique(pvAgent)))
        {
            return error("新增代理商'" + pvAgent.getAgentName() + "'失败，代理商名称已存在");
        }
        pvAgent.setCreateBy(getNickname());
        return toAjax(pvAgentService.insertPvAgent(pvAgent));
    }

    /**
     * 修改代理商
     */
    @ApiOperation("修改代理商")
    @PreAuthorize("@ss.hasPermi('pv:agent:edit')")
    @Log(title = "代理商", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody PvAgent pvAgent)
    {
        if (UserConstants.NOT_UNIQUE.equals(pvAgentService.checkAgentNameUnique(pvAgent)))
        {
            return error("修改代理商'" + pvAgent.getAgentName() + "'失败，代理商名称已存在");
        }
        pvAgent.setUpdateBy(getNickname());
        return toAjax(pvAgentService.updatePvAgent(pvAgent));
    }

    /**
     * 删除代理商
     */
    @ApiOperation("删除代理商")
    @PreAuthorize("@ss.hasPermi('pv:agent:remove')")
    @Log(title = "代理商", businessType = BusinessType.DELETE)
	@DeleteMapping("/{agentId}")
    public AjaxResult remove(@PathVariable Long agentId)
    {
        return toAjax(pvAgentService.deletePvAgentByAgentId(agentId));
    }
}
