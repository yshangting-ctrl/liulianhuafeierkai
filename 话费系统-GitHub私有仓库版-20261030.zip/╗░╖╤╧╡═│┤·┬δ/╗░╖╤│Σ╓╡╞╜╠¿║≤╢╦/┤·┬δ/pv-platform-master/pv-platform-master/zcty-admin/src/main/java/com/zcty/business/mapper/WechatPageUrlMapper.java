package com.zcty.business.mapper;

import java.util.List;
import com.zcty.business.domain.WechatPageUrl;

/**
 * 微信公众号页面链接地址Mapper接口
 * 
 * @author lsw
 * @date 2024-05-29
 */
public interface WechatPageUrlMapper 
{
    /**
     * 查询微信公众号页面链接地址
     * 
     * @param id 微信公众号页面链接地址主键
     * @return 微信公众号页面链接地址
     */
    public WechatPageUrl selectWechatPageUrlById(String id);

    /**
     * 查询微信公众号页面链接地址列表
     * 
     * @param wechatPageUrl 微信公众号页面链接地址
     * @return 微信公众号页面链接地址集合
     */
    public List<WechatPageUrl> selectWechatPageUrlList(WechatPageUrl wechatPageUrl);

    /**
     * 新增微信公众号页面链接地址
     * 
     * @param wechatPageUrl 微信公众号页面链接地址
     * @return 结果
     */
    public int insertWechatPageUrl(WechatPageUrl wechatPageUrl);

    /**
     * 修改微信公众号页面链接地址
     * 
     * @param wechatPageUrl 微信公众号页面链接地址
     * @return 结果
     */
    public int updateWechatPageUrl(WechatPageUrl wechatPageUrl);

    /**
     * 删除微信公众号页面链接地址
     * 
     * @param id 微信公众号页面链接地址主键
     * @return 结果
     */
    public int deleteWechatPageUrlById(String id);

    /**
     * 批量删除微信公众号页面链接地址
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteWechatPageUrlByIds(String[] ids);
}
