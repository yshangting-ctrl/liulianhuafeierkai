package com.zcty.web.utlis;

import com.zcty.common.utils.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

import javax.annotation.PostConstruct;
import java.util.Iterator;
import java.util.Set;

/**
 * Redis 工具类 Created by zharounze
 */
@Component
public class RedisUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(RedisUtil.class);



    // 测试
    private static String IP;
    private static String PASSWORD;


    @Value("${spring.redis.host}")
    private String redishost;
    @Value("${spring.redis.password}")
    private String redisPassword;


    @PostConstruct
    public void getRedisHost() {
        IP = this.redishost;
    }
    @PostConstruct
    public void getRedisPassWord() {
        PASSWORD = this.redisPassword;
    }

    // Redis的端口号
    private static int PORT = 6379;

    // 可用连接实例的最大数目，默认值为8；
    // 如果赋值为-1，则表示不限制；如果pool已经分配了maxActive个jedis实例，则此时pool的状态为exhausted(耗尽)。
    private static int MAX_ACTIVE = 1000;

    // 控制一个pool最多有多少个状态为idle(空闲的)的jedis实例，默认值也是8。
    private static int MAX_IDLE = 8;

    // 等待可用连接的最大时间，单位毫秒，默认值为-1，表示永不超时。如果超过等待时间，则直接抛出JedisConnectionException；
    private static int MAX_WAIT = -1;

    // 超时时间
    private static int TIMEOUT = 0;

    // 在borrow一个jedis实例时，是否提前进行validate操作；如果为true，则得到的jedis实例均是可用的；
    private static boolean TEST_ON_BORROW = false;

    private static JedisPool jedisPool = null;

    /**
     * redis过期时间,以秒为单位
     */
    // 一小时
    public final static int EXRP_HOUR = 60 * 60;
    // 一天
    public final static int EXRP_DAY = 60 * 60 * 24;
    // 一个月
    public final static int EXRP_MONTH = 60 * 60 * 24 * 30;

    /**
     * 初始化Redis连接池
     */
    private static void initialPool() {
        try {
            JedisPoolConfig config = new JedisPoolConfig();
            config.setMaxTotal(MAX_ACTIVE);
            config.setMaxIdle(MAX_IDLE);
            config.setMaxWaitMillis(MAX_WAIT);
            config.setTestOnBorrow(TEST_ON_BORROW);
            jedisPool = new JedisPool(config, IP, PORT, TIMEOUT);
        } catch (Exception e) {
            LOGGER.error("First create JedisPool error : " + e);
        }
    }

    /**
     * 在多线程环境同步初始化
     */
    private static synchronized void poolInit() {
        if (null == jedisPool) {
            initialPool();
        }
    }

    /**
     * exists
     *
     * @param key
     * @return
     */
    public static boolean exists(String key) {
        Jedis jedis = getJedis();
        boolean value = jedis.exists(key);
        jedis.close();
        return value;
    }

    /**
     * 同步获取Jedis实例
     *
     * @return Jedis
     */
    public synchronized static Jedis getJedis() {
//        System.out.println(IP);
        poolInit();
        Jedis jedis = null;
        try {
            if (null != jedisPool) {
                jedis = jedisPool.getResource();
                if(StringUtils.isNotEmpty(PASSWORD)) {
                    try {
                        jedis.auth(PASSWORD);
                    } catch (Exception e) {
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.error("Get jedis error : " + e);
        }
        return jedis;
    }

    /**
     * 设置 String
     *
     * @param key
     * @param value
     */
    public synchronized static void set(String key, String value) {
        Jedis jedis = null;
        try {
            value = "".equals(value) ? "" : value;
            jedis = getJedis();
            jedis.set(key, value);
//            jedis.close();
        } catch (Exception e) {
            LOGGER.error("Set key error : " + e);
        }finally {
            if(jedis!=null){
                jedis.close();
            }
        }
    }

    /**
     * 设置 byte[]
     *
     * @param key
     * @param value
     */
    public synchronized static void set(byte[] key, byte[] value) {
        Jedis jedis = null;
        try {
            jedis = getJedis();
            jedis.set(key, value);
//            jedis.close();
        } catch (Exception e) {
            LOGGER.error("Set key error : " + e);
        }finally {
            if(jedis!=null){
                jedis.close();
            }
        }
    }

    /**
     * 设置 String 过期时间
     *
     * @param key
     * @param value
     * @param seconds 以秒为单位
     */
    public synchronized static void set(String key, String value, int seconds) {
        Jedis jedis = null;
        try {
            // value = !"".equals(value) ? "" : value;
            jedis = getJedis();
            jedis.setex(key, seconds, value);
//            jedis.close();
        } catch (Exception e) {
            LOGGER.error("Set keyex error : " + e);
        }finally {
            if(jedis!=null){
                jedis.close();
            }
        }
    }

    /**
     * 设置 byte[] 过期时间
     *
     * @param key
     * @param value
     * @param seconds 以秒为单位
     */
    public synchronized static void set(byte[] key, byte[] value, int seconds) {
        Jedis jedis = null;
        try {
            jedis = getJedis();
            jedis.set(key, value);
            jedis.expire(key, seconds);
//            jedis.close();
        } catch (Exception e) {
            LOGGER.error("Set key error : " + e);
        }finally {
            if(jedis!=null){
                jedis.close();
            }
        }
    }

    /**
     * 获取String值
     *
     * @param key
     * @return value
     */
    public synchronized static String get(String key) {
        Jedis jedis = null;
        try {
            jedis = getJedis();
        if (null == jedis) {
            return null;
        }
        String value = jedis.get(key);
//        jedis.close();
        return value;
        } catch (Exception e) {
            LOGGER.error("Set key error : " + e);
            return null;
        }finally {
            if(jedis!=null){
                jedis.close();
            }
        }

    }

    /**
     * 获取String值
     *
     * @param key
     * @return value
     */
    public synchronized static long getTtl(String key) {
        Jedis jedis = null;
        try {
         jedis = getJedis();
        if (null == jedis) {
            return 0;
        }
        long value = jedis.ttl(key);
//        jedis.close();
        return value;
        } catch (Exception e) {
            LOGGER.error("Set key error : " + e);
            return 0;
        }finally {
            if(jedis!=null){
                jedis.close();
            }
        }
    }


    /**
     * 获取byte[]值
     *
     * @param key
     * @return value
     */
    public synchronized static byte[] get(byte[] key) {
        Jedis jedis = null;
        try {
        jedis = getJedis();
        if (null == jedis) {
            return null;
        }
        byte[] value = jedis.get(key);
//        jedis.close();
        return value;
        } catch (Exception e) {
            LOGGER.error("Set key error : " + e);
            return null;
        }finally {
            if(jedis!=null){
                jedis.close();
            }
        }
    }

    /**
     * 删除值
     *
     * @param key
     */
    public synchronized static void remove(String key) {
        Jedis jedis = null;
        try {
            jedis = getJedis();

            Iterator<String> it = jedis.keys(key + "*").iterator();
            while (it.hasNext()) {
                String key1 = it.next();
                // 清空缓存中记录的数据
                jedis.del(key1);
            }
//            jedis.close();
        } catch (Exception e) {
            LOGGER.error("Remove keyex error : " + e);
        }finally {
            if(jedis!=null){
                jedis.close();
            }
        }
    }

    /**
     * 删除值
     **/
    public synchronized static void remove() {
        Jedis jedis = null;
        try {
            jedis = getJedis();
            jedis.flushDB();
//            jedis.close();
        } catch (Exception e) {
            LOGGER.error("Remove keyex error : " + e);
        }finally {
            if(jedis!=null){
                jedis.close();
            }
        }
    }

    /**
     * 删除值
     *
     * @param key
     */
    public synchronized static void remove(byte[] key) {
        Jedis jedis = null;
        try {
             jedis = getJedis();
            jedis.del(key);
//            jedis.close();
        } catch (Exception e) {
            LOGGER.error("Remove keyex error : " + e);
        }finally {
            if(jedis!=null){
                jedis.close();
            }
        }
    }

    /**
     * lpush
     *
     * @param key
     * @param key
     */
    public synchronized static void lpush(String key, String... strings) {
        Jedis jedis = null;
        try {
            jedis = RedisUtil.getJedis();
            jedis.lpush(key, strings);
//            jedis.close();
        } catch (Exception e) {
            LOGGER.error("lpush error : " + e);
        }finally {
            if(jedis!=null){
                jedis.close();
            }
        }
    }

    /**
     * lpush
     *
     * @param key
     * @param key
     */
    public synchronized static void lpush(String key, Integer seconds, String... strings) {
        Jedis jedis = null;
        try {
            jedis = RedisUtil.getJedis();
            jedis.lpush(key, strings);
            jedis.expire(key, seconds);
//            jedis.close();
        } catch (Exception e) {
            LOGGER.error("lpush error : " + e);
        }finally {
            if(jedis!=null){
                jedis.close();
            }
        }
    }

    /**
     * lrem
     *
     * @param key
     * @param count
     * @param value
     */
    public synchronized static void lrem(String key, long count, String value) {
        Jedis jedis = null;
        try {
            jedis = RedisUtil.getJedis();
            jedis.lrem(key, count, value);
//            jedis.close();
        } catch (Exception e) {
            LOGGER.error("lpush error : " + e);
        }finally {
            if(jedis!=null){
                jedis.close();
            }
        }
    }

    /**
     * sadd
     *
     * @param key
     * @param value
     */
    public synchronized static void sadd(String key, String value) {
        Jedis jedis = null;
        try {
            jedis = RedisUtil.getJedis();
            jedis.sadd(key, value);
//            jedis.close();
        } catch (Exception e) {
            LOGGER.error("sadd error : " + e);
        }finally {
            if(jedis!=null){
                jedis.close();
            }
        }
    }

    /**
     * 删除set中的指定值
     *
     * @param key
     * @param value
     */
    public synchronized static void srem(String key, String value) {
        Jedis jedis = null;
        try {
            jedis = RedisUtil.getJedis();
            jedis.srem(key, value);
//            jedis.close();
        } catch (Exception e) {
            LOGGER.error("sadd error : " + e);
        }finally {
            if(jedis!=null){
                jedis.close();
            }
        }
    }

    /**
     * 返回指定set中的所有的值
     *
     * @param key
     */
    public synchronized static Set<String> smembers(String key) {
        Jedis jedis = RedisUtil.getJedis();
        if (null == jedis) {
            return null;
        }
        Set<String> set = jedis.smembers(key);
        jedis.close();
        return set;
    }

    /**
     * incr
     *
     * @param key
     * @return value
     */
    public synchronized static Long incr(String key) {
        Jedis jedis = getJedis();
        if (null == jedis) {
            return null;
        }
        long value = jedis.incr(key);
        jedis.close();
        return value;
    }

    /**
     * decr
     *
     * @param key
     * @return value
     */
    public synchronized static Long decr(String key) {
        Jedis jedis = getJedis();
        if (null == jedis) {
            return null;
        }
        long value = jedis.decr(key);
        jedis.close();
        return value;
    }

    /**
     * 关闭jedis连接池
     *
     * @param jedis
     */
    public static void closeRedis(Jedis jedis) {
        if (jedis != null) {
            try {
                jedis.close();
            } catch (Exception e) {
                LOGGER.error("Jedis关闭异常" + e.getMessage());
            }
        }
    }

}