package com.zcty.business.service.impl;


import com.zcty.business.domain.OnlineMessage;
import com.zcty.business.domain.OnlineMessageDTO;
import com.zcty.business.domain.OnlineMessageShow;
import com.zcty.business.mapper.OnlineMessageMapper;
import com.zcty.business.service.IOnlineMessageService;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.core.text.Convert;
import com.zcty.common.utils.DateUtils;
import com.zcty.web.utlis.IdGen;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * 在线留言 服务层实现
 * 
 * @author liuruibin
 * @date 2022-11-28
 */
@Service
public class OnlineMessageServiceImpl implements IOnlineMessageService
{
	@Autowired
	private OnlineMessageMapper onlineMessageMapper;

	/**
     * 查询在线留言信息
     * 
     * @param id 在线留言ID
     * @return 在线留言信息
     */
    @Override
	public OnlineMessage selectOnlineMessageById(String id)
	{
	    return onlineMessageMapper.selectOnlineMessageById(id);
	}
	
	/**
     * 查询在线留言列表
     * 
     * @param onlineMessage 在线留言信息
     * @return 在线留言集合
     */
	@Override
	public List<OnlineMessage> selectOnlineMessageList(OnlineMessage onlineMessage)
	{
	    return onlineMessageMapper.selectOnlineMessageList(onlineMessage);
	}
	
    /**
     * 新增在线留言
     * 
     * @param onlineMessageDTO 在线留言信息
     * @return 结果
     */
	@Override
	public AjaxResult insertOnlineMessage(OnlineMessageDTO onlineMessageDTO, String openId)
	{
		onlineMessageDTO.checkParams();

		OnlineMessage onlineMessage = new OnlineMessage();
		Date nowDate = DateUtils.getNowDate();
		onlineMessage.setImageText(onlineMessageDTO.getImageText());

		onlineMessage.setContactNumber(onlineMessageDTO.getContactNumber());
		onlineMessage.setContacts(onlineMessageDTO.getContacts());
		onlineMessage.setOrderNo(onlineMessageDTO.getOrderNo());
		onlineMessage.setProductName(onlineMessageDTO.getProductName());

		onlineMessage.setId(IdGen.uuid());
		onlineMessage.setStatus(0);
		onlineMessage.setCheckRemarks(0);
		onlineMessage.setCreateTime(nowDate);
		onlineMessage.setUpdateTime(nowDate);
		onlineMessage.setOpenId(openId);
	    return AjaxResult.switchOne(onlineMessageMapper.insertOnlineMessage(onlineMessage));
	}
	
	/**
     * 修改在线留言
     * 
     * @param onlineMessage 在线留言信息
     * @return 结果
     */
	@Override
	public int updateOnlineMessage(OnlineMessage onlineMessage)
	{
		onlineMessage.setUpdateTime(DateUtils.getNowDate());
	    return onlineMessageMapper.updateOnlineMessage(onlineMessage);
	}

	/**
     * 删除在线留言对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteOnlineMessageByIds(String ids)
	{
		return onlineMessageMapper.deleteOnlineMessageByIds(Convert.toStrArray(ids));
	}

	@Override
	public List<OnlineMessage> selectOnlineMessageShowList(OnlineMessage onlineMessage) {
		return onlineMessageMapper.selectOnlineMessageShowList(onlineMessage);
	}

	/**
	 * 查询小程序我的留言建议分页列表
	 * @param openId
	 * @return
	 */
	@Override
	public List<OnlineMessageShow> selectOnlineMessageShowWxList(String openId) {
		return onlineMessageMapper.selectOnlineMessageShowWxList(openId);
	}
}
