package com.zcty.business.service;

import java.util.List;
import com.zcty.business.domain.PlatformInfos;

/**
 * 第三方充值平台管理Service接口
 * 
 * @author lsw
 * @date 2024-06-29
 */
public interface IPlatformInfosService 
{
    /**
     * 查询第三方充值平台管理
     * 
     * @param id 第三方充值平台管理主键
     * @return 第三方充值平台管理
     */
    public PlatformInfos selectPlatformInfosById(String id);

    /**
     * 查询第三方充值平台管理列表
     * 
     * @param platformInfos 第三方充值平台管理
     * @return 第三方充值平台管理集合
     */
    public List<PlatformInfos> selectPlatformInfosList(PlatformInfos platformInfos);

    /**
     * 新增第三方充值平台管理
     * 
     * @param platformInfos 第三方充值平台管理
     * @return 结果
     */
    public int insertPlatformInfos(PlatformInfos platformInfos);

    /**
     * 修改第三方充值平台管理
     * 
     * @param platformInfos 第三方充值平台管理
     * @return 结果
     */
    public int updatePlatformInfos(PlatformInfos platformInfos);

    /**
     * 批量删除第三方充值平台管理
     * 
     * @param ids 需要删除的第三方充值平台管理主键集合
     * @return 结果
     */
    public int deletePlatformInfosByIds(String[] ids);

    /**
     * 删除第三方充值平台管理信息
     * 
     * @param id 第三方充值平台管理主键
     * @return 结果
     */
    public int deletePlatformInfosById(String id);

    public PlatformInfos selectPlatformInfosByKeyWord(String platformKey);
}
