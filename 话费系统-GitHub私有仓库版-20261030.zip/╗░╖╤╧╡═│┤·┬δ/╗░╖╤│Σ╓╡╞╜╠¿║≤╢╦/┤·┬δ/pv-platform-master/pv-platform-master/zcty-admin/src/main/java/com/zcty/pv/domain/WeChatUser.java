package com.zcty.pv.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.zcty.common.annotation.Excel;
import org.springframework.format.annotation.DateTimeFormat;
import java.io.Serializable;
import java.util.Date;

/**
 * 微名用户表 t_we_chat_user
 * 
 * @author liuruibin
 * @date 2020-04-03
 */
public class WeChatUser implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	/** 微信用户ID */
	private String id;
	/** 用户的标识，对当前公众号唯一 */
	private String openid;
	/** 用户的昵称 */
	private String nickname;
	/** 用户的性别，值为1时是男性，值为2时是女性，值为0时是未知 */
	private String sex;
	/** 用户所在城市 */
	private String city;
	/** 用户所在国家 */
	private String country;
	/** 用户所在省份 */
	private String province;
	/** 用户的语言，简体中文为zh_CN */
	private String language;
	/** 用户头像，最后一个数值代表正方形头像大小（有0、46、64、96、132数值可选，0代表640*640正方形头像），用户没有头像时该项为空。若用户更换头像，原有头像URL将失效 */
	private String headimgurl;
	/** 备注 */
	private String remark;
	/** 创建时间 */
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss" ,  timezone="GMT+8")
	private Date createTime;
	/** 更新时间 */
	private Date updateTime;
	/** 是否已授权注册了信息*/
	private Integer withScope;
	/** 绑定手机号码*/
	private String bindPhone;
	/** 用户的id（辨识号码）*/
	private String userId;
	/** 积分*/
	private Integer pointsTotal;

	/** 等级*/
	private Integer  userLevel;
	/**  是否vip用户 0否  1是*/
	private Integer  vipUser;
	/** vip手机号码*/
	private String vipPhone;
	/** vip用户的昵称*/
	private String vipNickName;
	/** 地址*/
	private String	vipAddress;
    /** 设置为vip的时间*/
	private Date vipTime;
	/** 最后一次充积分的时间*/
	private Date lastVipTime;
	/** 用户二维码**/
	private	String qrCodeUrl;

    private String unionid;

    private String supplierId;

	/** 公众号id */
	private String appId;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getOpenid() {
		return openid;
	}

	public void setOpenid(String openid) {
		this.openid = openid;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getHeadimgurl() {
		return headimgurl;
	}

	public void setHeadimgurl(String headimgurl) {
		this.headimgurl = headimgurl;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Integer getWithScope() {
		return withScope;
	}

	public void setWithScope(Integer withScope) {
		this.withScope = withScope;
	}

	public String getBindPhone() {
		return bindPhone;
	}

	public void setBindPhone(String bindPhone) {
		this.bindPhone = bindPhone;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Integer getPointsTotal() {
		return pointsTotal;
	}

	public void setPointsTotal(Integer pointsTotal) {
		this.pointsTotal = pointsTotal;
	}

	public Integer getUserLevel() {
		return userLevel;
	}

	public void setUserLevel(Integer userLevel) {
		this.userLevel = userLevel;
	}

	public Integer getVipUser() {
		return vipUser;
	}

	public void setVipUser(Integer vipUser) {
		this.vipUser = vipUser;
	}

	public String getVipPhone() {
		return vipPhone;
	}

	public void setVipPhone(String vipPhone) {
		this.vipPhone = vipPhone;
	}

	public String getVipNickName() {
		return vipNickName;
	}

	public void setVipNickName(String vipNickName) {
		this.vipNickName = vipNickName;
	}

	public String getVipAddress() {
		return vipAddress;
	}

	public void setVipAddress(String vipAddress) {
		this.vipAddress = vipAddress;
	}

	public Date getVipTime() {
		return vipTime;
	}

	public void setVipTime(Date vipTime) {
		this.vipTime = vipTime;
	}

	public Date getLastVipTime() {
		return lastVipTime;
	}

	public void setLastVipTime(Date lastVipTime) {
		this.lastVipTime = lastVipTime;
	}

	public String getQrCodeUrl() {
		return qrCodeUrl;
	}

	public void setQrCodeUrl(String qrCodeUrl) {
		this.qrCodeUrl = qrCodeUrl;
	}

	public String getUnionid() {
		return unionid;
	}

	public void setUnionid(String unionid) {
		this.unionid = unionid;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}
}
