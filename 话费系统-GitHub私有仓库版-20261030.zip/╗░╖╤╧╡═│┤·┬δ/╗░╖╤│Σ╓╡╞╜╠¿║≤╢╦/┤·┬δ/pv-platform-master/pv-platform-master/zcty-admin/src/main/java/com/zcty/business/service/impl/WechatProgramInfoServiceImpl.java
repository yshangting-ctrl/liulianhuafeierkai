package com.zcty.business.service.impl;

import java.util.List;
import com.zcty.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zcty.business.mapper.WechatProgramInfoMapper;
import com.zcty.business.domain.WechatProgramInfo;
import com.zcty.business.service.IWechatProgramInfoService;

/**
 * 微信公众号授权信息Service业务层处理
 * 
 * @author ruoyi
 * @date 2024-05-16
 */
@Service
public class WechatProgramInfoServiceImpl implements IWechatProgramInfoService 
{
    @Autowired
    private WechatProgramInfoMapper wechatProgramInfoMapper;

    /**
     * 查询微信公众号授权信息
     * 
     * @param id 微信公众号授权信息主键
     * @return 微信公众号授权信息
     */
    @Override
    public WechatProgramInfo selectWechatProgramInfoById(String id)
    {
        return wechatProgramInfoMapper.selectWechatProgramInfoById(id);
    }

    /**
     * 查询微信公众号授权信息列表
     * 
     * @param wechatProgramInfo 微信公众号授权信息
     * @return 微信公众号授权信息
     */
    @Override
    public List<WechatProgramInfo> selectWechatProgramInfoList(WechatProgramInfo wechatProgramInfo)
    {
        return wechatProgramInfoMapper.selectWechatProgramInfoList(wechatProgramInfo);
    }

    /**
     * 新增微信公众号授权信息
     * 
     * @param wechatProgramInfo 微信公众号授权信息
     * @return 结果
     */
    @Override
    public int insertWechatProgramInfo(WechatProgramInfo wechatProgramInfo)
    {
        wechatProgramInfo.setCreateTime(DateUtils.getNowDate());
        return wechatProgramInfoMapper.insertWechatProgramInfo(wechatProgramInfo);
    }

    /**
     * 修改微信公众号授权信息
     * 
     * @param wechatProgramInfo 微信公众号授权信息
     * @return 结果
     */
    @Override
    public int updateWechatProgramInfo(WechatProgramInfo wechatProgramInfo)
    {
        return wechatProgramInfoMapper.updateWechatProgramInfo(wechatProgramInfo);
    }

    /**
     * 批量删除微信公众号授权信息
     * 
     * @param ids 需要删除的微信公众号授权信息主键
     * @return 结果
     */
    @Override
    public int deleteWechatProgramInfoByIds(String[] ids)
    {
        return wechatProgramInfoMapper.deleteWechatProgramInfoByIds(ids);
    }

    /**
     * 删除微信公众号授权信息信息
     * 
     * @param id 微信公众号授权信息主键
     * @return 结果
     */
    @Override
    public int deleteWechatProgramInfoById(String id)
    {
        return wechatProgramInfoMapper.deleteWechatProgramInfoById(id);
    }

    /**
     * 删除微信公众号授权信息
     *
     * @param authorizerAppid 微信公众号授权公众号appId
     * @return 结果
     */
    @Override
    public int deleteWechatProgramInfoByAuthorizerAppid(String authorizerAppid) {
        return wechatProgramInfoMapper.deleteWechatProgramInfoByAuthorizerAppid(authorizerAppid);
    }
}
