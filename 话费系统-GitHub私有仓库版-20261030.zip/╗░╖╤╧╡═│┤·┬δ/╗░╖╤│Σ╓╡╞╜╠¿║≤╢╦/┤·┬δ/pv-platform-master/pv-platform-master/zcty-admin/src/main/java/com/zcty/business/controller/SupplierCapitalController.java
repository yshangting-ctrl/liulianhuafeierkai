package com.zcty.business.controller;

import java.util.List;
import com.zcty.business.domain.SupplierCapitalVo;
import com.zcty.common.config.WxOpenConfig;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.zcty.common.annotation.Log;
import com.zcty.common.core.controller.BaseController;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.enums.BusinessType;
import com.zcty.business.domain.SupplierCapital;
import com.zcty.business.service.ISupplierCapitalService;
import com.zcty.common.core.page.TableDataInfo;
/**
 * 代理商资金Controller
 * 
 * @author ruoyi
 * @date 2024-06-24
 */
@RestController
@RequestMapping("/business/capital")
public class SupplierCapitalController extends BaseController
{

    @Autowired
    private ISupplierCapitalService supplierCapitalService;

    /**
     * 查询代理商资金列表
     */
    @PreAuthorize("@ss.hasPermi('business:capital:list')")
    @GetMapping("/list")
    public TableDataInfo list(SupplierCapital supplierCapital)
    {
        startPage();
        List<SupplierCapital> list = supplierCapitalService.selectSupplierCapitalList(supplierCapital);
        return getDataTable(list);
    }

    /**
     * 查询代理商资金列表
     */
    @GetMapping("/showList")
    public TableDataInfo showList(SupplierCapitalVo supplierCapitalVo)
    {
        startPage();
        List<SupplierCapitalVo> list = supplierCapitalService.selectSupplierCapitalVoList(supplierCapitalVo);
        return getDataTable(list);
    }

    /**
     * 获取代理商资金详细信息
     */
    @PreAuthorize("@ss.hasPermi('business:capital:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") String id)
    {
        SupplierCapitalVo supplierCapitalVo = supplierCapitalService.selectSupplierCapitalVoById(id);
        return success(supplierCapitalVo);
    }

    /**
     * 修改代理商资金
     */
    @PreAuthorize("@ss.hasPermi('business:capital:edit')")
    @Log(title = "修改代理商资金", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody SupplierCapital supplierCapital)
    {
        supplierCapital.setTotalType(WxOpenConfig.ADD_TYPE);
        return (supplierCapitalService.updateSupplierCapital(supplierCapital));
    }


}
