package com.zcty.weChat.service.impl;


import com.alibaba.fastjson2.JSONObject;
import com.zcty.business.domain.Order;
import com.zcty.business.domain.WechartPayInfo;
import com.zcty.business.service.IOrderDetailService;
import com.zcty.business.service.IOrderService;
import com.zcty.business.service.IWechartPayInfoService;
import com.zcty.common.constant.PayConstants;
import com.zcty.common.exception.base.BaseException;
import com.zcty.common.utils.DateUtils;
import com.zcty.common.utils.StringUtils;
import com.zcty.weChat.service.WePayService;
import com.zcty.web.utlis.delay.AccessTokenDeLay;
import com.zcty.web.utlis.payInfo.AES256GCM;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.security.GeneralSecurityException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.DelayQueue;

/**
 * 支付，退款的回调业务实现
 */
@Service
public class WePayServiceImpl implements WePayService {


    @Autowired
    private IOrderService orderService;
    @Autowired
    private IOrderDetailService orderDetailService;
    @Autowired
    private IWechartPayInfoService wechartPayInfoService;

    private static final Logger log = LoggerFactory.getLogger("wePay-log");

    /**
     * 支付异步回调处理
     * @param response
     * @param request
     * @return
     */
    @Override
    public String payNotifyUrl(HttpServletResponse response, HttpServletRequest request,String supplierId) {

        log.info("---------微信支付回调/weChat/pay/payNotifyUrl");

        JSONObject resultObject = parseNotify(request,supplierId);

        String tradeState = resultObject.getString(PayConstants.PAY_NOTIFY_TRADE_STATE);

        if(!"SUCCESS".equals(tradeState)){
            log.info(resultObject.toJSONString());
            return PayConstants.PAY_NOTIFY_SUCCESS;
        }

        String orderNo = resultObject.getString(PayConstants.PAY_NOTIFY_OUT_TRADE_NO);

//        deleteDelay(orderNo);

        synchronized(orderNo.intern()){

            String payer = resultObject.getString(PayConstants.PAY_NOTIFY_PAYER);
            String openId = JSONObject.parseObject(payer).getString(PayConstants.PAY_NOTIFY_OPEN_ID);
            Order o = orderService.selectOrderByNo(orderNo);

            if (tradeState.equals(o.getPayStatus())){
                return PayConstants.PAY_NOTIFY_SUCCESS;
            }

            if (!openId.equals(o.getOpenId())){
                return PayConstants.PAY_NOTIFY_ERROR;
            }

            Date nowDate = new Date();
            Date payTime = DateUtils.parseDate(resultObject.getString(PayConstants.PAY_NOTIFY_SUCCESS_TIME));
            if (payTime == null){
                payTime = nowDate;
            }
            Order order = new Order();
            order.setOrderNo(orderNo);
            order.setOpenId(openId);
            order.setTransactionId(resultObject.getString(PayConstants.PAY_NOTIFY_TRANSACTION_ID));
            order.setPayStatus(resultObject.getString(PayConstants.PAY_NOTIFY_TRADE_STATE));
            order.setPayTime(payTime);
            order.setTradeType(resultObject.getString(PayConstants.PAY_NOTIFY_TRADE_TYPE));
            order.setUpdateTime(nowDate);
            order.setSysVersion(o.getSysVersion());
            if (orderService.updateOrderByPay(order) <= 0){
                return PayConstants.PAY_NOTIFY_ERROR;
            }

        }

        return resultObject.getString(PayConstants.PAY_NOTIFY_RESULT);
    }

//    /**
//     * 退款异步回调处理
//     * @param response
//     * @param request
//     * @return
//     */
//    @Transactional(rollbackFor = Exception.class)
//    @Override
//    public String refundNotifyUrl(HttpServletResponse response, HttpServletRequest request) {
//        log.info("---------微信退款回调:"+request.getServletPath()+"-------------------");
//        JSONObject resultObject = parseNotify(request);
//        log.info("退款解密后的参数："+resultObject);
////            退款状态，枚举值：
////            SUCCESS：退款成功
////            CLOSED：退款关闭
////            ABNORMAL：退款异常，退款到银行发现用户的卡作废或者冻结了，导致原路退款银行卡失败，可前往【商户平台—>交易中心】，手动处理此笔退款
//        String tradeState = resultObject.getString(PayConstants.PAY_NOTIFY_REFUND_STATUS);
//        //商户订单号，orderNo
//        String orderNo=resultObject.getString(PayConstants.PAY_NOTIFY_OUT_TRADE_NO);
//        if (StringUtils.isEmpty(orderNo)){
//            return   PayConstants.PAY_NOTIFY_ERROR;
//        }
//        //退款单号
//        String refundNo=resultObject.getString(PayConstants.PAY_NOTIFY_OUT_REFUND_NO);
//        if (StringUtils.isEmpty(refundNo)){
//            return   PayConstants.PAY_NOTIFY_ERROR;
//        }
//        synchronized (orderNo.intern()) {
//            Order order=orderService.selectOrderByNo(orderNo);
//            if(order==null){
//                return PayConstants.PAY_NOTIFY_ERROR;
//            }
//            OrderRefund orderRefund=orderRefundService.getOrderRefundByOrderNo(orderNo);
//            if(orderRefund==null){
//                return PayConstants.PAY_NOTIFY_ERROR;
//            }
//            //成功，这里就要执行订单的后续业务了
//            if ("SUCCESS".equals(tradeState)) {
//                //TODO 退款成功，后面对退款订单业务进行处理
//                //要拿什么字段就在https://pay.weixin.qq.com/wiki/doc/apiv3/apis/chapter3_5_5.shtml这里找
//                //例如要拿out_trade_no商户订单编号，则，jsonObjectDecryptResult.getString("trade_state")
//                //拿amount这个json对象，则JSONObject.parseObject(jsonObjectDecryptResult.getString("amount")),
//                //然后在去获取total（总金额） JSONObject.parseObject(jsonObjectDecryptResult.getString("amount")).getString("total")
//                //查询订单信息
//                //订单已完成，不需要重复进行处理
//                if(order.getOrderStatus().equals(OrderConstants.ORDER_STATUS_TRANSACTION_COMPLETE)){
//
//                }else{
//                    Date date=new Date();
//                    //该订单状态
//                    //没有完成，让订单，变成完成状态
//                    Map<String,Object> orderMap=new HashMap<>();
//                    orderMap.put(OrderConstants.ORDER_ID,order.getOrderId());
//                    orderMap.put(OrderConstants.OPEN_ID,order.getOpenId());
//                    orderMap.put(OrderConstants.SYS_VERSION_STR,order.getSysVersion());
//                    orderMap.put(OrderConstants.UPDATE_TIME,date);
//                    orderMap.put(OrderConstants.ORDER_STATUS,OrderConstants.ORDER_STATUS_TRANSACTION_COMPLETE);
//                    orderService.casUpdateOrderStatus(orderMap);
//
//                    //改退款订单状态
//                    //获取微信的退款单号
//                    String fundId=resultObject.getString(PayConstants.PAY_NOTIFY_REFUND_ID);
//                    String finishTime=resultObject.getString(PayConstants.PAY_NOTIFY_SUCCESS_TIME);
//                    orderRefund.setReturnMsg("退款完成");
//                    orderRefund.setRefundId(fundId);
//                    orderRefund.setFinishTime(DateUtils.parseDate(finishTime));
//                    orderRefund.setRefundPayStatus("SUCCESS");
//                    orderRefund.setRefundStatus(3);
//                    orderRefundService.updateOrderRefund(orderRefund);
//                    //库存退还
//                    OrderDetail orderDetail=new OrderDetail();
//                    orderDetail.setOrderId(order.getOrderId());
//                    List<OrderDetail> orderDetails=orderDetailService.selectOrderDetailList(orderDetail);
//                    for (OrderDetail detail : orderDetails) {
//                       boolean check=goodsBaseService.addStock(detail.getGoodsNum(),detail.getGoodsId());
//                       if(!check){
//                           throw new RuntimeException("减库存失败");
//                       }
//                    }
//                    //优惠券退还
//                    String ucid=order.getUcId();
//                    if(!StringUtils.isEmpty(ucid)){
//                        UserCoupon userConstants=new UserCoupon();
//                        userConstants.setUcId(ucid);
//                        userConstants.setUpdateTime(date);
//                        userConstants.setUcStatus(0);
//                        userCouponService.updateUserCoupon(userConstants);
//                    }
//                }
//            } else if ("CLOSED".equals(tradeState)) {
//                orderRefund.setReturnMsg("订单退款已关闭，无法完成退款");
//                orderRefund.setRefundPayStatus("CLOSED");
//                orderRefundService.updateOrderRefund(orderRefund);
//            } else if ("ABNORMAL".equals(tradeState)) {
//                orderRefund.setReturnMsg("订单退款异常，请通过线下形式完成退款");
//                orderRefund.setRefundPayStatus("ABNORMAL");
//                orderRefundService.updateOrderRefund(orderRefund);
//            }
//            log.info("---------微信退款回调完成-------------------");
//            return resultObject.getString(PayConstants.PAY_NOTIFY_RESULT);
//        }
//    }

    /**
     * 解析request
     * @param request   回调信息
     * @return  解析结果
     */
    private JSONObject parseNotify(HttpServletRequest request,String supplierId){
        JSONObject resultObject = new JSONObject();
        //回调过来的可以从request里面读取信息
        //获取支付结果回调的json字符串
        // 获取HTTP请求的输入流
        // 已HTTP请求输入流建立一个BufferedReader对象
        BufferedReader br = null;
        try {
            br = new BufferedReader(new InputStreamReader(
                    request.getInputStream(), "UTF-8"));

            String buffer;
            StringBuffer xml = new StringBuffer();
            while ((buffer = br.readLine()) != null) {
                xml.append(buffer);
            }
            String callbackMessage = xml.toString();

            log.info("微信通知回调参数" + callbackMessage);

            JSONObject jsonObject = JSONObject.parseObject(callbackMessage);
            String resource = jsonObject.getString(PayConstants.PAY_NOTIFY_RESOURCE);

            String decryptResult = parseResourceAndDecrypt(resource,supplierId);

            resultObject = JSONObject.parseObject(decryptResult);
            //返回接口回调信息,是一个json字符串
            log.info("---------微信支付回调结束/weChat/pay/payNotifyUrl");
            resultObject.put(PayConstants.PAY_NOTIFY_RESULT, PayConstants.PAY_NOTIFY_SUCCESS);
        }catch (Exception e){
            log.info("---------微信支付回调异常：/weChat/pay/payNotifyUrl");
            log.info(e.getMessage());
            resultObject.put(PayConstants.PAY_NOTIFY_RESULT, PayConstants.PAY_NOTIFY_ERROR)  ;
        }finally {

            if(br!=null){
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return resultObject;
    }

    /**
     * 解析回调信息
     * @param resource  回调数据
     * @return  结果
     * @throws GeneralSecurityException
     * @throws IOException
     */
    private String parseResourceAndDecrypt(String resource,String supplierId) throws GeneralSecurityException, IOException {
        JSONObject jsonObjectResource = JSONObject.parseObject(resource);
        String original_type = jsonObjectResource.getString(PayConstants.PAY_NOTIFY_ORIGINAL_TYPE);
        String algorithm = jsonObjectResource.getString(PayConstants.PAY_NOTIFY_ALGORITHM);
        String ciphertext = jsonObjectResource.getString(PayConstants.PAY_NOTIFY_CIPHER_TEXT);
        String associatedData = jsonObjectResource.getString(PayConstants.PAY_NOTIFY_ASSOCIATED_DATA);
        if(StringUtils.isEmpty(associatedData)){
            associatedData = "";
        }
        String nonce = jsonObjectResource.getString(PayConstants.PAY_NOTIFY_NONCE);
        if(StringUtils.isEmpty(nonce)){
            throw new BaseException("随机串数据丢失，请联系管理员！");
        }

        WechartPayInfo wechartPayInfo = wechartPayInfoService.selectWechartPayInfoSupplierId(supplierId);
        if(wechartPayInfo==null){
            return "";
        }
        String partnerKey = wechartPayInfo.getPartnerKey();
        if(StringUtils.isEmpty(partnerKey)){
            return "";
        }

        return AES256GCMDecryptToString(associatedData.getBytes(), nonce.getBytes(), ciphertext,partnerKey);
    }

    /**
     * 对回调数据进行解密
     * @param associatedData    附加数据
     * @param nonce             随机串
     * @param ciphertext        数据密文
     * @return  解密结果
     * @throws GeneralSecurityException
     * @throws IOException
     */
    private String AES256GCMDecryptToString(byte[] associatedData, byte[] nonce, String ciphertext,String partnerKey) throws GeneralSecurityException, IOException {
        AES256GCM aes256GCM = new AES256GCM(partnerKey.getBytes());
        return aes256GCM.decryptToString(associatedData, nonce, ciphertext);
    }

//    /**
//     * 删除指定延迟队列任务
//     * @param orderNo
//     */
//    private void deleteDelay(String orderNo){
//        DelayQueue<AccessTokenDeLay> accessTokenDeLays = (DelayQueue<AccessTokenDeLay>) servletContext.getAttribute(ParamNameConfig.DELAY_ORDER);
//        if (accessTokenDeLays != null){
//            accessTokenDeLays.removeIf(accessTokenDeLay -> accessTokenDeLay.getAccessTokenName().equals(orderNo));
//        }
//    }
}
