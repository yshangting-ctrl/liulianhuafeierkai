package com.zcty.business.domain;


import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;

/**
 * 留言回复表 t_online_message_reply
 * 
 * @author liuruibin
 * @date 2023-03-10
 */

public class OnlineMessageReply implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	/** 主键id */
	@ApiModelProperty(name="id",value="主键id",example = "1")
	private String id;
	/** 回复的留言id */
	@ApiModelProperty(name="messageId",value="上级id",example = "1")
	private String messageId;
	/**  */
	@ApiModelProperty(name="replyText",value="回复内容",example = "回复")
	private String replyText;
	/** 创建人 */
	@ApiModelProperty(name="createBy",value="admin",example = "1")
	private String createBy;
	/** 回复时间 */
	@ApiModelProperty(name="createTime",value="回复时间",example = "2023-11-11 11:11:11")
	private Date createTime;
	@ApiModelProperty(name="delFlag",value="删除标识",example = "0")
	private Integer delFlag;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public String getReplyText() {
		return replyText;
	}

	public void setReplyText(String replyText) {
		this.replyText = replyText;
	}

	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Integer getDelFlag() {
		return delFlag;
	}

	public void setDelFlag(Integer delFlag) {
		this.delFlag = delFlag;
	}
}
