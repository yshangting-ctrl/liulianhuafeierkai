package com.zcty.web.utlis;

import com.alibaba.fastjson2.JSONObject;
import com.zcty.common.config.WxOpenConfig;

import java.util.Map;

/**
 * 发送请求调数据
 */
public class TicketHttpSend {

    public static int getCompentToken(String ticket) throws Exception{


        //微信换取令牌（component_access_token）的路径url
        String url=WxOpenConfig.API_COMPONENT_TOKEN_URL;

        //发送请求的时候参数POST
        String data="";
        data+="{";

        data+="\"component_appid\":";
        data+="\""+ WxOpenConfig.appId+"\",";

        data+="\"component_appsecret\":";
        data+="\""+WxOpenConfig.appSecret+"\",";

        data+="\"component_verify_ticket\":";
        data+="\""+ticket+"\"";

        data+="}";


        //发送获取第三方平台accesstoken单接口
        String result=  HttpSendUtils.doPost(url,data,5000);
        System.out.println(result);
        JSONObject json = JSONObject.parseObject(result);
        //把回调的xml数据转化为map
//        Map<String, String> resultMap=  HttpSendUtils.xmlToMap(result);
//        System.out.println(resultMap);
        //只有这个结果为SUCCESS的时候有返回其他的数据，此字段是通信标识，非交易标识，交易是否成功需要查看result_code来判断
//        String return_code=json.get("return_code");
//
//        String return_msg=resultMap.get("return_msg");
//        //错误描述
//        String err_code_des=resultMap.get("err_code_des");

        String component_access_token=json.getString("component_access_token");
//        String component_access_token=resultMap.get("component_access_token");
        System.out.println("--------component_access_token-------:"+component_access_token);
        String expires_in=json.getString("expires_in");
//                resultMap.get("expires_in");

        System.out.println("--------expires_in-------:"+expires_in);


        //将access_token和expires_in保存到redis对象里面
        RedisUtil.set(WxOpenConfig.COMPONENT_ACCESS_TOKEN,component_access_token);
        RedisUtil.set(WxOpenConfig.COMPONENT_ACCESS_TOKEN_EXPIRES_IN,  expires_in);

//        if(!"SUCCESS".equals(return_code)){
//            System.out.println("--------------微信支付下单错误信息返回-----------原因return_msg："+return_msg);
//            return 0;
//        }

        //业务结果SUCCESS/FAIL
//        String result_code=resultMap.get("result_code");
//        if(!"SUCCESS".equals(result_code)){
//            System.out.println("--------------微信支付下单错误信息返回-----------原因err_code_des："+err_code_des);
//            return 0;
//        }




        return 1;
    }

}
