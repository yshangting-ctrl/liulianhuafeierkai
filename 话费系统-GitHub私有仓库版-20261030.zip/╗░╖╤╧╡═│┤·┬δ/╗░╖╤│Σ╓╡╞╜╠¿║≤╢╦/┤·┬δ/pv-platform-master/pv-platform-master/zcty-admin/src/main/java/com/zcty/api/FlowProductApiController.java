package com.zcty.api;

import com.zcty.business.domain.FlowProduct;
import com.zcty.business.service.IFlowProductService;
import com.zcty.common.core.controller.BaseController;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.core.page.TableDataInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;
/**
 * 流量产品Controller
 *
 * @author lsw
 * @date 2024-03-13
 */
@RestController
@RequestMapping("/api/flowProduct")
public class FlowProductApiController  extends BaseController {

    @Autowired
    private IFlowProductService flowProductService;


    /**
     * 查询流量商品分页列表
     * @param product
     * @return
     */
    @PostMapping("/list")
    public TableDataInfo list(FlowProduct product)
    {
        startPage();
        List<FlowProduct> list = flowProductService.selectFlowProductList(product);
        return getDataTable(list);
    }

    /**
     * 根据流量商品id查询流量商品详情
     * @param id
     * @return
     */
    @PostMapping("/selectInfo")
    public AjaxResult selectInfo(String id){
        FlowProduct flowProduct = flowProductService.selectFlowProductById(id);
        return AjaxResult.success(flowProduct);

    }
}
