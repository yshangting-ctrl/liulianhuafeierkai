package com.zcty.business.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.zcty.common.annotation.Excel;
import java.io.Serializable;
import java.util.Date;

/**
 * 微信公众号授权信息对象 t_wechat_program_info
 * 
 * @author ruoyi
 * @date 2024-05-16
 */
public class WechatProgramInfo implements Serializable
{
    private static final long serialVersionUID = 1L;

    /** 主键id */
    private String id;

    /** 公众号id */
    @Excel(name = "公众号id")
    private String authorizerAppid;

    /** 得到授权信息 */
    @Excel(name = "得到授权信息")
    private String authorizationInfo;

    /** 得到接口调用令牌 */
    @Excel(name = "得到接口调用令牌")
    private String authorizerAccessToken;

    /** 得到接口刷新令牌   存入数据库 */
    @Excel(name = "得到接口刷新令牌   存入数据库")
    private String authorizerRefreshToken;

    /** 接口调用令牌的有效期 */
    @Excel(name = "接口调用令牌的有效期")
    private Integer expiresIn;

    /** 删除标识0 未删除 1已删除 */
    private Integer delFlag;

    /** 创建时间 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;

    public void setId(String id) 
    {
        this.id = id;
    }

    public String getId() 
    {
        return id;
    }
    public void setAuthorizerAppid(String authorizerAppid) 
    {
        this.authorizerAppid = authorizerAppid;
    }

    public String getAuthorizerAppid() 
    {
        return authorizerAppid;
    }
    public void setAuthorizationInfo(String authorizationInfo) 
    {
        this.authorizationInfo = authorizationInfo;
    }

    public String getAuthorizationInfo() 
    {
        return authorizationInfo;
    }
    public void setAuthorizerAccessToken(String authorizerAccessToken) 
    {
        this.authorizerAccessToken = authorizerAccessToken;
    }

    public String getAuthorizerAccessToken() 
    {
        return authorizerAccessToken;
    }
    public void setAuthorizerRefreshToken(String authorizerRefreshToken) 
    {
        this.authorizerRefreshToken = authorizerRefreshToken;
    }

    public String getAuthorizerRefreshToken() 
    {
        return authorizerRefreshToken;
    }
    public void setExpiresIn(Integer expiresIn) 
    {
        this.expiresIn = expiresIn;
    }

    public Integer getExpiresIn() 
    {
        return expiresIn;
    }
    public void setDelFlag(Integer delFlag) 
    {
        this.delFlag = delFlag;
    }

    public Integer getDelFlag() 
    {
        return delFlag;
    }

    public Date getCreateTime()
    {
        return createTime;
    }

    public void setCreateTime(Date createTime)
    {
        this.createTime = createTime;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("authorizerAppid", getAuthorizerAppid())
            .append("authorizationInfo", getAuthorizationInfo())
            .append("authorizerAccessToken", getAuthorizerAccessToken())
            .append("authorizerRefreshToken", getAuthorizerRefreshToken())
            .append("expiresIn", getExpiresIn())
            .append("createTime", getCreateTime())
            .append("delFlag", getDelFlag())
            .toString();
    }
}
