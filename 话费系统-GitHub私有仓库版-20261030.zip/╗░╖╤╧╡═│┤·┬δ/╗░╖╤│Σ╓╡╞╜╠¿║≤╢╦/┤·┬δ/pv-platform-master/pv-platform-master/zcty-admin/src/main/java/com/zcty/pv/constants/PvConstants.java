package com.zcty.pv.constants;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 光伏平台常量类
 */
public class PvConstants {
    /** 合同编号前缀 */
    public static final String PREFIX_CONTRACT_STR = "D/H.";

    /** 入库单编号前缀 */
    public static final String PREFIX_STORE_IN_STR = "IP";

    /** 出库单前缀 */
    public static final String PREFIX_STORE_OUT_STR = "OP";

    /** 库存转移单前缀 */
    public static final String PREFIX_STORE_ALLO_STR = "AL";

    /** 订单编号前缀 */
    public static final String PREFIX_ORDER_STR = "OD";

    /** 仓库编号前缀 */
    public static final String PREFIX_STORE_STR = "WH";

    /** 代理商对应的上级部门id */
    public static final Long AGENT_PARENT_DEPT_ID = 200L;

    /** 删除标识，0-未删除，2-已删除 */
    public static final String DEL_FLAG_0 = "0";
    public static final String DEL_FLAG_1 = "2";

    /** 财务结算-组件单价 */
    public static final BigDecimal SETTLE_BLOCK_PRICE = new BigDecimal(20);
    public static final String SETTLE_BATCH_NO_PREFIX = "JS";

    /** 勘察照片文件列表,key表示文件名，value表示是否必填 */
    public static final Map<String, String> SURVEY_FILEl_NAME_LIST = new HashMap<>();
    static {
        SURVEY_FILEl_NAME_LIST.put("房屋整体(南侧视角)","T");
        SURVEY_FILEl_NAME_LIST.put("房屋周边(左)","T");
        SURVEY_FILEl_NAME_LIST.put("房屋周边(右)", "T");
        SURVEY_FILEl_NAME_LIST.put("房屋内部整体照片", "T");
        SURVEY_FILEl_NAME_LIST.put("电表参数", "T");
        SURVEY_FILEl_NAME_LIST.put("屋顶全貌(东南方向)", "T");
        SURVEY_FILEl_NAME_LIST.put("屋顶全貌(西南方向)", "T");
        SURVEY_FILEl_NAME_LIST.put("屋顶全貌(东北方向)", "T");
        SURVEY_FILEl_NAME_LIST.put("屋顶全貌(西北方向)", "T");
        SURVEY_FILEl_NAME_LIST.put("屋顶平面草图", "T");
        SURVEY_FILEl_NAME_LIST.put("房屋方位角(测量图)", "T");
        SURVEY_FILEl_NAME_LIST.put("房屋方位角(角度图)", "T");
    }

    /** 勘察照片文件列表,key表示文件名，value表示是否必填 */
    public static final Map<String, String> FINISH_FILEl_NAME_LIST = new HashMap<>();
    static {
        FINISH_FILEl_NAME_LIST.put("电站照片","F");
        FINISH_FILEl_NAME_LIST.put("安全交底文件","F");
        FINISH_FILEl_NAME_LIST.put("自检文件", "F");
        FINISH_FILEl_NAME_LIST.put("调试文件", "F");
        FINISH_FILEl_NAME_LIST.put("组件序列号", "F");
        FINISH_FILEl_NAME_LIST.put("逆变器序列号", "F");
        FINISH_FILEl_NAME_LIST.put("监控序列号", "F");
    }

    /** 勘察照片文件列表,key表示文件名，value表示是否必填 */
    public static final Map<String, String> BUSINESS_INFO_FILES_NAME_LIST = new HashMap<>();
    static {
        BUSINESS_INFO_FILES_NAME_LIST.put("身份证正、反面","T");
        BUSINESS_INFO_FILES_NAME_LIST.put("银行卡", "T");
        BUSINESS_INFO_FILES_NAME_LIST.put("产权证明", "T");
    }
}
