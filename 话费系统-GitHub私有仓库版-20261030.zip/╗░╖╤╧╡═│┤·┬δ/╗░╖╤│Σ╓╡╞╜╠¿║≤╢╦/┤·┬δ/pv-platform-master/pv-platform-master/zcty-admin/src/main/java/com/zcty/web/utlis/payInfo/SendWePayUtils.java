package com.zcty.web.utlis.payInfo;


import com.alibaba.fastjson2.JSONObject;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.zcty.common.config.LuckqunxinConfig;
import com.zcty.common.constant.PayConstants;
import com.zcty.common.utils.StringUtils;
import com.zcty.web.utlis.RandomString;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * 在这里统一调微信的支付接口,查询订单支付状态接口，发起退款接口，查询退款订单状态的接口
 */
public class SendWePayUtils {



    /**
     * 统一下单接口，获取prepay_id 预支付交易会话标识
     * @param param
     * @return
     */
    public static Map<String,String> transactions(Map<String,String> param,PayInfoParam payInfoParam){

        //统一下单接口需要的必要参数
        //商品描述
        String description = param.get(LuckqunxinConfig.PARAM_DESCRIPTION);
        //订单编号
        String out_trade_no = param.get(LuckqunxinConfig.PARAM_OUT_TRADE_NO);
        //订单实付金额
        String total = param.get(LuckqunxinConfig.PARAM_TOTAL);
        //购买的用户openid
        String openid = param.get(LuckqunxinConfig.PARAM_OPEN_ID);


        if(StringUtils.isEmpty(description)){
            throw new RuntimeException("商品描述不能为空");
        }
        if(StringUtils.isEmpty(out_trade_no)){
            throw new RuntimeException("订单编号不能为空");
        }
        if(StringUtils.isEmpty(total)){
            throw new RuntimeException("金额不能为空");
        }
        if(StringUtils.isEmpty(openid)){
            throw new RuntimeException("openid不能为空");
        }

        BigDecimal totalBig = new BigDecimal(total).multiply(new BigDecimal(100));
        Double totalInt = Double.parseDouble(totalBig.toString());

        Map<String,String> map = new HashMap<>();
        CloseableHttpClient httpClient = null;

        System.out.println(out_trade_no + "：微信订单下单开始");

        try {
            HttpPost httpPost = new HttpPost(LuckqunxinConfig.UNIFIED_ORDER_WEBSITE);

            //设置请求体
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ObjectMapper objectMapper = new ObjectMapper();

            ObjectNode rootNode = objectMapper.createObjectNode();
            rootNode.put("mchid",payInfoParam.getMchid())
                    .put("appid", payInfoParam.getWeixinAppId())
                    .put("description", description)
                    .put("notify_url", LuckqunxinConfig.payNotifyUrl+"/"+payInfoParam.getSupplierId())
                    .put("out_trade_no", out_trade_no);
            rootNode.putObject("amount")
                    .put("total", totalInt.intValue());
            rootNode.putObject("payer")
                    .put("openid", openid);
            objectMapper.writeValue(bos, rootNode);
            System.out.println("rootNode：" + rootNode);

            //随机字符串生成
            String nonceStr= RandomString.getRandomString(32);
            //时间戳10位数字
            String timestamp=System.currentTimeMillis()/1000+"";
            //签名
            String signature=getAuthorizationSignature("POST","/v3/pay/transactions/jsapi", timestamp ,nonceStr,bos.toString("UTF-8"),payInfoParam);
            //最终 authorization的值
            String authorization="WECHATPAY2-SHA256-RSA2048 "+
                    "mchid=\""+payInfoParam.getMchid()+"\","+
                    "nonce_str=\""+nonceStr+"\","+
                    "signature=\""+signature+"\","+
                    "timestamp=\""+timestamp+"\","+
                    "serial_no=\""+payInfoParam.getSerialNo()+"\"";
            System.out.println("authorization：" + authorization);

            httpPost.addHeader("Accept", "application/json");
            httpPost.addHeader("Content-type","application/json; charset=utf-8");
            //使用自身系统和应用的名称和版本等信息，组成自己独有的User-Agent,微信支付API v3很可能会拒绝处理无User-Agent 的请求。
            httpPost.addHeader("User-Agent",createUserAgent());
            //签名
            httpPost.addHeader("Authorization",authorization);

            System.out.println("bos：" + bos.toString("UTF-8"));
            httpPost.setEntity(new StringEntity(bos.toString("UTF-8"), "UTF-8"));

            //http客户端创建
            httpClient = HttpClients.createDefault();
            //发送请求
            CloseableHttpResponse response = httpClient.execute(httpPost);
            //调取服务的返回值200正常完成，其他可以去查回调代码
            int responseCode = response.getStatusLine().getStatusCode() ;
            System.out.println("responseCode：" + responseCode);
            //处理返回数据为字符串格式
            String bodyAsString = EntityUtils.toString(response.getEntity());
            System.out.println("bodyAsString：" + bodyAsString);
            JSONObject object = JSONObject.parseObject(bodyAsString);

            if (200 != responseCode) {

                map.put(LuckqunxinConfig.RESULT_CODE, "500");
                map.put(LuckqunxinConfig.RESULT_MSG, "数据异常，请刷新重试！");
            } else {

                String prepayId = object.getString(LuckqunxinConfig.RESULT_PREPAY_ID);
                String packageStr = LuckqunxinConfig.RESULT_PREPAY_ID + "=" +prepayId;
                String paySign = getRequestPaymentParam(timestamp, nonceStr, packageStr,payInfoParam);

                map.put(LuckqunxinConfig.RESULT_TIME_STAMP, timestamp);
                map.put(LuckqunxinConfig.RESULT_NONCE_STR, nonceStr);
                map.put(LuckqunxinConfig.RESULT_SIGN_TYPE, LuckqunxinConfig.RESULT_SIGN_TYPE_RSA);
                map.put(LuckqunxinConfig.RESULT_PACKAGE, packageStr);
                map.put(LuckqunxinConfig.RESULT_PAY_SIGN, paySign);
            }
        }catch (Exception e){
            e.printStackTrace();
            throw new RuntimeException("请求失败!");
        }finally {
            if(httpClient!=null){
                try {
                    System.out.println("结果：" + map.toString());
                    System.out.println(out_trade_no + "：微信订单下单结束");
                    httpClient.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return map;

    }

    /**
     * 获取签名
     * @return
     */
    public static String getAuthorizationSignature(String method,String url,String timeStamp ,String nonceStr,String requestBody,PayInfoParam payInfoParam){
        //拼接参数，按照顺序（不能乱）
//        HTTP请求方法\n
//        URL\n
//        请求时间戳\n
//        请求随机串\n
//        请求报文主体\n
        String param=method+"\n"+url+"\n"+timeStamp+"\n"+nonceStr+"\n"+requestBody+"\n";
        System.out.println("-----param--------"+param);
        String signature="";
        try {
            System.out.println("----------------privateKeyPath-------------------"+payInfoParam.getPrivateKeyPath());
            System.out.println("----------------publicKeyPath-------------------"+payInfoParam.getPublicKeyPath());
            SHA256withRSAUtils sha256withRSAUtils = new SHA256withRSAUtils(payInfoParam.getPrivateKeyPath(),payInfoParam.getPublicKeyPath());
            signature = sha256withRSAUtils.sign(param.getBytes("utf-8"));
        }catch (Exception e){
            e.printStackTrace();
        }
        return signature;
    }

    public static void main(String[] args) {
        PayInfoParam payInfoParam = new  PayInfoParam();
        payInfoParam.setPublicKeyPath("D:/payInfo/sw/apiclient_cert.pem");
        payInfoParam.setPrivateKeyPath("D:/payInfo/sw/apiclient_key.pem");
        String sign =  getAuthorizationSignature("", "","" ,"","", payInfoParam);
        System.out.println(sign);

    }


    /**
     * 订单查询
     * 需要调用查询接口的情况：
     *
     * • 当商户后台、网络、服务器等出现异常，商户系统最终未接收到支付通知。
     *
     * • 调用支付接口后，返回系统错误或未知交易状态情况。
     *
     * • 调用付款码支付API，返回USERPAYING的状态。
     *
     * • 调用关单或撤销接口API之前，需确认支付状态
     * @param orderNo
     * @return
     */
    public static Map<String,String>  checkTransactions(String orderNo,PayInfoParam payInfoParam){
        //返回参数给其他接口调用
        Map<String,String> map = new HashMap<>();
        CloseableHttpClient httpClient = null;
        System.out.println(orderNo + "：微信订单查询开始");
        try {
            //访问地址，例如
            //https://api.mch.weixin.qq.com/v3/pay/transactions/out-trade-no/1217752501201407033233368018?mchid=1230000109
            String url=LuckqunxinConfig.CHECK_ORDER_STATUS_OUT_TRADE_NO+orderNo+"?mchid="+payInfoParam.getMchid();
            //截取.com后面的字符串即/v3/pay/transactions/out-trade-no/1217752501201407033233368018?mchid=1230000109
            String signatureUrl=StringUtils.subLastUrl(url);
            HttpGet httpGet = new HttpGet(url);

            //随机字符串生成
            String nonceStr= RandomString.getRandomString(32);
            //时间戳10位数字
            String timestamp=System.currentTimeMillis()/1000+"";
            //签名
            String signature=getAuthorizationSignature(httpGet.getMethod(),signatureUrl, timestamp ,nonceStr,"",payInfoParam);
            //最终 authorization的值
            String authorization="WECHATPAY2-SHA256-RSA2048 "+
                    "mchid=\""+payInfoParam.getMchid()+"\","+
                    "nonce_str=\""+nonceStr+"\","+
                    "signature=\""+signature+"\","+
                    "timestamp=\""+timestamp+"\","+
                    "serial_no=\""+payInfoParam.getSerialNo()+"\"";
            System.out.println("authorization：" + authorization);

            //设置表头信息
            httpGet.addHeader("Accept", "application/json");
            httpGet.addHeader("Content-type","application/json; charset=utf-8");
            //使用自身系统和应用的名称和版本等信息，组成自己独有的User-Agent,微信支付API v3很可能会拒绝处理无User-Agent 的请求。
            httpGet.addHeader("User-Agent",createUserAgent());
            //签名
            httpGet.addHeader("Authorization",authorization);

            //http客户端创建
            httpClient = HttpClients.createDefault();
            //发送请求
            CloseableHttpResponse response = httpClient.execute(httpGet);

            //调取服务的返回值200正常完成，其他可以去查回调代码
            int responseCode = response.getStatusLine().getStatusCode() ;
            System.out.println("responseCode：" + responseCode);
            //处理返回数据为字符串格式
            String  bodyAsString = EntityUtils.toString(response.getEntity());
            System.out.println("bodyAsString：" + bodyAsString);
            JSONObject jsonObject=JSONObject.parseObject(bodyAsString);

            if (404 == responseCode || (400 == responseCode && "MCH_NOT_EXISTS".equals(jsonObject.get(LuckqunxinConfig.RESULT_CODE)))){

                map.put(LuckqunxinConfig.RESULT_CODE, "200");
                map.put(LuckqunxinConfig.RESULT_MSG, jsonObject.get(LuckqunxinConfig.RESULT_MSG).toString());
            } else if (200 != responseCode){
                map.put(LuckqunxinConfig.RESULT_CODE, "500");
                map.put(LuckqunxinConfig.RESULT_MSG, "数据异常，请刷新重试！");
            } else {
                //查看订单的状态
                String trade_state=(String)jsonObject.get(PayConstants.PAY_NOTIFY_TRADE_STATE);
                //订单状态的描述
                String trade_state_desc = (String)jsonObject.get(PayConstants.PAY_NOTIFY_TRADE_STATE_DESC);
                String successTime = jsonObject.getString(PayConstants.PAY_NOTIFY_SUCCESS_TIME);
                map.put(PayConstants.PAY_NOTIFY_TRADE_STATE, trade_state);
                map.put(PayConstants.PAY_NOTIFY_TRADE_STATE_DESC, trade_state_desc);
                map.put(PayConstants.PAY_NOTIFY_SUCCESS_TIME, successTime);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if(httpClient!=null){
                try {
                    System.out.println("结果：" + map.toString());
                    System.out.println(orderNo + "：微信订单查询结束");
                    httpClient.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        }

        return map;
    }


    /**
     * 申请退款接口,在这里就可以直接处理退款的业务了
     * @param param
     * @return
     */
    public static Map<String,String> refund(Map<String,String> param,PayInfoParam payInfoParam){

        //统一下单接口需要的必要参数
        //退款单号（后台创建，唯一）
        String out_refund_no=param.get("out_refund_no");
        //订单编号
        String out_trade_no=param.get("out_trade_no");
        //订单实付金额
        String total=param.get("total");

        if(StringUtils.isEmpty(out_trade_no)){
            throw new RuntimeException("订单编号不能为空");
        }
        if(StringUtils.isEmpty(total)){
            throw new RuntimeException("金额不能为空");
        }
        if(StringUtils.isEmpty(out_refund_no)){
            throw new RuntimeException("退款单号不能为空");
        }

        Map<String,String> map=new HashMap<>();
        CloseableHttpClient httpClient=null;
        try {
            HttpPost httpPost = new HttpPost(LuckqunxinConfig.weChatRefundUrl);

            //设置请求体
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ObjectMapper objectMapper = new ObjectMapper();

            ObjectNode rootNode = objectMapper.createObjectNode();
            rootNode.put("out_trade_no", out_trade_no)
                    .put("out_refund_no", out_refund_no)
                    .put("notify_url", LuckqunxinConfig.refundNotifyUrl);
            rootNode.putObject("amount")
                    .put("refund", Integer.valueOf(total))
                    .put("total", Integer.valueOf(total))
                    .put("currency", "CNY");

            objectMapper.writeValue(bos, rootNode);

            //随机字符串生成
            String nonceStr= RandomString.getRandomString(32);
            //时间戳10位数字
            String timestamp=System.currentTimeMillis()/1000+"";
            //签名
            String signature=getAuthorizationSignature("POST","/v3/refund/domestic/refunds", timestamp ,nonceStr,bos.toString("UTF-8"),payInfoParam);
            //最终 authorization的值
            String authorization="WECHATPAY2-SHA256-RSA2048 "+
                    "mchid=\""+payInfoParam.getMchid()+"\","+
                    "nonce_str=\""+nonceStr+"\","+
                    "signature=\""+signature+"\","+
                    "timestamp=\""+timestamp+"\","+
                    "serial_no=\""+payInfoParam.getSerialNo()+"\"";

//  mchid="1900009191",nonce_str="593BEC0C930BF1AFEB40B4A08C8FB242",signature="uOVRnA4qG/MNnYzdQxJanN+zU+lTgIcnU9BxGw5dKjK+VdEUz2FeIoC+D5sB/LN+nGzX3hfZg6r5wT1pl2ZobmIc6p0ldN7J6yDgUzbX8Uk3sD4a4eZVPTBvqNDoUqcYMlZ9uuDdCvNv4TM3c1WzsXUrExwVkI1XO5jCNbgDJ25nkT/c1gIFvqoogl7MdSFGc4W4xZsqCItnqbypR
// 3RuGIlR9h9vlRsy7zJR9PBI83X8alLDIfR1ukt1P7tMnmogZ0cuDY8cZsd8ZlCgLadmvej58SLsIkVxFJ8XyUgx9FmutKSYTmYtWBZ0+tNvfGmbXU7cob8
// H/4nLBiCwIUFluw==",timestamp="1554208460",serial_no="1DDE55AD98ED71D6EDD4A4A16996DE7B47773A8C"

            httpPost.addHeader("Accept", "application/json");
            httpPost.addHeader("Content-type","application/json; charset=utf-8");
            //使用自身系统和应用的名称和版本等信息，组成自己独有的User-Agent,微信支付API v3很可能会拒绝处理无User-Agent 的请求。
            httpPost.addHeader("User-Agent",createUserAgent());
            //签名
            httpPost.addHeader("Authorization",authorization);

            httpPost.setEntity(new StringEntity(bos.toString("UTF-8"), "UTF-8"));
            //http客户端创建
            httpClient = HttpClients.createDefault();
            //发送请求
            CloseableHttpResponse response = httpClient.execute(httpPost);
            //回调状态码
            int responseCode=response.getStatusLine().getStatusCode();
            String bodyAsString = EntityUtils.toString(response.getEntity());
            if(responseCode==200){
                //bodyAsString
//         {"amount":{"currency":"CNY","discount_refund":0,"from":[],"payer_refund":6,"payer_total":6,"refund":6,"settlement_refund":6,"settlement_total":6,"total":6},"channel":"ORIGINAL","create_time":"2022-08-02T17:17:42+08:00","funds_account":"AVAILABLE","out_refund_no":"TK20220802834458000","out_trade_no":"OD20220802130944017","promotion_detail":[],"refund_id":"50302002712022080223338966934","status":"PROCESSING","transaction_id":"4200001516202208026335607197","user_received_account":"农业银行借记卡0578"}
                JSONObject jsonObject=JSONObject.parseObject(bodyAsString);
                //退款状态SUCCESS：退款成功
                //CLOSED：退款关闭
                //PROCESSING：退款处理中
                //ABNORMAL：退款异常
                String status=(String)jsonObject.get("status");
                map.put("code","200");
                map.put("status",status);
            }else{
                JSONObject jsonObject=JSONObject.parseObject(bodyAsString);
//                {"code":"RESOURCE_NOT_EXISTS","message":"订单不存在"}
                String code= (String)jsonObject.get("code");
                String message= (String)jsonObject.get("message");
                if(StringUtils.isEmpty(code)){
                    code="";
                }
                if(StringUtils.isEmpty(message)){
                    message="";
                }
                String returnMsg=code+"-"+message;
                map.put("code","500");
                map.put("returnMsg",returnMsg);
            }
            //处理返回数据为字符串格式
       }catch (Exception e){
            e.printStackTrace();
            throw new RuntimeException("请求失败!");
        }finally {
            if(httpClient!=null){
                try {
                    httpClient.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return map;

    }

    /**
     * 根据我们系统的退款单号去查退款订单的状态
     * @param refundNo
     * @return
     */
    public static Map<String,String> checkRefund(String refundNo,PayInfoParam payInfoParam){
        Map<String,String> map=new HashMap<>();

        CloseableHttpClient httpClient=null;
        try {
            //访问地址，例如
            //https://api.mch.weixin.qq.com/v3/refund/domestic/refunds/1217752501201407033233368018
            String url= LuckqunxinConfig.CHECK_ORDER_STATUS_REFUND_NO+"/"+refundNo;
            String signatureUrl=StringUtils.subLastUrl(url);
            HttpGet httpGet = new HttpGet(url);

            //随机字符串生成
            String nonceStr= RandomString.getRandomString(32);
            //时间戳10位数字
            String timestamp=System.currentTimeMillis()/1000+"";
            //签名
            String signature=getAuthorizationSignature(httpGet.getMethod(),signatureUrl, timestamp ,nonceStr,"",payInfoParam);
            //最终 authorization的值
            String authorization="WECHATPAY2-SHA256-RSA2048 "+
                    "mchid=\""+payInfoParam.getMchid()+"\","+
                    "nonce_str=\""+nonceStr+"\","+
                    "signature=\""+signature+"\","+
                    "timestamp=\""+timestamp+"\","+
                    "serial_no=\""+payInfoParam.getSerialNo()+"\"";

//  mchid="1900009191",nonce_str="593BEC0C930BF1AFEB40B4A08C8FB242",signature="uOVRnA4qG/MNnYzdQxJanN+zU+lTgIcnU9BxGw5dKjK+VdEUz2FeIoC+D5sB/LN+nGzX3hfZg6r5wT1pl2ZobmIc6p0ldN7J6yDgUzbX8Uk3sD4a4eZVPTBvqNDoUqcYMlZ9uuDdCvNv4TM3c1WzsXUrExwVkI1XO5jCNbgDJ25nkT/c1gIFvqoogl7MdSFGc4W4xZsqCItnqbypR
// 3RuGIlR9h9vlRsy7zJR9PBI83X8alLDIfR1ukt1P7tMnmogZ0cuDY8cZsd8ZlCgLadmvej58SLsIkVxFJ8XyUgx9FmutKSYTmYtWBZ0+tNvfGmbXU7cob8
// H/4nLBiCwIUFluw==",timestamp="1554208460",serial_no="1DDE55AD98ED71D6EDD4A4A16996DE7B47773A8C"

            httpGet.addHeader("Accept", "application/json");
            httpGet.addHeader("Content-type","application/json; charset=utf-8");
            //使用自身系统和应用的名称和版本等信息，组成自己独有的User-Agent,微信支付API v3很可能会拒绝处理无User-Agent 的请求。
            httpGet.addHeader("User-Agent",createUserAgent());
            //签名
            httpGet.addHeader("Authorization",authorization);

            //http客户端创建
            httpClient = HttpClients.createDefault();
            //发送请求
            CloseableHttpResponse response = httpClient.execute(httpGet);
            //处理返回数据为字符串格式
            String  bodyAsString = EntityUtils.toString(response.getEntity());

        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if(httpClient!=null){
                try {
                    httpClient.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
       return map;
    }

    //生成用户端的用户信息,用
    public static String createUserAgent(){
        return "Apache Tomcat/8.5.34 Ubuntu 20.04.4 LTS (GNU/Linux 5.4.0-100-generic x86_64)";
    }

    /**
     * 小程序唤起支付二次签名
     * @param timestamp
     * @param nonceStr
     * @param packageStr
     * @return
     */
    public static String getRequestPaymentParam(String timestamp,String nonceStr,String packageStr,PayInfoParam payInfoParam){

//        参与签名字段及格式：
//        小程序appId
//        时间戳
//        随机字符串
//        订单详情扩展字符串
//        String param=CommonMallConfig.weixinAppId+"\n"+timestamp+"\n"+nonceStr+"\n"+packageStr+"\n";
        String param=payInfoParam.getWeixinAppId()+"\n"+timestamp+"\n"+nonceStr+"\n"+packageStr+"\n";
        String signature="";
        try {
            SHA256withRSAUtils sha256withRSAUtils = new SHA256withRSAUtils(payInfoParam.getPrivateKeyPath(),payInfoParam.getPublicKeyPath());
            signature = sha256withRSAUtils.sign(param.getBytes("utf-8"));
        }catch (Exception e){
            e.printStackTrace();
        }
        return signature;

    }

//    public static void main(String[] args) throws Exception {
//        Map<String,String> map=new HashMap<>();
//        map.put("description","description");
//        map.put("out_trade_no","out_trade_no");
//        map.put("total","100");
//        map.put("out_refund_no","out_refund_no");
//        transactions(map);
//          refund(map);
//        checkRefund("134654321321");
//        checkTransactions("134654321321");
//        System.out.println(getRequestPaymentParam("1658910050","ffX20omYe6COpXrh64b1l2vs8dD6xG6M","wx27162054316005970d084077da565b0000"));

//        checkTransactions("OD20220728217642000");
//        String message="POST\n" +
//                "/v3/pay/transactions/jsapi\n" +
//                "1658371923\n" +
//                "n6WABE81p0Wd6ENDIf6zk81p7D9rXf044\n" +
//                "{\"mchid\":\"11111111\",\"appid\":\"wx19851ae914821e64\",\"description\":\"description\",\"notify_url\":\"https://commonmall.piggogo.cn/weChat/pay/payNotifyUrl\",\"out_trade_no\":\"out_trade_no\",\"amount\":{\"total\":100},\"payer\":{\"openid\":\"openid\"}}";
//        String result=SHA256withRSAUtils.sign(message.getBytes());
//        System.out.println(result);
//          checkRefund("TK20220728128879000");
//        System.out.println(SHA256withRSAUtils.checkSign(message,result));

        //拼接参数，按照顺序（不能乱）
//        HTTP请求方法\n
//        URL\n
//        请求时间戳\n
//        请求随机串\n
//        请求报文主体\n

//        System.out.println(DateUtils.parseDate("2022-08-02T17:17:42+08:00"));
//    }
}
