package com.zcty.business.service;


import com.zcty.business.domain.OnlineMessage;
import com.zcty.business.domain.OnlineMessageDTO;
import com.zcty.business.domain.OnlineMessageShow;
import com.zcty.common.core.domain.AjaxResult;

import java.util.List;

/**
 * 在线留言 服务层
 * 
 * @author liuruibin
 * @date 2022-11-28
 */
public interface IOnlineMessageService 
{
	/**
     * 查询在线留言信息
     * 
     * @param id 在线留言ID
     * @return 在线留言信息a
     */
	public OnlineMessage selectOnlineMessageById(String id);
	
	/**
     * 查询在线留言列表
     * 
     * @param onlineMessage 在线留言信息
     * @return 在线留言集合
     */
	public List<OnlineMessage> selectOnlineMessageList(OnlineMessage onlineMessage);
	/**
	 * 查询在线留言列表
	 *
	 * @param onlineMessage 在线留言信息
	 * @return 在线留言集合
	 */
	public List<OnlineMessage> selectOnlineMessageShowList(OnlineMessage onlineMessage);


	
	/**
     * 新增在线留言
     * @return 结果
     */
	public AjaxResult insertOnlineMessage(OnlineMessageDTO onlineMessageDTO, String openId);
	
	/**
     * 修改在线留言
     * 
     * @param onlineMessage 在线留言信息
     * @return 结果
     */
	public int updateOnlineMessage(OnlineMessage onlineMessage);
		
	/**
     * 删除在线留言信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteOnlineMessageByIds(String ids);

	/**
	 * 查询小程序我的留言建议分页列表
	 * @param openId
	 * @return
	 */
	public List<OnlineMessageShow> selectOnlineMessageShowWxList(String openId);
	
}
