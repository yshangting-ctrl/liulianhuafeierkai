package com.zcty.business.service.impl;

import java.util.List;

import com.zcty.business.domain.SupplierCapitalLogVo;
import com.zcty.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zcty.business.mapper.SupplierCapitalLogMapper;
import com.zcty.business.domain.SupplierCapitalLog;
import com.zcty.business.service.ISupplierCapitalLogService;

/**
 * 代理商资金使用记录Service业务层处理
 * 
 * @author ruoyi
 * @date 2024-06-24
 */
@Service
public class SupplierCapitalLogServiceImpl implements ISupplierCapitalLogService 
{
    @Autowired
    private SupplierCapitalLogMapper supplierCapitalLogMapper;

    /**
     * 查询代理商资金使用记录
     * 
     * @param id 代理商资金使用记录主键
     * @return 代理商资金使用记录
     */
    @Override
    public SupplierCapitalLog selectSupplierCapitalLogById(String id)
    {
        return supplierCapitalLogMapper.selectSupplierCapitalLogById(id);
    }

    /**
     * 查询代理商资金使用记录列表
     * 
     * @param supplierCapitalLog 代理商资金使用记录
     * @return 代理商资金使用记录
     */
    @Override
    public List<SupplierCapitalLog> selectSupplierCapitalLogList(SupplierCapitalLog supplierCapitalLog)
    {
        return supplierCapitalLogMapper.selectSupplierCapitalLogList(supplierCapitalLog);
    }

    /**
     * 新增代理商资金使用记录
     * 
     * @param supplierCapitalLog 代理商资金使用记录
     * @return 结果
     */
    @Override
    public int insertSupplierCapitalLog(SupplierCapitalLog supplierCapitalLog)
    {
        supplierCapitalLog.setCreateTime(DateUtils.getNowDate());
        return supplierCapitalLogMapper.insertSupplierCapitalLog(supplierCapitalLog);
    }

    /**
     * 修改代理商资金使用记录
     * 
     * @param supplierCapitalLog 代理商资金使用记录
     * @return 结果
     */
    @Override
    public int updateSupplierCapitalLog(SupplierCapitalLog supplierCapitalLog)
    {
        return supplierCapitalLogMapper.updateSupplierCapitalLog(supplierCapitalLog);
    }

    /**
     * 批量删除代理商资金使用记录
     * 
     * @param ids 需要删除的代理商资金使用记录主键
     * @return 结果
     */
    @Override
    public int deleteSupplierCapitalLogByIds(String[] ids)
    {
        return supplierCapitalLogMapper.deleteSupplierCapitalLogByIds(ids);
    }

    /**
     * 删除代理商资金使用记录信息
     * 
     * @param id 代理商资金使用记录主键
     * @return 结果
     */
    @Override
    public int deleteSupplierCapitalLogById(String id)
    {
        return supplierCapitalLogMapper.deleteSupplierCapitalLogById(id);
    }

    /**
     * 查询前端显示的列表信息
     * @param supplierCapitalLogVo
     * @return
     */
    @Override
    public  List<SupplierCapitalLogVo> selectSupplierCapitalLogVoList(SupplierCapitalLogVo supplierCapitalLogVo) {
        return supplierCapitalLogMapper.selectSupplierCapitalLogVoList(supplierCapitalLogVo);
    }
}
