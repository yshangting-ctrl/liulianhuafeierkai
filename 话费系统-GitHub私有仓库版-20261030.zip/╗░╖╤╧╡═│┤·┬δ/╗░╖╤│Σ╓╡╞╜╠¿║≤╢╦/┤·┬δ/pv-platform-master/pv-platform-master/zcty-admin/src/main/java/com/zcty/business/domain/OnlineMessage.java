package com.zcty.business.domain;



import java.io.Serializable;
import java.util.Date;

/**
 * 在线留言表 t_online_message
 * 
 * @author liuruibin
 * @date 2022-11-28
 */

public class OnlineMessage implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	/** 记录ID */
	private String id;
	/** 标题 */
	private String title;
	/** 留言内容 富文本 */
	private String imageText;
	/** 微信号 */
	private String contacts;
	/** 联系电话 */
	private String contactNumber;

	/** 订单号 */
	private String orderNo;
	/** 产品名称 */
	private String productName;


	/** 备注 - 后台填写 */
	private String remarks;
	/** 是否已备注 */
	private Integer checkRemarks;
	/** 状态 0：正常、1：删除 */
	private Integer status;
	/** 创建时间 */
	private Date createTime;
	/** 创建人 */
	private String createBy;
	/** 更新时间 */
	private Date updateTime;
	/** 更新人 */
	private String updateBy;

	/** 数据来源的openId */
	private String openId;

	/** 数据来源的数据来源的openI对应用户表的userId */
	private String userId;



	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getImageText() {
		return imageText;
	}

	public void setImageText(String imageText) {
		this.imageText = imageText;
	}

	public String getContacts() {
		return contacts;
	}

	public void setContacts(String contacts) {
		this.contacts = contacts;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Integer getCheckRemarks() {
		return checkRemarks;
	}

	public void setCheckRemarks(Integer checkRemarks) {
		this.checkRemarks = checkRemarks;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}

	public String getOpenId() {
		return openId;
	}

	public void setOpenId(String openId) {
		this.openId = openId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}
}
