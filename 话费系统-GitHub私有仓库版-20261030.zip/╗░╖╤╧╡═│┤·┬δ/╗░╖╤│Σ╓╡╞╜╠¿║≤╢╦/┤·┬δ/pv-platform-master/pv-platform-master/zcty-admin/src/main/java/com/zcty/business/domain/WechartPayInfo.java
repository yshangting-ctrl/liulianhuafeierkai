package com.zcty.business.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.zcty.common.annotation.Excel;
import com.zcty.common.core.domain.BaseEntity;

/**
 * 微信支付信息对象 t_wechart_pay_info
 * 
 * @author lsw
 * @date 2024-05-30
 */
public class WechartPayInfo extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 主键id */
    private String id;

    /** 商户支付证书序列号 */
    @Excel(name = "商户支付证书序列号")
    private String serialNo;

    /** 商户号名称 */
    @Excel(name = "商户号名称")
    private String payName;

    /** api-v3秘钥 */
    @Excel(name = "api-v3秘钥")
    private String partnerKey;

    /** 商户id */
    @Excel(name = "商户id")
    private String mchid;

    /** 商户V3私钥证书 */
    @Excel(name = "商户V3私钥证书")
    private String privateKeyPath;

    /** 商户V3公钥证书 */
    @Excel(name = "商户V3公钥证书")
    private String publicKeyPath;

    /** 代理商id */
    @Excel(name = "代理商id")
    private String supplierId;

    /** 状态开启 0未开启 1已开启 */
    @Excel(name = "状态开启 0未开启 1已开启")
    private Integer useStatus;

    /** 删除标识 0 未删除 1已删除 */
    private Integer delFlag;

    private String weixinAppId;

    public void setId(String id) 
    {
        this.id = id;
    }

    public String getId() 
    {
        return id;
    }
    public void setSerialNo(String serialNo) 
    {
        this.serialNo = serialNo;
    }

    public String getSerialNo() 
    {
        return serialNo;
    }
    public void setPayName(String payName) 
    {
        this.payName = payName;
    }

    public String getPayName() 
    {
        return payName;
    }
    public void setPartnerKey(String partnerKey) 
    {
        this.partnerKey = partnerKey;
    }

    public String getPartnerKey() 
    {
        return partnerKey;
    }
    public void setMchid(String mchid) 
    {
        this.mchid = mchid;
    }

    public String getMchid() 
    {
        return mchid;
    }
    public void setPrivateKeyPath(String privateKeyPath) 
    {
        this.privateKeyPath = privateKeyPath;
    }

    public String getPrivateKeyPath() 
    {
        return privateKeyPath;
    }
    public void setPublicKeyPath(String publicKeyPath) 
    {
        this.publicKeyPath = publicKeyPath;
    }

    public String getPublicKeyPath() 
    {
        return publicKeyPath;
    }
    public void setSupplierId(String supplierId) 
    {
        this.supplierId = supplierId;
    }

    public String getSupplierId() 
    {
        return supplierId;
    }
    public void setUseStatus(Integer useStatus) 
    {
        this.useStatus = useStatus;
    }

    public Integer getUseStatus() 
    {
        return useStatus;
    }
    public void setDelFlag(Integer delFlag) 
    {
        this.delFlag = delFlag;
    }

    public Integer getDelFlag() 
    {
        return delFlag;
    }

    public String getWeixinAppId() {
        return weixinAppId;
    }

    public void setWeixinAppId(String weixinAppId) {
        this.weixinAppId = weixinAppId;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("serialNo", getSerialNo())
            .append("payName", getPayName())
            .append("partnerKey", getPartnerKey())
            .append("mchid", getMchid())
            .append("privateKeyPath", getPrivateKeyPath())
            .append("publicKeyPath", getPublicKeyPath())
            .append("supplierId", getSupplierId())
            .append("useStatus", getUseStatus())
            .append("createTime", getCreateTime())
            .append("delFlag", getDelFlag())
            .toString();
    }
}
