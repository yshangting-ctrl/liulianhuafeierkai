package com.zcty.api;


import com.zcty.business.domain.HomeBanner;
import com.zcty.business.platformUtils.AbstractPlacePlatformBusiness;
import com.zcty.business.platformUtils.AbstractPlacePlatformJipu;
import com.zcty.business.service.IHomeBannerService;
import com.zcty.common.config.RuoYiConfig;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.utils.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 产品Controller
 *
 * @author lsw
 * @date 2024-03-13
 */
@RestController
@RequestMapping("/api/homeBanner")
public class HomeBannerApiController {

    @Autowired
    private IHomeBannerService homeBannerService;

    @Autowired
    private AbstractPlacePlatformJipu abstractPlacePlatformJipu;

    @PostMapping("/list")
    public AjaxResult list(){
        List<HomeBanner> list = homeBannerService.selectHomeBannerApiList();
        list.forEach(c->{
            if(!StringUtils.isEmpty(c.getFileUrl())){
                c.setFileUrl( RuoYiConfig.getPicPath()+c.getFileUrl());
            }
        });
        return AjaxResult.success(list);
    }

    @PostMapping("/test")
    public AjaxResult test(String activityProductId,String phone,String orderNo){
        AbstractPlacePlatformBusiness abstractPlacePlatformBusiness = abstractPlacePlatformJipu;
        AjaxResult ajaxResult =abstractPlacePlatformBusiness.createPlatformBusiness(activityProductId,phone,orderNo);

        return ajaxResult;
    }

}
