package com.zcty.business.domain;

import com.zcty.common.core.domain.BaseEntity;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 订单详情表 t_order_detal
 * 
 * @author liuruibin
 * @date 2022-07-25
 */
public class OrderDetail extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** 详情ID */
	private String detId;
	/** 订单ID */
	private String orderId;
	/** 商品ID */
	private String goodsId;
	/** 商品数量 */
	private Integer goodsNum;
	/** 单价 */
	private BigDecimal goodsPrice;
	/** 总金额 */
	private BigDecimal totalPrice;
	/**商品类型 1 话费商品 2 流量商品 */
	private Integer goodsType;
	/** 商品编号 */
	private String commonSn;
	/** 商品名称 */
	private String commonName;
	/** 商品副标题 */
	private String commonDes;
	/**流量商品标签 */
	private String productTitle;
	/** 创建时间 */
	private Date createTime;


	public String getDetId() {
		return detId;
	}

	public void setDetId(String detId) {
		this.detId = detId;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getGoodsId() {
		return goodsId;
	}

	public void setGoodsId(String goodsId) {
		this.goodsId = goodsId;
	}

	public Integer getGoodsNum() {
		return goodsNum;
	}

	public void setGoodsNum(Integer goodsNum) {
		this.goodsNum = goodsNum;
	}

	public BigDecimal getGoodsPrice() {
		return goodsPrice;
	}

	public void setGoodsPrice(BigDecimal goodsPrice) {
		this.goodsPrice = goodsPrice;
	}

	public BigDecimal getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(BigDecimal totalPrice) {
		this.totalPrice = totalPrice;
	}


	public String getCommonSn() {
		return commonSn;
	}

	public void setCommonSn(String commonSn) {
		this.commonSn = commonSn;
	}

	public String getCommonName() {
		return commonName;
	}

	public void setCommonName(String commonName) {
		this.commonName = commonName;
	}

	public String getCommonDes() {
		return commonDes;
	}

	public void setCommonDes(String commonDes) {
		this.commonDes = commonDes;
	}

	public String getProductTitle() {
		return productTitle;
	}

	public void setProductTitle(String productTitle) {
		this.productTitle = productTitle;
	}

	@Override
	public Date getCreateTime() {
		return createTime;
	}

	@Override
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Integer getGoodsType() {
		return goodsType;
	}

	public void setGoodsType(Integer goodsType) {
		this.goodsType = goodsType;
	}

	public String toString() {
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
            .append("detId", getDetId())
            .append("orderId", getOrderId())
            .append("goodsId", getGoodsId())
            .append("goodsNum", getGoodsNum())
            .append("goodsPrice", getGoodsPrice())
            .append("totalPrice", getTotalPrice())
            .append("commonSn", getCommonSn())
            .append("commonName", getCommonName())
            .append("createTime", getCreateTime())
            .toString();
    }
}
