package com.zcty.business.controller;

import com.zcty.business.domain.Order;
import com.zcty.business.domain.OrderShippedInfo;
import com.zcty.business.domain.OrderVO;
import com.zcty.business.service.IOrderService;
import com.zcty.common.annotation.Log;
import com.zcty.common.core.controller.BaseController;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.core.page.TableDataInfo;
import com.zcty.common.enums.BusinessType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import java.util.List;
/**
 * 订单 信息操作处理
 * 
 * @author liuruibin
 * @date 2022-07-25
 */
@Controller
@RequestMapping("/business/order")
public class OrderController extends BaseController
{
//    private String prefix = "business/order";
	
	@Autowired
	private IOrderService orderService;
	

	
	/**
	 * 查询订单列表
	 */
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(Order order)
	{
		startPage();
        List<OrderVO> list = orderService.selectOrderList(order);
		return getDataTable(list);
	}

//	/**
//	 * 订单详情
//	 */
//	@GetMapping("/orderInfo/{orderId}")
//	public String edit(@PathVariable("orderId") String orderId, ModelMap mmap)
//	{
//		OrderInfoVO order = orderService.selectOrderInfoVOById(orderId);
//		mmap.put("order", order);
//	    return prefix + "/orderInfo";
//	}

//	/**
//	 * 发货设置
//	 * @return
//	 */
//	@GetMapping("/orderShipped/{orderId}")
//	public String orderShipped(@PathVariable("orderId") String orderId, ModelMap mmap){
//		OrderInfoVO order = orderService.selectOrderInfoVOById(orderId);
//		mmap.put("order", order);
//		return prefix + "/orderShipped";
//	}

	/**
	 * 待发货订单列表
	 * @return
	 */
	@PostMapping("/toBeDeliveredList")
	@ResponseBody
	public TableDataInfo selectOrderListByToBeDelivered(Order order){
		startPage();
		List<OrderVO> list = orderService.selectOrderListByToBeDelivered(order);
		return getDataTable(list);
	}
	
	/**
	 * 编辑订单发货信息 -- 订单编号、快递单号、快递备注
	 */
	@Log(title = "编辑订单发货信息", businessType = BusinessType.UPDATE)
	@PostMapping("/editOrderSend")
	@ResponseBody
	public AjaxResult editOrderSend(@Validated OrderShippedInfo orderShippedInfo)
	{		
		return orderService.editOrderSend(orderShippedInfo);
	}

	/**
	 * 获取订单发货信息
	 * @param orderNo
	 * @return
	 */
	@PostMapping("/queryShippedInfo")
	@ResponseBody
	public AjaxResult queryOrderShippedInfo(String orderNo){
		return orderService.queryOrderShippedInfo(orderNo);
	}

}
