package com.zcty.pv.service;

import java.util.List;
import java.util.Map;

import com.zcty.pv.domain.PubFile;
import org.springframework.web.multipart.MultipartFile;

/**
 * 通用文件Service接口
 * 
 * @author luohui
 * @date 2022-11-20
 */
public interface IPubFileService 
{
    /**
     * 查询通用文件
     * 
     * @param id 通用文件主键
     * @return 通用文件
     */
    public PubFile selectPubFileById(Long id);

    /**
     * 查询通用文件列表
     * 
     * @param pubFile 通用文件
     * @return 通用文件集合
     */
    public List<PubFile> selectPubFileList(PubFile pubFile);

    /**
     * 新增通用文件
     * 
     * @param pubFile 通用文件
     * @return 结果
     */
    public int insertPubFile(PubFile pubFile);

    /**
     * 修改通用文件
     * 
     * @param pubFile 通用文件
     * @return 结果
     */
    public int updatePubFile(PubFile pubFile);

    /**
     * 批量删除通用文件
     * 
     * @param ids 需要删除的通用文件主键集合
     * @return 结果
     */
    public int deletePubFileByIds(Long[] ids);

    /**
     * 删除通用文件信息
     * 
     * @param id 通用文件主键
     * @return 结果
     */
    public int deletePubFileById(Long id);

    public int uploadFiles(MultipartFile[] files, PubFile pubFile);

    public int uploadFile(MultipartFile file);

    /**
     * 初始化文件列表
     * @param bizId
     * @param bizKey
     * @param files
     * @return
     */
    public int genDefualtFiles(Long bizId, String bizKey, Map<String, String> files);

    /**
     * 检查文件名称对应的文件是否存在
     * @param bizId
     * @param bizKey
     * @param files
     * @return
     */
    public int checkFileExit(Long bizId, String bizKey, Map<String, String> files);
}
