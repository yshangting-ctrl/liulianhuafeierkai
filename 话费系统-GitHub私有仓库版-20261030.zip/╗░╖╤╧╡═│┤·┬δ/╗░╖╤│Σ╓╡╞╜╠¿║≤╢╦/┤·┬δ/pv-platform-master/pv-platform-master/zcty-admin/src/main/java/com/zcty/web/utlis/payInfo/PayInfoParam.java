package com.zcty.web.utlis.payInfo;


/**
 * 支付发起实体类
 */
public class PayInfoParam {

    /** 商户id*/
    public String mchid;
    /** 证书序列号*/
    public String serialNo;
    /** 公众号id*/
    public String weixinAppId;
    /** 证书私玥apiclient_key.pem*/
    public String privateKeyPath;
    /** 证书公玥apiclient_cert.pem*/
    public String publicKeyPath;
    /** 代理商id*/
    public String supplierId;

    /** api-v3秘钥 */
    private String partnerKey;


    public String getMchid() {
        return mchid;
    }

    public void setMchid(String mchid) {
        this.mchid = mchid;
    }

    public String getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(String serialNo) {
        this.serialNo = serialNo;
    }

    public String getWeixinAppId() {
        return weixinAppId;
    }

    public void setWeixinAppId(String weixinAppId) {
        this.weixinAppId = weixinAppId;
    }

    public String getPrivateKeyPath() {
        return privateKeyPath;
    }

    public void setPrivateKeyPath(String privateKeyPath) {
        this.privateKeyPath = privateKeyPath;
    }

    public String getPublicKeyPath() {
        return publicKeyPath;
    }

    public void setPublicKeyPath(String publicKeyPath) {
        this.publicKeyPath = publicKeyPath;
    }

    public String getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(String supplierId) {
        this.supplierId = supplierId;
    }

    public String getPartnerKey() {
        return partnerKey;
    }

    public void setPartnerKey(String partnerKey) {
        this.partnerKey = partnerKey;
    }
}
