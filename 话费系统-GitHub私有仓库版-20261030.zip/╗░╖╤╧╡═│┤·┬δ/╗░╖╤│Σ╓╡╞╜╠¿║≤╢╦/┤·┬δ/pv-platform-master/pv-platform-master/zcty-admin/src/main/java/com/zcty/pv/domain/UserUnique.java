package com.zcty.pv.domain;


import java.io.Serializable;

/**
 * 用户唯一编号记录表 t_user_unique
 * 
 * @author liuruibin
 * @date 2020-12-10
 */
public class UserUnique implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	/** 主键id */
	private String id;

	public void setId(String id) 
	{
		this.id = id;
	}

	public String getId() 
	{
		return id;
	}


}
