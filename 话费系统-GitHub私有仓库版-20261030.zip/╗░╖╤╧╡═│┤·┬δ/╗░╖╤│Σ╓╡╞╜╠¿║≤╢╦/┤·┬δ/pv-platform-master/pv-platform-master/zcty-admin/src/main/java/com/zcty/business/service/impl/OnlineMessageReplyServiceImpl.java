package com.zcty.business.service.impl;


import com.zcty.business.domain.OnlineMessage;
import com.zcty.business.domain.OnlineMessageReply;
import com.zcty.business.mapper.OnlineMessageReplyMapper;
import com.zcty.business.service.IOnlineMessageReplyService;
import com.zcty.business.service.IOnlineMessageService;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.core.text.Convert;
import com.zcty.common.utils.SecurityUtils;
import com.zcty.common.utils.StringUtils;
import com.zcty.web.utlis.IdGen;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * 留言回复 服务层实现
 * 
 * @author liuruibin
 * @date 2023-03-10
 */
@Service
public class OnlineMessageReplyServiceImpl implements IOnlineMessageReplyService
{
	@Autowired
	private OnlineMessageReplyMapper onlineMessageReplyMapper;
	@Autowired
	private IOnlineMessageService onlineMessageService;
	/**
     * 查询留言回复信息
     * 
     * @param id 留言回复ID
     * @return 留言回复信息
     */
    @Override
	public OnlineMessageReply selectOnlineMessageReplyById(String id)
	{
	    return onlineMessageReplyMapper.selectOnlineMessageReplyById(id);
	}
	
	/**
     * 查询留言回复列表
     * 
     * @param onlineMessageReply 留言回复信息
     * @return 留言回复集合
     */
	@Override
	public List<OnlineMessageReply> selectOnlineMessageReplyList(OnlineMessageReply onlineMessageReply)
	{
	    return onlineMessageReplyMapper.selectOnlineMessageReplyList(onlineMessageReply);
	}
	
    /**
     * 新增留言回复
     * 
     * @param onlineMessageReply 留言回复信息
     * @return 结果
     */
	@Override
	public AjaxResult insertOnlineMessageReply(OnlineMessageReply onlineMessageReply)
	{
	    //数据校验
		String messageId = onlineMessageReply.getMessageId();
		String replyText = onlineMessageReply.getReplyText();
		if(StringUtils.isEmpty(messageId)){
			return AjaxResult.error("未找到回复的信息id，请刷新重试");
		}
		if(StringUtils.isEmpty(replyText)){
			return AjaxResult.error("请输入回复内容!");
		}
		//回复人
		String createBy = SecurityUtils.getNickname();
        //数据填充
		String id = IdGen.uuid();
		Date date =new Date();
		onlineMessageReply.setCreateBy(createBy);
		onlineMessageReply.setCreateTime(date);
		onlineMessageReply.setDelFlag(0);
		onlineMessageReply.setId(id);

		//变更为已回复
		OnlineMessage onlineMessage =onlineMessageService.selectOnlineMessageById(messageId);
		if(onlineMessage!=null){
			onlineMessage.setCheckRemarks(1);
			onlineMessageService.updateOnlineMessage(onlineMessage);
		}
	    return AjaxResult.switchOne(onlineMessageReplyMapper.insertOnlineMessageReply(onlineMessageReply));
	}
	
	/**
     * 修改留言回复
     * 
     * @param onlineMessageReply 留言回复信息
     * @return 结果
     */
	@Override
	public synchronized AjaxResult updateOnlineMessageReply(OnlineMessageReply onlineMessageReply)
	{
		String id = onlineMessageReply.getId();
		if (StringUtils.isEmpty(id)){
			onlineMessageReply.setId(IdGen.uuid());
			onlineMessageReply.setCreateBy(SecurityUtils.getNickname());
			onlineMessageReply.setCreateTime(new Date());
			onlineMessageReply.setDelFlag(0);
			return AjaxResult.switchOne(onlineMessageReplyMapper.insertOnlineMessageReply(onlineMessageReply));
		}else{
			onlineMessageReply.setCreateBy(SecurityUtils.getNickname());
			onlineMessageReply.setCreateTime(new Date());
			onlineMessageReply.setDelFlag(0);
			return AjaxResult.switchOne(onlineMessageReplyMapper.updateOnlineMessageReply(onlineMessageReply));
		}
	}

	/**
     * 删除留言回复对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteOnlineMessageReplyByIds(String ids)
	{
		return onlineMessageReplyMapper.deleteOnlineMessageReplyByIds(Convert.toStrArray(ids));
	}

}
