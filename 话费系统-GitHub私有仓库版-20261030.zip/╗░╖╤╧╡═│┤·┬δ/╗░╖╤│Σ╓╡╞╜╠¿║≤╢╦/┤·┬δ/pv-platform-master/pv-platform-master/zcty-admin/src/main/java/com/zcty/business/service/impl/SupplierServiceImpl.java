package com.zcty.business.service.impl;


import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.zcty.business.domain.SupplierCapital;
import com.zcty.business.service.ISupplierCapitalService;
import com.zcty.business.service.NumberService;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.core.domain.entity.AgentUser;
import com.zcty.common.utils.SecurityUtils;
import com.zcty.common.utils.StringUtils;
import com.zcty.system.service.ISysUserService;
import com.zcty.web.utlis.IdGen;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zcty.business.mapper.SupplierMapper;
import com.zcty.business.domain.Supplier;
import com.zcty.business.service.ISupplierService;
/**
 * supplierService业务层处理
 * 
 * @author lsw
 * @date 2024-03-09
 */
@Service
public class SupplierServiceImpl implements ISupplierService 
{
    @Autowired
    private SupplierMapper supplierMapper;

    @Autowired
    private NumberService numberService;

    @Autowired
    private ISysUserService sysUserService;
    @Autowired
    private ISupplierCapitalService supplierCapitalService;

    /**
     * 查询supplier
     * 
     * @param id supplier主键
     * @return supplier
     */
    @Override
    public Supplier selectSupplierById(String id)
    {
        return supplierMapper.selectSupplierById(id);
    }

    /**
     * 查询supplier列表
     * 
     * @param supplier supplier
     * @return supplier
     */
    @Override
    public List<Supplier> selectSupplierList(Supplier supplier)
    {
        return supplierMapper.selectSupplierList(supplier);
    }

    /**
     * 新增supplier
     * 
     * @param supplier supplier
     * @return 结果
     */
    @Override
    public AjaxResult insertSupplier(Supplier supplier)
    {

        String appId = supplier.getAppId();
        if(StringUtils.isEmpty(appId)){
           return AjaxResult.error("请输入公众号id");
        }
        String supName = supplier.getSupName();
        if(StringUtils.isEmpty(supName)){
            return AjaxResult.error("请输入代理商名称");
        }
        String contactPeople = supplier.getContactPeople();
        if(StringUtils.isEmpty(contactPeople)){
            return AjaxResult.error("请输入联系人");
        }
        String phone = supplier.getPhone();
        if(StringUtils.isEmpty(phone)){
            return AjaxResult.error("请输入联系号码");
        }
        String userName = supplier.getUserName();
        if(StringUtils.isEmpty(userName)){
            return AjaxResult.error("请输入代理商登陆账号");
        }

        //先查询改用户名是否已经被占用
        AgentUser agentUserCheckName = sysUserService.checkAgentUserNameUnique(userName);
        if(agentUserCheckName!=null){
            return AjaxResult.error("代理商用户名已使用么，请重新输入");
        }

        Date date =new Date();
        String createBy = SecurityUtils.getNickname();
        String busNo =  numberService.getYHNumber();
        numberService.updateNumber(busNo);
        supplier.setSupNo(busNo);
        String id = IdGen.uuid();
        supplier.setId(id);
        supplier.setCreateTime(date);
        supplier.setCreateBy(createBy);
        supplier.setDelFlag(0);

        //生成代理商登陆用户
        AgentUser agentUser = new AgentUser();
        agentUser.setCreateBy(createBy);
        agentUser.setCreateTime(date);
        agentUser.setNickName(contactPeople);
        agentUser.setStatus("0");
        agentUser.setPhonenumber(phone);
        agentUser.setDelFlag("0");
        //生成密码
        String password = SecurityUtils.encryptPassword("Aa123456");
        agentUser.setPassword(password);
        agentUser.setUserName(userName);
        agentUser.setSupplierId(id);
        agentUser.setUserId(0l);
        sysUserService.insertAgentUser(agentUser);

        SupplierCapital supplierCapital = new SupplierCapital();
        supplierCapital.setId(IdGen.uuid());
        supplierCapital.setCapitalTotal(BigDecimal.ZERO);
        supplierCapital.setDelFlag(0);
        supplierCapital.setSupplierId(id);
        supplierCapital.setCreateTime(date);
        supplierCapital.setUpdateTime(date);
        supplierCapitalService.insertSupplierCapital(supplierCapital);

        return AjaxResult.switchOne(supplierMapper.insertSupplier(supplier));
    }

    /**
     * 修改supplier
     * 
     * @param supplier supplier
     * @return 结果
     */
    @Override
    public int updateSupplier(Supplier supplier)
    {
        return supplierMapper.updateSupplier(supplier);
    }

    /**
     * 批量删除supplier
     * 
     * @param ids 需要删除的supplier主键
     * @return 结果
     */
    @Override
    public int deleteSupplierByIds(String[] ids)
    {
        return supplierMapper.deleteSupplierByIds(ids);
    }

    /**
     * 删除supplier信息
     * 
     * @param id supplier主键
     * @return 结果
     */
    @Override
    public int deleteSupplierById(String id)
    {
        return supplierMapper.deleteSupplierById(id);
    }

    @Override
    public AjaxResult resetPwd(String supplierId) {

        Supplier supplier = supplierMapper.selectSupplierById(supplierId);
        if(supplier==null){
            return AjaxResult.error("未找到代理商信息，请刷新重试");
        }
        AgentUser agentUser = sysUserService.selectAgentBySupplierId(supplierId);
        if(agentUser== null){
            return AjaxResult.error("系统错误，晴联系管理员");
        }
        //生成密码
        String password = SecurityUtils.encryptPassword("Aa123456");
        agentUser.setPassword(password);
        int i =  sysUserService.updateUserPassword(agentUser);

        return AjaxResult.switchOne(i);
    }

    @Override
    public Supplier selectSupplierByAppId(String appId) {
        return supplierMapper.selectSupplierByAppId(appId);
    }
}
