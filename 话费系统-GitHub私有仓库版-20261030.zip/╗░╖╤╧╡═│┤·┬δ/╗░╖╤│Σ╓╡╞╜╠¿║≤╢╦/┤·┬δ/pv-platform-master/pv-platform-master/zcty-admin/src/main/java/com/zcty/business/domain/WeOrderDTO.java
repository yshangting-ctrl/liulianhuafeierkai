package com.zcty.business.domain;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
/**
 * @Author: chushengkun
 * @Date: 2022/7/26 9:27
 */
public class WeOrderDTO {

    public interface BuyNow{}

    /** 微信的用户ID */
    private String openId;
    /** 话费流量充值号码*/
    @NotBlank(message = "手机号码不能为空！", groups = BuyNow.class)
    private String phone;
    /** 订单备注 */
    private String remark;
    /** 商品规格ID -- 立即购买校验*/
    @NotBlank(message = "商品数据异常，请刷新重试！", groups = BuyNow.class)
    private String goodsId;
    /**商品类型 1 话费商品 2 流量商品 */
    private Integer goodsType;
    /** 商品数量 -- 立即购买校验*/
    @Min(value = 1, message = "商品数量必须大于0", groups = BuyNow.class)
    @NotNull(message = "商品数量必须大于0", groups = BuyNow.class)
    private Integer num;




    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }


    public String getGoodsId() {
        return goodsId;
    }

    public void setGoodsId(String goodsId) {
        this.goodsId = goodsId;
    }

    public Integer getNum() {
        return num;
    }

    public void setNum(Integer num) {
        this.num = num;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Integer getGoodsType() {
        return goodsType;
    }

    public void setGoodsType(Integer goodsType) {
        this.goodsType = goodsType;
    }
}
