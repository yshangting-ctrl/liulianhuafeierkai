package com.zcty.business.mapper;

import java.util.List;
import com.zcty.business.domain.FlowProduct;


/**
 * 流量商品Mapper接口
 * 
 * @author lsw
 * @date 2024-03-20
 */
public interface FlowProductMapper 
{
    /**
     * 查询流量商品
     * 
     * @param id 流量商品主键
     * @return 流量商品
     */
    public FlowProduct selectFlowProductById(String id);

    /**
     * 查询流量商品列表
     * 
     * @param flowProduct 流量商品
     * @return 流量商品集合
     */
    public List<FlowProduct> selectFlowProductList(FlowProduct flowProduct);

    /**
     * 新增流量商品
     * 
     * @param flowProduct 流量商品
     * @return 结果
     */
    public int insertFlowProduct(FlowProduct flowProduct);

    /**
     * 修改流量商品
     * 
     * @param flowProduct 流量商品
     * @return 结果
     */
    public int updateFlowProduct(FlowProduct flowProduct);

    /**
     * 删除流量商品
     * 
     * @param id 流量商品主键
     * @return 结果
     */
    public int deleteFlowProductById(String id);

    /**
     * 批量删除流量商品
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteFlowProductByIds(String[] ids);

    /**
     * 添加销量
     * @param flowProduct
     * @return
     */
    public int addSales(FlowProduct flowProduct);

    public int updateFlowProductStatus(FlowProduct flowProduct);
}
