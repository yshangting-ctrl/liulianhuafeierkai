package com.zcty.pv.utils;

import javax.crypto.Cipher;
import java.io.ByteArrayOutputStream;
import java.security.*;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.HashMap;
import java.util.Map;

/**
 * RSA算法私钥公钥生成工具
 */
public class RSAUtils {
    /**
     * 加密算法RSA
     */
    public static final String KEY_ALGORITHM = "RSA";
    /**
     * 签名算法
     */
    public static final String SIGNATURE_ALGORITHM = "MD5withRSA";

    /**
     * 获取公钥的key
     */
    private static final String PUBLIC_KEY = "RSAPublicKey";
    /**
     * 获取私钥的key
     */
    private static final String PRIVATE_KEY = "RSAPrivateKey";
    /**
     * RSA最大加密明文大小
     */
    private static final int MAX_ENCRYPT_BLOCK = 117;
    /**
     * RSA最大解密密文大小
     */
    private static final int MAX_DECRYPT_BLOCK = 128;

    public static final String publicKey="MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCYPz2iB1l72OS9lG3FXpq/xh5sSDHb8Yd0p1ed3E3IcPZU8fUOoqd3E+tNI1BESAkUVtcd7FaIgDn6eLQWSBOsTdR7navxdkgW486ka+r0Ijw0oelBvQYmHj0P4q0rDFVotLSD3Gc6cdGbV+dgwk0QT1Pi27ha4/t3pH/1UaSUYQIDAQAB";
    public static final String privateKey=System.getenv().getOrDefault("APP_RSA_PRIVATE_KEY", "");
    /**
     * 生成密钥对(公钥和私钥)
     * @return
     * @throws Exception
     */
    public static Map<String, Object> genKeyPair() throws Exception {

        KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance(KEY_ALGORITHM);

        keyPairGen.initialize(1024);

        KeyPair keyPair = keyPairGen.generateKeyPair();

        RSAPublicKey publicKey = (RSAPublicKey) keyPair.getPublic();

        RSAPrivateKey privateKey = (RSAPrivateKey) keyPair.getPrivate();

        Map<String, Object> keyMap = new HashMap<String, Object>(2);

        keyMap.put(PUBLIC_KEY, publicKey);

        keyMap.put(PRIVATE_KEY, privateKey);

        return keyMap;
    }

    /**
     * 用私钥对信息生成数字签名
     * @param data
     *            已加密数据
     * @param privateKey
     *            私钥(BASE64编码)
     * @return
     * @throws Exception
     */
    public static String sign(byte[] data, String privateKey) throws Exception {

        byte[] keyBytes = Base64Utils.decode(privateKey);

        PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(keyBytes);

        KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);

        PrivateKey privateK = keyFactory.generatePrivate(pkcs8KeySpec);

        Signature signature = Signature.getInstance(SIGNATURE_ALGORITHM);

        signature.initSign(privateK);

        signature.update(data);

        return Base64Utils.encode(signature.sign());
    }

    /**
     * 校验数字签名
     * @param data
     *            已加密数据
     * @param publicKey
     *            公钥(BASE64编码)
     * @param sign
     *            数字签名
     * @return
     * @throws Exception
     */
    public static boolean verify(byte[] data, String publicKey, String sign) throws Exception {

        byte[] keyBytes = Base64Utils.decode(publicKey);

        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);

        KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);

        PublicKey publicK = keyFactory.generatePublic(keySpec);

        Signature signature = Signature.getInstance(SIGNATURE_ALGORITHM);

        signature.initVerify(publicK);

        signature.update(data);

        return signature.verify(Base64Utils.decode(sign));
    }

    /**
     * 私钥解密
     * @param encryptedData
     *            已加密数据
     * @param privateKey
     *            私钥(BASE64编码)
     * @return
     * @throws Exception
     */
    public static byte[] decryptByPrivateKey(byte[] encryptedData, String privateKey) throws Exception {

        byte[] keyBytes = Base64Utils.decode(privateKey);

        PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(keyBytes);

        KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);

        Key privateK = keyFactory.generatePrivate(pkcs8KeySpec);

        Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());

        cipher.init(Cipher.DECRYPT_MODE, privateK);

        int inputLen = encryptedData.length;

        ByteArrayOutputStream out = new ByteArrayOutputStream();

        int offSet = 0;

        byte[] cache;

        int i = 0;

        // 对数据分段解密

        while (inputLen - offSet > 0) {

            if (inputLen - offSet > MAX_DECRYPT_BLOCK) {

                cache = cipher.doFinal(encryptedData, offSet, MAX_DECRYPT_BLOCK);

            } else {

                cache = cipher.doFinal(encryptedData, offSet, inputLen - offSet);

            }

            out.write(cache, 0, cache.length);

            i++;

            offSet = i * MAX_DECRYPT_BLOCK;

        }
        byte[] decryptedData = out.toByteArray();
        out.close();
        return decryptedData;
    }

    /**
     * 公钥解密
     * @param encryptedData
     *            已加密数据
     * @param publicKey
     *            公钥(BASE64编码)
     * @return
     * @throws Exception
     */
    public static byte[] decryptByPublicKey(byte[] encryptedData, String publicKey) throws Exception {

        byte[] keyBytes = Base64Utils.decode(publicKey);

        X509EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(keyBytes);

        KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);

        Key publicK = keyFactory.generatePublic(x509KeySpec);

        Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());

        cipher.init(Cipher.DECRYPT_MODE, publicK);

        int inputLen = encryptedData.length;

        ByteArrayOutputStream out = new ByteArrayOutputStream();

        int offSet = 0;

        byte[] cache;

        int i = 0;

        // 对数据分段解密

        while (inputLen - offSet > 0) {

            if (inputLen - offSet > MAX_DECRYPT_BLOCK) {

                cache = cipher.doFinal(encryptedData, offSet, MAX_DECRYPT_BLOCK);

            } else {

                cache = cipher.doFinal(encryptedData, offSet, inputLen - offSet);

            }

            out.write(cache, 0, cache.length);

            i++;

            offSet = i * MAX_DECRYPT_BLOCK;
        }
        byte[] decryptedData = out.toByteArray();

        out.close();

        return decryptedData;
    }

    /**
     * 公钥加密
     * @param data
     *            源数据
     * @param publicKey
     *            公钥(BASE64编码)
     * @return
     * @throws Exception
     */
    public static byte[] encryptByPublicKey(byte[] data, String publicKey) throws Exception {

        byte[] keyBytes = Base64Utils.decode(publicKey);

        X509EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(keyBytes);

        KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);

        Key publicK = keyFactory.generatePublic(x509KeySpec);

        // 对数据加密

        Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());

        cipher.init(Cipher.ENCRYPT_MODE, publicK);

        int inputLen = data.length;

        ByteArrayOutputStream out = new ByteArrayOutputStream();

        int offSet = 0;

        byte[] cache;

        int i = 0;

        // 对数据分段加密

        while (inputLen - offSet > 0) {

            if (inputLen - offSet > MAX_ENCRYPT_BLOCK) {

                cache = cipher.doFinal(data, offSet, MAX_ENCRYPT_BLOCK);

            } else {

                cache = cipher.doFinal(data, offSet, inputLen - offSet);

            }

            out.write(cache, 0, cache.length);

            i++;

            offSet = i * MAX_ENCRYPT_BLOCK;

        }

        byte[] encryptedData = out.toByteArray();

        out.close();

        return encryptedData;

    }

    /**
     * 私钥加密
     * @param data
     *            源数据
     * @param privateKey
     *            私钥(BASE64编码)
     * @return
     * @throws Exception
     */
    public static byte[] encryptByPrivateKey(byte[] data, String privateKey) throws Exception {

        byte[] keyBytes = Base64Utils.decode(privateKey);

        PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(keyBytes);

        KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);

        Key privateK = keyFactory.generatePrivate(pkcs8KeySpec);

        Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());

        cipher.init(Cipher.ENCRYPT_MODE, privateK);

        int inputLen = data.length;

        ByteArrayOutputStream out = new ByteArrayOutputStream();

        int offSet = 0;

        byte[] cache;

        int i = 0;

        // 对数据分段加密

        while (inputLen - offSet > 0) {

            if (inputLen - offSet > MAX_ENCRYPT_BLOCK) {

                cache = cipher.doFinal(data, offSet, MAX_ENCRYPT_BLOCK);

            } else {

                cache = cipher.doFinal(data, offSet, inputLen - offSet);

            }

            out.write(cache, 0, cache.length);

            i++;

            offSet = i * MAX_ENCRYPT_BLOCK;

        }

        byte[] encryptedData = out.toByteArray();

        out.close();

        return encryptedData;

    }

    /**
     * 获取私钥
     * @param keyMap
     *            密钥对
     * @return
     * @throws Exception
     */
    public static String getPrivateKey(Map<String, Object> keyMap) throws Exception {

        Key key = (Key) keyMap.get(PRIVATE_KEY);

        return Base64Utils.encode(key.getEncoded());

    }

    /**
     * 获取公钥
     * @param keyMap
     *    密钥对
     * @return
     * @throws Exception
     */
    public static String getPublicKey(Map<String, Object> keyMap) throws Exception {

        Key key = (Key) keyMap.get(PUBLIC_KEY);

        return Base64Utils.encode(key.getEncoded());

    }

    /**
     * java端公钥加密
     */
    public static String encryptedDataOnJava(String data, String PUBLICKEY) {

        try {

            data = Base64Utils.encode(encryptByPublicKey(data.getBytes(), PUBLICKEY));

        } catch (Exception e) {

            // TODO Auto-generated catch block

            e.printStackTrace();

        }
        return data;
    }

    /**
     * java端私钥解密
     */
    public static String decryptDataOnJava(String data, String PRIVATEKEY) {

        String temp = "";

        try {
            byte[] rs = Base64Utils.decode(data);

            temp = new String(RSAUtils.decryptByPrivateKey(rs, PRIVATEKEY),"UTF-8"); //以utf-8的方式生成字符串

        } catch (Exception e) {

            e.printStackTrace();

        }
        return temp;
    }


    public static void main(String[] args) throws Exception {

        Map<String, Object> map=genKeyPair();
        String publicKey=getPublicKey(map);
        String privateKey=getPrivateKey(map);
//        System.out.println("公钥："+getPublicKey(map));
//        System.out.println("公钥："+getPublicKey(map));
//        System.out.println("公钥："+publicKey);
//        System.out.println("私钥："+privateKey);
//        String originStr="hello";
//        //公钥加密，私钥解密
//        String encryptedDataOnJava=encryptedDataOnJava(originStr,publicKey);
//        System.out.println("originStr+publicKey:"+encryptedDataOnJava);
//        String decryptDataOnJava=decryptDataOnJava(encryptedDataOnJava,privateKey);
//        System.out.println("decryptDataOnJava:"+decryptDataOnJava);
//        //私钥加密，公钥解密
//        byte[] encryptByPrivateKey=encryptByPrivateKey(originStr.getBytes(),privateKey);
//        System.out.println("私钥加密，公钥解密结果："+new String(decryptByPublicKey(encryptByPrivateKey,publicKey)));
//        //签名校验
//        String sign= sign(originStr.getBytes(),privateKey);
//        System.out.println("sign:"+sign);
//        System.out.println(verify(originStr.getBytes(),publicKey,sign));


//        String param="D3/9rlZ4d/3dQJRoYEQd6mFs/wl11VbygaRp9YbV/RLCPmiTlw4E9ZeJNZ+2U8JRyMVR0ep44x5ej7awnA0ls0bw9TVh1k07klova75YIelzgnUcu2YgyYXbY3917kscuNqdkUaXskGJc6Cwwpi6aoxbStaqCRBiqq8Z8eA2hWk=";
//        String decryptDataOnJava1=decryptDataOnJava(param,privateKey);
//        System.out.println("decryptDataOnJava:"+decryptDataOnJava1);


//        String publicKey="MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCLvTcQ1XPatRJ2e8dw1EIkbfzOgTLVCXxe3/uM uyVSa9V7VnwvhYs2A67WKkPLVGFpOcHw617jo6ma2q5LQHfdAliYmkGzXylchg7BFb/riV5EafRMoQecsu3D+DBXt15AleKPITk2W6A2LnCr9qsK7Sb9IVhu7qIqeg89PsftOQIDAQAB";
        // Private-key example removed from repository package.
//                "MtUJfF7f+4y7JVJr1XtWfC+FizYDrtYqQ8tUYWk5wfDrXuOjqZrarktAd90CWJiaQbNfKVyGDsEV" +
//                "v+uJXkRp9EyhB5yy7cP4MFe3XkCV4o8hOTZboDYucKv2qwrtJv0hWG7uoip6Dz0+x+05AgMBAAEC" +
//                "gYEAg2TEfWCn0jNGjAAxdScwlj6RYr9bQ7PqrO8hAaALJOfeUV3t4WVJk918rUYKfwr1mVLEyLsY" +
//                "eyWt2bzb/Eg/Kz4H4OFj/5G+tfyN8CID2FAVn09/qqjlbeBzA15sEdFIMN+Kmz+IgRg8DUvsSIxQ" +
//                "j2o8RxphIXXqRB9OfxYk6b0CQQDFBXDSaJvd6IPu7mrT6jNfCtX/OS2M5w2ejCNcnCPfOiZeqz2G" +
//                "NU+5fRr6L/M28Cghyloc8+1KwkNKITPWiqejAkEAtZIBjT5wq2ffYrqBCcw0Z2cQF9tnXGlY4yp4" +
//                "uYaAK28/rzLJjUYcA1BRwzZL7cz5jn2DMDpMqQXedwlKmyzVcwJAdJa5oumggvrbSALyWKEY8T86" +
//                "T6QIXn9EQfRv4JfNaoXAuvjemZLmsL9lvXOum24WcZiLJuL6Iuk+ZJmtUWIPvQJAByw+bXMDBnJz" +
//                "C7ZsdJOhmlgi9Z5QRgFPZqH95O5gT9b0QBqUhcU4RBU/NaQGed14Gl3w+c3Dy4WU1UUDsn+h6wJA" +
//                "AOBZR1V/ypmtZPL2fXQ35DtZcTVyI607Wie2ghbaRJMRfYI36oiGzddXMXCcXlavBlQgrPQojrnO" +
//                "ASksgywzSA==";
//        String originStr="hello";
//        //公钥加密，私钥解密
//        String encryptedDataOnJava=encryptedDataOnJava(originStr,publicKey);
//        System.out.println("originStr+publicKey:"+encryptedDataOnJava);
//        String decryptDataOnJava=decryptDataOnJava(encryptedDataOnJava,privateKey);
//        System.out.println("decryptDataOnJava:"+decryptDataOnJava);


//        String originStr="hello";
//        //公钥加密，私钥解密
//        String encryptedDataOnJava1="VmSYxF/8nkfhIetuVuC1LsK/AIEf59aGJ8FtJJgwy1SMEE/uZPsI/ROQ7ykGcYn8H7bduapydrUKb7V0ppD1rS1JNrYnM4bLpqO1dUZ2Hyf8SUCYZg6DA6iQVwupdVLiseJJ0ZRYPPLOn35wKAn20SGeNBslqqDRFZT9VIWLvqE=";
//        System.out.println("originStr+publicKey:"+encryptedDataOnJava1);
//        String decryptDataOnJava1=decryptDataOnJava(encryptedDataOnJava1,privateKey);
//        System.out.println("decryptDataOnJava:"+decryptDataOnJava1);

    }
}
