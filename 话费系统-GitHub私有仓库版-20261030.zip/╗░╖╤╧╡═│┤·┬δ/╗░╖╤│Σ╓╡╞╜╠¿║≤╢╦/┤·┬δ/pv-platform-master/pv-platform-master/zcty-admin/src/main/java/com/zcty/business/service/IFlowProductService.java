package com.zcty.business.service;

import java.util.List;
import com.zcty.business.domain.FlowProduct;
import com.zcty.common.core.domain.AjaxResult;

/**
 * 流量商品Service接口
 * 
 * @author lsw
 * @date 2024-03-20
 */
public interface IFlowProductService 
{
    /**
     * 查询流量商品
     * 
     * @param id 流量商品主键
     * @return 流量商品
     */
    public FlowProduct selectFlowProductById(String id);

    /**
     * 查询流量商品列表
     * 
     * @param flowProduct 流量商品
     * @return 流量商品集合
     */
    public List<FlowProduct> selectFlowProductList(FlowProduct flowProduct);

    /**
     * 新增流量商品
     * 
     * @param flowProduct 流量商品
     * @return 结果
     */
    public AjaxResult insertFlowProduct(FlowProduct flowProduct);

    /**
     * 修改流量商品
     * 
     * @param flowProduct 流量商品
     * @return 结果
     */
    public AjaxResult updateFlowProduct(FlowProduct flowProduct);

    /**
     * 批量删除流量商品
     * 
     * @param ids 需要删除的流量商品主键集合
     * @return 结果
     */
    public int deleteFlowProductByIds(String[] ids);

    /**
     * 删除流量商品信息
     * 
     * @param id 流量商品主键
     * @return 结果
     */
    public int deleteFlowProductById(String id);

    /**
     * 添加销量
     * @return
     */
    public int addSales(String commonId, Integer num);

    public  AjaxResult   updateFlowProductStatus(FlowProduct flowProduct);


}
