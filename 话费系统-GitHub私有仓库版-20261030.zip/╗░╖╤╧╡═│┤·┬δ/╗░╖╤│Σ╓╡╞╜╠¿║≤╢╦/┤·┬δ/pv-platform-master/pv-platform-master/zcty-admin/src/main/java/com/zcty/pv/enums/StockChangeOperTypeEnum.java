package com.zcty.pv.enums;

/**
 * 出入库操作类型枚举
 */
public enum StockChangeOperTypeEnum {
    /** 默认状态 */
    DEFAULT(0, "默认状态"),
    /** 入库 */
    INPUT(1,"入库"),
    /** 出库 */
    OUTPUT(2, "出库"),
    /** 调拨 */
    ALLOCATION(3, "调拨");

    private Integer value;
    private String text;

    StockChangeOperTypeEnum(Integer value, String text) {
        this.value = value;
        this.text = text;
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
