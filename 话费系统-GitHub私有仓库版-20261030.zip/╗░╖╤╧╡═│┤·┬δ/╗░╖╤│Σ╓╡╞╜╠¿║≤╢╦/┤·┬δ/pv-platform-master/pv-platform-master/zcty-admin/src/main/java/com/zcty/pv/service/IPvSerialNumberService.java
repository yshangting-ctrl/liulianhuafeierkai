package com.zcty.pv.service;

import java.util.List;
import com.zcty.pv.domain.PvSerialNumber;

/**
 * 编号生成记录Service接口
 * 
 * @author luohui
 * @date 2022-12-07
 */
public interface IPvSerialNumberService 
{
    /**
     * 查询编号生成记录
     * 
     * @param id 编号生成记录主键
     * @return 编号生成记录
     */
    public PvSerialNumber selectPvSerialNumberById(Long id);

    /**
     * 查询编号生成记录列表
     * 
     * @param pvSerialNumber 编号生成记录
     * @return 编号生成记录集合
     */
    public List<PvSerialNumber> selectPvSerialNumberList(PvSerialNumber pvSerialNumber);

    /**
     * 新增编号生成记录
     * 
     * @param pvSerialNumber 编号生成记录
     * @return 结果
     */
    public int insertPvSerialNumber(PvSerialNumber pvSerialNumber);

    /**
     * 修改编号生成记录
     * 
     * @param pvSerialNumber 编号生成记录
     * @return 结果
     */
    public int updatePvSerialNumber(PvSerialNumber pvSerialNumber);

    /**
     * 批量删除编号生成记录
     * 
     * @param ids 需要删除的编号生成记录主键集合
     * @return 结果
     */
    public int deletePvSerialNumberByIds(Long[] ids);

    /**
     * 删除编号生成记录信息
     * 
     * @param id 编号生成记录主键
     * @return 结果
     */
    public int deletePvSerialNumberById(Long id);

    /**
     * 根据前缀查询出当前最大的编号
     * @param prefix
     * @return
     */
    public PvSerialNumber getMaxSerialNo(String prefix);
}
