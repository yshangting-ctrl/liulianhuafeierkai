package com.zcty.pv.domain;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.zcty.common.annotation.Excel;
import com.zcty.common.core.domain.BaseEntity;

/**
 * 区域对象 pv_area
 * 
 * @author luohui
 * @date 2022-11-29
 */
@ApiModel("区域对象")
public class PvArea extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 区域id */
    @ApiModelProperty("区域id")
    private String areaId;

    /** 上级区域id */
    @ApiModelProperty("上级区域id")
    @Excel(name = "上级区域id")
    private String parentId;

    /** 祖级列表 */
    @ApiModelProperty("祖级列表")
    @Excel(name = "祖级列表")
    private String ancestors;

    /** 省市区名称 */
    @ApiModelProperty("省市区名称")
    @Excel(name = "省市区名称")
    private String shortName;

    /** 省市区简称 */
    @ApiModelProperty("省市区简称")
    @Excel(name = "省市区简称")
    private String realName;

    /** 显示层级 */
    @ApiModelProperty("显示层级")
    @Excel(name = "显示层级")
    private Integer level;

    public void setAreaId(String areaId) 
    {
        this.areaId = areaId;
    }

    public String getAreaId() 
    {
        return areaId;
    }
    public void setParentId(String parentId) 
    {
        this.parentId = parentId;
    }

    public String getParentId() 
    {
        return parentId;
    }
    public void setAncestors(String ancestors) 
    {
        this.ancestors = ancestors;
    }

    public String getAncestors() 
    {
        return ancestors;
    }
    public void setShortName(String shortName) 
    {
        this.shortName = shortName;
    }

    public String getShortName() 
    {
        return shortName;
    }
    public void setRealName(String realName) 
    {
        this.realName = realName;
    }

    public String getRealName() 
    {
        return realName;
    }
    public void setLevel(Integer level) 
    {
        this.level = level;
    }

    public Integer getLevel() 
    {
        return level;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("areaId", getAreaId())
            .append("parentId", getParentId())
            .append("ancestors", getAncestors())
            .append("shortName", getShortName())
            .append("realName", getRealName())
            .append("level", getLevel())
            .append("createBy", getCreateBy())
            .append("createTime", getCreateTime())
            .append("updateBy", getUpdateBy())
            .append("updateTime", getUpdateTime())
            .append("remark", getRemark())
            .toString();
    }
}
