package com.zcty.api;


import com.alibaba.fastjson2.JSONObject;
import com.zcty.business.domain.WechatProgramInfo;
import com.zcty.business.service.IWechatProgramInfoService;
import com.zcty.common.config.WxOpenConfig;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.utils.StringUtils;
import com.zcty.web.utlis.HttpSendUtils;
import com.zcty.web.utlis.IdGen;
import com.zcty.web.utlis.RedisUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;
/**
 * 用于接受授权二维码的回调和二维码生成路径的入口
 */
@Controller
@RequestMapping("/api/component")
public class AuthorizerAccessTokenApiController {

    @Autowired
    private IWechatProgramInfoService iWechatProgramInfoService;



    /**
     * 用于获取授权二维码的图片
     * @return
     */
    @GetMapping("/getPreAuthImage")
    @ResponseBody
    public AjaxResult getPreAuthImage(){

        System.out.println("----------授权二维码------");
        //授权链接的预授权码
        String pre_auth_code = RedisUtil.get(WxOpenConfig.PRE_AUTH_CODE);
        //授权二维码的回调地址
        String redirect_uri = "http://api.example.com/api/component/redirectUri";
        if(StringUtils.isEmpty(pre_auth_code)){
            return AjaxResult.error("微信公众号授权异常，请稍后尝试","");
        }
        //二维码的文本内容
        String preAuthcodeUrl = WxOpenConfig.PRE_AUTH_CODE_URL+"?component_appid="+WxOpenConfig.appId+"&pre_auth_code="+pre_auth_code+"&redirect_uri="+redirect_uri+"&auth_type=1";
        System.out.println("----------授权二维码链接内容------"+preAuthcodeUrl);
//
//        try
//        {
//            //二维码不需要做持久化，生成图片base64字符串即可
//            BufferedImage image=     QrCodecUtils.onlyCreateImageBuff(preAuthcodeUrl);
//            // 转换流信息写出
//            FastByteArrayOutputStream os = new FastByteArrayOutputStream();
//
//            ImageIO.write(image, "jpg", os);
//
//            return AjaxResult.success("data", Base64.encode(os.toByteArray()));
//        }
//        catch (IOException e)
//        {
//            return AjaxResult.error(e.getMessage());
//        } catch (Exception e) {
//            e.printStackTrace();
//            return AjaxResult.error(e.getMessage());
//        }
        return AjaxResult.success("data",preAuthcodeUrl);
    }


    /**
     * 用于授权成功的回调，处理，绑定成功之后的逻辑代码
     * @return
     */
    @RequestMapping("/redirectUri")
    @ResponseBody
    public String redirectUri(HttpServletResponse response,
                            @RequestParam("auth_code") String authCode,
                            @RequestParam("expires_in") String expiresIn) {

        System.out.println("-------------------------回调成功-----------------------------");
        try {
            System.out.println("小程序或者公众号授权给第三方平台【authCode】：" + authCode + "【expiresIn】：" + expiresIn);
            System.out.println("小程序或者公众号授权给第三方平台,操作成功");

        } catch (Exception e) {
            System.out.println("小程序或者公众号授权给第三方平台,操作异常");
            System.out.println(e.getMessage());
        }
        Date date = new Date();
        long nowTimestamp = date.getTime();
        //清除缓存中的预授权码
        RedisUtil.remove(WxOpenConfig.PRE_AUTH_CODE);
        boolean hasKey_sys_weixin_open_preauthcode = StringUtils.isEmpty(RedisUtil.get(WxOpenConfig.PRE_AUTH_CODE));
        System.out.println("二维码授权完成，清除预授权码成功：" + !hasKey_sys_weixin_open_preauthcode);
        try {
            String accessToken = RedisUtil.get(WxOpenConfig.COMPONENT_ACCESS_TOKEN);
            //设置请求参数
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("component_appid", WxOpenConfig.appId);
            jsonObject.put("authorization_code", authCode);
            String api_query_auth = WxOpenConfig.API_QUERY_AUTH;
            String responseData = HttpSendUtils.doPost(api_query_auth + accessToken, jsonObject.toString(), 5000);
            JSONObject postData = JSONObject.parseObject(responseData);
            System.out.println("====================返回post结果：" + postData.toString());

            JSONObject authorizationInfo = (JSONObject) postData.get("authorization_info");   //得到授权信息
            String authorizerAppid = (String) authorizationInfo.get("authorizer_appid");   //得到授权方 APPID    （存入数据库）
            String authorizerAccessToken = (String) authorizationInfo.get("authorizer_access_token");   //得到接口调用令牌
            String authorizerRefreshToken = (String) authorizationInfo.get("authorizer_refresh_token");   //得到接口刷新令牌   存入数据库）
            Integer accessTokenexpiresIn = (Integer) authorizationInfo.get("expires_in");   //接口调用令牌的有效期
            //从数据库中删除数据
            iWechatProgramInfoService.deleteWechatProgramInfoByAuthorizerAppid(authorizerAppid);
            //新值写入数据库
            WechatProgramInfo wechatProgramInfo = new WechatProgramInfo();

            String id = IdGen.uuid();
            wechatProgramInfo.setId(id);
            wechatProgramInfo.setCreateTime(date);
            wechatProgramInfo.setAuthorizationInfo("公众号授权信息");
            wechatProgramInfo.setAuthorizerAccessToken(authorizerAccessToken);
            wechatProgramInfo.setAuthorizerRefreshToken(authorizerRefreshToken);
            wechatProgramInfo.setDelFlag(0);
            wechatProgramInfo.setExpiresIn(accessTokenexpiresIn);
            wechatProgramInfo.setAuthorizerAppid(authorizerAppid);

            iWechatProgramInfoService.insertWechatProgramInfo(wechatProgramInfo);

            //将授权码写入缓存(HashSet方式(key,item,val,time)->(authorizer_access_token+appid,token,expiresIn))
            RedisUtil.set("authorizer_access_token" + authorizerAppid, authorizerAccessToken, accessTokenexpiresIn);
            //写入一个redis信息列用于处理提示剩余时间
//            RedisUtil.set("authorizer_access_token" + authorizerAppid + "time", nowTimestamp + "");

            System.out.println("小程序或者公众号授权给第三方平台【authorizer_access_token】：" + authorizerAccessToken + "【authorizer_refresh_token】：" + authorizerRefreshToken);
            System.out.println("小程序或者公众号授权给第三方平台,操作成功");
        } catch (Exception e) {
            System.out.println("小程序或者公众号授权给第三方平台,操作异常" + e.getMessage());
        }
        return "success";  //扫码成功后跳转到 success.html页面 或者给予提示信息 }
    }
}
