package com.zcty.business.domain;


/**
 * @Author: chushengkun
 * @Date: 2022/7/26 10:06
 */

public class WeOrderCart {

    /** 商品ID */
    private String goodsId;
    /**商品类型 1 话费商品 2 流量商品 */
    private Integer goodsType;
    /** 数量 */
    private Integer goodsNum;



    public String getGoodsId() {
        return goodsId;
    }

    public void setGoodsId(String goodsId) {
        this.goodsId = goodsId;
    }



    public Integer getGoodsNum() {
        return goodsNum;
    }

    public void setGoodsNum(Integer goodsNum) {
        this.goodsNum = goodsNum;
    }



    public Integer getGoodsType() {
        return goodsType;
    }

    public void setGoodsType(Integer goodsType) {
        this.goodsType = goodsType;
    }
}
