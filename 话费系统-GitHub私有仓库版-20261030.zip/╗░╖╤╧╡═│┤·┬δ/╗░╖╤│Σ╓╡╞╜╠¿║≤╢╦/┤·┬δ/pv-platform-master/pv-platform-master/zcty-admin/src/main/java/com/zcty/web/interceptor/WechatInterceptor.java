package com.zcty.web.interceptor;

import com.zcty.common.constant.UserConstants;
import com.zcty.web.utlis.WeChatUserUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.util.*;

/**
 * 微信小程序用户访问拦截器
 */
@Repository
public class WechatInterceptor implements HandlerInterceptor {


    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        String[] allowDomains = {"http://192.168.0.171:8980","http://ateli.soolds.com","http://api.example.com"};
        Set allowOrigins = new HashSet(Arrays.asList(allowDomains));
        String originHeads = request.getHeader("Origin");
        if(allowOrigins.contains(originHeads)){
          //设置允许跨域的配置
         // 这里填写你允许进行跨域的主机ip(正式上线时可以动态配置具体允许的域名和IP)
          response.setHeader("Access-Control-Allow-Origin", originHeads);
        }
//        response.setHeader("Access-Control-Allow-Origin", "http://192.168.0.170:8198");// 允许指定域访问跨域资源
        response.setHeader("Access-Control-Allow-Credentials", "true");       // 允许客户端携带跨域cookie，此时origin值不能为“*”，只能为指定单一域名


        String allowMethod = request.getHeader("Access-Control-Request-Method");
        String allowHeaders = request.getHeader("Access-Control-Request-Headers");
        response.setHeader("Access-Control-Max-Age", "86400");            // 浏览器缓存预检请求结果时间,单位:秒
        response.setHeader("Access-Control-Allow-Methods", allowMethod);  // 允许浏览器在预检请求成功之后发送的实际请求方法名
        response.setHeader("Access-Control-Allow-Headers", allowHeaders); // 允许浏览器发送的请求消息头

        String openId= WeChatUserUtils.getWeChatOpenId(request);

        String origin = request.getHeader("Origin");
        if(origin == null) {
            origin = request.getHeader("Referer");
        }


        if(StringUtils.isEmpty(openId)){
//            log.error("--------------------登录信息过期--------------------------");
//            response.setContentType("application/json;charset=utf-8");
            response.setCharacterEncoding("GBK"); //本地(因为本地系统的编码格式是GBK)
            response.setContentType("application/json");
//            response.setCharacterEncoding("GBK"); //本地(因为本地系统的编码格式是GBK)
            // response.setCharacterEncoding("UTF-8"); //服务器本地(因为本地系统的编码格式是UTF-8)
//            OutputStream os=response.getOutputStream();
//            PrintWriter pw=new PrintWriter(os);
//            OutputStream os=response.getOutputStream();
            PrintWriter pw=response.getWriter();
//            pw.println("{\"code\":406,\"msg\":\"登录过期,请重新登录\",\"data\":\"error\"}");
            pw.write("{\"code\":406,\"msg\":\"登录过期,请重新登录\",\"data\":\"error\"}");
            pw.flush();
            pw.close();
            return false;
        }
        response.setCharacterEncoding("UTF-8");
        //把openid塞进去request请求体你们，在controller里面就可以直接拿了
        request.setAttribute(UserConstants.OPENID,openId);
        return true;
    }




}
