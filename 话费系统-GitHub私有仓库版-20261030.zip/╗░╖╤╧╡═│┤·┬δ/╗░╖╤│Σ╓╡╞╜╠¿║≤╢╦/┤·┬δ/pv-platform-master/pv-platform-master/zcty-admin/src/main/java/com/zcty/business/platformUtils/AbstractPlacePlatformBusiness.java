package com.zcty.business.platformUtils;

import com.zcty.business.domain.ActivityProduct;
import com.zcty.business.domain.Order;
import com.zcty.business.domain.OrderSendProduct;
import com.zcty.business.domain.PlatformInfos;
import com.zcty.common.core.domain.AjaxResult;
import org.springframework.stereotype.Component;

/**
 * 充值平台业务处理
 */
@Component
public abstract class AbstractPlacePlatformBusiness {

    /**
     * 调取第三方平台业务，创建订单
     */
    public abstract AjaxResult createPlatformBusiness(String activityProductId,String phone,String orderNo);

    /**
     * 发送验证码
     */
    public abstract AjaxResult sendFirstSmsCode(String activityProductId, String phone, String orderNo, String third_order_no, Order order);

    /**
     * 提交验证码
     * @param phone
     * @param third_order_no
     * @return
     */
    public abstract AjaxResult submitFirstSmsCode(PlatformInfos platformInfos, OrderSendProduct orderSendProduct, ActivityProduct activityProduct , String smsCode, String phone, String third_order_no, Order order);

    /**
     * 获取前置验证码
     * @param activityProductId
     * @param phone
     * @param orderNo
     * @param third_order_no
     * @param order
     * @return
     */
    public abstract AjaxResult getPreSmsCode(String activityProductId, String phone, String orderNo, String third_order_no, Order order);

    /**
     * 提交验证码
     * @param phone
     * @param third_order_no
     * @return
     */
    public abstract AjaxResult submitPreSmsCode(PlatformInfos platformInfos, OrderSendProduct orderSendProduct, ActivityProduct activityProduct , String smsCode, String phone, String third_order_no, Order order);



}
