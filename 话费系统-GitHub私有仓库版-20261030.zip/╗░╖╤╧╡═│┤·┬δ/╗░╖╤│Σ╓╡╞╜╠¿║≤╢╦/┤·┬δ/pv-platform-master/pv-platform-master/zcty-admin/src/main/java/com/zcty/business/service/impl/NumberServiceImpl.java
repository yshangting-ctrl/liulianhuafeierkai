package com.zcty.business.service.impl;


import com.zcty.business.domain.INumber;
import com.zcty.business.service.INumberService;
import com.zcty.business.service.NumberService;
import com.zcty.web.utlis.IdGen;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * @authour:linxiaohan
 * @date:2018/12/12
 * @description:
 */
@Service
public class NumberServiceImpl implements NumberService {

    @Autowired
    private INumberService iNumberService;


    // 代理商 type:1
    private static final String YH_PREX = "YH";

    //订单编号 type:2
    private static final String OD_PREX = "OD";

    //订单编号 type:3
    private static final String XM_PREX = "XM";

    //退款订单编号 type:4
    private static final String TK_PREX = "TK";

    //评论订单编号 type:5
    private static final String PL_PREX = "PL";

    //回复评论编号 type:6
    private static final String HF_PREX = "HF";

    //回复评论编号 type:7
    private static final String ll_PREX = "LL";


    private static final int DEFAULT_LENGTH = 3;

    @Override
    public String getYHNumber(){
        return  getNumber(YH_PREX, 1);
    }

    @Override
    public String getODNumber(){
        return  getNumber(OD_PREX, 2);
    }

    @Override
    public String getXMNumber(){
        return  getNumber(XM_PREX, 3);
    }

    @Override
    public String getTKNumber(){
        return  getNumber(TK_PREX, 4);
    }

    @Override
    public String getPLNumber(){
        return  getNumber(PL_PREX, 5);
    }

    @Override
    public String getHFNumber(){
        return  getNumber(HF_PREX, 6);
    }

    @Override
    public String getLLNumber(){
        return  getNumber(ll_PREX, 7);
    }
    /**
     * 获取单号
     */
    public String getNumber(String prex1, Integer type) {
        StringBuffer sb = new StringBuffer();
        SimpleDateFormat mF = new SimpleDateFormat("yyyy-MM-dd", Locale.CHINA);
        Date dt = new Date();
        String date = mF.format(dt);
        String date1 = mF.format(dt);
        String [] item = date.split("-");
        sb.append(prex1).append(item[0]).append(item[1]).append(item[2]).append((int) ((Math.random() * 9 + 1) * 100000));
        Integer n = number(date1, type);
        String seq = getSequence(n);
        sb.append(seq);
        return  sb.toString();
    }

    /** 同一天有相同的单号累加*/
    public Integer number(String date, Integer type){
        int i = 0;
        INumber iNnumber = iNumberService.selectByDateAndType(date, type);
        if(null != iNnumber){
            i = iNnumber.getNumber() + 1;
        }
        return i;
    }

    /**
     * @num: 编码
     * @description: 更新编号到数据库，对单号进行拆封和更新。以防止同一个单号出现两次。
     */
    public void updateNumber(String num){
        try {
            String number = num.substring(num.length()- 3 , num.length());
            String date = num.substring(num.length() - 17, num.length() - 3);
            StringBuffer sb = new StringBuffer();
            date = date.substring(0, 8);
            char[] c1 = date.toCharArray();
            for(int i = 0; i < c1.length; i++){
                sb.append(c1[i]);
                if(i == 3 || i==5){
                    sb.append("-");
                }
            }
            String prex = num.substring(0, num.length() - 17);
            int type = getType(prex);
            int i = Integer.parseInt(number);

            INumber in = iNumberService.selectByType(type);
            if(null != in) {
                INumber number1 = new INumber(in.getId(), type, sb.toString(), i);
                iNumberService.update(number1);
            } else {
                INumber iNumber1 = new INumber(IdGen.uuid(), type, sb.toString(), i);
                iNumberService.save(iNumber1);
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
    }

    /**
     * 得到3位的序列号,长度不足3位,前面补0
     * @param seq
     * @return
     */
    public static String getSequence(Integer seq) {
        String str = String.valueOf(seq);
        int len = str.length();
        if (len >= DEFAULT_LENGTH) {
            return str;
        }
        int rest = DEFAULT_LENGTH - len;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < rest; i++) {
            sb.append('0');
        }
        sb.append(str);
        return sb.toString();
    }

    /**
     * 更新单号的时候需要用到。
     * */
    int getType(String prex){
        int i = 0;
        switch (prex){
            case YH_PREX : i = 1;break;
            case OD_PREX : i = 2;break;
            case XM_PREX : i = 3;break;
            case TK_PREX : i = 4;break;
            case PL_PREX : i = 5;break;
            case HF_PREX : i = 6;break;
            case ll_PREX : i = 7;break;
            default:
        }
        return i;
    }

    /**
     * 前端调用
     * */
    @Override
    public String getNumber(int type){
        String n = new String();
        switch(type){
            case 1: n = getYHNumber(); break;
            case 2: n = getODNumber(); break;
            case 3: n = getXMNumber(); break;
            case 4: n = getTKNumber(); break;
            case 5: n = getPLNumber(); break;
            case 6: n = getHFNumber(); break;
            case 7: n = getLLNumber(); break;
            default:
        }
        return n;
    }

}