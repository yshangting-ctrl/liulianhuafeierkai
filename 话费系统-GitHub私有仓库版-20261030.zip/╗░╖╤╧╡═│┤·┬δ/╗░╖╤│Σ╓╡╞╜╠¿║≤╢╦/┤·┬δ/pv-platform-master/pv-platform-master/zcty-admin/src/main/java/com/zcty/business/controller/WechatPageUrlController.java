package com.zcty.business.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.zcty.common.annotation.Log;
import com.zcty.common.core.controller.BaseController;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.enums.BusinessType;
import com.zcty.business.domain.WechatPageUrl;
import com.zcty.business.service.IWechatPageUrlService;
import com.zcty.common.utils.poi.ExcelUtil;
import com.zcty.common.core.page.TableDataInfo;
/**
 * 微信公众号页面链接地址Controller
 * 
 * @author lsw
 * @date 2024-05-29
 */
@RestController
@RequestMapping("/business/url")
public class WechatPageUrlController extends BaseController
{
    @Autowired
    private IWechatPageUrlService wechatPageUrlService;

    /**
     * 查询微信公众号页面链接地址列表
     */
    @PreAuthorize("@ss.hasPermi('business:url:list')")
    @GetMapping("/list")
    public TableDataInfo list(WechatPageUrl wechatPageUrl)
    {
        startPage();
        List<WechatPageUrl> list = wechatPageUrlService.selectWechatPageUrlList(wechatPageUrl);
        return getDataTable(list);
    }

    /**
     * 导出微信公众号页面链接地址列表
     */
    @PreAuthorize("@ss.hasPermi('business:url:export')")
    @Log(title = "微信公众号页面链接地址", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, WechatPageUrl wechatPageUrl)
    {
        List<WechatPageUrl> list = wechatPageUrlService.selectWechatPageUrlList(wechatPageUrl);
        ExcelUtil<WechatPageUrl> util = new ExcelUtil<WechatPageUrl>(WechatPageUrl.class);
        util.exportExcel(response, list, "微信公众号页面链接地址数据");
    }

    /**
     * 获取微信公众号页面链接地址详细信息
     */
    @PreAuthorize("@ss.hasPermi('business:url:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") String id)
    {
        return success(wechatPageUrlService.selectWechatPageUrlById(id));
    }

    /**
     * 新增微信公众号页面链接地址
     */
    @PreAuthorize("@ss.hasPermi('business:url:add')")
    @Log(title = "微信公众号页面链接地址", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody WechatPageUrl wechatPageUrl)
    {
        return toAjax(wechatPageUrlService.insertWechatPageUrl(wechatPageUrl));
    }

    /**
     * 修改微信公众号页面链接地址
     */
    @PreAuthorize("@ss.hasPermi('business:url:edit')")
    @Log(title = "微信公众号页面链接地址", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody WechatPageUrl wechatPageUrl)
    {
        return toAjax(wechatPageUrlService.updateWechatPageUrl(wechatPageUrl));
    }

    /**
     * 删除微信公众号页面链接地址
     */
    @PreAuthorize("@ss.hasPermi('business:url:remove')")
    @Log(title = "微信公众号页面链接地址", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable String[] ids)
    {
        return toAjax(wechatPageUrlService.deleteWechatPageUrlByIds(ids));
    }
}
