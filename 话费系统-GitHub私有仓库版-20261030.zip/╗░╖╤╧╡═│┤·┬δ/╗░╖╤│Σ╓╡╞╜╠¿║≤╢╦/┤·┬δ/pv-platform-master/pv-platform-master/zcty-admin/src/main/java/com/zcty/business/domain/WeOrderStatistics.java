package com.zcty.business.domain;


/**
 * @Author: chushengkun
 * @Date: 2022/8/2 11:24
 */
public class WeOrderStatistics {
    // 全部
    private String allOrders;
    // 待支付
    private String toBePay;
    // 待发货
    private String toBeDelivered;
    // 待收货
    private String pendingReceipt;
    // 已完成
    private String completed;
    // 退款/退款完成
    private String refund;

    public String getAllOrders() {
        return allOrders;
    }

    public void setAllOrders(String allOrders) {
        this.allOrders = allOrders;
    }

    public String getToBePay() {
        return toBePay;
    }

    public void setToBePay(String toBePay) {
        this.toBePay = toBePay;
    }

    public String getToBeDelivered() {
        return toBeDelivered;
    }

    public void setToBeDelivered(String toBeDelivered) {
        this.toBeDelivered = toBeDelivered;
    }

    public String getPendingReceipt() {
        return pendingReceipt;
    }

    public void setPendingReceipt(String pendingReceipt) {
        this.pendingReceipt = pendingReceipt;
    }

    public String getCompleted() {
        return completed;
    }

    public void setCompleted(String completed) {
        this.completed = completed;
    }

    public String getRefund() {
        return refund;
    }

    public void setRefund(String refund) {
        this.refund = refund;
    }
}
