package com.zcty.business.domain;


import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.List;
/**
 * 留言小程序端 分页
 */
public class OnlineMessageShowPageList implements Serializable {
    /** 数据总数**/
    @ApiModelProperty(name="total",value="数据总数",example = "1")
    private Integer total;
    /** 数据总数**/
    @ApiModelProperty(name="code",value="返回状态",example = "0")
    private Integer code;
    /** 数据主体**/
    @ApiModelProperty(name="rows",value="数据主体")
    private List<OnlineMessageShow> rows;

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public List<OnlineMessageShow> getRows() {
        return rows;
    }

    public void setRows(List<OnlineMessageShow> rows) {
        this.rows = rows;
    }
}
