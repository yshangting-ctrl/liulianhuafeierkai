package com.zcty.business.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.zcty.common.annotation.Log;
import com.zcty.common.core.controller.BaseController;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.enums.BusinessType;
import com.zcty.business.domain.OrderSendProductDetail;
import com.zcty.business.service.IOrderSendProductDetailService;
import com.zcty.common.utils.poi.ExcelUtil;
import com.zcty.common.core.page.TableDataInfo;

/**
 * 业务发货详情Controller
 * 
 * @author lsw
 * @date 2024-07-09
 */
@RestController
@RequestMapping("/business/detail")
public class OrderSendProductDetailController extends BaseController
{
    @Autowired
    private IOrderSendProductDetailService orderSendProductDetailService;

    /**
     * 查询业务发货详情列表
     */
    @PreAuthorize("@ss.hasPermi('business:detail:list')")
    @GetMapping("/list")
    public TableDataInfo list(OrderSendProductDetail orderSendProductDetail)
    {
        startPage();
        List<OrderSendProductDetail> list = orderSendProductDetailService.selectOrderSendProductDetailList(orderSendProductDetail);
        return getDataTable(list);
    }

    /**
     * 导出业务发货详情列表
     */
    @PreAuthorize("@ss.hasPermi('business:detail:export')")
    @Log(title = "业务发货详情", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, OrderSendProductDetail orderSendProductDetail)
    {
        List<OrderSendProductDetail> list = orderSendProductDetailService.selectOrderSendProductDetailList(orderSendProductDetail);
        ExcelUtil<OrderSendProductDetail> util = new ExcelUtil<OrderSendProductDetail>(OrderSendProductDetail.class);
        util.exportExcel(response, list, "业务发货详情数据");
    }

    /**
     * 获取业务发货详情详细信息
     */
    @PreAuthorize("@ss.hasPermi('business:detail:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") String id)
    {
        return success(orderSendProductDetailService.selectOrderSendProductDetailById(id));
    }

    /**
     * 新增业务发货详情
     */
    @PreAuthorize("@ss.hasPermi('business:detail:add')")
    @Log(title = "业务发货详情", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody OrderSendProductDetail orderSendProductDetail)
    {
        return toAjax(orderSendProductDetailService.insertOrderSendProductDetail(orderSendProductDetail));
    }

    /**
     * 修改业务发货详情
     */
    @PreAuthorize("@ss.hasPermi('business:detail:edit')")
    @Log(title = "业务发货详情", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody OrderSendProductDetail orderSendProductDetail)
    {
        return toAjax(orderSendProductDetailService.updateOrderSendProductDetail(orderSendProductDetail));
    }

    /**
     * 删除业务发货详情
     */
    @PreAuthorize("@ss.hasPermi('business:detail:remove')")
    @Log(title = "业务发货详情", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable String[] ids)
    {
        return toAjax(orderSendProductDetailService.deleteOrderSendProductDetailByIds(ids));
    }
}
