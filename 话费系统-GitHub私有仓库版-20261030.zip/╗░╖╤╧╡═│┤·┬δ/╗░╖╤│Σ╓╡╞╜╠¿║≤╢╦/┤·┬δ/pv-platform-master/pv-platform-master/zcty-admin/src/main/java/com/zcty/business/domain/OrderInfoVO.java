package com.zcty.business.domain;

import com.fasterxml.jackson.annotation.JsonFormat;

import org.springframework.format.annotation.DateTimeFormat;

import java.util.List;

/**
 * @Author: chushengkun
 * @Date: 2022/8/2 14:49
 */
public class OrderInfoVO {
    /** 订单ID */
    private String orderId;
    /** 卖家ID*/
    private String userId;
    /** 订单编号 */
    private String orderNo;
    /** 微信返回的订单号 */
    private String transactionId;
    /** 订单title */
    private String remarkBody;
    /** 订单备注 */
    private String remark;
    /** 联系电话 */
    private String phone;
    /** 订单金额 */
    private String totalFee;
    /** 订单支付金额*/
    private String payFee;

    private String tradeType;

    private String sendProduct;
    /** 发货时间 */
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss" ,  timezone="GMT+8")
    private String sendProductTime;
    /** 发货备注 */
    private String sendRemark;

    /** 创建时间 */
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss" ,  timezone="GMT+8")
    private String createTime;
    /** 支付时间 */
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss" ,  timezone="GMT+8")
    private String payTime;
    /** 取消时间 */
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss" ,  timezone="GMT+8")
    private String cancelTime;

    /** 订单状态 0、待付款 1、待发货 2、待收货 3、交易完成 4、交易关闭 5、退款 6、取消 */
    private String orderStatus;

    /**商品类型 1 话费商品 2 流量商品 */
    private Integer goodsType;


    // 订单商品列表
    private List<WeOrderGoodsVO> orderGoodsVOList;


    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getRemarkBody() {
        return remarkBody;
    }

    public void setRemarkBody(String remarkBody) {
        this.remarkBody = remarkBody;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }


    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }



    public String getTotalFee() {
        return totalFee;
    }

    public void setTotalFee(String totalFee) {
        this.totalFee = totalFee;
    }



    public String getPayFee() {
        return payFee;
    }

    public void setPayFee(String payFee) {
        this.payFee = payFee;
    }

    public String getTradeType() {
        return tradeType;
    }

    public void setTradeType(String tradeType) {
        this.tradeType = tradeType;
    }

    public String getSendProduct() {
        return sendProduct;
    }

    public void setSendProduct(String sendProduct) {
        this.sendProduct = sendProduct;
    }

    public String getSendProductTime() {
        return sendProductTime;
    }

    public void setSendProductTime(String sendProductTime) {
        this.sendProductTime = sendProductTime;
    }

    public String getSendRemark() {
        return sendRemark;
    }

    public void setSendRemark(String sendRemark) {
        this.sendRemark = sendRemark;
    }


    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getPayTime() {
        return payTime;
    }

    public void setPayTime(String payTime) {
        this.payTime = payTime;
    }

    public String getCancelTime() {
        return cancelTime;
    }

    public void setCancelTime(String cancelTime) {
        this.cancelTime = cancelTime;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public List<WeOrderGoodsVO> getOrderGoodsVOList() {
        return orderGoodsVOList;
    }

    public void setOrderGoodsVOList(List<WeOrderGoodsVO> orderGoodsVOList) {
        this.orderGoodsVOList = orderGoodsVOList;
    }

    public Integer getGoodsType() {
        return goodsType;
    }

    public void setGoodsType(Integer goodsType) {
        this.goodsType = goodsType;
    }
}
