package com.zcty.business.service.impl;


import com.zcty.business.domain.Areas;
import com.zcty.business.mapper.AreasMapper;
import com.zcty.business.service.IAreasService;
import com.zcty.common.core.text.Convert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
/**
 * 地区码 服务层实现
 * 
 * @author liuruibin
 * @date 2019-07-11
 */
@Service
public class AreasServiceImpl implements IAreasService
{
	@Autowired
	private AreasMapper areasMapper;

	/**
     * 查询地区码信息
     * 
     * @param areaId 地区码ID
     * @return 地区码信息
     */
    @Override
	public Areas selectAreasById(Integer areaId)
	{
	    return areasMapper.selectAreasById(areaId);
	}
	
	/**
     * 查询地区码列表
     * 
     * @param areas 地区码信息
     * @return 地区码集合
     */
	@Override
	public List<Areas> selectAreasList(Areas areas)
	{
	    return areasMapper.selectAreasList(areas);
	}
	
    /**
     * 新增地区码
     * 
     * @param areas 地区码信息
     * @return 结果
     */
	@Override
	public int insertAreas(Areas areas)
	{
	    return areasMapper.insertAreas(areas);
	}
	
	/**
     * 修改地区码
     * 
     * @param areas 地区码信息
     * @return 结果
     */
	@Override
	public int updateAreas(Areas areas)
	{
	    return areasMapper.updateAreas(areas);
	}

	/**
     * 删除地区码对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteAreasByIds(String ids)
	{
		return areasMapper.deleteAreasByIds(Convert.toStrArray(ids));
	}
	
}
