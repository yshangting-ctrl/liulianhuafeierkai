package com.zcty.weChat.controller;

import com.zcty.business.domain.WechatPageUrl;
import com.zcty.business.service.IWechatPageUrlService;
import com.zcty.common.config.WxOpenConfig;
import com.zcty.common.utils.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * 代理商访问菜单链接
 */
@Controller
@RequestMapping("/weChat/webRedirect")
public class WechatUrlRediectController {

    @Autowired
    private IWechatPageUrlService wechatPageUrlService;

    /**
     * 指定跳转菜单我的中心
     * @Param state 公众号id
     * @return
     */
    @RequestMapping(value = "/user/index",method = RequestMethod.GET)
    public String userIndex(HttpServletRequest request){

        String  pageUrl = getRedirectUrlInfo(request);
        System.out.println("--------pageUrl--------"+pageUrl);
        if(StringUtils.isEmpty(pageUrl)){
            return "redirect:http://ateli.soolds.com";
        }else{
            return "redirect:"+pageUrl;
        }
    }

    /**
     * 指定跳转菜单商城首页
     * @Param state 公众号id
     * @return
     */
    @RequestMapping(value = "/index",method = RequestMethod.GET)
    public String index(HttpServletRequest request){

        String  pageUrl = getRedirectUrlInfo(request);
        if(StringUtils.isEmpty(pageUrl)){
            return "redirect:http://ateli.soolds.com";
        }else{
            return "redirect:"+pageUrl;
        }
    }


    public String getRedirectUrlInfo( HttpServletRequest request){
        //访问路径
        String url = request.getRequestURL().toString();
        System.out.println("--------url------"+url);
        String appId ;
        try {
             appId = getWechatAppId(url);
        }catch (Exception e){
            System.out.println("链接地址错误，未获取代理商信息");
            return "";
        }
        System.out.println("--------appId------"+appId);


        //查询平台的url映射表
        WechatPageUrl wechatPageUrl = new WechatPageUrl();
        List<WechatPageUrl> list = wechatPageUrlService.selectWechatPageUrlList(wechatPageUrl);
        //获取
        String redirectUrl = "";
        for (WechatPageUrl wechatPageUrl1:list){
            String pageShowUrl = wechatPageUrl1.getPageShowUrl();
            System.out.println("-----------pageShowUrl----------"+pageShowUrl);
            pageShowUrl = replaceWechatAppId(appId,pageShowUrl);
            System.out.println("-----------pageShowUrl----------"+pageShowUrl);
            if(url.equals(pageShowUrl)){
               //匹配成功，赋值，跳出循环
               redirectUrl = wechatPageUrl1.getPageUrl();
               break;
            }
        }
        if(StringUtils.isEmpty(redirectUrl)){
            return "";
        }
        //对页面需要设置的参数进行替换,替换第三方平台appid
        redirectUrl = replaceRedirectUrl(appId,redirectUrl);
        System.out.println("-----------redirectUrl----------"+redirectUrl);
//        //替换掉公众号appid
//        redirectUrl = replaceWechatAppId(appId,redirectUrl);
//        System.out.println("-----------redirectUrl----------"+redirectUrl);
        return redirectUrl;
    }

    public static void main(String[] args) {

        String url = "http://wx0b07ebb93f97e3da.wx.soolds.com/weChat/webRedirect/index";
        String pageShowUrl = "http://${appId}.wx.soolds.com/weChat/webRedirect/user/index";
//        System.out.println();
//        getWechatAppId(url);
        String appId =  getWechatAppId(url);
        System.out.println(replaceWechatAppId(appId,pageShowUrl));
    }

    //获取url里面的公众号appid
    public static String getWechatAppId(String url){
        //字符串处理，截取第一个点的字符串
        int dian = url.indexOf(".");
        url = url.substring(0,dian);
        //截取最后一个斜杠到字符串后面的数据
        System.out.println(url);
        int xiegan = url.lastIndexOf("/");
        url = url.substring(xiegan+1);
        System.out.println(url);
        return url;
    }

    public static String replaceWechatAppId(String appId,String pageShowUrl){
        //替换字符串
        pageShowUrl = pageShowUrl.replace(WxOpenConfig.appIdUrlKey,appId);
        return pageShowUrl;
    }

    public static String replaceRedirectUrl(String appId,String pageUrl){
        //替换字符串
        pageUrl = pageUrl.replace(WxOpenConfig.appIdUrlKey,appId);
        pageUrl = pageUrl.replace(WxOpenConfig.componentappidUrlKey,WxOpenConfig.appId);
        return pageUrl;
    }

}
