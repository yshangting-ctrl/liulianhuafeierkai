package com.zcty.business.controller;

import com.zcty.business.domain.Areas;
import com.zcty.business.service.IAreasService;
import com.zcty.common.annotation.Log;
import com.zcty.common.core.controller.BaseController;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.core.page.TableDataInfo;
import com.zcty.common.enums.BusinessType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 地区码 信息操作处理
 * 
 * @author liuruibin
 * @date 2019-07-11
 */
@Controller
@RequestMapping("/api/areas")
public class AreasController extends BaseController
{
    private String prefix = "business/areas";
	
	@Autowired
	private IAreasService areasService;

	@GetMapping()
	public String areas()
	{
	    return prefix + "/areas";
	}

	/**
	 * 查询地区码列表
	 */
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(Areas areas)
	{
		startPage();
        List<Areas> list = areasService.selectAreasList(areas);
		return getDataTable(list);
	}
	
	/**
	 * 新增地区码
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存地区码
	 */
	@Log(title = "地区码", businessType = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(Areas areas)
	{		
		return toAjax(areasService.insertAreas(areas));
	}

	/**
	 * 修改地区码
	 */
	@GetMapping("/edit/{areaId}")
	public String edit(@PathVariable("areaId") Integer areaId, ModelMap mmap)
	{
		Areas areas = areasService.selectAreasById(areaId);
		mmap.put("areas", areas);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存地区码
	 */
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(Areas areas)
	{		
		return toAjax(areasService.updateAreas(areas));
	}
	
	/**
	 * 删除地区码
	 */
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(areasService.deleteAreasByIds(ids));
	}


	@PostMapping("/getProvinceList")
	@ResponseBody
	public AjaxResult getProvinceList(){

		Areas areas=new Areas();
		areas.setLevel(1);
		List<Areas>  list=areasService.selectAreasList(areas);

		return  AjaxResult.success("data",list);
	}

	@PostMapping("/getCityList")
	@ResponseBody
	public AjaxResult getCityList(@RequestBody Areas areas){

		int parentId = 0 ;
		if(areas.getParentId()!=null){
			parentId  = areas.getParentId();
		}
		areas.setLevel(2);
		areas.setParentId(parentId);
		List<Areas>  list=areasService.selectAreasList(areas);

		return  AjaxResult.success("data",list);
	}

	@PostMapping("/getDistrictList")
	@ResponseBody
	public AjaxResult getDistrictList(int parentId){

		Areas areas=new Areas();
		areas.setLevel(3);
		areas.setParentId(parentId);
		List<Areas>  list=areasService.selectAreasList(areas);
		return  AjaxResult.success("data",list);
	}


//	@PostMapping("/test")
//	@ResponseBody
//	public AjaxResult test(){
//
//		List<WeChatUser> list=weChatUserService.selectWeChatUserList(new WeChatUser());
//
//		System.out.println(list.size());
//
//		for(WeChatUser c:list){
//			String id=c.getId();
//			String userId=weChatUserService.getUniqueUserId();
//			weChatUserService.updateWeChatUserUserId(id,userId);
//		}
//		return  AjaxResult.success();
//	}

}
