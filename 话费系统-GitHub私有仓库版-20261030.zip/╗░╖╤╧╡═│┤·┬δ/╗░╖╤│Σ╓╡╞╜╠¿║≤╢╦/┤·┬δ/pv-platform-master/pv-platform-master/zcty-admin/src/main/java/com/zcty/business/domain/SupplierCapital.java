package com.zcty.business.domain;

import java.math.BigDecimal;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.zcty.common.annotation.Excel;
import com.zcty.common.core.domain.BaseEntity;

/**
 * 代理商资金对象 t_supplier_capital
 * 
 * @author ruoyi
 * @date 2024-06-24
 */
public class SupplierCapital extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 主键id */
    private String id;

    /** 代理商id */
    @Excel(name = "代理商id")
    private String supplierId;

    /** 资金总数 */
    @Excel(name = "资金总数")
    private BigDecimal capitalTotal;

    /** 删除标示 0未删除 1已删除 */
    private Integer delFlag;

    /** 增加资金总数 */
    private BigDecimal addTotal;

    private Integer totalType;

    public void setId(String id) 
    {
        this.id = id;
    }

    public String getId() 
    {
        return id;
    }
    public void setSupplierId(String supplierId) 
    {
        this.supplierId = supplierId;
    }

    public String getSupplierId() 
    {
        return supplierId;
    }
    public void setCapitalTotal(BigDecimal capitalTotal) 
    {
        this.capitalTotal = capitalTotal;
    }

    public BigDecimal getCapitalTotal() 
    {
        return capitalTotal;
    }
    public void setDelFlag(Integer delFlag) 
    {
        this.delFlag = delFlag;
    }

    public Integer getDelFlag() 
    {
        return delFlag;
    }

    public BigDecimal getAddTotal() {
        return addTotal;
    }

    public void setAddTotal(BigDecimal addTotal) {
        this.addTotal = addTotal;
    }

    public Integer getTotalType() {
        return totalType;
    }

    public void setTotalType(Integer totalType) {
        this.totalType = totalType;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("supplierId", getSupplierId())
            .append("capitalTotal", getCapitalTotal())
            .append("createTime", getCreateTime())
            .append("updateTime", getUpdateTime())
            .append("delFlag", getDelFlag())
            .toString();
    }
}
