package com.zcty.business.platformUtils;

import com.alibaba.fastjson2.JSONObject;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.zcty.business.domain.*;
import com.zcty.business.mapper.OrderMapper;
import com.zcty.business.service.IActivityProductService;
import com.zcty.business.service.IOrderSendProductDetailService;
import com.zcty.business.service.IOrderSendProductService;
import com.zcty.business.service.IPlatformInfosService;
import com.zcty.common.config.PlatformBusinessParam;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.utils.StringUtils;
import com.zcty.web.utlis.IdGen;
import org.apache.http.HttpResponse;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.io.ByteArrayOutputStream;

/**
 * Eliuliang的业务代码
 */
@Component
@Service
public class AbstractPlacePlatformEliuliang  extends AbstractPlacePlatformBusiness  {

    public static String keyWord = "eliuliang";

    @Autowired
    private IPlatformInfosService platformInfosService;

    @Autowired
    private IActivityProductService activityProductService;

    @Autowired
    private IOrderSendProductService orderSendProductService;

    @Autowired
    private IOrderSendProductDetailService orderSendProductDetailService;

    @Autowired
    private OrderMapper orderMapper;

    public static String sendFirstCode  =  "/v1/getCode";


    public static String submitFirstCode =  "/v1/submitCode";

    public static String sendPreCode  =  "/v1/getPreCode";

    public static String submitPreCode  =   "/v1/submitPreCode";


    @Override
    public AjaxResult createPlatformBusiness(String activityProductId, String phone, String orderNo) {
        return null;
    }



    @Transactional(rollbackFor = Exception.class)
    @Override
    public AjaxResult sendFirstSmsCode(String activityProductId, String phone, String orderNo,String third_order_no, Order order) {

        //查询订单发货表
        OrderSendProduct orderSendProduct = orderSendProductService.selectOrderSendProductByParentOrderNo(third_order_no);
        if(orderSendProduct!=null){
            orderNo = orderSendProduct.getOrderNo();
        }


        //数据校验
        PlatformInfos platformInfos = platformInfosService.selectPlatformInfosByKeyWord(keyWord);
        //平台校验，用于获取当前平台的token，和secreat
        if(platformInfos == null){
            return AjaxResult.error("充值平台设置一次，未找到jipu平台信息");
        }
        System.out.println("-------platformInfos-----------"+platformInfos.toString());
        String url = platformInfos.getPlaformUrl();
        if(StringUtils.isEmpty(url) ){
            return AjaxResult.error("充值平台未设置访问地址");
        }
        String secret = platformInfos.getUserSecrect();

        if(StringUtils.isEmpty(secret)){
            return AjaxResult.error("未设置接口调用的信息");
        }

        ActivityProduct activityProduct = activityProductService.selectActivityProductById(activityProductId);

        if(activityProduct == null ){
            return AjaxResult.error("未找到充值商品业务信息");
        }
        String activityId = activityProduct.getActivityid();
        System.out.println("-------activityProduct-----------"+activityProduct.toString());

//        String activityid = activityProduct.getActivityid();

        if(StringUtils.isEmpty(activityId) ){
            return AjaxResult.error("充值商品业务未设置业务id");
        }


        Integer smscodenum= activityProduct.getSmscodenum();

        if(smscodenum==null){
            return AjaxResult.error("未设置验证次数");
        }

        if(!smscodenum.equals(1)&&!smscodenum.equals(2)){
            return AjaxResult.error("设置验证次数错误");
        }

        //生成订单
        CloseableHttpClient httpClient = null;

        System.out.println(third_order_no + "：第三方充值平台订单获取首次短信验证码开始");
        try {
            //http客户端创建
            httpClient = HttpClients.createDefault();

            //第二步获取验证码
            String sendFirstCodeUrl = url +sendFirstCode;
            //获取第一个验证码参数
            // {
            //    "bid":{{BID}},
            //    "phone":"{{PHONE}}"
            //}
            //bid
            //integer
            //产品ID
            //必需
            //phone
            //string
            //手机号
            //必需
            //order_no
            //string
            //平台订单号
            //可选
            //third_order_no
            //string
            //接入方订单号
            //可选
            //选填，如果填了则绑定该订单
            //设置请求体
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ObjectMapper objectMapper = new ObjectMapper();
            ObjectNode rootNode = objectMapper.createObjectNode();

            rootNode.put("bid",activityId)
                    .put("phone",phone)
                    .put("third_order_no", third_order_no);
            if(!StringUtils.isEmpty(orderNo)){
                rootNode.put("order_no",orderNo);
            }

            objectMapper.writeValue(bos, rootNode);
            System.out.println("rootNode：" + rootNode);

            String param = bos.toString("UTF-8");

            //访问线上接口
            String resultSendFirst = sendPostBusiness(sendFirstCodeUrl,param,httpClient,secret);

            System.out.println(resultSendFirst);
            //第二步获取验证码数据处理
            JSONObject jsonObjectSendFirst = JSONObject.parseObject(resultSendFirst);

            System.out.println(jsonObjectSendFirst);

            String status = jsonObjectSendFirst.getString("status");

            System.out.println("---------------status-------"+status);

            String data = jsonObjectSendFirst.getString("data");

            System.out.println("---------------data-------"+data);

            if(StringUtils.isEmpty(data)){
                System.out.println("codeSendFirst值为空，请检查codeSendFirst");
                return AjaxResult.error("codeSendFirst值为空，请检查codeSendFirst");
            }

            if(!status.equals("200")){
                System.out.println("codeSendFirst值校验异常");
                return AjaxResult.error("codeSendFirst值校验异常");
            }
            String id = "";
            //把当前信息写入发货订单表
            if(orderSendProduct==null){
                id = IdGen.uuid();
                orderSendProduct = new OrderSendProduct();
                orderSendProduct.setActivityid(activityId);
                orderSendProduct.setId(id);
                orderSendProduct.setOrderModel(activityProduct.getSmscodenum());
                orderSendProduct.setPhone(phone);
                orderSendProduct.setSendStatus(1);
                orderSendProduct.setParentOrderNo(third_order_no);
                orderSendProduct.setOrderNo(data);

                orderSendProductService.insertOrderSendProduct(orderSendProduct);
            }else{
                id = orderSendProduct.getId();
                orderSendProduct.setSendStatus(1);
                orderSendProduct.setOrderNo(data);
                orderSendProductService.updateOrderSendProduct(orderSendProduct);
            }

            OrderSendProductDetail orderSendProductDetail = new OrderSendProductDetail();
            orderSendProductDetail.setActivityid(activityId);
            orderSendProductDetail.setBusniessStatus(1);
            orderSendProductDetail.setStepNumber(PlatformBusinessParam.sendSmsCode);
            orderSendProductDetail.setId(IdGen.uuid());
            orderSendProductDetail.setPhone(phone);
            orderSendProductDetail.setParentOrderNo(third_order_no);
            orderSendProductDetail.setSendId(id);
            orderSendProductDetail.setSmscode("");
            orderSendProductDetail.setOrderNo(data);

            orderSendProductDetailService.insertOrderSendProductDetail(orderSendProductDetail);

        }catch (Exception e){
            e.printStackTrace();
            return AjaxResult.error("业务处理失败");
        }

        //发送到这个验证码就代表可以进行了发货
        int sendResult =  orderMapper.editOrderSend(order);

        return AjaxResult.success();

    }


    @Override
    public AjaxResult submitFirstSmsCode(PlatformInfos platformInfos,OrderSendProduct orderSendProduct,ActivityProduct activityProduct ,String smsCode,String phone,String third_order_no, Order order) {

        String url = platformInfos.getPlaformUrl();
        if(StringUtils.isEmpty(url) ){
            return AjaxResult.error("充值平台未设置访问地址");
        }
        String secret = platformInfos.getUserSecrect();

        if(StringUtils.isEmpty(secret)){
            return AjaxResult.error("未设置接口调用的信息");
        }
        String activityId = activityProduct.getActivityid();
        System.out.println("-------activityProduct-----------"+activityProduct.toString());
        if(StringUtils.isEmpty(activityId) ){
            return AjaxResult.error("充值商品业务未设置业务id");
        }

        Integer smscodenum= activityProduct.getSmscodenum();

        if(smscodenum==null){
            return AjaxResult.error("未设置验证次数");
        }

        if(!smscodenum.equals(1)&&!smscodenum.equals(2)){
            return AjaxResult.error("设置验证次数错误");
        }
        String orderNo = orderSendProduct.getOrderNo();
        //生成订单
        CloseableHttpClient httpClient = null;

        System.out.println(third_order_no + "：第三方充值平台订单提交首次短信验证码开始");
        try {
            //http客户端创建
            httpClient = HttpClients.createDefault();

            //第二步获取验证码
            String sendFirstCodeUrl = url +submitFirstCode;
            //获取第一个验证码参数
            // {
            //    "bid":{{BID}},
            //    "phone":"{{PHONE}}"
            //}
            //bid
            //integer
            //产品ID
            //必需
            //phone
            //string
            //手机号
            //必需
            //order_no
            //string
            //平台订单号
            //可选
            //third_order_no
            //string
            //接入方订单号
            //可选
            //选填，如果填了则绑定该订单
            //设置请求体
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ObjectMapper objectMapper = new ObjectMapper();
            ObjectNode rootNode = objectMapper.createObjectNode();

            rootNode.put("bid",activityId)
                    .put("phone",phone)
                    .put("smscode",smsCode)
                    .put("third_order_no", third_order_no)
                    .put("order_no",orderNo);

            objectMapper.writeValue(bos, rootNode);
            System.out.println("rootNode：" + rootNode);

            String param = bos.toString("UTF-8");

            //访问线上接口
            String resultSendFirst = sendPostBusiness(sendFirstCodeUrl,param,httpClient,secret);

            System.out.println(resultSendFirst);
            //第二步获取验证码数据处理
            JSONObject jsonObjectSendFirst = JSONObject.parseObject(resultSendFirst);

            System.out.println(jsonObjectSendFirst);

            String status = jsonObjectSendFirst.getString("status");

            System.out.println("---------------status-------"+status);

            String data = jsonObjectSendFirst.getString("data");

            System.out.println("---------------data-------"+data);

            if(StringUtils.isEmpty(data)){
                System.out.println("codeSendFirst值为空，请检查codeSendFirst");
                return AjaxResult.error("codeSendFirst值为空，请检查codeSendFirst");
            }

            if(!status.equals("200")){
                System.out.println("codeSendFirst值校验异常");
                return AjaxResult.error("codeSendFirst值校验异常");
            }
            String id = orderSendProduct.getId();
            //把当前信息写入发货订单表


            OrderSendProductDetail orderSendProductDetail = new OrderSendProductDetail();
            orderSendProductDetail.setActivityid(activityId);
            orderSendProductDetail.setBusniessStatus(1);
            orderSendProductDetail.setStepNumber(PlatformBusinessParam.submitSmsCode);
            orderSendProductDetail.setId(IdGen.uuid());
            orderSendProductDetail.setPhone(phone);
            orderSendProductDetail.setParentOrderNo(third_order_no);
            orderSendProductDetail.setSendId(id);
            orderSendProductDetail.setSmscode(smsCode);
            orderSendProductDetail.setOrderNo(data);

            orderSendProductDetailService.insertOrderSendProductDetail(orderSendProductDetail);

        }catch (Exception e){
            e.printStackTrace();
            return AjaxResult.error("业务处理失败");
        }

        //发送到这个验证码就代表可以进行了发货
        int sendResult =  orderMapper.editOrderSend(order);

        return AjaxResult.success();
    }

    public static String sendPostBusiness(String url , String param, CloseableHttpClient httpClient, String secret){

        int timeout =5000;

        try {
            //超时设置

            RequestConfig requestConfig =  RequestConfig.custom().setConnectTimeout(timeout) //连接超时
                    .setConnectionRequestTimeout(timeout)//请求超时
                    .setSocketTimeout(timeout)
                    .setRedirectsEnabled(true)  //允许自动重定向
                    .build();

            HttpPost httpPost = new HttpPost(url);

            StringEntity stringEntity = new StringEntity(param);

            httpPost.setEntity(new StringEntity(param, "UTF-8"));

            httpPost.addHeader("Accept", "application/json");
            httpPost.addHeader("Content-type","application/json; charset=utf-8");
            //使用自身系统和应用的名称和版本等信息，组成自己独有的User-Agent,很可能会拒绝处理无User-Agent 的请求。
            httpPost.addHeader("User-Agent",createUserAgent());

            //签名
            httpPost.addHeader("secret",secret);

            httpPost.setConfig(requestConfig);
            httpPost.setEntity(stringEntity);

            HttpResponse httpResponse = httpClient.execute(httpPost);

            String result = EntityUtils.toString(httpResponse.getEntity(), "UTF-8");

            return result;

        }catch (Exception e){
            e.printStackTrace();
            return null;
        }

    }

    //生成用户端的用户信息,用
    public static String createUserAgent(){
        return "Apifox/1.0.0 (https://apifox.com)";
    }


    @Override
    public AjaxResult getPreSmsCode(String activityProductId, String phone, String orderNo, String third_order_no, Order order) {

        //数据校验
        PlatformInfos platformInfos = platformInfosService.selectPlatformInfosByKeyWord(keyWord);
        //平台校验，用于获取当前平台的token，和secreat
        if(platformInfos == null){
            return AjaxResult.error("充值平台设置一次，未找到jipu平台信息");
        }
        System.out.println("-------platformInfos-----------"+platformInfos.toString());
        String url = platformInfos.getPlaformUrl();
        if(StringUtils.isEmpty(url) ){
            return AjaxResult.error("充值平台未设置访问地址");
        }
        String secret = platformInfos.getUserSecrect();

        if(StringUtils.isEmpty(secret)){
            return AjaxResult.error("未设置接口调用的信息");
        }

        ActivityProduct activityProduct = activityProductService.selectActivityProductById(activityProductId);

        if(activityProduct == null ){
            return AjaxResult.error("未找到充值商品业务信息");
        }
        String activityId = activityProduct.getActivityid();
        System.out.println("-------activityProduct-----------"+activityProduct.toString());

//        String activityid = activityProduct.getActivityid();

        if(StringUtils.isEmpty(activityId) ){
            return AjaxResult.error("充值商品业务未设置业务id");
        }

        Integer smscodenum= activityProduct.getSmscodenum();

        if(smscodenum==null){
            return AjaxResult.error("未设置验证次数");
        }

        if(!smscodenum.equals(2)){
            return AjaxResult.error("设置验证次数错误");
        }

        //生成订单
        CloseableHttpClient httpClient = null;

        System.out.println(third_order_no + "：第三方充值平台订单获取业务前置短信验证码开始");
        try {
            //http客户端创建
            httpClient = HttpClients.createDefault();

            //第二步获取验证码
            String sendPreCodeUrl = url + sendPreCode;
            //{
            //  "bid": 104,
            //  "phone": "15793377537"
            //}
            //bid
            //integer
            //产品ID
            //必需
            //phone
            //string
            //手机号
            //必需
            //order_no
            //string
            //平台订单号
            //可选
            //third_order_no
            //string
            //接入方平台订单号
            //可选
            //选填，如果填了则绑定该订单号
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ObjectMapper objectMapper = new ObjectMapper();
            ObjectNode rootNode = objectMapper.createObjectNode();

            rootNode.put("bid",activityId)
                    .put("phone",phone)
                    .put("third_order_no", third_order_no);
//            if(!StringUtils.isEmpty(orderNo)){
//                rootNode.put("order_no",orderNo);
//            }

            objectMapper.writeValue(bos, rootNode);
            System.out.println("rootNode：" + rootNode);

            String param = bos.toString("UTF-8");


            //访问线上接口
            String resultSendFirst = sendPostBusiness(sendPreCodeUrl,param,httpClient,secret);

            System.out.println(resultSendFirst);
            //第二步获取验证码数据处理
            JSONObject jsonObjectSendFirst = JSONObject.parseObject(resultSendFirst);

            System.out.println(jsonObjectSendFirst);

            String status = jsonObjectSendFirst.getString("status");

            System.out.println("---------------status-------"+status);

            String data = jsonObjectSendFirst.getString("data");

            System.out.println("---------------data-------"+data);

            if(StringUtils.isEmpty(data)){
                System.out.println("codeSendFirst值为空，请检查codeSendFirst");
                return AjaxResult.error("codeSendFirst值为空，请检查codeSendFirst");
            }

            if(!status.equals("200")){
                System.out.println("codeSendFirst值校验异常");
                return AjaxResult.error("codeSendFirst值校验异常");
            }

            OrderSendProduct orderSendProduct = new OrderSendProduct();

            String id =IdGen.uuid();

            orderSendProduct.setActivityid(activityId);
            orderSendProduct.setId(id);
            orderSendProduct.setOrderModel(activityProduct.getSmscodenum());
            orderSendProduct.setPhone(phone);
            orderSendProduct.setSendStatus(1);
            orderSendProduct.setParentOrderNo(third_order_no);
            orderSendProduct.setOrderNo(data);

            orderSendProductService.insertOrderSendProduct(orderSendProduct);

            OrderSendProductDetail orderSendProductDetail = new OrderSendProductDetail();
            orderSendProductDetail.setActivityid(activityId);
            orderSendProductDetail.setBusniessStatus(1);
            orderSendProductDetail.setStepNumber(PlatformBusinessParam.sendPreCode);
            orderSendProductDetail.setId(IdGen.uuid());
            orderSendProductDetail.setPhone(phone);
            orderSendProductDetail.setParentOrderNo(third_order_no);
            orderSendProductDetail.setSendId(id);
            orderSendProductDetail.setSmscode("");
            orderSendProductDetail.setOrderNo(data);

            orderSendProductDetailService.insertOrderSendProductDetail(orderSendProductDetail);

        }catch (Exception e){
            e.printStackTrace();
            return AjaxResult.error("业务处理失败");
        }

        return AjaxResult.success();
    }

    @Override
    public AjaxResult submitPreSmsCode(PlatformInfos platformInfos, OrderSendProduct orderSendProduct, ActivityProduct activityProduct, String smsCode, String phone, String third_order_no, Order order) {
        String url = platformInfos.getPlaformUrl();
        if(StringUtils.isEmpty(url) ){
            return AjaxResult.error("充值平台未设置访问地址");
        }
        String secret = platformInfos.getUserSecrect();

        if(StringUtils.isEmpty(secret)){
            return AjaxResult.error("未设置接口调用的信息");
        }
        String activityId = activityProduct.getActivityid();
        System.out.println("-------activityProduct-----------"+activityProduct.toString());
        if(StringUtils.isEmpty(activityId) ){
            return AjaxResult.error("充值商品业务未设置业务id");
        }

        Integer smscodenum= activityProduct.getSmscodenum();

        if(smscodenum==null){
            return AjaxResult.error("未设置验证次数");
        }

        if(!smscodenum.equals(2)){
            return AjaxResult.error("设置验证次数错误");
        }
        String orderNo = orderSendProduct.getOrderNo();

        //生成订单
        CloseableHttpClient httpClient = null;

        System.out.println(third_order_no + "：第三方充值平台订单提交前置短信验证码开始");
        try {
            //http客户端创建
            httpClient = HttpClients.createDefault();

            //第二步获取验证码
            String sendFirstCodeUrl = url +submitPreCode;
            //{
            //    "bid":{{BID}},
            //    "phone":"{{PHONE}}",
            //    "smscode":"001961"
            //}
            //phone
            //string
            //手机号
            //必需
            //bid
            //integer
            //产品ID
            //必需
            //smscode
            //string
            //验证码
            //必需
            //order_no
            //string
            //平台订单号，从《发送办理验证码》接口返回内容中获取
            //可选
            //third_order_no
            //string
            //对接方平台订单号


            //设置请求体
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ObjectMapper objectMapper = new ObjectMapper();
            ObjectNode rootNode = objectMapper.createObjectNode();

            rootNode.put("bid",activityId)
                    .put("phone",phone)
                    .put("smscode",smsCode)
                    .put("third_order_no", third_order_no)
                    .put("order_no",orderNo);

            objectMapper.writeValue(bos, rootNode);
            System.out.println("rootNode：" + rootNode);

            String param = bos.toString("UTF-8");

            //访问线上接口
            String resultSendFirst = sendPostBusiness(sendFirstCodeUrl,param,httpClient,secret);

            System.out.println(resultSendFirst);

            //第二步获取验证码数据处理
            JSONObject jsonObjectSendFirst = JSONObject.parseObject(resultSendFirst);

            System.out.println(jsonObjectSendFirst);

            String status = jsonObjectSendFirst.getString("status");

            System.out.println("---------------status-------"+status);

            String data = jsonObjectSendFirst.getString("data");

            System.out.println("---------------data-------"+data);

            if(StringUtils.isEmpty(data)){
                System.out.println("codeSendFirst值为空，请检查codeSendFirst");
                return AjaxResult.error("codeSendFirst值为空，请检查codeSendFirst");
            }

            if(!status.equals("200")){
                System.out.println("codeSendFirst值校验异常");
                return AjaxResult.error("codeSendFirst值校验异常");
            }

            String id = orderSendProduct.getId();
            //把当前信息写入发货订单表

            OrderSendProductDetail orderSendProductDetail = new OrderSendProductDetail();
            orderSendProductDetail.setActivityid(activityId);
            orderSendProductDetail.setBusniessStatus(1);
            orderSendProductDetail.setStepNumber(PlatformBusinessParam.submitPreCode);
            orderSendProductDetail.setId(IdGen.uuid());
            orderSendProductDetail.setPhone(phone);
            orderSendProductDetail.setParentOrderNo(third_order_no);
            orderSendProductDetail.setSendId(id);
            orderSendProductDetail.setSmscode(smsCode);
            orderSendProductDetail.setOrderNo(data);

            orderSendProductDetailService.insertOrderSendProductDetail(orderSendProductDetail);

        }catch (Exception e){
            e.printStackTrace();
            return AjaxResult.error("业务处理失败");
        }
        return AjaxResult.success();

    }
}

