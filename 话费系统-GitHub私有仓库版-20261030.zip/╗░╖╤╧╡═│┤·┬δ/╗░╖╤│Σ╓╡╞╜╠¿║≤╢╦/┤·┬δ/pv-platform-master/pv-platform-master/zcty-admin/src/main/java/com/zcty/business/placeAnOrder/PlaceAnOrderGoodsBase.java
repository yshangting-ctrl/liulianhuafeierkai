package com.zcty.business.placeAnOrder;

import org.springframework.stereotype.Component;
/**
 * @Author: chushengkun
 * @Date: 2022/7/26 11:48
 */
@Component
public class PlaceAnOrderGoodsBase extends AbstractPlaceAnOrder {



}
