package com.zcty.business.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.zcty.common.annotation.Excel;
import com.zcty.common.core.domain.BaseEntity;

/**
 * 业务发货详情对象 t_order_send_product_detail
 * 
 * @author lsw
 * @date 2024-07-09
 */
public class OrderSendProductDetail extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 主键id */
    private String id;

    /** 上级id */
    private String sendId;

    /** 订单编号 */
    private String orderNo;

    /** 上级订单编号 */
    private String parentOrderNo;

    /** 步奏 1234 */
    private Integer stepNumber;

    /** 短信验证码 */
    private String smscode;

    /** 手机号码 */
    private String phone;

    /** 业务状态 0 失败 1成功 */
    private Integer busniessStatus;

    /** 业务id */
    private String activityid;

    public void setId(String id) 
    {
        this.id = id;
    }

    public String getId() 
    {
        return id;
    }
    public void setSendId(String sendId) 
    {
        this.sendId = sendId;
    }

    public String getSendId() 
    {
        return sendId;
    }
    public void setOrderNo(String orderNo) 
    {
        this.orderNo = orderNo;
    }

    public String getOrderNo() 
    {
        return orderNo;
    }
    public void setStepNumber(Integer stepNumber) 
    {
        this.stepNumber = stepNumber;
    }

    public Integer getStepNumber() 
    {
        return stepNumber;
    }
    public void setSmscode(String smscode) 
    {
        this.smscode = smscode;
    }

    public String getSmscode() 
    {
        return smscode;
    }
    public void setPhone(String phone) 
    {
        this.phone = phone;
    }

    public String getPhone() 
    {
        return phone;
    }
    public void setBusniessStatus(Integer busniessStatus) 
    {
        this.busniessStatus = busniessStatus;
    }

    public Integer getBusniessStatus() 
    {
        return busniessStatus;
    }
    public void setActivityid(String activityid) 
    {
        this.activityid = activityid;
    }

    public String getActivityid() 
    {
        return activityid;
    }

    public String getParentOrderNo() {
        return parentOrderNo;
    }

    public void setParentOrderNo(String parentOrderNo) {
        this.parentOrderNo = parentOrderNo;
    }

    @Override
    public String toString() {
        return "OrderSendProductDetail{" +
                "id='" + id + '\'' +
                ", sendId='" + sendId + '\'' +
                ", orderNo='" + orderNo + '\'' +
                ", parentOrderNo='" + parentOrderNo + '\'' +
                ", stepNumber=" + stepNumber +
                ", smscode='" + smscode + '\'' +
                ", phone='" + phone + '\'' +
                ", busniessStatus=" + busniessStatus +
                ", activityid='" + activityid + '\'' +
                '}';
    }
}
