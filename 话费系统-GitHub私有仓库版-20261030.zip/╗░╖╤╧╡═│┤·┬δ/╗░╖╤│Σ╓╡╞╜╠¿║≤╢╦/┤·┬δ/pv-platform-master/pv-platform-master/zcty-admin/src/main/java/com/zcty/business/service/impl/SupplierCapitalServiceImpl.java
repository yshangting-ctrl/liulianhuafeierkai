package com.zcty.business.service.impl;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import com.zcty.business.domain.SupplierCapitalLog;
import com.zcty.business.domain.SupplierCapitalVo;
import com.zcty.business.mapper.SupplierCapitalLogMapper;
import com.zcty.common.config.WxOpenConfig;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.utils.DateUtils;
import com.zcty.web.utlis.IdGen;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zcty.business.mapper.SupplierCapitalMapper;
import com.zcty.business.domain.SupplierCapital;
import com.zcty.business.service.ISupplierCapitalService;
import org.springframework.transaction.annotation.Transactional;

/**
 * 代理商资金Service业务层处理
 * 
 * @author ruoyi
 * @date 2024-06-24
 */
@Service
public class SupplierCapitalServiceImpl implements ISupplierCapitalService 
{
    @Autowired
    private SupplierCapitalMapper supplierCapitalMapper;

    @Autowired
    private SupplierCapitalLogMapper supplierCapitalLogMapper;

    /**
     * 查询代理商资金
     * 
     * @param id 代理商资金主键
     * @return 代理商资金
     */
    @Override
    public SupplierCapital selectSupplierCapitalById(String id)
    {
        return supplierCapitalMapper.selectSupplierCapitalById(id);
    }

    /**
     * 查询代理商资金列表
     * 
     * @param supplierCapital 代理商资金
     * @return 代理商资金
     */
    @Override
    public List<SupplierCapital> selectSupplierCapitalList(SupplierCapital supplierCapital)
    {
        return supplierCapitalMapper.selectSupplierCapitalList(supplierCapital);
    }

    /**
     * 新增代理商资金
     * 
     * @param supplierCapital 代理商资金
     * @return 结果
     */
    @Override
    public int insertSupplierCapital(SupplierCapital supplierCapital)
    {
        supplierCapital.setCreateTime(DateUtils.getNowDate());
        return supplierCapitalMapper.insertSupplierCapital(supplierCapital);
    }

    /**
     * 修改代理商资金
     * 
     * @param supplierCapital 代理商资金
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public synchronized AjaxResult updateSupplierCapital(SupplierCapital supplierCapital)
    {
        //数据校验
        BigDecimal addCapital = supplierCapital.getAddTotal();
        if (addCapital==null){
            return AjaxResult.error("请输入要变更的资金数量");
        }
        if(addCapital.compareTo(BigDecimal.ZERO)<=0){
            return AjaxResult.error("请输入大于零的资金数量");
        }
        //资金变动类型查看
        Integer type = supplierCapital.getTotalType();
        if(type ==null){
            return AjaxResult.error("资金变动类型异常，请重新操作");
        }
        Date date = DateUtils.getNowDate();
        //资金账号查询
        SupplierCapital supplierCapitalChange = supplierCapitalMapper.selectSupplierCapitalById(supplierCapital.getId());
        //资金变动记录
        SupplierCapitalLog supplierCapitalLog = new SupplierCapitalLog();
        supplierCapitalLog.setDelFlag(0);
        supplierCapitalLog.setId(IdGen.uuid());
        supplierCapitalLog.setSupplierCapitalId(supplierCapital.getId());
        supplierCapitalLog.setSupplierId(supplierCapitalChange.getSupplierId());
        supplierCapitalLog.setCreateTime(date);
        supplierCapitalLog.setCapitalTotal(addCapital);
        supplierCapitalLog.setOldTotal(supplierCapitalChange.getCapitalTotal());

        BigDecimal  capitalTotal=supplierCapitalChange.getCapitalTotal();


        BigDecimal newTotal;
        //变更类型增加
        if(type.equals(WxOpenConfig.ADD_TYPE)){
            newTotal = addCapital.add(capitalTotal);
            supplierCapitalChange.setCapitalTotal(newTotal);
            supplierCapitalLog.setCapitalType(WxOpenConfig.ADD_TYPE);

        }else {
            //变更类型减少
            //判断资金是否足够减少
            if((capitalTotal.subtract(addCapital)).compareTo(BigDecimal.ZERO)<0){
                return AjaxResult.error("资金不足以扣除");
            }
            newTotal = capitalTotal.subtract(addCapital);
            supplierCapitalChange.setCapitalTotal(newTotal);
            supplierCapitalLog.setCapitalType(WxOpenConfig.SUB_TYPE);

        }

        supplierCapitalChange.setUpdateTime(date);
        supplierCapitalLog.setNewTotal(newTotal);
        supplierCapitalLogMapper.insertSupplierCapitalLog(supplierCapitalLog);
        return AjaxResult.switchOne(supplierCapitalMapper.updateSupplierCapital(supplierCapitalChange));
    }

    /**
     * 批量删除代理商资金
     * 
     * @param ids 需要删除的代理商资金主键
     * @return 结果
     */
    @Override
    public int deleteSupplierCapitalByIds(String[] ids)
    {
        return supplierCapitalMapper.deleteSupplierCapitalByIds(ids);
    }

    /**
     * 删除代理商资金信息
     * 
     * @param id 代理商资金主键
     * @return 结果
     */
    @Override
    public int deleteSupplierCapitalById(String id)
    {
        return supplierCapitalMapper.deleteSupplierCapitalById(id);
    }


    @Override
    public List<SupplierCapitalVo> selectSupplierCapitalVoList(SupplierCapitalVo supplierCapitalVo) {
        return supplierCapitalMapper.selectSupplierCapitalVoList(supplierCapitalVo);
    }

    @Override
    public SupplierCapitalVo selectSupplierCapitalVoById(String id) {
        return supplierCapitalMapper.selectSupplierCapitalVoById(id);
    }
}
