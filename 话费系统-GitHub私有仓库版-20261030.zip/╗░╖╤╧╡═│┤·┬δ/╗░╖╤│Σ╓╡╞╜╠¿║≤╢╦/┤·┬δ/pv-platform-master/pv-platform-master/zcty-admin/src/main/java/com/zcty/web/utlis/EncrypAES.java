package com.zcty.web.utlis;

import com.zcty.common.config.LuckqunxinConfig;

import javax.crypto.*;
import java.io.*;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.Security;
import java.util.Base64;

/**
 *AES加解密的工具类
 */
public class EncrypAES {
    //KeyGenerator 提供对称密钥生成器的功能，支持各种算法
    private  static KeyGenerator keygen;
    //SecretKey 负责保存对称密钥
    private static SecretKey deskey;
    //Cipher负责完成加密或解密工作
    private static Cipher c;

    //加载Cipher类的实例化
    /**BouncyCastle作为安全提供，防止我们加密解密时候因为jdk内置的不支持改模式运行报错。**/
    static {

        try {
            Security.addProvider(new com.sun.crypto.provider.SunJCE());

            File file=new File(LuckqunxinConfig.KEYFile);
            System.out.println("--------------------"+file.exists()+"===========--");
            System.out.println("--------------------"+LuckqunxinConfig.KEYFile+"===========--");
            if(file.exists()){
                /** 将文件中的SecretKey对象读出 */
                ObjectInputStream ois = new ObjectInputStream(new FileInputStream(LuckqunxinConfig.KEYFile));
                deskey=(SecretKey) ois.readObject();
                //生成Cipher对象,指定其支持的DES算法
                c = Cipher.getInstance("AES");
            }else{
                file.getParentFile().mkdirs();
                keygen = KeyGenerator.getInstance("AES");
                deskey = keygen.generateKey();
                //生成Cipher对象,指定其支持的DES算法
                c = Cipher.getInstance("AES");
                ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(LuckqunxinConfig.KEYFile));
                oos.writeObject(deskey);
            }
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
//            log.info("------------------注意，加解密实例化失败，请检查程序--------------------");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
//            log.info("------------------注意，加解密实例化失败，请检查程序--------------------");
        } catch (IOException e) {
            e.printStackTrace();
//            log.info("------------------注意，加解密实例化失败，请检查程序--------------------");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
//            log.info("------------------注意，加解密实例化失败，请检查程序--------------------");
        } catch (NoSuchPaddingException e) {
            e.printStackTrace();
//            log.info("------------------注意，加解密实例化失败，请检查程序--------------------");
        }
    }


    public static byte[] EncrytorNew(String str) throws InvalidKeyException,
            IllegalBlockSizeException, BadPaddingException {
        // 根据密钥，对Cipher对象进行初始化，ENCRYPT_MODE表示加密模式
        c.init(Cipher.ENCRYPT_MODE, deskey);
        byte[] src = str.getBytes();
        // 加密，结果保存进cipherByte
        byte[] cipherByte = c.doFinal(src);
        return cipherByte;
    }

    public static byte[] DecryptorNew(byte[] buff) throws InvalidKeyException,
            IllegalBlockSizeException, BadPaddingException {
//        initialize();
        // 根据密钥，对Cipher对象进行初始化，DECRYPT_MODE表示加密模式
        c.init(Cipher.DECRYPT_MODE, deskey);

        byte[] cipherByte = c.doFinal(buff);
        return cipherByte;
    }

    /**
     * 主函数
     */
    public static void main(String[] args) throws Exception {

        System.out.println(System.currentTimeMillis());
        String timestamp=""+System.currentTimeMillis();
        String msg = LuckqunxinConfig.aeskey +timestamp+"ompz35b8iiCf1ImvxppooRA1ipKg";

        byte[] encontent=EncrypAES.EncrytorNew(msg);
//        System.out.println("明文是:" + msg);
//        System.out.println("加密后:" + new String(encontent));

        String encoded = Base64.getEncoder().encodeToString(encontent);
//        System.out.println("加码后base64:" + encoded);

        byte[] decoded = Base64.getDecoder().decode(encoded);
//        System.out.println("解码后:" + new String(decoded));
        byte[] decontent = EncrypAES.DecryptorNew(decoded);
//        System.out.println("解密后:" + new String(decontent));



//        String encoded1= "5HFbub2j9uHYZIQdb9iipF0YLLG3Sm6NAzbSQObOU2UjHhP/ghf92x1NOFbqipdFn7VRzNlAV/5aBS+qS+gyWg==";
//        byte[] decoded1 = Base64.getDecoder().decode(encoded1);
//        System.out.println("解码后:" + new String(decoded1));
//        byte[] decontent1 = EncrypAES.DecryptorNew(decoded1);
//        System.out.println("解密后:" + new String(decontent1));


//        System.out.println(System.currentTimeMillis());
//        EncrypAES de1 = new EncrypAES();
//        EncrypAES de2 = new EncrypAES();
////        String msg ="You are not alone.";
//        String msg = BygmallConfig.aeskey +"20201022"+"ompz35b8iiCf1ImvxppooRA1ipKg";
//        byte[] encontent = de1.Encrytor(msg);
//        byte[] decontent = de1.Decryptor(encontent);
//        System.out.println("明文是:" + msg);
//        //Base64 加密
//        String encoded = Base64.getEncoder().encodeToString(encontent);
//        System.out.println("Base 64 加密后：" + encoded);
//
//        //Base64 解密
//        byte[] decoded = Base64.getDecoder().decode(encoded);
//        byte[] decontent2 = de1.Decryptor(decoded);
//
//        byte[] decontent3 = de2.Decryptor(decoded);
//
//
//        System.out.println("加密后:" + new String(encontent));
//        System.out.println("解密后:" + new String(decontent));
//        System.out.println("解密后:" + new String(decontent2));
//        System.out.println("解密后:" + new String(decontent3));
//        System.out.println(System.currentTimeMillis());





    }
}
