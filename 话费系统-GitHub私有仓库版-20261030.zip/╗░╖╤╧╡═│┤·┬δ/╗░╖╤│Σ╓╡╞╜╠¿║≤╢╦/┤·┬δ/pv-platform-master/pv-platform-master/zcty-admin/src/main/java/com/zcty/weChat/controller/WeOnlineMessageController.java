package com.zcty.weChat.controller;

import com.zcty.business.domain.OnlineMessageDTO;
import com.zcty.business.domain.OnlineMessageShow;
import com.zcty.business.service.IOnlineMessageService;
import com.zcty.common.constant.UserConstants;
import com.zcty.common.core.controller.BaseController;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.core.page.TableDataInfo;
import com.zcty.common.utils.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import javax.servlet.http.HttpServletRequest;
import java.util.Collections;
import java.util.List;

/**
 * @Author: chushengkun
 * @Date: 2022/11/29 15:43
 */
@Controller
@RequestMapping("/weChat/onlineMessage")
public class WeOnlineMessageController extends BaseController {

    @Autowired
    private IOnlineMessageService onlineMessageService;

    /**
     * 添加留言
     * @return
     */

    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(OnlineMessageDTO onlineMessageDTO, HttpServletRequest request)
    {
        String openId = (String)request.getAttribute(UserConstants.OPENID);
        if(StringUtils.isEmpty(openId)){
            return AjaxResult.withOutUser();
        }
        return onlineMessageService.insertOnlineMessage(onlineMessageDTO,openId);
    }

    /**
     * 查询留言建议列表 - 分页
     */
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(HttpServletRequest request)
    {
        String openId = (String)request.getAttribute(UserConstants.OPENID);
        if(StringUtils.isEmpty(openId)){
            return new TableDataInfo(Collections.emptyList(),0,0);
        }
        startPage();
        List<OnlineMessageShow> list = onlineMessageService.selectOnlineMessageShowWxList(openId);
        return getDataTable(list);
    }
}
