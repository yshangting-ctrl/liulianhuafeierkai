package com.zcty.business.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
/**
 * 留言小程序端
 */
public class OnlineMessageShow implements Serializable {

    /** 记录ID */
    private String id;
    /** 留言内容 富文本 */
    private String imageText;
    /** 是否已回复 */
    private Integer checkRemarks;
    /** 创建时间 */
    private Date createTime;
    /** 微信号 */
    private String contacts;
    /** 联系电话 */
    private String contactNumber;
    /** 订单号 */
    private String orderNo;
    /** 产品名称 */
    private String productName;

    private List<OnlineMessageReply> list;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getImageText() {
        return imageText;
    }

    public void setImageText(String imageText) {
        this.imageText = imageText;
    }

    public Integer getCheckRemarks() {
        return checkRemarks;
    }

    public void setCheckRemarks(Integer checkRemarks) {
        this.checkRemarks = checkRemarks;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public List<OnlineMessageReply> getList() {
        return list;
    }

    public void setList(List<OnlineMessageReply> list) {
        this.list = list;
    }

    public String getContacts() {
        return contacts;
    }

    public void setContacts(String contacts) {
        this.contacts = contacts;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }
}
