package com.zcty.business.service;

import java.util.List;
import com.zcty.business.domain.OrderSendProductDetail;

/**
 * 业务发货详情Service接口
 * 
 * @author lsw
 * @date 2024-07-09
 */
public interface IOrderSendProductDetailService 
{
    /**
     * 查询业务发货详情
     * 
     * @param id 业务发货详情主键
     * @return 业务发货详情
     */
    public OrderSendProductDetail selectOrderSendProductDetailById(String id);

    /**
     * 查询业务发货详情列表
     * 
     * @param orderSendProductDetail 业务发货详情
     * @return 业务发货详情集合
     */
    public List<OrderSendProductDetail> selectOrderSendProductDetailList(OrderSendProductDetail orderSendProductDetail);

    /**
     * 新增业务发货详情
     * 
     * @param orderSendProductDetail 业务发货详情
     * @return 结果
     */
    public int insertOrderSendProductDetail(OrderSendProductDetail orderSendProductDetail);

    /**
     * 修改业务发货详情
     * 
     * @param orderSendProductDetail 业务发货详情
     * @return 结果
     */
    public int updateOrderSendProductDetail(OrderSendProductDetail orderSendProductDetail);

    /**
     * 批量删除业务发货详情
     * 
     * @param ids 需要删除的业务发货详情主键集合
     * @return 结果
     */
    public int deleteOrderSendProductDetailByIds(String[] ids);

    /**
     * 删除业务发货详情信息
     * 
     * @param id 业务发货详情主键
     * @return 结果
     */
    public int deleteOrderSendProductDetailById(String id);
}
