package com.zcty.business.platformUtils;

import java.text.Collator;
import java.util.*;

/**
 * 字典排序工具
 */
public class DictSortUtils {

    /**
     * 字符串数组排序,回去字符串
     * @param list
     */
    public static String dictSort(List<String> list){

        Collections.sort(list, new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                Comparator<Object> com = Collator.getInstance(Locale.CHINA);
                return com.compare(o1, o2);
            }
        });

        StringBuffer sb=new StringBuffer();
        for(String s:list){
            sb .append(s);
        }

        return sb.toString();

    }

    /**
     * 对map数据进行字典排序
     * @param map
     * @return
     */
    public static String dictMapSort(Map<String,String> map){

        //记录除了sign字段的字符串集合
        StringBuffer sb =new StringBuffer();

        //对原map进行按照参数名ASCII码从小到大排序（字典排序）
        if (!(map instanceof SortedMap<?,?>)) {
            map = new TreeMap<String,String>(map);
        }

        //所有参与传参的参数按照accsii排序（升序），sign参数不参与签名
        Set<?> es =map.entrySet();
        //遍历map
        Iterator<?> it =es.iterator();
        //过滤掉null值和空字符串值，还有不用先传进来的参数key
        while (it.hasNext()) {
            Map.Entry entry= (Map.Entry)it.next();
            String k = (String)entry.getKey();
            Object v =entry.getValue();
            if (null !=v && !"".equals(v) && !"key".equals(k)&&!"sign".equals(k)){
                sb.append(k +"=" +v +"&");
            }
        }

        //最终字符串
        String sbStr=sb.toString();

        return sbStr;

    }




}
