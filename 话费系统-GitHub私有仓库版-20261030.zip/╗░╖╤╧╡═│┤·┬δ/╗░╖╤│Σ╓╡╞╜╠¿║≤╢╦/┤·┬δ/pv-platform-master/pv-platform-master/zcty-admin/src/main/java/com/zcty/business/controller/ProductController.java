package com.zcty.business.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.zcty.common.utils.StringUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.zcty.common.annotation.Log;
import com.zcty.common.core.controller.BaseController;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.enums.BusinessType;
import com.zcty.business.domain.Product;
import com.zcty.business.service.IProductService;
import com.zcty.common.utils.poi.ExcelUtil;
import com.zcty.common.core.page.TableDataInfo;

/**
 * 产品项目Controller
 * 
 * @author lsw
 * @date 2024-03-13
 */
@RestController
@RequestMapping("/business/product")
public class ProductController extends BaseController
{
    @Autowired
    private IProductService productService;

    /**
     * 查询产品项目列表
     */
    @PreAuthorize("@ss.hasPermi('business:product:list')")
    @GetMapping("/list")
    public TableDataInfo list(Product product)
    {
        startPage();
        List<Product> list = productService.selectProductList(product);
        return getDataTable(list);
    }

    /**
     * 导出产品项目列表
     */
    @PreAuthorize("@ss.hasPermi('business:product:export')")
    @Log(title = "产品项目", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, Product product)
    {
        List<Product> list = productService.selectProductList(product);
        ExcelUtil<Product> util = new ExcelUtil<Product>(Product.class);
        util.exportExcel(response, list, "产品项目数据");
    }

    /**
     * 获取产品项目详细信息
     */
    @PreAuthorize("@ss.hasPermi('business:product:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") String id)
    {
        return success(productService.selectProductById(id));
    }

    /**
     * 新增产品项目
     */
    @PreAuthorize("@ss.hasPermi('business:product:add')")
    @Log(title = "产品项目", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody Product product)
    {
        return productService.insertProduct(product);
    }

    /**
     * 修改产品项目
     */
    @PreAuthorize("@ss.hasPermi('business:product:edit')")
    @Log(title = "产品项目", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody Product product)
    {
        return productService.updateProduct(product);
    }

    /**
     * 删除产品项目
     */
    @PreAuthorize("@ss.hasPermi('business:product:remove')")
    @Log(title = "产品项目", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable String[] ids)
    {
        return toAjax(productService.deleteProductByIds(ids));
    }

    /**
     * 状态修改
     */
    @Log(title = "话费商品上下架", businessType = BusinessType.UPDATE)
    @PutMapping("/changeStatus")
    public AjaxResult changeStatus(@RequestBody Product product)
    {
        String id = product.getId();
        if(StringUtils.isEmpty(id)){
            return AjaxResult.error("未找到流量商品信息");
        }
        Product flowProductUpdate = productService.selectProductById(id);
        if(flowProductUpdate==null){
            return AjaxResult.error("未找到流量商品的信息");
        }
        flowProductUpdate.setStatus(product.getStatus());
        return (productService.updateProductStatus(flowProductUpdate));
    }

}
