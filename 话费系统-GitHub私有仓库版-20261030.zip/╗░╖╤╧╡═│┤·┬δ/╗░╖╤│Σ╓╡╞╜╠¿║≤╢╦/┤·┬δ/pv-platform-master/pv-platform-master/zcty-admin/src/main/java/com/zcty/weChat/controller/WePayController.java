package com.zcty.weChat.controller;


import com.zcty.weChat.service.WePayService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 支付和退款回调地址
 */

@Controller
@RequestMapping("/weChat")
public class WePayController {


    @Autowired
    private WePayService wePayService;


    /**
     * 下单支付回调
     * @return
     */
    @PostMapping("/pay/payNotifyUrl/{supplierId}")
    @ResponseBody
    public String payNotifyUrl(HttpServletResponse response, HttpServletRequest request,@PathVariable String supplierId){
        //因为这个请求不经过拦截器，建议这里最好做好跨域处理
        response.setHeader("Access-Control-Allow-Origin", "*");
        return wePayService.payNotifyUrl(response,request,supplierId);
    }

//    /**
//     *
//     * @param response
//     * @param request
//     * @return
//     */
//    @PostMapping("/pay/refundNotifyUrl")
//    @ResponseBody
//    public String refundNotifyUrl(HttpServletResponse response, HttpServletRequest request){
//        //因为这个请求不经过拦截器，建议这里最好做好跨域处理
//        response.setHeader("Access-Control-Allow-Origin", "*");
//        return wePayService.refundNotifyUrl(response,request);
//    }

}
