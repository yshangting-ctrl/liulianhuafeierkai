package com.zcty.business.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.zcty.common.annotation.Log;
import com.zcty.common.core.controller.BaseController;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.enums.BusinessType;
import com.zcty.business.domain.ActivityProduct;
import com.zcty.business.service.IActivityProductService;
import com.zcty.common.core.page.TableDataInfo;

/**
 * 第三方业务商品Controller
 * 
 * @author LSW
 * @date 2024-07-01
 */
@RestController
@RequestMapping("/business/activityProduct")
public class ActivityProductController extends BaseController
{
    @Autowired
    private IActivityProductService activityProductService;

    /**
     * 查询第三方业务商品列表
     */
    @PreAuthorize("@ss.hasPermi('business:activityProduct:list')")
    @GetMapping("/list")
    public TableDataInfo list(ActivityProduct activityProduct)
    {
        startPage();
        List<ActivityProduct> list = activityProductService.selectActivityProductList(activityProduct);
        return getDataTable(list);
    }


    @GetMapping("/platProductList")
    public TableDataInfo platProductList(ActivityProduct activityProduct)
    {
        startPage();
        List<ActivityProduct> list = activityProductService.selectActivityPlatProductList(activityProduct);
        return getDataTable(list);
    }


    /**
     * 查询第三方业务商品列表
     */
    @PostMapping("/selectList")
    public AjaxResult selectList(@RequestBody  ActivityProduct activityProduct)
    {
        activityProduct.setCategory(2);
        List<ActivityProduct> list = activityProductService.selectActivityProductList(activityProduct);
        return AjaxResult.success(list);
    }

    /**
     * 查询第三方业务商品列表
     */
    @PostMapping("/selectProductList")
    public AjaxResult selectProductList(@RequestBody  ActivityProduct activityProduct)
    {
        activityProduct.setCategory(1);
        List<ActivityProduct> list = activityProductService.selectActivityProductList(activityProduct);
        return AjaxResult.success(list);
    }

    /**
     * 获取第三方业务商品详细信息
     */
    @PreAuthorize("@ss.hasPermi('business:activityProduct:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") String id)
    {
        return success(activityProductService.selectActivityProductById(id));
    }



    /**
     * 新增第三方业务商品
     */
    @PreAuthorize("@ss.hasPermi('business:activityProduct:add')")
    @Log(title = "第三方业务商品", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody ActivityProduct activityProduct)
    {
        return (activityProductService.insertActivityProduct(activityProduct));
    }

    /**
     * 修改第三方业务商品
     */
    @PreAuthorize("@ss.hasPermi('business:activityProduct:edit')")
    @Log(title = "第三方业务商品", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody ActivityProduct activityProduct)
    {
        return (activityProductService.updateActivityProduct(activityProduct));
    }

    /**
     * 删除第三方业务商品
     */
    @PreAuthorize("@ss.hasPermi('business:activityProduct:remove')")
    @Log(title = "第三方业务商品", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable String[] ids)
    {
        return toAjax(activityProductService.deleteActivityProductByIds(ids));
    }
}
