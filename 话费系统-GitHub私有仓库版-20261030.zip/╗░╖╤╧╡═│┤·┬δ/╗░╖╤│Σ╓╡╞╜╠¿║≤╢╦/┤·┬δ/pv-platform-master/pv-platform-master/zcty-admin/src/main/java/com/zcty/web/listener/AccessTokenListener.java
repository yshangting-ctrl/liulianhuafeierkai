package com.zcty.web.listener;


import com.alibaba.fastjson2.JSONObject;
import com.zcty.business.domain.WechatProgramInfo;
import com.zcty.business.service.IWechatProgramInfoService;
import com.zcty.common.config.LuckqunxinConfig;
import com.zcty.common.config.ParamNameConfig;
import com.zcty.common.config.WxOpenConfig;
import com.zcty.common.utils.StringUtils;
import com.zcty.web.utlis.HttpSendUtils;
import com.zcty.web.utlis.RedisUtil;
import com.zcty.web.utlis.delay.AccessTokenDeLay;
import com.zcty.web.utlis.delay.DelayType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import org.springframework.web.context.WebApplicationContext;

import javax.servlet.ServletContext;
import java.util.Date;
import java.util.List;
import java.util.concurrent.DelayQueue;

/**
 * 服务器监听器
 * 1、微信小程序的accessToken对象的维护
 */
@Component
public class AccessTokenListener implements ApplicationListener<ContextRefreshedEvent> {

    @Autowired
    private IWechatProgramInfoService wechatProgramInfoService;

    @Override
    public void onApplicationEvent(ContextRefreshedEvent contextRefreshedEvent) {
        // 将 ApplicationContext 转化为 WebApplicationContext
        WebApplicationContext webApplicationContext =
                (WebApplicationContext)contextRefreshedEvent.getApplicationContext();
        // 从 webApplicationContext 中获取  servletContext
        ServletContext servletContext = webApplicationContext.getServletContext();
        // servletContext设置值

        String getAccessTokenUrl="https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid="+ LuckqunxinConfig.appId +"&secret="+ LuckqunxinConfig.appSecret;
        String result= HttpSendUtils.sendGet(getAccessTokenUrl);

        System.out.println("------获取第三方平台授权tocken-----------"+result);
        JSONObject jsonObject = JSONObject.parseObject(result);

        //正常回调,accessToken和expiresIn非空
        String accessToken =jsonObject.getString(ParamNameConfig.ACCESS_TOKEN);
        String expiresIn =jsonObject.getString(ParamNameConfig.EXPIRES_IN);

        //错误回调
        String errcode =jsonObject.getString("errcode");
        String errmsg =jsonObject.getString("errmsg");

        //输出在服务器上打印
        StringBuffer sb=new StringBuffer();
        sb.append("errcode:"+errcode+"\n");
        sb.append("errmsg:"+errmsg+"\n");
        sb.append("accessToken:"+accessToken+"\n");
        sb.append("expiresIn:"+expiresIn+"\n");
//        log.info(sb.toString());

        //执行预授权码获取，每30分钟执行一次，建议28分钟左右获取一次容错
        preAuthCodeDelayFun();

        //执行一个延迟队列，每20分钟去询问authorizer_access_token时间剩余不到30分钟的token需要重新获取
        authorizerAccessTokenFun();

//        //执行网页ticket-jsapi管理
//        webTicketDelayFun();
        //插入服务的上下文
//        servletContext.setAttribute("orderQueue",queue);

        //启动一条线程去处理长时间订单未支付的关闭问题,后面加入的新增订单则调接口把数据put进延迟队列里面
//        orderCloseByTimeOver(servletContext);

//        if(!StringUtils.isEmpty(accessToken)&&!StringUtils.isEmpty(expiresIn)){
//            log.info("-----------获取微信服务需要的access_token成功-------------");

            //将access_token和expires_in保存到context对象里面
//            servletContext.setAttribute(ParamNameConfig.ACCESS_TOKEN, accessToken);
//            servletContext.setAttribute(ParamNameConfig.EXPIRES_IN, expiresIn);

            //授权页面的门票
//            String getJsapiTicketUrl="https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token="+accessToken+"&type=jsapi";
//            String  jsapiResult= HttpSendUtils.sendGet(getJsapiTicketUrl);
//            JSONObject jsonJsapi = JSONObject.parseObject(jsapiResult);
//            String ticket=jsonJsapi.getString(ParamNameConfig.TICKET);
//            servletContext.setAttribute(ParamNameConfig.TICKET, ticket);

            //初始化一个延迟队列并执行，管理授权门票以及access_token
//            accessTokenDelayFun(servletContext,accessToken,Integer.valueOf(expiresIn));




//        }else{
            //获取失败，建议重新开启服务器
//            log.error("获取微信服务需要的access_token失败，错误信息："+errmsg+",错误代码："+errcode+",建议重新开启服务器");
//        }
    }

    //开启一个延迟队列线程，并把需要进行的任务，加入进去执行
//    public void accessTokenDelayFun(ServletContext servletContext, String accessToken, Integer expiresIn){
//        //定义一个延迟队列
//        DelayQueue<AccessTokenDeLay> queue=new DelayQueue<AccessTokenDeLay>();
//        long currentTimeMillis=System.currentTimeMillis();
//        //创建一个延迟队列元素
//        AccessTokenDeLay accessTokenDeLay1=new AccessTokenDeLay( accessToken, currentTimeMillis+expiresIn*1000, DelayType.accessToken);
////        log.info("服务器access_token将在："+new Date(currentTimeMillis+expiresIn*1000)+"过期");
//        //将元素放入队列里面
//        queue.put(accessTokenDeLay1);
//        //把延迟队列塞进服务器上下文里
//        servletContext.setAttribute(ParamNameConfig.Delay_Queue, queue);
//        //执行队列
//        try{
//            Thread thread=new Thread(() -> {
//
//                try {
//                    AccessTokenDeLay accessTokenDeLayItem;
//                    while ((accessTokenDeLayItem = queue.take()) != null) {
////                        log.info("服务器access_token:"+accessTokenDeLayItem.getAccessTokenName()+"已过期，执行获取新数据!");
//                        //设置一个1秒钟的延迟,太快可不妙
//                        Thread.sleep(1000);
//                        //返回值为0则重复执行
//                        int  reLast=0;
//                        while(reLast==0){
//                            //延迟两秒执行
//                            Thread.sleep(2000);
//                            reLast= executeAccessTokenDelay(servletContext);
//                        }
//                    }
//                }catch (Exception e){
//                    e.printStackTrace();
//                }
//            }
//            );
//            thread.start();
//        }catch (Exception e){
//            e.printStackTrace();
//        }
//    }
//
//    //返回的数字是一个秒为单位的数值
//    public static int executeAccessTokenDelay(ServletContext servletContext){
////        log.info("服务器更新新的token信息");
//        int expiresInTime;
//        String getAccessTokenUrl="https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid="+ LuckqunxinConfig.appId +"&secret="+ LuckqunxinConfig.appSecret;
//        String result=HttpSendUtils.sendGet(getAccessTokenUrl);
//        JSONObject jsonObject = JSONObject.parseObject(result);
//
//        String accessToken =jsonObject.getString(ParamNameConfig.ACCESS_TOKEN);
//        String expiresIn =jsonObject.getString(ParamNameConfig.EXPIRES_IN);
//
//        if(!StringUtils.isEmpty(accessToken)&&!StringUtils.isEmpty(expiresIn)){
//            servletContext.setAttribute(ParamNameConfig.ACCESS_TOKEN, accessToken);
//            servletContext.setAttribute(ParamNameConfig.EXPIRES_IN, expiresIn);
//            expiresInTime=Integer.valueOf(expiresIn);
//            //创建一个新的队列元素
//            DelayQueue<AccessTokenDeLay> queue= (DelayQueue<AccessTokenDeLay>)servletContext.getAttribute(ParamNameConfig.Delay_Queue);
//
//            if(queue==null){
//                //服务器的上下文不见了，怎么处理？？？？？？？？？？
//                throw new RuntimeException("服务器的延迟队列上下文不见了");
//            }
//            //授权页面的门票
//            String getJsapiTicketUrl="https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token="+accessToken+"&type=jsapi";
//            String  jsapiResult=HttpSendUtils.sendGet(getJsapiTicketUrl);
//            JSONObject jsonJsapi = JSONObject.parseObject(jsapiResult);
//            String ticket=jsonJsapi.getString(ParamNameConfig.TICKET);
//            servletContext.setAttribute(ParamNameConfig.TICKET, ticket);
//
//
//            //创建一个延迟队列元素
//            AccessTokenDeLay accessTokenDeLay=new AccessTokenDeLay( accessToken, System.currentTimeMillis()+expiresInTime*1000, DelayType.accessToken);
//            queue.put(accessTokenDeLay);
//
//        }else{
//            //若因为某些原因导致不能获取数据
//            expiresInTime=0;
//        }
//        return  expiresInTime;
//    }

    /**
     *  执行预授权码获取，每30分钟执行一次，建议28分钟左右获取一次容错
     */
    public static void  preAuthCodeDelayFun(){
        //定义一个延迟队列
        DelayQueue<AccessTokenDeLay> queue=new DelayQueue<AccessTokenDeLay>();

        System.out.println("-----------获取预授权码的延迟队列开启------------");
        //创建一个延迟队列元素
        AccessTokenDeLay accessTokenDeLay;
        //获取实体类队列元素
        accessTokenDeLay= preAuthCodeDelayFunGetPro();

        queue.put(accessTokenDeLay);

        //执行队列
        try{
                System.out.println("--------执行队列-------------------------");
                //开启一个线程用于执行延迟队列
                Thread thread=new Thread(() -> {
                    try {
                        while ((queue.take()) != null) {
//                        log.info("服务器access_token:"+accessTokenDeLayItem.getAccessTokenName()+"已过期，执行获取新数据!");
                            //设置一个1秒钟的延迟,太快可不妙
                            Thread.sleep(2000);
                            //返回值为0则重复执行
                            AccessTokenDeLay  accessTokenDeLayThread= preAuthCodeDelayFunGetPro();
                            queue.put(accessTokenDeLayThread);
                        }
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }
                );
                thread.start();
            }catch (Exception e){
                e.printStackTrace();
            }
        }

    /**
     * 获取执行预授权码获取延迟队列的实体类
     */
    public static AccessTokenDeLay  preAuthCodeDelayFunGetPro(){
        //创建一个延迟队列元素
        AccessTokenDeLay accessTokenDeLay;
        //当前时间戳
        long currentTimeMillis=System.currentTimeMillis();
        //第三方平台调用凭证
        String  component_access_token =  RedisUtil.get(WxOpenConfig.COMPONENT_ACCESS_TOKEN);
        System.out.println("-----------component_access_token------------"+component_access_token);
        //判断是否存在，若不存在，则在十分钟之后进行调用
        if(StringUtils.isEmpty(component_access_token)){
            //设置一个十分钟厚
            long expiresIn = 60*10*1000l;
            accessTokenDeLay= new AccessTokenDeLay( "" , currentTimeMillis+expiresIn, DelayType.preAuthCode);
        }else {
            long expiresIn = 60 * 10 * 1000 * 3l;

            //微信获取授权链接码的url
            String url = WxOpenConfig.GET_PRE_AUTH_CODE_URL+component_access_token;

            //发送请求的时候参数POST
            String data = "";
            data += "{";

            data += "\"component_appid\":";
            data += "\"" + WxOpenConfig.appId + "\"";

            data += "}";

            //发送获取第三方平台预授权码接口
            String result = HttpSendUtils.doPost(url, data, 5000);
            //返回值
//            {
//                "pre_auth_code": "Cx_Dk6qiBE0Dmx4EmlT3oRfArPvwSQ-oa3NL_fwHM7VI08r52wazoZX2Rhpz1dEw",
//                    "expires_in": 600
//            }

            System.out.println(result);
            JSONObject json = JSONObject.parseObject(result);
            System.out.println("--------component_access_token-------:" + component_access_token);

            String pre_auth_code = json.getString(WxOpenConfig.PRE_AUTH_CODE);
            System.out.println("--------pre_auth_code-------:" + pre_auth_code);
            String expires_in = json.getString("expires_in");
            System.out.println("--------expires_in-------:" + expires_in);
            //若调取应用成功，按照神域分钟数减去2，若调取失败，则10分钟后在调取
            if (StringUtils.isEmpty(pre_auth_code)) {
                expiresIn = 60 * 10 * 1000l;
                accessTokenDeLay = new AccessTokenDeLay("", currentTimeMillis + expiresIn, DelayType.preAuthCode);
            } else {
                //成功调取
                expiresIn = StringUtils.isEmpty(expires_in) ? expiresIn : (Long.valueOf(expires_in) - 60 * 2l) * 1000l;
                //不能小于0
                if(expiresIn<=0l){
                    expiresIn = 60 * 10 * 1000l;
                }
                accessTokenDeLay = new AccessTokenDeLay(pre_auth_code, currentTimeMillis + expiresIn, DelayType.preAuthCode);
                System.out.println("-------------------------成功获取预授权码-------------------");
                RedisUtil.set(WxOpenConfig.PRE_AUTH_CODE, pre_auth_code);
            }
        }
        return accessTokenDeLay;
    }
    /**
     *     执行一个延迟队列，每20分钟去询问authorizer_access_token时间剩余不到20分钟的token需要重新获取
     */
    public void authorizerAccessTokenFun(){
        //定义一个延迟队列
        DelayQueue<AccessTokenDeLay> queue=new DelayQueue<AccessTokenDeLay>();

        System.out.println("-----------获取各个公众号token的刷新延迟队列开启------------");

        long timeStart = System.currentTimeMillis()+60*20*1000l;
        //创建一个延迟队列元素
        AccessTokenDeLay accessTokenDeLay = new AccessTokenDeLay("",timeStart,2);

        queue.put(accessTokenDeLay);

        //执行队列
        try{
            System.out.println("--------执行队列-------------------------");
            //开启一个线程用于执行延迟队列
            Thread thread=new Thread(() -> {
                try {
                    while ((queue.take()) != null) {
//                        log.info("服务器access_token:"+accessTokenDeLayItem.getAccessTokenName()+"已过期，执行获取新数据!");
                        //设置一个1秒钟的延迟,太快可不妙
                        Thread.sleep(2000);
                        //返回值为0则重复执行
                        AccessTokenDeLay  accessTokenDeLayThread= authorizerAccessTokenFunGetPro();
                        queue.put(accessTokenDeLayThread);
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
            );
            thread.start();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public AccessTokenDeLay authorizerAccessTokenFunGetPro(){
        long timeStart = System.currentTimeMillis()+60*20*1000l;
        //创建一个延迟队列元素
        AccessTokenDeLay accessTokenDeLay = new AccessTokenDeLay("",timeStart,2);

        try {

        //执行查询
        List<WechatProgramInfo> list = wechatProgramInfoService.selectWechatProgramInfoList(new WechatProgramInfo());
        //redis上剩余时间少于20分钟的

        for(WechatProgramInfo wpi:list){

            String authorizer_access_token = RedisUtil.get("authorizer_access_token"+wpi.getAuthorizerAppid());
            long ttl =  RedisUtil.getTtl("authorizer_access_token"+wpi.getAuthorizerAppid());

            //需要刷新令牌的两个条件，一个是已经过期了，redis里面的令牌不见了，
            if(StringUtils.isEmpty(authorizer_access_token)){

                getAuthorizerAccessToken(wpi);

            }else{
                //第二个，还没消失，当时剩余时间不足30分钟，包含三十分钟
                if(ttl<=30l){
                    getAuthorizerAccessToken(wpi);
                }
            }

        }
        }catch (Exception e){
            System.out.println("--------执行公众号accesstoken循环获取出问题--------请检查---:"+e.getMessage());
        }
        return accessTokenDeLay;
    }

    public static void main(String[] args) {
        long timeStart = System.currentTimeMillis();
        System.out.println(timeStart);
        timeStart = timeStart +60*30*1000l;
        System.out.println(timeStart);

        System.out.println(new Date(timeStart));
    }


    public void getAuthorizerAccessToken(WechatProgramInfo wpi){

        try {
            String component_access_token = RedisUtil.get(WxOpenConfig.COMPONENT_ACCESS_TOKEN);

            String url = WxOpenConfig.API_AUTHORIZER_TOKEN;
            url = url + component_access_token;


            //发送请求的时候参数POST
            String data = "";
            data += "{";

            data += "\"component_appid\":";
            data += "\"" + WxOpenConfig.appId + "\",";

            data += "\"authorizer_appid\":";
            data += "\"" + wpi.getAuthorizerAppid() + "\",";

            data += "\"authorizer_refresh_token\":";
            data += "\"" + wpi.getAuthorizerRefreshToken() + "\"";

            data += "}";

            //发送获取公众号调取api接口的accesstoken接口
            String result = HttpSendUtils.doPost(url, data, 5000);

            System.out.println(result);
            JSONObject json = JSONObject.parseObject(result);
            System.out.println("--------API_AUTHORIZER_TOKEN-------:信息重新拉取");

            String authorizer_access_token = json.getString(WxOpenConfig.authorizer_access_token);
            System.out.println("--------authorizer_access_token-------:" + authorizer_access_token);
            String expires_in = json.getString("expires_in");
            int expiresIn = Integer.valueOf(expires_in);
            System.out.println("--------expires_in-------:" + expires_in);
            //最终执行
            RedisUtil.set("authorizer_access_token"+wpi.getAuthorizerAppid(),authorizer_access_token,expiresIn);
            String authorizer_refresh_token = json.getString("authorizer_refresh_token");
            System.out.println("--------authorizer_refresh_token-------:" + authorizer_refresh_token);

            System.out.println("-------比较获取token之前的刷新令牌和获取之后的刷新令牌数据----"+wpi.getAuthorizerRefreshToken().equals(authorizer_refresh_token));

            //授权页面的门票
            String getJsapiTicketUrl="https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token="+System.getenv().getOrDefault("WX_JSAPI_ACCESS_TOKEN", "")+"&type=jsapi";

            System.out.println("-------发送请求获取网页的JsapiTicket----"+getJsapiTicketUrl);

            String  jsapiResult=HttpSendUtils.sendGet(getJsapiTicketUrl);
            JSONObject jsonJsapi = JSONObject.parseObject(jsapiResult);
            System.out.println("-------获取网页的JsapiTicket--结果--"+jsonJsapi);
            String ticket=jsonJsapi.getString(ParamNameConfig.TICKET);

            RedisUtil.set("authorizer_jsapi_ticket"+wpi.getAuthorizerAppid(),ticket,expiresIn);



        }catch (Exception e){
            System.out.println("--------API_AUTHORIZER_TOKEN-------:信息重新拉取结果---------失败---"+e.getMessage() );
        }

    }
}
