package com.zcty.pv.service;

import com.zcty.pv.domain.WeChatUser;

import java.util.List;

/**
 * 微名用户 服务层
 * 
 * @author liuruibin
 * @date 2020-04-03
 */
public interface IWeChatUserService 
{
	/**
     * 查询微名用户信息
     * 
     * @param id 微名用户ID
     * @return 微名用户信息
     */
	public WeChatUser selectWeChatUserById(String id);
	
	/**
     * 查询微名用户列表
     * 
     * @param weChatUser 微名用户信息
     * @return 微名用户集合
     */
	public List<WeChatUser> selectWeChatUserList(WeChatUser weChatUser);
	
	/**
     * 新增微名用户
     * 
     * @param weChatUser 微名用户信息
     * @return 结果
     */
	public int insertWeChatUser(WeChatUser weChatUser);
	
	/**
     * 修改微名用户
     * 
     * @param weChatUser 微名用户信息
     * @return 结果
     */
	public int updateWeChatUser(WeChatUser weChatUser);

	/**获取唯一的用户id
	 * @return
	 */
	public String getUniqueUserId();

	/**
	 * 删除会员
	 * @param id
	 * @return
	 */
	public int deleteWeChatUserByIds(String id);

	/**
	 * 根据openId查询用户信息
	 * @param openId
	 * @return
	 */
	public WeChatUser selectWeChatUserByOpenId(String openId);

	/**
	 * 根据用户id查询用户信息
	 * @param userId
	 * @return
	 */
	public WeChatUser selectWeChatUserByUserId(String userId);

}
