package com.zcty.business.service;

import java.util.List;
import com.zcty.business.domain.SupplierCapital;
import com.zcty.business.domain.SupplierCapitalVo;
import com.zcty.common.core.domain.AjaxResult;

/**
 * 代理商资金Service接口
 * 
 * @author ruoyi
 * @date 2024-06-24
 */
public interface ISupplierCapitalService 
{
    /**
     * 查询代理商资金
     * 
     * @param id 代理商资金主键
     * @return 代理商资金
     */
    public SupplierCapital selectSupplierCapitalById(String id);

    /**
     * 查询代理商资金列表
     * 
     * @param supplierCapital 代理商资金
     * @return 代理商资金集合
     */
    public List<SupplierCapital> selectSupplierCapitalList(SupplierCapital supplierCapital);

    /**
     * 新增代理商资金
     * 
     * @param supplierCapital 代理商资金
     * @return 结果
     */
    public int insertSupplierCapital(SupplierCapital supplierCapital);

    /**
     * 修改代理商资金
     * 
     * @param supplierCapital 代理商资金
     * @return 结果
     */
    public AjaxResult updateSupplierCapital(SupplierCapital supplierCapital);

    /**
     * 批量删除代理商资金
     * 
     * @param ids 需要删除的代理商资金主键集合
     * @return 结果
     */
    public int deleteSupplierCapitalByIds(String[] ids);

    /**
     * 删除代理商资金信息
     * 
     * @param id 代理商资金主键
     * @return 结果
     */
    public int deleteSupplierCapitalById(String id);


    public List<SupplierCapitalVo> selectSupplierCapitalVoList(SupplierCapitalVo supplierCapitalVo);

    public SupplierCapitalVo selectSupplierCapitalVoById(String id);
}
