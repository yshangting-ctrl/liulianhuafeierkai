package com.zcty.pv.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.zcty.common.annotation.Log;
import com.zcty.common.core.controller.BaseController;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.enums.BusinessType;
import com.zcty.pv.domain.PvArea;
import com.zcty.pv.service.IPvAreaService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import com.zcty.common.utils.poi.ExcelUtil;
import com.zcty.common.core.page.TableDataInfo;

/**
 * 区域Controller
 * 
 * @author luohui
 * @date 2022-11-29
 */
@Api(tags = "区域接口")
@RestController
@RequestMapping("/pv/area")
public class PvAreaController extends BaseController
{
    @Autowired
    private IPvAreaService pvAreaService;

    /**
     * 查询区域列表
     */
    @ApiOperation("查询区域列表")
    @PreAuthorize("@ss.hasPermi('pv:area:list')")
    @GetMapping("/list")
    public TableDataInfo list(PvArea pvArea)
    {
        startPage();
        List<PvArea> list = pvAreaService.selectPvAreaList(pvArea);
        return getDataTable(list);
    }

    /**
     * 导出区域列表
     */
    @ApiOperation("导出区域列表")
    @PreAuthorize("@ss.hasPermi('pv:area:export')")
    @Log(title = "区域", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, PvArea pvArea)
    {
        List<PvArea> list = pvAreaService.selectPvAreaList(pvArea);
        ExcelUtil<PvArea> util = new ExcelUtil<PvArea>(PvArea.class);
        util.exportExcel(response, list, "区域数据");
    }

    /**
     * 获取区域详细信息
     */
    @ApiOperation("获取区域详细信息")
    @PreAuthorize("@ss.hasPermi('pv:area:query')")
    @GetMapping(value = "/{areaId}")
    public AjaxResult getInfo(@PathVariable("areaId") String areaId)
    {
        return success(pvAreaService.selectPvAreaByAreaId(areaId));
    }

    /**
     * 新增区域
     */
    @ApiOperation("新增区域")
    @PreAuthorize("@ss.hasPermi('pv:area:add')")
    @Log(title = "区域", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody PvArea pvArea)
    {
        pvArea.setCreateBy(getNickname());
        return toAjax(pvAreaService.insertPvArea(pvArea));
    }

    /**
     * 修改区域
     */
    @ApiOperation("修改区域")
    @PreAuthorize("@ss.hasPermi('pv:area:edit')")
    @Log(title = "区域", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody PvArea pvArea)
    {
        pvArea.setUpdateBy(getNickname());
        return toAjax(pvAreaService.updatePvArea(pvArea));
    }

    /**
     * 删除区域
     */
    @ApiOperation("删除区域")
    @PreAuthorize("@ss.hasPermi('pv:area:remove')")
    @Log(title = "区域", businessType = BusinessType.DELETE)
	@DeleteMapping("/{areaIds}")
    public AjaxResult remove(@PathVariable String[] areaIds)
    {
        return toAjax(pvAreaService.deletePvAreaByAreaIds(areaIds));
    }
}
