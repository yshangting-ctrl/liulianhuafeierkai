package com.zcty.business.service.impl;

import java.util.List;
import com.zcty.common.utils.DateUtils;
import com.zcty.web.utlis.IdGen;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zcty.business.mapper.PlatformInfosMapper;
import com.zcty.business.domain.PlatformInfos;
import com.zcty.business.service.IPlatformInfosService;

/**
 * 第三方充值平台管理Service业务层处理
 * 
 * @author lsw
 * @date 2024-06-29
 */
@Service
public class PlatformInfosServiceImpl implements IPlatformInfosService 
{
    @Autowired
    private PlatformInfosMapper platformInfosMapper;

    /**
     * 查询第三方充值平台管理
     * 
     * @param id 第三方充值平台管理主键
     * @return 第三方充值平台管理
     */
    @Override
    public PlatformInfos selectPlatformInfosById(String id)
    {
        return platformInfosMapper.selectPlatformInfosById(id);
    }

    /**
     * 查询第三方充值平台管理列表
     * 
     * @param platformInfos 第三方充值平台管理
     * @return 第三方充值平台管理
     */
    @Override
    public List<PlatformInfos> selectPlatformInfosList(PlatformInfos platformInfos)
    {
        return platformInfosMapper.selectPlatformInfosList(platformInfos);
    }

    /**
     * 新增第三方充值平台管理
     * 
     * @param platformInfos 第三方充值平台管理
     * @return 结果
     */
    @Override
    public int insertPlatformInfos(PlatformInfos platformInfos)
    {
        String id = IdGen.uuid();
        platformInfos.setDelFlag(0);
        platformInfos.setUseStatus(1);
        platformInfos.setId(id);
        platformInfos.setCreateTime(DateUtils.getNowDate());
        return platformInfosMapper.insertPlatformInfos(platformInfos);
    }

    /**
     * 修改第三方充值平台管理
     * 
     * @param platformInfos 第三方充值平台管理
     * @return 结果
     */
    @Override
    public int updatePlatformInfos(PlatformInfos platformInfos)
    {
        return platformInfosMapper.updatePlatformInfos(platformInfos);
    }

    /**
     * 批量删除第三方充值平台管理
     * 
     * @param ids 需要删除的第三方充值平台管理主键
     * @return 结果
     */
    @Override
    public int deletePlatformInfosByIds(String[] ids)
    {
        return platformInfosMapper.deletePlatformInfosByIds(ids);
    }

    /**
     * 删除第三方充值平台管理信息
     * 
     * @param id 第三方充值平台管理主键
     * @return 结果
     */
    @Override
    public int deletePlatformInfosById(String id)
    {
        return platformInfosMapper.deletePlatformInfosById(id);
    }


    @Override
    public PlatformInfos selectPlatformInfosByKeyWord(String platformKey) {
        return platformInfosMapper.selectPlatformInfosByKeyWord(platformKey);
    }
}
