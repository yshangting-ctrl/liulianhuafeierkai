package com.zcty.business.service;


import com.zcty.business.domain.INumber;

/**
 * @authour:linxiaohan
 * @date:2018/12/13
 * @description:
 */
public interface INumberService {

    void save(INumber INumber);

    INumber selectByDateAndType(String date, int type);

    void update(INumber INumber);

    INumber selectByType(Integer type);
}
