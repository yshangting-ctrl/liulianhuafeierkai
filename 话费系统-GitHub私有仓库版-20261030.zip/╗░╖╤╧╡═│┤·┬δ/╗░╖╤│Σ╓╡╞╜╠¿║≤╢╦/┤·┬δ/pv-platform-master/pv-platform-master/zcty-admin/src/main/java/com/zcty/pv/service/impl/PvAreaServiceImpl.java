package com.zcty.pv.service.impl;

import java.util.List;
import com.zcty.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zcty.pv.mapper.PvAreaMapper;
import com.zcty.pv.domain.PvArea;
import com.zcty.pv.service.IPvAreaService;

/**
 * 区域Service业务层处理
 * 
 * @author luohui
 * @date 2022-11-12
 */
@Service
public class PvAreaServiceImpl implements IPvAreaService 
{
    @Autowired
    private PvAreaMapper pvAreaMapper;

    /**
     * 查询区域
     * 
     * @param areaId 区域主键
     * @return 区域
     */
    @Override
    public PvArea selectPvAreaByAreaId(String areaId)
    {
        return pvAreaMapper.selectPvAreaByAreaId(areaId);
    }

    /**
     * 查询区域列表
     * 
     * @param pvArea 区域
     * @return 区域
     */
    @Override
    public List<PvArea> selectPvAreaList(PvArea pvArea)
    {
        return pvAreaMapper.selectPvAreaList(pvArea);
    }

    /**
     * 新增区域
     * 
     * @param pvArea 区域
     * @return 结果
     */
    @Override
    public int insertPvArea(PvArea pvArea)
    {
        pvArea.setCreateTime(DateUtils.getNowDate());
        return pvAreaMapper.insertPvArea(pvArea);
    }

    /**
     * 修改区域
     * 
     * @param pvArea 区域
     * @return 结果
     */
    @Override
    public int updatePvArea(PvArea pvArea)
    {
        pvArea.setUpdateTime(DateUtils.getNowDate());
        return pvAreaMapper.updatePvArea(pvArea);
    }

    /**
     * 批量删除区域
     * 
     * @param areaIds 需要删除的区域主键
     * @return 结果
     */
    @Override
    public int deletePvAreaByAreaIds(String[] areaIds)
    {
        return pvAreaMapper.deletePvAreaByAreaIds(areaIds);
    }

    /**
     * 删除区域信息
     * 
     * @param areaId 区域主键
     * @return 结果
     */
    @Override
    public int deletePvAreaByAreaId(String areaId)
    {
        return pvAreaMapper.deletePvAreaByAreaId(areaId);
    }
}
