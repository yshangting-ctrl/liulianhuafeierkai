package com.zcty.pv.service.impl;


import com.zcty.pv.domain.UserUnique;
import com.zcty.pv.mapper.UserUniqueMapper;
import com.zcty.pv.service.IUserUniqueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 用户唯一编号记录 服务层实现
 * 
 * @author liuruibin
 * @date 2020-12-10
 */
@Service
public class UserUniqueServiceImpl implements IUserUniqueService
{
	@Autowired
	private UserUniqueMapper userUniqueMapper;

	/**
     * 查询用户唯一编号记录信息
     * 
     * @param id 用户唯一编号记录ID
     * @return 用户唯一编号记录信息
     */
    @Override
	public UserUnique selectUserUniqueById(String id)
	{
	    return userUniqueMapper.selectUserUniqueById(id);
	}

    /**
     * 新增用户唯一编号记录
     * 
     * @param userUnique 用户唯一编号记录信息
     * @return 结果
     */
	@Override
	public int insertUserUnique(UserUnique userUnique)
	{
	    return userUniqueMapper.insertUserUnique(userUnique);
	}
	


	
}
