package com.zcty.api;

import com.zcty.common.config.WxOpenConfig;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.utils.StringUtils;
import com.zcty.web.utlis.RedisUtil;
import com.zcty.web.utlis.TicketHttpSend;
import com.zcty.web.utlis.wxUtils.WXBizMsgCrypt;
import com.zcty.web.utlis.wxUtils.XMLParse;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Map;

/**
 * 用于接受授权门票的入口
 */
@Controller
@RequestMapping("/api/component")
public class TicketComponentController {

    /**
     * 用于调试项目程序是否正常运行的入口
     * @return
     */
    @GetMapping("/test")
    @ResponseBody
    public AjaxResult test(String key){

        String value = RedisUtil.get(key);
        long ttl = RedisUtil.getTtl(key);
        return AjaxResult.success("value:"+value+";"+"ttl:"+ttl);
    }


    /**
     * 用于调试项目程序是否正常运行的入口
     * @return
     */
    @PostMapping("/verifyTicket")
    @ResponseBody
    public String verifyTicket(HttpServletResponse response, HttpServletRequest request){
        //因为这个请求不经过拦截器，建议这里最好做好跨域处理
        response.setHeader("Access-Control-Allow-Origin", "*");
        //解析获取推送事件ComponentVerifyTicket
        String ComponentVerifyTicket = "";
        BufferedReader br = null;
        String callbackMessage = null;
        try {
            br = new BufferedReader(new InputStreamReader(
                    request.getInputStream(), "UTF-8"));

            String buffer;
            StringBuffer xml = new StringBuffer();
            while ((buffer = br.readLine()) != null) {
                xml.append(buffer);
            }
            callbackMessage = xml.toString();
            System.out.println(callbackMessage);
//            JSONObject jsonObject = FastJsonUtil.xmlToFastJson(callbackMessage);
            //空值判断
//             if(jsonObject!=null){
//                 String a = "<xml>\n" +
//                         "<AppId>some_appid</AppId>\n" +
//                         "<CreateTime>1413192605</CreateTime>\n" +
//                         "<InfoType>component_verify_ticket</InfoType>\n" +
//                         "<ComponentVerifyTicket>some_verify_ticket</ComponentVerifyTicket>\n" +
//                         "</xml>";
                 //xml层
//                 JSONObject xmlJson = jsonObject.getJSONObject("xml");
                 //ComponentVerifyTicket
//                 if(xmlJson!=null){
//                     ComponentVerifyTicket = xmlJson.getString("ComponentVerifyTicket");


//                 }
//             }

            String msgSignature = request.getParameter("msg_signature");
            System.out.println("------------------msgSignature:"+msgSignature+"-----------");
            String timeStamp = request.getParameter("timestamp");
            System.out.println("------------------timeStamp:"+timeStamp+"-----------");
            String nonce = request.getParameter("nonce");
            System.out.println("------------------nonce:"+nonce+"-----------");
            WXBizMsgCrypt wxcpt = new WXBizMsgCrypt(WxOpenConfig.appToken, WxOpenConfig.encodingAesKey, WxOpenConfig.appId);
//          String msgXml = null;
            String result = wxcpt.decryptMsg(msgSignature,timeStamp, nonce, callbackMessage);
            System.out.println(result);

            Map<String,String> ticketInfo =   XMLParse.getComponentVerifyTicket(result);
            System.out.println(ticketInfo);
            //component_verify_ticket 的有效时间为12小时


            String oldTICKET =   RedisUtil.get(WxOpenConfig.COMPONENT_VERIFY_TICKET);

            if(StringUtils.isEmpty(oldTICKET)||!oldTICKET.equals(ticketInfo.get("ComponentVerifyTicket"))){

            }

            if("component_verify_ticket".equals(ticketInfo.get("InfoType"))){
                System.out.println("-----------------------------------获取component_verify_ticket推送信息成功---------------------------");
                //将access_token和expires_in保存到redis对象里面
                RedisUtil.set(WxOpenConfig.COMPONENT_VERIFY_TICKET, ticketInfo.get("ComponentVerifyTicket"));
                RedisUtil.set(WxOpenConfig.COMPONENT_VERIFY_TICKET_EXPIRES_IN,  ticketInfo.get("CreateTime")+0000);
                TicketHttpSend.getCompentToken(ticketInfo.get("ComponentVerifyTicket"));
            }


//            String componentVerifyTicket = (String)ticketInfo[2];
//            Integer createTime = (Integer)ticketInfo[0];
//            System.out.println(ticketInfo);
//            System.out.println("---------------------componentVerifyTicket----------:"+componentVerifyTicket);
//            System.out.println("---------------------createTime----------:"+createTime);
//            System.out.println(ticketInfo);

        }catch (Exception e){

        }finally {
            if(br!=null){
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return "success";
        }

    }



}
