package com.zcty.business.mapper;

import java.util.List;
import com.zcty.business.domain.SupplierCapitalLog;
import com.zcty.business.domain.SupplierCapitalLogVo;

/**
 * 代理商资金使用记录Mapper接口
 * 
 * @author ruoyi
 * @date 2024-06-24
 */
public interface SupplierCapitalLogMapper 
{
    /**
     * 查询代理商资金使用记录
     * 
     * @param id 代理商资金使用记录主键
     * @return 代理商资金使用记录
     */
    public SupplierCapitalLog selectSupplierCapitalLogById(String id);

    /**
     * 查询代理商资金使用记录列表
     * 
     * @param supplierCapitalLog 代理商资金使用记录
     * @return 代理商资金使用记录集合
     */
    public List<SupplierCapitalLog> selectSupplierCapitalLogList(SupplierCapitalLog supplierCapitalLog);

    /**
     * 新增代理商资金使用记录
     * 
     * @param supplierCapitalLog 代理商资金使用记录
     * @return 结果
     */
    public int insertSupplierCapitalLog(SupplierCapitalLog supplierCapitalLog);

    /**
     * 修改代理商资金使用记录
     * 
     * @param supplierCapitalLog 代理商资金使用记录
     * @return 结果
     */
    public int updateSupplierCapitalLog(SupplierCapitalLog supplierCapitalLog);

    /**
     * 删除代理商资金使用记录
     * 
     * @param id 代理商资金使用记录主键
     * @return 结果
     */
    public int deleteSupplierCapitalLogById(String id);

    /**
     * 批量删除代理商资金使用记录
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteSupplierCapitalLogByIds(String[] ids);


    /**
     * 查询前端显示的列表信息
     * @param supplierCapitalLogVo
     * @return
     */
    public  List<SupplierCapitalLogVo>  selectSupplierCapitalLogVoList(SupplierCapitalLogVo supplierCapitalLogVo);
}
