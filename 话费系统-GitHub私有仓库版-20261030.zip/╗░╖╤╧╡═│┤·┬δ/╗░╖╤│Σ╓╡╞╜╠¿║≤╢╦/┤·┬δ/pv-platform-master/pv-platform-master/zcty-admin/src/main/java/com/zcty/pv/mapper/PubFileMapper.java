package com.zcty.pv.mapper;

import java.util.List;
import com.zcty.pv.domain.PubFile;

/**
 * 通用文件Mapper接口
 * 
 * @author luohui
 * @date 2022-11-20
 */
public interface PubFileMapper 
{
    /**
     * 查询通用文件
     * 
     * @param id 通用文件主键
     * @return 通用文件
     */
    public PubFile selectPubFileById(Long id);

    /**
     * 查询通用文件列表
     * 
     * @param pubFile 通用文件
     * @return 通用文件集合
     */
    public List<PubFile> selectPubFileList(PubFile pubFile);

    /**
     * 新增通用文件
     * 
     * @param pubFile 通用文件
     * @return 结果
     */
    public int insertPubFile(PubFile pubFile);

    /**
     * 修改通用文件
     * 
     * @param pubFile 通用文件
     * @return 结果
     */
    public int updatePubFile(PubFile pubFile);

    /**
     * 删除通用文件
     * 
     * @param id 通用文件主键
     * @return 结果
     */
    public int deletePubFileById(Long id);

    /**
     * 批量删除通用文件
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deletePubFileByIds(Long[] ids);
}
