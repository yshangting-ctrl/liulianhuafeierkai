package com.zcty.business.service;



import com.zcty.business.domain.OnlineMessageReply;
import com.zcty.common.core.domain.AjaxResult;

import java.util.List;

/**
 * 留言回复 服务层
 * 
 * @author liuruibin
 * @date 2023-03-10
 */
public interface IOnlineMessageReplyService 
{
	/**
     * 查询留言回复信息
     * 
     * @param id 留言回复ID
     * @return 留言回复信息
     */
	public OnlineMessageReply selectOnlineMessageReplyById(String id);
	
	/**
     * 查询留言回复列表
     * 
     * @param onlineMessageReply 留言回复信息
     * @return 留言回复集合
     */
	public List<OnlineMessageReply> selectOnlineMessageReplyList(OnlineMessageReply onlineMessageReply);


	
	/**
     * 新增留言回复
     * 
     * @param onlineMessageReply 留言回复信息
     * @return 结果
     */
	public AjaxResult insertOnlineMessageReply(OnlineMessageReply onlineMessageReply);
	
	/**
     * 修改留言回复
     * 
     * @param onlineMessageReply 留言回复信息
     * @return 结果
     */
	public AjaxResult updateOnlineMessageReply(OnlineMessageReply onlineMessageReply);
		
	/**
     * 删除留言回复信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteOnlineMessageReplyByIds(String ids);
	
}
