package com.zcty.pv.service.impl;

import java.util.List;

import cn.hutool.core.util.IdUtil;
import com.zcty.common.utils.DateUtils;
import com.zcty.common.utils.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zcty.pv.mapper.PvSerialNumberMapper;
import com.zcty.pv.domain.PvSerialNumber;
import com.zcty.pv.service.IPvSerialNumberService;

/**
 * 编号生成记录Service业务层处理
 * 
 * @author luohui
 * @date 2022-12-07
 */
@Service
public class PvSerialNumberServiceImpl implements IPvSerialNumberService 
{
    @Autowired
    private PvSerialNumberMapper pvSerialNumberMapper;

    /**
     * 查询编号生成记录
     * 
     * @param id 编号生成记录主键
     * @return 编号生成记录
     */
    @Override
    public PvSerialNumber selectPvSerialNumberById(Long id)
    {
        return pvSerialNumberMapper.selectPvSerialNumberById(id);
    }

    /**
     * 查询编号生成记录列表
     * 
     * @param pvSerialNumber 编号生成记录
     * @return 编号生成记录
     */
    @Override
    public List<PvSerialNumber> selectPvSerialNumberList(PvSerialNumber pvSerialNumber)
    {
        return pvSerialNumberMapper.selectPvSerialNumberList(pvSerialNumber);
    }

    /**
     * 新增编号生成记录
     * 
     * @param pvSerialNumber 编号生成记录
     * @return 结果
     */
    @Override
    public int insertPvSerialNumber(PvSerialNumber pvSerialNumber)
    {
        pvSerialNumber.setId(IdUtil.getSnowflakeNextId());
        pvSerialNumber.setCreateTime(DateUtils.getNowDate());
        pvSerialNumber.setCreateBy(SecurityUtils.getNickname());
        return pvSerialNumberMapper.insertPvSerialNumber(pvSerialNumber);
    }

    /**
     * 修改编号生成记录
     * 
     * @param pvSerialNumber 编号生成记录
     * @return 结果
     */
    @Override
    public int updatePvSerialNumber(PvSerialNumber pvSerialNumber)
    {
        pvSerialNumber.setUpdateTime(DateUtils.getNowDate());
        pvSerialNumber.setUpdateBy(SecurityUtils.getNickname());
        return pvSerialNumberMapper.updatePvSerialNumber(pvSerialNumber);
    }

    /**
     * 批量删除编号生成记录
     * 
     * @param ids 需要删除的编号生成记录主键
     * @return 结果
     */
    @Override
    public int deletePvSerialNumberByIds(Long[] ids)
    {
        return pvSerialNumberMapper.deletePvSerialNumberByIds(ids);
    }

    /**
     * 删除编号生成记录信息
     * 
     * @param id 编号生成记录主键
     * @return 结果
     */
    @Override
    public int deletePvSerialNumberById(Long id)
    {
        return pvSerialNumberMapper.deletePvSerialNumberById(id);
    }

    /**
     * 根据前缀查询出当前最大的编号
     *
     * @param prefix
     * @return
     */
    @Override
    public PvSerialNumber getMaxSerialNo(String prefix) {
        return pvSerialNumberMapper.getMaxSerialNumber(prefix);
    }
}
