package com.zcty.weChat.service.impl;

import com.alibaba.fastjson2.JSONObject;
import com.zcty.business.domain.Supplier;
import com.zcty.business.service.ISupplierService;
import com.zcty.common.config.LuckqunxinConfig;
import com.zcty.common.config.WeChatAccountConfig;
import com.zcty.common.config.WxOpenConfig;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.utils.StringUtils;
import com.zcty.pv.domain.WeChatUser;
import com.zcty.pv.service.IWeChatUserService;
import com.zcty.weChat.domain.WxConfigVo;
import com.zcty.weChat.service.WechatIndexService;
import com.zcty.web.utlis.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import javax.servlet.http.HttpServletRequest;
import java.util.Base64;
import java.util.Date;
import java.util.List;

/**
 * 获取用户授权（登录态） 实现层
 */
@Service
public class WechatIndexServiceImpl implements WechatIndexService {


    @Autowired
    private IWeChatUserService weChatUserService;

    @Autowired
    private ISupplierService supplierService;

//    @Autowired
//    private ServletContext servletContext;

    private static final Logger log = LoggerFactory.getLogger(WechatIndexServiceImpl.class);


    @Override
    public String registeOrLogin(String code,String state,  HttpServletRequest request) {

        //若code是空的，则不需要再继续
        if(StringUtils.isEmpty(code)){
            log.error("页面授权失败:未传入code");
            return "";
        }
        System.out.println("----------------code-------------"+code);
        String component_appid = WxOpenConfig.appId;
        String component_access_token = RedisUtil.get(WxOpenConfig.COMPONENT_ACCESS_TOKEN);
        //获取用户的openid和授权页面access_token
        String url= String.format(WeChatAccountConfig.accessTokenUrl,state,code,component_appid,component_access_token);
        //发送请求微信服务器，获取微信用户信息的access_token，和openId
        String result= HttpSendUtils.sendGet(url);
        //获取json数据
        JSONObject jsonObject = JSONObject.parseObject(result);

        System.out.println("----------------jsonObject-------------"+jsonObject);
        //解释openId
        String openId=jsonObject.getString("openid");
        //解释一个用于获取微信用户信息的access_token,
        String generalAccessToken = jsonObject.getString("access_token");

        //若获取不到openId,则code是非法的
        if(StringUtils.isEmpty(openId)){
            log.error("找不到，页面授权失败:传入的code信息数据对不上");
            return "";
        }

        if(StringUtils.isEmpty(generalAccessToken)){
            log.error("页面授权失败:传入的code信息数据对不上");
            return "";
        }
        //防止出现多个WechatUser数据，加上同步锁
        synchronized (openId.intern()) {
            //将openId进行加密
            //第一步：获取当前服务器时间，将服务器的时间转为timestamp的时间格式字符串
            Date date = new Date();
            String timestamp = date.getTime()+"";
            String accessToken;
            //对openId进行加密
            try {
                //将数据加密成byte数据，byte数组的数据由三部分组成，服务器的私钥+时间字符串（yyyyMMdd）+openId
                byte[] encontent = EncrypAES.EncrytorNew(LuckqunxinConfig.aeskey + timestamp + openId);
                //将byte数组转base64编码为可以识别的字符串
                accessToken = Base64.getEncoder().encodeToString(encontent);
                //将字符串的斜杆转化为-ss-
                accessToken=accessToken.replaceAll("/","-ss-");
                //将字符串的+化为-jj-
                accessToken=accessToken.replaceAll("\\+","-jj-");
                //讲字符串=化为-kk-
                accessToken=accessToken.replaceAll("=","-kk-");
            } catch (Exception e) {
                return "";
            }
            log.info("------------openId为：" + openId+"------------accessToken为：" + accessToken+"------------时间为：" + timestamp);

            WeChatUser wechatUser = new WeChatUser();
            wechatUser.setOpenid(openId);

            //查找用户是否已经登记过信息了
            List<WeChatUser> list = weChatUserService.selectWeChatUserList(wechatUser);
            //返回链接的字符串头
            String resultHeader = "accessToken=" + accessToken + "&timestamps=" + timestamp+"&appId="+state;
            //若已登记过，不需要在发送微信请求去获取用户信息
            if (list.size() > 0) {
                return resultHeader;
            }
            //新用户，获取用户的基本信息
//            url = "https://api.weixin.qq.com/sns/userinfo?access_token=" + generalAccessToken + "&openid=" + openId + "&lang=zh_CN";
//            result = HttpSendUtils.sendGet(url);
//            System.out.println("----------------------result-------------------"+result);

            //获取到的用户信息（比较完整）
//            jsonObject = JSONObject.parseObject(result);
//            if(jsonObject==null){
//                log.info("----------jsonObject数据为null--------");
//                return "";
//            }
//            String openidCheck = jsonObject.getString("openid");
            //用输入的openid和回调的openid进行比较，若相同则通过，说明回调正确，否则就是失败
//            if (StringUtils.isEmpty(openidCheck) || !openidCheck.equals(openId)) {
//                log.error("页面授权失败:获取用户的基本信息失败");
//                return "";
//            }

//            String nickname = jsonObject.getString("nickname");
//            String sex = jsonObject.getString("sex");
//            String province = jsonObject.getString("province");
//            String city = jsonObject.getString("city");
//            String country = jsonObject.getString("country");
//            String headimgurl = jsonObject.getString("headimgurl");
            //unionid未实现
//            String unionid = jsonObject.getString("unionid");
            //填充数据
            String userId=weChatUserService.getUniqueUserId();
            //二维码图片地址
//            String qrCodeUrl=ruoYiConfig.getProfile()+FileConstants.USER_QRCODE+"/"+System.currentTimeMillis()+"_"+RandomString.getRandomString(8)+".jpg";
//            //生成二维码
//            try {
//                QrCodecUtils.encode(userId, "", qrCodeUrl, true);
//            } catch (Exception e) {
//                log.info("-------------二维码生成失败，用户id="+userId+"--------------");
//                e.printStackTrace();
//            }
            //代理商id
            Supplier supplier = supplierService.selectSupplierByAppId(state);
            if(supplier==null){
                return "";
            }

            WeChatUser weChatUser=new WeChatUser();
            weChatUser.setOpenid(openId);
//            weChatUser.setQrCodeUrl(qrCodeUrl);
            //用户第一次注册,注入openid，主键id，未授权标识
            weChatUser.setCreateTime(new Date());
            weChatUser.setWithScope(0);
            //初始积分0
            weChatUser.setPointsTotal(0);
            //非会员
            weChatUser.setVipUser(0);
            weChatUser.setId(IdGen.uuid());
            //加入用户id
            weChatUser.setUserId(userId);
            weChatUser.setCity("");
            weChatUser.setCountry("");
            weChatUser.setNickname("");
            weChatUser.setLanguage("");
            weChatUser.setHeadimgurl("");
            weChatUser.setProvince("");
            weChatUser.setSex("");
            weChatUser.setWithScope(1);
            weChatUser.setSupplierId(supplier.getId());
            weChatUser.setAppId(state);
            weChatUserService.insertWeChatUser(weChatUser);
            return resultHeader;
        }
    }



    /**
     * 获取网页使用微信js的参数
     * @param url
     * @return
     */
    @Override
    public AjaxResult getWxConfig(String url ,String openId) {
//      String accessToken=(String)servletContext.getAttribute("access_token");
        WeChatUser weChatUser = weChatUserService.selectWeChatUserByOpenId(openId);
        if(weChatUser==null){
            return AjaxResult.withOutUser();
        }

        String appId =weChatUser.getAppId();

        String ticket=  RedisUtil.get("authorizer_jsapi_ticket"+appId);

        if(StringUtils.isEmpty(ticket)){
            log.error("网页门票ticket不存在");
            return AjaxResult.error();
        }
        //16位长度随机字符串
        String noncestr= RandomString.getRandomString(16);

        String  jsapi_ticket=ticket;
        //十位数的时间戳
        Long timestamp= System.currentTimeMillis()/1000;

        String sha1="jsapi_ticket="+jsapi_ticket+"&noncestr="+noncestr+"&timestamp="+timestamp+"&url="+url+"";
//        System.out.println(sha1);
        String signature = Sha.bytes2Hex(Sha.sha1(sha1));

        WxConfigVo wxConfigVo=new WxConfigVo();
        // appId: '', // 必填，公众号的唯一标识
        wxConfigVo.setAppId(appId);
        // nonceStr: '', // 必填，生成签名的随机串
        wxConfigVo.setNonceStr(noncestr);
        //  signature: '',// 必填，签名
        wxConfigVo.setSignature(signature);
        // timestamp: , // 必填，生成签名的时间戳,10位数，精度到秒
        wxConfigVo.setTimestamp(timestamp);
        return AjaxResult.success("data",wxConfigVo);
    }

    public static void main(String[] args) {

//
//        Date date = new Date();
//        System.out.println(date.getTime());
//        String timestamp = date.getTime()+"";
//        String accessToken;
//        String openId = "fefefefefefefefefefeff";
//        //对openId进行加密
//        try {
//            //将数据加密成byte数据，byte数组的数据由三部分组成，服务器的私钥+时间字符串（yyyyMMdd）+openId
//            byte[] encontent = EncrypAES.EncrytorNew(LuckqunxinConfig.aeskey + timestamp + openId);
//            //将byte数组转base64编码为可以识别的字符串
//            accessToken = Base64.getEncoder().encodeToString(encontent);
//            //将字符串的斜杆转化为-ss-
//            accessToken=accessToken.replaceAll("/","-ss-");
//            //将字符串的+化为-jj-
//            accessToken=accessToken.replaceAll("\\+","-jj-");
//
//        } catch (Exception e) {
//
//        }
//        System.out.println(new Date().getTime());
        String noncestr= RandomString.getRandomString(32);

        System.out.println(noncestr);
        String noncestr1= RandomString.getRandomString(43);
        System.out.println(noncestr1);

    }
}
