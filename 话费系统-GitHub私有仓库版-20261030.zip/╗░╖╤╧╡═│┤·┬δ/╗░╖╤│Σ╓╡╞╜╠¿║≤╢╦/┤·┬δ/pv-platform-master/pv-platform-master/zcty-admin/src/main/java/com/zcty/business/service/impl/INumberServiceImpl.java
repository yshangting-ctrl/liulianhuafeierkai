package com.zcty.business.service.impl;


import com.zcty.business.domain.INumber;
import com.zcty.business.mapper.INumberMapper;
import com.zcty.business.service.INumberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @authour:linxiaohan
 * @date:2018/12/13
 * @description:
 */

@Service
public class INumberServiceImpl implements INumberService {

    @Autowired
    private INumberMapper mapper;

    @Override
    public void save(INumber number) {
        mapper.save(number);
    }

    @Override
    public INumber selectByDateAndType(String date, int type) {
        return mapper.selectByDateAndType(date, type);
    }


    @Override
    public void update(INumber number) {
        mapper.update(number);
    }

    @Override
    public INumber selectByType(Integer type) {
        return mapper.selectByType(type);
    }
}
