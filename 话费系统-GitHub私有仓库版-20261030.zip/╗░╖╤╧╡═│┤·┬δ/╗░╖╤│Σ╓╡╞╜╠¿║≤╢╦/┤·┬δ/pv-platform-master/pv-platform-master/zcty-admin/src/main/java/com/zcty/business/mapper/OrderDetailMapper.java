package com.zcty.business.mapper;


import com.zcty.business.domain.OrderDetail;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 订单详情 数据层
 * 
 * @author liuruibin
 * @date 2022-07-25
 */
public interface OrderDetailMapper
{
	
	/**
     * 查询订单详情列表
     * 
     * @param orderDetail 订单详情信息
     * @return 订单详情集合
     */
	public List<OrderDetail> selectOrderDetailList(OrderDetail orderDetail);

	/**
	 * 新增订单详情
	 *
	 * @param orderDetailList 订单详情信息
	 * @return 结果
	 */
	public int insertOrderDetailList(@Param("orderDetailList") List<OrderDetail> orderDetailList);
	
}