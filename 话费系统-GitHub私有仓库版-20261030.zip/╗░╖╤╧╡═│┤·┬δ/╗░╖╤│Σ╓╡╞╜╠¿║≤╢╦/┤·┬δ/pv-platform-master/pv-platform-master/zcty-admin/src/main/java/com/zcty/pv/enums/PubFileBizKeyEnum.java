package com.zcty.pv.enums;

/**
 * 业务标识
 */
public enum PubFileBizKeyEnum {
    /** 电站勘察照片 */
    PS_SURVEY("PSSurvey","电站勘察照片"),

    /** 电站设计列表 */
    PS_DESIGN_LIST("PSDesignList","电站设计列表"),

    /** 电站设计附件 */
    PS_DESIGN_ATTACH("PSDesignAttach","电站设计附件"),

    /** 电站商务信息 */
    PS_BUSINESS_INFO("PSBusinessInfo","电站商务信息"),

    /** 电站商务合同 */
    PS_BUSINESS_CONTRACT("PSBusinessContract","电站商务合同"),

    /** 电站工程施工资料 */
    PS_ENGINEER_BUILD_RES("PSEngineerBuildRes","电站工程施工资料"),

    /** 电站工程施工视频 */
    PS_ENGINEER_BUILD_VIDEO("PSEngineerBuildVideo","电站工程施工视频"),

    /** 电站工程信息记录 */
    PS_ENGINEER_INFO("PSEngineerInfo","电站工程信息记录"),

    /** 电站工程图片 */
    PS_ENGINEER_PIC("PSEngineerPic","电站工程图片"),

    /** 电站并网资料 */
    PS_CONNECT_RES("PSConnectRes","电站并网资料"),

    /** 电站资料归档-工程施工资料 */
    PS_ARCHIVE_BUILD_RES("PSArchiveBuildRes","电站资料归档-工程施工资料"),

    /** 电站资料归档-工程施工视频 */
    PS_ARCHIVE_BUILD_VIDEO("PSArchiveBuildVideo","电站资料归档-工程施工视频"),

    /** 电站资料归档-工程信息记录 */
    PS_ARCHIVE_ENGINEER_INFO("PSArchiveEngineerInfo","电站资料归档-工程信息记录"),

    /** 电站资料归档-工程图片 */
    PS_ARCHIVE_ENGINEER_PIC("PSArchiveEngineerPic","电站资料归档-工程图片"),

    /** 电站资料归档-并网资料 */
    PS_ARCHIVE_CONNECT_RES("PSArchiveConnectRes","电站资料归档-并网资料"),

    /** 电站施工领料凭证 */
    PS_BUILD_PICKING_PROOF("PSBuildPickingProof","电站施工领料凭证"),

    /** 电站完工资料 */
    PS_FINISH_RES("PSFinishRes","电站完工资料"),

    /** 仓库附件 */
    STORE_FILES("StoreFiles", "仓库附件");

    private String value;
    private String text;

    PubFileBizKeyEnum(String value, String text) {
        this.value = value;
        this.text = text;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
