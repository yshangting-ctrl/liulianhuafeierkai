package com.zcty.business.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.zcty.common.core.domain.entity.SysUser;
import com.zcty.common.utils.SecurityUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.zcty.common.annotation.Log;
import com.zcty.common.core.controller.BaseController;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.enums.BusinessType;
import com.zcty.business.domain.Supplier;
import com.zcty.business.service.ISupplierService;
import com.zcty.common.utils.poi.ExcelUtil;
import com.zcty.common.core.page.TableDataInfo;

/**
 * supplierController
 * 
 * @author lsw
 * @date 2024-03-09
 */
@RestController
@RequestMapping("/business/supplier")
public class SupplierController extends BaseController
{
    @Autowired
    private ISupplierService supplierService;

    /**
     * 查询supplier列表
     */
    @PreAuthorize("@ss.hasPermi('business:supplier:list')")
    @GetMapping("/list")
    public TableDataInfo list(Supplier supplier)
    {
        startPage();
        List<Supplier> list = supplierService.selectSupplierList(supplier);
        return getDataTable(list);
    }

    /**
     * 导出supplier列表
     */
    @PreAuthorize("@ss.hasPermi('business:supplier:export')")
    @Log(title = "导出supplier列表", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, Supplier supplier)
    {
        List<Supplier> list = supplierService.selectSupplierList(supplier);
        ExcelUtil<Supplier> util = new ExcelUtil<Supplier>(Supplier.class);
        util.exportExcel(response, list, "supplier数据");
    }

    /**
     * 获取supplier详细信息
     */
    @PreAuthorize("@ss.hasPermi('business:supplier:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") String id)
    {
        return success(supplierService.selectSupplierById(id));
    }

    /**
     * 新增supplier
     */
    @PreAuthorize("@ss.hasPermi('business:supplier:add')")
    @Log(title = "新增代理商", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody Supplier supplier)
    {
        return (supplierService.insertSupplier(supplier));
    }

    /**
     * 修改supplier
     */
    @PreAuthorize("@ss.hasPermi('business:supplier:edit')")
    @Log(title = "修改代理商", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody Supplier supplier)
    {
        return toAjax(supplierService.updateSupplier(supplier));
    }

    /**
     * 删除supplier
     */
    @PreAuthorize("@ss.hasPermi('business:supplier:remove')")
    @Log(title = "删除代理商", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable String[] ids)
    {
        return toAjax(supplierService.deleteSupplierByIds(ids));
    }

    /**
     * 重置密码
     */
    @Log(title = "重置代理商用户密码", businessType = BusinessType.UPDATE)
    @GetMapping("/resetPwd")
    public AjaxResult resetPwd(String supplierId)
    {
        return (supplierService.resetPwd(supplierId));
    }
}
