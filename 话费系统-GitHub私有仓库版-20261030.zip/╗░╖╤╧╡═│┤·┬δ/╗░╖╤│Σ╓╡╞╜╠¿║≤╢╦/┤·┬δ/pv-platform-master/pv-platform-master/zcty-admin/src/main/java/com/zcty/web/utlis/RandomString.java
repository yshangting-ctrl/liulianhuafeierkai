package com.zcty.web.utlis;

import java.util.Random;

/**
 * 获取随机字符串
 */
public class RandomString {
    /**
     * 可以指定某个位置是a-z、A-Z或是0-9
     * @param length
     */
    public static String getRandomString(int length){

        Random random=new Random();
        StringBuffer sb=new StringBuffer();
        for(int i=0;i<length;i++){
            int number=random.nextInt(3);
            long result;
            switch(number){
                case 0:
                    result=Math.round(Math.random()*25+65);
                    sb.append(String.valueOf((char)result));
                    break;
                case 1:
                    result=Math.round(Math.random()*25+97);
                    sb.append(String.valueOf((char)result));
                    break;
                case 2:
                    sb.append(String.valueOf(new Random().nextInt(10)));
                    break;
            }


        }
        return  sb.toString();

    }

    public static void main(String[] args){

        System.out.println(getRandomString(32));

    }

}
