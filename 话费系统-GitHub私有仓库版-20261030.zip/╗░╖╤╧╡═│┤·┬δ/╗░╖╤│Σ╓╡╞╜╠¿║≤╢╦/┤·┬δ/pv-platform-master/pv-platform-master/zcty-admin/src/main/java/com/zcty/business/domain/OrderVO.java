package com.zcty.business.domain;


/**
 * @Author: chushengkun
 * @Date: 2022/7/27 17:43
 */
public class OrderVO {
    /** 订单ID */
    private String orderId;
    /** 订单编号 */
    private String orderNo;
    /** 订单金额 */
    private String totalFee;
    /** 订单支付金额*/
    private String payFee;
    /** 订单状态 0、待付款 1、待发货 2、待收货 3、交易完成 4、交易关闭 5、退款 6、取消 */
    private String orderStatus;
    /** 是否已经发货 0、未发货 1、已发货 */
    private String sendProduct;
    /** 微信返回的订单号 */
    private String transactionId;
    /** 创建时间 */
    private String createTime;
    /**商品类型 1 话费商品 2 流量商品 */
    private Integer goodsType;
    /** 联系电话 */
    private String phone;


    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getTotalFee() {
        return totalFee;
    }

    public void setTotalFee(String totalFee) {
        this.totalFee = totalFee;
    }

    public String getPayFee() {
        return payFee;
    }

    public void setPayFee(String payFee) {
        this.payFee = payFee;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getSendProduct() {
        return sendProduct;
    }

    public void setSendProduct(String sendProduct) {
        this.sendProduct = sendProduct;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public Integer getGoodsType() {
        return goodsType;
    }

    public void setGoodsType(Integer goodsType) {
        this.goodsType = goodsType;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
