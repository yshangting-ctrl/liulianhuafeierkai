package com.zcty.business.placeAnOrder;


import com.zcty.business.domain.*;
import com.zcty.business.service.*;
import com.zcty.common.config.LuckqunxinConfig;
import com.zcty.common.constant.OrderConstants;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.exception.base.BaseException;
import com.zcty.pv.domain.WeChatUser;
import com.zcty.pv.service.IWeChatUserService;
import com.zcty.web.utlis.IdGen;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;

/**
 * @Author: chushengkun
 * @Date: 2022/7/26 11:36
 */
@Component
public abstract class AbstractPlaceAnOrder {

    @Autowired
    private NumberService numberService;
    @Autowired
    private IOrderDetailService orderDetailService;
    @Autowired
    private IOrderService orderService;
    @Autowired
    private IProductService productService;
    @Autowired
    private IFlowProductService flowProductService;
    @Autowired
    private IWeChatUserService weChatUserService;
    /**
     * 封装订单详情信息 - 同时根据优惠券和购物车计算订单总金额和应付金额
     * @param orderId   订单ID
     * @param nowDate   当前时间
     * @return  订单详情列表
     */
    private List<OrderDetail> packagingOrderDetail(String orderId, Date nowDate,WeOrderDTO weOrderCart){

        List<OrderDetail> orderDetailList = new ArrayList<>();

//        for (WeOrderCart weOrderCart : weOrderCarts) {

            Integer goodsType = weOrderCart.getGoodsType();

            // 获取商品信息
            if(goodsType==null){
                return Collections.emptyList();
            }

            OrderDetail orderDetail = new OrderDetail();
            orderDetail.setDetId(IdGen.uuid());
            orderDetail.setOrderId(orderId);
            orderDetail.setGoodsId(weOrderCart.getGoodsId());
            orderDetail.setGoodsNum(weOrderCart.getNum());
            orderDetail.setCreateTime(nowDate);
            orderDetail.setGoodsType(weOrderCart.getGoodsType());

            if(goodsType.equals(1)){
                //话费商品
               Product product = productService.selectProductById(weOrderCart.getGoodsId());
               if(product == null ){
                   return Collections.emptyList();
               }
                orderDetail.setCommonSn(product.getProductNo());
                orderDetail.setCommonName(product.getProductName());
                orderDetail.setCommonDes(product.getProductSname());
                orderDetail.setProductTitle(product.getProductTitle());
                orderDetail.setGoodsPrice(product.getPrice());
                BigDecimal totalPrice = product.getPrice().multiply(
                        new BigDecimal(weOrderCart.getNum()));
                orderDetail.setTotalPrice(totalPrice);

                productService.addSales(weOrderCart.getGoodsId(), weOrderCart.getNum());
            }else {
                //流量商品
               FlowProduct flowProduct =  flowProductService.selectFlowProductById(weOrderCart.getGoodsId());
                if(flowProduct == null ){
                    return Collections.emptyList();
                }
                orderDetail.setCommonSn(flowProduct.getProductNo());
                orderDetail.setCommonName(flowProduct.getProductName());
                orderDetail.setCommonDes(flowProduct.getProductSname());
                orderDetail.setProductTitle(flowProduct.getProductTitle());
                orderDetail.setGoodsPrice(flowProduct.getPrice());
                BigDecimal totalPrice = flowProduct.getPrice().multiply(
                        new BigDecimal(weOrderCart.getNum()));
                orderDetail.setTotalPrice(totalPrice);

                flowProductService.addSales(weOrderCart.getGoodsId(), weOrderCart.getNum());
            }

            orderDetailList.add(orderDetail);
//        }
        return orderDetailList;
    }

    /**
     * 封装订单信息
     * @param orderId   订单ID
     * @param nowDate   当前时间
     * @param weOrderDTO    订单信息
     * @return  订单信息
     */
    private Order packagingOrder(String orderId,
                                 Date nowDate,
                                 WeOrderDTO weOrderDTO){

        WeChatUser weChatUser = weChatUserService.selectWeChatUserByOpenId(weOrderDTO.getOpenId());
        String supplierId = "0";
        if(weChatUser!=null){
            supplierId = weChatUser.getSupplierId();
        }

        String orderNo = numberService.getODNumber();
        Order order = new Order();
        order.setOrderId(orderId);
        order.setOrderNo(orderNo);
        order.setRemarkBody("商品订单：" + orderNo);
        order.setSupplierId(supplierId);
        order.setOpenId(weOrderDTO.getOpenId());
        order.setPhone(weOrderDTO.getPhone());
        order.setSendProduct(OrderConstants.SEND_PRODUCT_NOT_SHIPPED);

        order.setRemark(weOrderDTO.getRemark());

        order.setFeeType(LuckqunxinConfig.FEE_TYPE);
        order.setTradeType(LuckqunxinConfig.TRADE_TYPE);
        order.setOrderStatus(OrderConstants.ORDER_STATUS_PENDING_PAYMENT);
        order.setPayStatus(OrderConstants.PAY_STATUS_NOT_PAY);
        order.setThirdPayStatus(OrderConstants.THIRD_PAY_STATUS_NOT_PAY);

        order.setCreateTime(nowDate);
        order.setUpdateTime(nowDate);
        order.setSysVersion(OrderConstants.SYS_VERSION);

        return order;
    }

    /**
     * 计算订单应付金额
     * @param orderDetailList   订单详情
     * @return  结果
     */
    private Map<String, BigDecimal> solutionTotalFee(List<OrderDetail> orderDetailList){
        Map<String, BigDecimal> result = new HashMap<>();
        BigDecimal totalFee = BigDecimal.ZERO;

        for (OrderDetail orderDetail : orderDetailList) {
            totalFee = totalFee.add(orderDetail.getTotalPrice());
        }

        BigDecimal payFee = totalFee;

        if (payFee.compareTo(BigDecimal.ZERO) == 0){
            throw new BaseException("当前订单为0，下单失败！");
        }
        result.put(OrderConstants.TOTAL_FEE, totalFee);
        result.put(OrderConstants.PAY_FEE, payFee);
        return result;
    }


    // 执行下单逻辑
    @Transactional(rollbackFor = Exception.class)
    public Map<String, Object> placeAnOrder(WeOrderDTO weOrderDTO){
        System.out.println("开始创建订单：" + weOrderDTO.toString());

        String orderId = IdGen.uuid();
        Date nowDate = new Date();

        List<OrderDetail> orderDetailList = packagingOrderDetail(orderId, nowDate, weOrderDTO);

        if(orderDetailList.isEmpty()){
            throw new BaseException("订单信息异常，商品不存在！");
        }
        System.out.println("获取订单详情信息：" + orderDetailList.toString());

        int count = orderDetailService.insertOrderDetailList(orderDetailList);
        if (count < orderDetailList.size()){
            throw new BaseException("订单详情数据异常，下单失败！");
        }


        Map<String, BigDecimal> result = solutionTotalFee(orderDetailList);

        Order order = packagingOrder(orderId, nowDate, weOrderDTO);
        order.setTotalFee(result.get(OrderConstants.TOTAL_FEE));
        order.setPayFee(result.get(OrderConstants.PAY_FEE));
        order.setGoodsType(weOrderDTO.getGoodsType());
        System.out.println("创建订单：" + order.toString());
        int orderCount = orderService.insertOrder(order);
        if (orderCount < 1){
            throw new BaseException("订单信息异常，下单失败！");
        }
        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put(OrderConstants.CREATE_ORDER_FLAG, true);
        resultMap.put(OrderConstants.CREATE_ORDER_INFO, order);
        return resultMap;
    }



}
