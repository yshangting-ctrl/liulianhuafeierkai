package com.zcty.weChat.service;

import com.zcty.common.core.domain.AjaxResult;

import javax.servlet.http.HttpServletRequest;

/**
 * 获取用户授权（登录态） 服务层
 */
public interface WechatIndexService {

    /**
     *  注册用户或者登陆
     * @param code
     * @param request
     * @return
     */
    public String registeOrLogin(String code, String state, HttpServletRequest request);

    /**
    返回js-sdk的config配置信息
     */
    public AjaxResult getWxConfig(String url, String openId);
}
