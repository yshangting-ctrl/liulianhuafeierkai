package com.zcty.business.mapper;


import com.zcty.business.domain.*;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * 订单 数据层
 * 
 * @author liuruibin
 * @date 2022-07-25
 */
public interface OrderMapper 
{
	/**
     * 查询订单信息
     * 
     * @param orderId 订单ID
     * @return 订单信息
     */
	public Order selectOrderById(String orderId);

    /**
     * 查询订单详情
     *
     * @param orderId 订单ID
     * @return 订单信息
     */
    public OrderInfoVO selectOrderInfoVOById(String orderId);

	/**
	 * 查询订单信息
	 *
	 * @param orderNo 订单编号
	 * @return 订单信息
	 */
	public Order selectOrderByNo(String orderNo);

    /**
     * 查询订单列表信息 待付款、待收货
     * @return
     */
    public List<Order> selectOrderListByStatus();

	/**
	 * 查询订单信息
	 *
	 * @param orderId 订单ID
	 * @return 订单信息
	 */
	public WeOrderInfoVO selectWeOrderInfoVOById(@Param("orderId") String orderId, @Param("openId") String openId);
	
	/**
     * 查询订单列表
     * 
     * @param order 订单信息
     * @return 订单集合
     */
	public List<OrderVO> selectOrderList(Order order);

	/**
	 * 查询发货订单列表 除未付款和已取消订单
	 * @return
	 */
	public List<OrderVO> selectOrderShippedList(Order order);

	/**
	 * 查询订单列表
	 *
	 * @param params 赛选条件
	 * @return 订单集合
	 */
	public List<WeOrderVO> selectWeOrderVOList(Map<String, Object> params);
	
	/**
     * 新增订单
     * 
     * @param order 订单信息
     * @return 结果
     */
	public int insertOrder(Order order);
	
	/**
     * 修改订单
     * 
     * @param order 订单信息
     * @return 结果
     */
	public int updateOrder(Order order);

	/**
	 * 修改订单
	 *
	 * @param order 订单信息
	 * @return 结果
	 */
	public int updateOrderByPay(Order order);

    /**
     * 修改订单
     *
     * @param order 订单信息
     * @return 结果
     */
	public int updateOrderStatusByOrder(Order order);
	
	/**
     * 删除订单
     * 
     * @param orderId 订单ID
     * @return 结果
     */
	public int deleteOrderById(String orderId);
	
	/**
     * 批量删除订单
     * 
     * @param orderIds 需要删除的数据ID
     * @return 结果
     */
	public int deleteOrderByIds(String[] orderIds);

    /**
     * 获取订单版本号
     * @param orderId   订单ID
     * @return  结果
     */
	public int selectOrderVersion(String orderId);

    /**
     * 更新订单状态
     * @param params 更新参数
     * @return  结果
     */
	public int updateOrderStatus(Map<String, Object> params);

    /**
     * 校验是否可以取消或支付订单
     * @param orderId   订单单号
     * @return  结果
     */
	public int checkOrderStatusByCancelOrPay(String orderId);

    /**
     * 校验订单是否可以确认收货
     * @param orderId   订单单号
     * @return  结果
     */
    public int checkOrderStatusByConfirm(String orderId);

    /**
     * 校验订单是否可以发货
     * @param orderId   订单单号
     * @return  结果
     */
    public int checkOrderStatusBySendProductTime(String orderId);

	/**
	 * 订单统计
	 * @param openId 微信用户ID
	 * @return
	 */
	public WeOrderStatistics selectOrderCountByStatus(String openId);

	public int editOrderSend(Order order);

	public OrderShippedInfoVO queryOrderShippedInfo(String orderNo);
	
}