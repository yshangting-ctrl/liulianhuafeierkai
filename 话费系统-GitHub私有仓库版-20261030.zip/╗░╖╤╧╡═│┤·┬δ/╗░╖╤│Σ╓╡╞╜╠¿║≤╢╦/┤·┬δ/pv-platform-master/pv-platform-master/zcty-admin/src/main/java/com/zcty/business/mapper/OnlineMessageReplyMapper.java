package com.zcty.business.mapper;


import com.zcty.business.domain.OnlineMessageReply;

import java.util.List;

/**
 * 留言回复 数据层
 * 
 * @author liuruibin
 * @date 2023-03-10
 */
public interface OnlineMessageReplyMapper 
{
	/**
     * 查询留言回复信息
     * 
     * @param id 留言回复ID
     * @return 留言回复信息
     */
	public OnlineMessageReply selectOnlineMessageReplyById(String id);
	
	/**
     * 查询留言回复列表
     * 
     * @param onlineMessageReply 留言回复信息
     * @return 留言回复集合
     */
	public List<OnlineMessageReply> selectOnlineMessageReplyList(OnlineMessageReply onlineMessageReply);


	/**
     * 新增留言回复
     * 
     * @param onlineMessageReply 留言回复信息
     * @return 结果
     */
	public int insertOnlineMessageReply(OnlineMessageReply onlineMessageReply);
	
	/**
     * 修改留言回复
     * 
     * @param onlineMessageReply 留言回复信息
     * @return 结果
     */
	public int updateOnlineMessageReply(OnlineMessageReply onlineMessageReply);
	
	/**
     * 删除留言回复
     * 
     * @param id 留言回复ID
     * @return 结果
     */
	public int deleteOnlineMessageReplyById(String id);
	
	/**
     * 批量删除留言回复
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteOnlineMessageReplyByIds(String[] ids);
	
}