package com.zcty.web.utlis.delay;

public class DelayType {

    public static Integer accessToken=1;

    public final static Integer DELAY_COUPON_START = 2;

    public final static Integer DELAY_COUPON_END = 3;

    // 执行取消订单
    public final static Integer ORDER_CANCEL = 4;
    // 执行确认收货
    public final static Integer ORDER_CONFIRM = 5;
    // 执行交易完成
    public final static Integer ORDER_RECEIPT = 6;

    public final static Integer ACTIVITY_START = 7;

    public final static Integer preAuthCode = 8;

}
