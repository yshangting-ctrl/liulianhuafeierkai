package com.zcty.business.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.zcty.common.annotation.Log;
import com.zcty.common.core.controller.BaseController;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.enums.BusinessType;
import com.zcty.business.domain.WechartPayInfo;
import com.zcty.business.service.IWechartPayInfoService;
import com.zcty.common.utils.poi.ExcelUtil;
import com.zcty.common.core.page.TableDataInfo;

/**
 * 微信支付信息Controller
 * 
 * @author lsw
 * @date 2024-05-30
 */
@RestController
@RequestMapping("/wechartPayInfo/wechartPayInfo")
public class WechartPayInfoController extends BaseController
{
    @Autowired
    private IWechartPayInfoService wechartPayInfoService;

    /**
     * 查询微信支付信息列表
     */
    @PreAuthorize("@ss.hasPermi('wechartPayInfo:wechartPayInfo:list')")
    @GetMapping("/list")
    public TableDataInfo list(WechartPayInfo wechartPayInfo)
    {
        startPage();
        List<WechartPayInfo> list = wechartPayInfoService.selectWechartPayInfoList(wechartPayInfo);
        return getDataTable(list);
    }

    /**
     * 导出微信支付信息列表
     */
    @PreAuthorize("@ss.hasPermi('wechartPayInfo:wechartPayInfo:export')")
    @Log(title = "微信支付信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, WechartPayInfo wechartPayInfo)
    {
        List<WechartPayInfo> list = wechartPayInfoService.selectWechartPayInfoList(wechartPayInfo);
        ExcelUtil<WechartPayInfo> util = new ExcelUtil<WechartPayInfo>(WechartPayInfo.class);
        util.exportExcel(response, list, "微信支付信息数据");
    }

    /**
     * 获取微信支付信息详细信息
     */
    @PreAuthorize("@ss.hasPermi('wechartPayInfo:wechartPayInfo:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") String id)
    {
        return success(wechartPayInfoService.selectWechartPayInfoById(id));
    }

    /**
     * 新增微信支付信息
     */
    @PreAuthorize("@ss.hasPermi('wechartPayInfo:wechartPayInfo:add')")
    @Log(title = "微信支付信息", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody WechartPayInfo wechartPayInfo)
    {
        return toAjax(wechartPayInfoService.insertWechartPayInfo(wechartPayInfo));
    }

    /**
     * 修改微信支付信息
     */
    @PreAuthorize("@ss.hasPermi('wechartPayInfo:wechartPayInfo:edit')")
    @Log(title = "微信支付信息", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody WechartPayInfo wechartPayInfo)
    {
        return toAjax(wechartPayInfoService.updateWechartPayInfo(wechartPayInfo));
    }

    /**
     * 删除微信支付信息
     */
    @PreAuthorize("@ss.hasPermi('wechartPayInfo:wechartPayInfo:remove')")
    @Log(title = "微信支付信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable String[] ids)
    {
        return toAjax(wechartPayInfoService.deleteWechartPayInfoByIds(ids));
    }
}
