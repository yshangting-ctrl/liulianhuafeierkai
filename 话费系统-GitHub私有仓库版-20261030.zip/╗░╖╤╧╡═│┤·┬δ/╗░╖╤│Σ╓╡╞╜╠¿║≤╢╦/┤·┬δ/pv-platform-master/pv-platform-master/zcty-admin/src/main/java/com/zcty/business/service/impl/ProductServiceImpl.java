package com.zcty.business.service.impl;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.zcty.business.domain.ActivityProduct;
import com.zcty.business.domain.FlowProduct;
import com.zcty.business.service.IActivityProductService;
import com.zcty.business.service.NumberService;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.utils.DateUtils;
import com.zcty.common.utils.StringUtils;
import com.zcty.web.utlis.IdGen;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zcty.business.mapper.ProductMapper;
import com.zcty.business.domain.Product;
import com.zcty.business.service.IProductService;

/**
 * 产品项目Service业务层处理
 * 
 * @author lsw
 * @date 2024-03-13
 */
@Service
public class ProductServiceImpl implements IProductService 
{
    @Autowired
    private ProductMapper productMapper;

    @Autowired
    private NumberService numberService;

    @Autowired
    private IActivityProductService activityProductService;
    /**
     * 查询产品项目
     * 
     * @param id 产品项目主键
     * @return 产品项目
     */
    @Override
    public Product selectProductById(String id)
    {
        return productMapper.selectProductById(id);
    }

    /**
     * 查询产品项目列表
     * 
     * @param product 产品项目
     * @return 产品项目
     */
    @Override
    public List<Product> selectProductList(Product product)
    {
        return productMapper.selectProductList(product);
    }

    /**
     * 新增产品项目
     * 
     * @param product 产品项目
     * @return 结果
     */
    @Override
    public AjaxResult insertProduct(Product product)
    {

        //判断数据空值问题
        if(product==null){
            return  AjaxResult.error("未找到操作数据");
        }

        //先对必填项进行校验
        //商品名称
        String productName=product.getProductName();
        if(StringUtils.isEmpty(productName)){
            return AjaxResult.error("请输入项目名称");
        }
        //排序
        Integer orderBy=product.getOrderBy();
        if(orderBy==null){
            return  AjaxResult.error("请填写排序号");
        }
        //初始销售数量
        Integer salesTotal=product.getSalesTotal();
        if(salesTotal==null){
            return  AjaxResult.error("请填写初始销售数量");
        }
        //单价
        BigDecimal price=product.getPrice();
        if(price==null||price.compareTo(BigDecimal.ZERO)<=0){
            return AjaxResult.error("请填写项目价格，请金额大于0");
        }

        //平台商品信息
        ActivityProduct  activityProduct= activityProductService.selectActivityProductById(product.getActivityProductId());
        if(activityProduct == null){
            return AjaxResult.error("请绑定充值业务");
        }
        product.setActivityDescribes(activityProduct.getActivityDescribes());
        product.setActivityid(activityProduct.getActivityid());
        product.setCity(activityProduct.getCity());
        product.setProvince(activityProduct.getProvince());
        product.setActivityProductId(activityProduct.getPlatformInfosId());
        product.setPlatformInfosId(activityProduct.getPlatformInfosId());
        product.setActivityProductId(activityProduct.getId());
        product.setYys(activityProduct.getYys());

        product.setCreateTime(DateUtils.getNowDate());


        //获取话费商品编号
        String busNo=numberService.getHFNumber();
        //自动填写必要的数据,主键id，创建时间
        String id= IdGen.uuid();
        Date date=new Date();

        product.setId(id);
        product.setCreateTime(date);
        product.setUpdateTime(date);
        product.setDelFlag(0);
        product.setProductNo(busNo);

        //更新编号
        numberService.updateNumber(busNo);

        int i =productMapper.insertProduct(product);

        return i > 0 ? AjaxResult.success() : AjaxResult.error();
    }

    /**
     * 修改产品项目
     * 
     * @param product 产品项目
     * @return 结果
     */
    @Override
    public AjaxResult updateProduct(Product product)
    {
        //判断数据空值问题
        if(product==null){
            return  AjaxResult.error("未找到操作数据");
        }
        //判断ID信息
        String id=product.getId();
        if(StringUtils.isEmpty(id)){
            return AjaxResult.error("未找到编辑的项目Id信息");
        }

        //先对必填项进行校验
        //商品名称
        String productName=product.getProductName();
        if(StringUtils.isEmpty(productName)){
            return AjaxResult.error("请输入项目名称");
        }
        //排序
        Integer orderBy=product.getOrderBy();
        if(orderBy==null){
            return  AjaxResult.error("请填写排序号");
        }
        //单价
        BigDecimal price=product.getPrice();
        if(price==null&&price.compareTo(BigDecimal.ZERO)<=0){
            return AjaxResult.error("请填写项目价格，请金额大于0");
        }

        //初始销售数量
        Integer salesTotal=product.getSalesTotal();
        if(salesTotal==null){
            return  AjaxResult.error("请填写初始销售数量");
        }

        //平台商品信息
        ActivityProduct activityProduct= activityProductService.selectActivityProductById(product.getActivityProductId());
        if(activityProduct == null){
            return AjaxResult.error("请绑定充值业务");
        }
        product.setActivityDescribes(activityProduct.getActivityDescribes());
        product.setActivityid(activityProduct.getActivityid());
        product.setCity(activityProduct.getCity());
        product.setProvince(activityProduct.getProvince());
        product.setPlatformInfosId(activityProduct.getPlatformInfosId());
        product.setActivityProductId(activityProduct.getId());
        product.setYys(activityProduct.getYys());

        product.setUpdateTime(DateUtils.getNowDate());
        int i = productMapper.updateProduct(product);
        return i > 0 ? AjaxResult.success() : AjaxResult.error();
    }

    /**
     * 批量删除产品项目
     * 
     * @param ids 需要删除的产品项目主键
     * @return 结果
     */
    @Override
    public int deleteProductByIds(String[] ids)
    {
        return productMapper.deleteProductByIds(ids);
    }

    /**
     * 删除产品项目信息
     * 
     * @param id 产品项目主键
     * @return 结果
     */
    @Override
    public int deleteProductById(String id)
    {
        return productMapper.deleteProductById(id);
    }

    /**
     * 添加销量
     * @return
     */
    @Override
    public int addSales(String commonId, Integer num) {
        Product goodsCommon = productMapper.selectProductById(commonId);
        goodsCommon.setUpdateTime(new Date());
        goodsCommon.setSalesTotal(num+goodsCommon.getSalesTotal());
        return productMapper.addSales(goodsCommon);
    }

    @Override
    public AjaxResult updateProductStatus(Product product) {
        return AjaxResult.switchOne(productMapper.updateProductStatus(product));
    }
}
