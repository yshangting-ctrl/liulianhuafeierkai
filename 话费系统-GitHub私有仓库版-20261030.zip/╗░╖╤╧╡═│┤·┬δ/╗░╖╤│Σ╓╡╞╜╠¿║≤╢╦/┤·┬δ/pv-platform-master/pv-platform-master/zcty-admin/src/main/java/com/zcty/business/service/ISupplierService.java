package com.zcty.business.service;

import java.util.List;
import com.zcty.business.domain.Supplier;
import com.zcty.common.core.domain.AjaxResult;

/**
 * supplierService接口
 * 
 * @author lsw
 * @date 2024-03-09
 */
public interface ISupplierService 
{
    /**
     * 查询supplier
     * 
     * @param id supplier主键
     * @return supplier
     */
    public Supplier selectSupplierById(String id);

    /**
     * 查询supplier列表
     * 
     * @param supplier supplier
     * @return supplier集合
     */
    public List<Supplier> selectSupplierList(Supplier supplier);

    /**
     * 新增supplier
     * 
     * @param supplier supplier
     * @return 结果
     */
    public AjaxResult insertSupplier(Supplier supplier);

    /**
     * 修改supplier
     * 
     * @param supplier supplier
     * @return 结果
     */
    public int updateSupplier(Supplier supplier);

    /**
     * 批量删除supplier
     * 
     * @param ids 需要删除的supplier主键集合
     * @return 结果
     */
    public int deleteSupplierByIds(String[] ids);

    /**
     * 删除supplier信息
     * 
     * @param id supplier主键
     * @return 结果
     */
    public int deleteSupplierById(String id);

    /**
     * 重置密码
     * @param supplierId
     * @return
     */
    public AjaxResult resetPwd(String supplierId);

    /**
     * 查询supplier
     *
     * @param appId 公众号id
     * @return supplier
     */
    public Supplier selectSupplierByAppId(String appId);
}
