package com.zcty.pv.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.zcty.common.utils.SecurityUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.zcty.common.annotation.Log;
import com.zcty.common.core.controller.BaseController;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.enums.BusinessType;
import com.zcty.pv.domain.PvSerialNumber;
import com.zcty.pv.service.IPvSerialNumberService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import com.zcty.common.utils.poi.ExcelUtil;
import com.zcty.common.core.page.TableDataInfo;

/**
 * 编号生成记录Controller
 * 
 * @author luohui
 * @date 2022-12-07
 */
@Api(tags = "编号生成记录接口")
@RestController
@RequestMapping("/pv/number")
public class PvSerialNumberController extends BaseController
{
    @Autowired
    private IPvSerialNumberService pvSerialNumberService;

    /**
     * 查询编号生成记录列表
     */
    @ApiOperation("查询编号生成记录列表")
    @PreAuthorize("@ss.hasPermi('pv:number:list')")
    @GetMapping("/list")
    public TableDataInfo list(PvSerialNumber pvSerialNumber)
    {
        startPage();
        List<PvSerialNumber> list = pvSerialNumberService.selectPvSerialNumberList(pvSerialNumber);
        return getDataTable(list);
    }

    /**
     * 导出编号生成记录列表
     */
    @ApiOperation("导出编号生成记录列表")
    @PreAuthorize("@ss.hasPermi('pv:number:export')")
    @Log(title = "编号生成记录", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, PvSerialNumber pvSerialNumber)
    {
        List<PvSerialNumber> list = pvSerialNumberService.selectPvSerialNumberList(pvSerialNumber);
        ExcelUtil<PvSerialNumber> util = new ExcelUtil<PvSerialNumber>(PvSerialNumber.class);
        util.exportExcel(response, list, "编号生成记录数据");
    }

    /**
     * 获取编号生成记录详细信息
     */
    @ApiOperation("获取编号生成记录详细信息")
    @PreAuthorize("@ss.hasPermi('pv:number:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(pvSerialNumberService.selectPvSerialNumberById(id));
    }

    /**
     * 新增编号生成记录
     */
    @ApiOperation("新增编号生成记录")
    @PreAuthorize("@ss.hasPermi('pv:number:add')")
    @Log(title = "编号生成记录", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody PvSerialNumber pvSerialNumber)
    {
        pvSerialNumber.setCreateBy(getNickname());
        return toAjax(pvSerialNumberService.insertPvSerialNumber(pvSerialNumber));
    }

    /**
     * 修改编号生成记录
     */
    @ApiOperation("修改编号生成记录")
    @PreAuthorize("@ss.hasPermi('pv:number:edit')")
    @Log(title = "编号生成记录", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody PvSerialNumber pvSerialNumber)
    {
        pvSerialNumber.setUpdateBy(getNickname());
        return toAjax(pvSerialNumberService.updatePvSerialNumber(pvSerialNumber));
    }

    /**
     * 删除编号生成记录
     */
    @ApiOperation("删除编号生成记录")
    @PreAuthorize("@ss.hasPermi('pv:number:remove')")
    @Log(title = "编号生成记录", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(pvSerialNumberService.deletePvSerialNumberByIds(ids));
    }
}
