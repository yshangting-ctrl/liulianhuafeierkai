package com.zcty.pv.enums;

/**
 * 通用状态枚举类
 */
public enum AuditStatusEnum {
    /** 待审批 */
    INITIAL(0, "待审批"),
    /** 审批通过 */
    OK(1, "通过"),
    /** 审批不通过 */
    FAIL(2, "不通过");

    private Integer value;
    private String text;

    AuditStatusEnum(Integer value, String text) {
        this.value = value;
        this.text = text;
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
