package com.zcty.business.service;

import java.util.List;
import com.zcty.business.domain.WechartPayInfo;

/**
 * 微信支付信息Service接口
 * 
 * @author lsw
 * @date 2024-05-30
 */
public interface IWechartPayInfoService 
{
    /**
     * 查询微信支付信息
     * 
     * @param id 微信支付信息主键
     * @return 微信支付信息
     */
    public WechartPayInfo selectWechartPayInfoById(String id);

    /**
     * 查询微信支付信息列表
     * 
     * @param wechartPayInfo 微信支付信息
     * @return 微信支付信息集合
     */
    public List<WechartPayInfo> selectWechartPayInfoList(WechartPayInfo wechartPayInfo);

    /**
     * 新增微信支付信息
     * 
     * @param wechartPayInfo 微信支付信息
     * @return 结果
     */
    public int insertWechartPayInfo(WechartPayInfo wechartPayInfo);

    /**
     * 修改微信支付信息
     * 
     * @param wechartPayInfo 微信支付信息
     * @return 结果
     */
    public int updateWechartPayInfo(WechartPayInfo wechartPayInfo);

    /**
     * 批量删除微信支付信息
     * 
     * @param ids 需要删除的微信支付信息主键集合
     * @return 结果
     */
    public int deleteWechartPayInfoByIds(String[] ids);

    /**
     * 删除微信支付信息信息
     * 
     * @param id 微信支付信息主键
     * @return 结果
     */
    public int deleteWechartPayInfoById(String id);

    /**
     * 查询该代理商的支付信息
     * @param supplierId
     * @return
     */
    public WechartPayInfo selectWechartPayInfoSupplierId(String supplierId);
}
