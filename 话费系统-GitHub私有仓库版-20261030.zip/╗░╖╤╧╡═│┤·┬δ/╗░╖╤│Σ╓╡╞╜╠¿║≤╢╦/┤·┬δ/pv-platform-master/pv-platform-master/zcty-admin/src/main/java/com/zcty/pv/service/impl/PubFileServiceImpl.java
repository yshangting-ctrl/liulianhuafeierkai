package com.zcty.pv.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.IdUtil;
import com.zcty.common.config.RuoYiConfig;
import com.zcty.common.constant.Constants;
import com.zcty.common.exception.ServiceException;
import com.zcty.common.utils.DateUtils;
import com.zcty.common.utils.SecurityUtils;
import com.zcty.common.utils.StringUtils;
import com.zcty.common.utils.file.FileUploadUtils;
import com.zcty.common.utils.file.FileUtils;
import com.zcty.pv.enums.AuditStatusEnum;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zcty.pv.mapper.PubFileMapper;
import com.zcty.pv.domain.PubFile;
import com.zcty.pv.service.IPubFileService;
import org.springframework.web.multipart.MultipartFile;

/**
 * 通用文件Service业务层处理
 * 
 * @author luohui
 * @date 2022-11-20
 */
@Service
public class PubFileServiceImpl implements IPubFileService 
{
    @Autowired
    private PubFileMapper pubFileMapper;

    /**
     * 查询通用文件
     * 
     * @param id 通用文件主键
     * @return 通用文件
     */
    @Override
    public PubFile selectPubFileById(Long id)
    {
        return pubFileMapper.selectPubFileById(id);
    }

    /**
     * 查询通用文件列表
     * 
     * @param pubFile 通用文件
     * @return 通用文件
     */
    @Override
    public List<PubFile> selectPubFileList(PubFile pubFile)
    {
        return pubFileMapper.selectPubFileList(pubFile);
    }

    /**
     * 新增通用文件
     * 
     * @param pubFile 通用文件
     * @return 结果
     */
    @Override
    public int insertPubFile(PubFile pubFile)
    {
        pubFile.setCreateTime(DateUtils.getNowDate());
        pubFile.setAuditTime(pubFile.getCreateTime());
        pubFile.setId(IdUtil.getSnowflakeNextId());
        if(StringUtils.isNotBlank(pubFile.getFileUrl())){
            pubFile.setFileType(FilenameUtils.getExtension(pubFile.getFileUrl()));
        }
        return pubFileMapper.insertPubFile(pubFile);
    }

    /**
     * 修改通用文件
     * 
     * @param pubFile 通用文件
     * @return 结果
     */
    @Override
    public int updatePubFile(PubFile pubFile)
    {
        pubFile.setUpdateTime(DateUtils.getNowDate());
        if(StringUtils.isNotBlank(pubFile.getFileUrl())){
            pubFile.setFileType(FilenameUtils.getExtension(pubFile.getFileUrl()));
        }
        return pubFileMapper.updatePubFile(pubFile);
    }

    /**
     * 批量删除通用文件
     * 
     * @param ids 需要删除的通用文件主键
     * @return 结果
     */
    @Override
    public int deletePubFileByIds(Long[] ids)
    {
        int count = 0;
        for(Long id : ids){
            count += this.deletePubFileById(id);
        }
        return count;
    }

    /**
     * 删除通用文件信息
     * 
     * @param id 通用文件主键
     * @return 结果
     */
    @Override
    public int deletePubFileById(Long id)
    {
        PubFile pubFile = this.selectPubFileById(id);
        String resource = pubFile.getFileUrl();
        int count = pubFileMapper.deletePubFileById(id);
        if(count > 0) {
            try {
                // 本地资源路径
                String localPath = RuoYiConfig.getProfile();
                // 数据库资源地址
                String downloadPath = localPath + StringUtils.substringAfter(resource, Constants.RESOURCE_PREFIX);
                FileUtils.deleteFile(downloadPath);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return count;
    }

    /**
     * 上传文件
     * @param files
     * @param pubFile
     * @return
     */
    @Override
    public int uploadFiles(MultipartFile[] files, PubFile pubFile) {
        if (files == null || files.length == 0) {
            throw new ServiceException("没有上传文件");
        }
        List<PubFile> fileList = new ArrayList<>();
        // 上传文件路径
        String filePath = RuoYiConfig.getUploadPath();
        try {
            for (MultipartFile file : files) {
                String fileUrl = FileUploadUtils.upload(filePath, file);
                PubFile newFile = new PubFile();
                String fileName = pubFile.getFileName();
                newFile.setFileName(fileName);
                newFile.setSize(file.getSize());
                newFile.setBizId(pubFile.getBizId());
                newFile.setBizKey(pubFile.getBizKey());
                newFile.setFileUrl(fileUrl);
                newFile.setAgentId(SecurityUtils.getLoginUser().getUser().getDeptId());
                String fileType = fileName.substring(fileName.lastIndexOf(".")+1);
                newFile.setFileType(StringUtils.lowerCase(fileType));
                newFile.setStatus(AuditStatusEnum.INITIAL.getValue());
                newFile.setFileType(FileUploadUtils.getExtension(file));
                newFile.setCreateBy(SecurityUtils.getNickname());
                this.insertPubFile(newFile);
                fileList.add(newFile);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new ServiceException("文件上传失败");
        }


        return 1;
    }


    @Override
    public int uploadFile(MultipartFile file) {

        if (file == null || file.getSize() == 0) {
            throw new ServiceException("没有上传文件");
        }
        try {
        // 上传文件路径
        String filePath = RuoYiConfig.getUploadPath();
        String fileUrl = FileUploadUtils.upload(filePath, file);
        PubFile newFile = new PubFile();
        String fileName = file.getOriginalFilename();
        newFile.setFileName(fileName);
        newFile.setSize(file.getSize());
//        newFile.setBizId();
//        newFile.setBizKey();
        newFile.setFileUrl(fileUrl);
//        newFile.setAgentId(SecurityUtils.getLoginUser().getUser().getDeptId());
        String fileType = fileName.substring(fileName.lastIndexOf(".")+1);
        newFile.setFileType(StringUtils.lowerCase(fileType));
        newFile.setFileType(FileUploadUtils.getExtension(file));
        newFile.setCreateBy(SecurityUtils.getNickname());
        this.insertPubFile(newFile);
        } catch (Exception e) {
            e.printStackTrace();
            throw new ServiceException("文件上传失败");
        }
        return 0;
    }

    /**
     * 初始化文件列表
     *
     * @param bizId
     * @param bizKey
     * @param files 文件清单，包含文件名称以及是否必须
     * @return
     */
    @Override
    public int genDefualtFiles(Long bizId, String bizKey, Map<String, String> files) {
        if(StringUtils.isEmpty(files)){
            return 0;
        }
        int i = 1;
        for(Map.Entry<String, String> entry : files.entrySet()){
            String fileName = entry.getKey();
            String isNeed = entry.getValue();
            PubFile pubFile = new PubFile();
            pubFile.setBizId(bizId);
            pubFile.setBizKey(bizKey);
            pubFile.setFileName(fileName);
            pubFile.setIsNeed(isNeed);
            pubFile.setSortNum(i);
            pubFile.setCreateBy(SecurityUtils.getNickname());
            this.insertPubFile(pubFile);
            i++;
        }
        return i;
    }

    /**
     * 检查文件名称对应的文件是否存在
     *
     * @param bizId
     * @param bizKey
     * @param files
     * @return
     */
    @Override
    public int checkFileExit(Long bizId, String bizKey, Map<String, String> files) {
        int i = 1;
        for(Map.Entry<String, String> entry : files.entrySet()){
            String fileName = entry.getKey();
            PubFile pubFile = new PubFile();
            pubFile.setBizId(bizId);
            pubFile.setBizKey(bizKey);
            pubFile.setFileName(fileName);
            List<PubFile> fileList = this.selectPubFileList(pubFile);
            if(CollUtil.isEmpty(fileList)){
                i = 0;
                break;
            }
        }
        return i;
    }
}
