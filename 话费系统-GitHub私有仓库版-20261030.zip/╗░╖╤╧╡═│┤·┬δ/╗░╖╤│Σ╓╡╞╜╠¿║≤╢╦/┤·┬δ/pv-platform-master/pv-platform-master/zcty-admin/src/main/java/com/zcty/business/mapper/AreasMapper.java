package com.zcty.business.mapper;

import com.zcty.business.domain.Areas;

import java.util.List;

/**
 * 地区码 数据层
 * 
 * @author liuruibin
 * @date 2019-07-11
 */
public interface AreasMapper 
{
	/**
     * 查询地区码信息
     * 
     * @param areaId 地区码ID
     * @return 地区码信息
     */
	public Areas selectAreasById(Integer areaId);
	
	/**
     * 查询地区码列表
     * 
     * @param areas 地区码信息
     * @return 地区码集合
     */
	public List<Areas> selectAreasList(Areas areas);
	
	/**
     * 新增地区码
     * 
     * @param areas 地区码信息
     * @return 结果
     */
	public int insertAreas(Areas areas);
	
	/**
     * 修改地区码
     * 
     * @param areas 地区码信息
     * @return 结果
     */
	public int updateAreas(Areas areas);
	
	/**
     * 删除地区码
     * 
     * @param areaId 地区码ID
     * @return 结果
     */
	public int deleteAreasById(Integer areaId);
	
	/**
     * 批量删除地区码
     * 
     * @param areaIds 需要删除的数据ID
     * @return 结果
     */
	public int deleteAreasByIds(String[] areaIds);
	
}