package com.zcty.web.utlis.payInfo;

import org.bouncycastle.util.io.pem.PemReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;

/**
 * 微信支付V3版本的签名生成，验签工具类
 */
public class SHA256withRSAUtils {

    private static final String SIGN_SHA256RSA_ALGORITHMS = "SHA256WithRSA";

    public String privateKeyPath;

    public String publicKeyPath;

    /**
     * 构造方法，填充支付参数证书路径
     * @param privateKeyPath
     * @param publicKeyPath
     */
    public SHA256withRSAUtils(String privateKeyPath,String publicKeyPath){
        this.privateKeyPath = privateKeyPath;
        this.publicKeyPath = publicKeyPath;
    }
    /**
     * 签名生成
     * @param message
     * @return
     * @throws Exception
     */
     String sign(byte[] message) throws Exception {

        Signature sign = Signature.getInstance(SIGN_SHA256RSA_ALGORITHMS);

        PrivateKey privateKey=loadPrivateKey();
        sign.initSign(privateKey);
        sign.update(message);

        return java.util.Base64.getEncoder().encodeToString(sign.sign());
    }

    /**
     * 加载 pkcs8 格式私钥
     *
     * @return
     * @throws Exception
     */
    public  PrivateKey loadPrivateKey() throws Exception {
        PemReader pemReader = new PemReader(new InputStreamReader(new FileInputStream(privateKeyPath)));
        PKCS8EncodedKeySpec pkcs8EncodedKeySpec = new PKCS8EncodedKeySpec(pemReader.readPemObject().getContent());
        pemReader.close();
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        return keyFactory.generatePrivate(pkcs8EncodedKeySpec);
    }

    /**
     * 验签
     *
     * @param content
     * @param signature
     * @return
     */
    public  Boolean checkSign(String content, String signature) {
        try {
            System.out.println("content = " + content);
            System.out.println("signature = " + signature);
            Signature signatureTool = Signature.getInstance(SIGN_SHA256RSA_ALGORITHMS);
            PublicKey publicKey=loadPublicKey();
            signatureTool.initVerify(publicKey);
            signatureTool.update(content.getBytes(StandardCharsets.UTF_8));
            byte[] signbyte = java.util.Base64.getDecoder().decode(signature.getBytes());
            return signatureTool.verify(signbyte);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }


    /**
     * 从证书加载公钥
     *
     * @return
     * @throws Exception
     */
    public  PublicKey loadPublicKey() throws Exception {
        CertificateFactory fact = CertificateFactory.getInstance("X.509");
        FileInputStream is = new FileInputStream(publicKeyPath);
        X509Certificate cer = (X509Certificate) fact.generateCertificate(is);
        return cer.getPublicKey();
    }

}
