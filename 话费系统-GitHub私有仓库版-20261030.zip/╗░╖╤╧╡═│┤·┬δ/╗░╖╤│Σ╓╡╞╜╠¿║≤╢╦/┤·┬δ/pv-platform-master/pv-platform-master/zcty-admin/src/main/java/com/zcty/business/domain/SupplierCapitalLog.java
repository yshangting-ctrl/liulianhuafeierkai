package com.zcty.business.domain;

import java.math.BigDecimal;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.zcty.common.annotation.Excel;
import com.zcty.common.core.domain.BaseEntity;
/**
 * 代理商资金使用记录对象 t_supplier_capital_log
 * 
 * @author ruoyi
 * @date 2024-06-24
 */
public class SupplierCapitalLog extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 主键id */
    private String id;

    /** 代理商资金表id */
    @Excel(name = "代理商资金表id")
    private String supplierCapitalId;

    /** 代理商id */
    @Excel(name = "代理商id")
    private String supplierId;

    /** 资金记录类型， 1 增加 2减少 */
    @Excel(name = "资金记录类型， 1 增加 2减少")
    private Integer capitalType;

    /** 资金数量 */
    @Excel(name = "资金数量")
    private BigDecimal capitalTotal;

    /** 删除标示 0 未删除 1已删除 */
    private Integer delFlag;

    /** 原资金 */
    private  BigDecimal oldTotal;
    /** 变动后资金 */
    private  BigDecimal newTotal;

    public void setId(String id) 
    {
        this.id = id;
    }

    public String getId() 
    {
        return id;
    }
    public void setSupplierCapitalId(String supplierCapitalId) 
    {
        this.supplierCapitalId = supplierCapitalId;
    }

    public String getSupplierCapitalId() 
    {
        return supplierCapitalId;
    }
    public void setSupplierId(String supplierId) 
    {
        this.supplierId = supplierId;
    }

    public String getSupplierId() 
    {
        return supplierId;
    }
    public void setCapitalType(Integer capitalType) 
    {
        this.capitalType = capitalType;
    }

    public Integer getCapitalType() 
    {
        return capitalType;
    }
    public void setCapitalTotal(BigDecimal capitalTotal) 
    {
        this.capitalTotal = capitalTotal;
    }

    public BigDecimal getCapitalTotal() 
    {
        return capitalTotal;
    }
    public void setDelFlag(Integer delFlag) 
    {
        this.delFlag = delFlag;
    }

    public Integer getDelFlag() 
    {
        return delFlag;
    }

    public BigDecimal getOldTotal() {
        return oldTotal;
    }

    public void setOldTotal(BigDecimal oldTotal) {
        this.oldTotal = oldTotal;
    }

    public BigDecimal getNewTotal() {
        return newTotal;
    }

    public void setNewTotal(BigDecimal newTotal) {
        this.newTotal = newTotal;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("supplierCapitalId", getSupplierCapitalId())
            .append("supplierId", getSupplierId())
            .append("capitalType", getCapitalType())
            .append("capitalTotal", getCapitalTotal())
            .append("oldTotal", getOldTotal() )
            .append("newTotal",getNewTotal())
            .append("createTime", getCreateTime())
            .append("delFlag", getDelFlag())
            .toString();
    }
}
