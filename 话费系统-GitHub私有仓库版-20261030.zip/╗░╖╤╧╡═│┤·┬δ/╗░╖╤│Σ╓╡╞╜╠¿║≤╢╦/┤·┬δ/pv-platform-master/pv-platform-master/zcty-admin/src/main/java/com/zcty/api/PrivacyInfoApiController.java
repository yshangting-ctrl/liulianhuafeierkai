package com.zcty.api;


import com.zcty.business.domain.PrivacyInfo;
import com.zcty.business.service.IPrivacyInfoService;
import com.zcty.common.core.controller.BaseController;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.core.page.TableDataInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
/**
 * 隐私政策Controller
 *
 * @author lsw
 * @date 2024-03-20
 */
@RestController
@RequestMapping("/api/privacy")
public class PrivacyInfoApiController extends BaseController {

    @Autowired
    private IPrivacyInfoService privacyInfoService;

    /**
     * 查询隐私政策列表
     */
    @PostMapping("/list")
    public TableDataInfo list(PrivacyInfo privacyInfo)
    {
        startPage();
        List<PrivacyInfo> list = privacyInfoService.selectPrivacyInfoList(privacyInfo);
        return getDataTable(list);
    }

    @PostMapping("/getInfo")
    public AjaxResult getInfo(String id)
    {
        return success(privacyInfoService.selectPrivacyInfoById(id));
    }
}
