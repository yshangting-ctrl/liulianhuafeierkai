package com.zcty.business.service;

import java.util.List;
import com.zcty.business.domain.HomeBanner;
import com.zcty.common.core.domain.AjaxResult;

/**
 * 首页轮播图Service接口
 * 
 * @author lsw
 * @date 2024-03-15
 */
public interface IHomeBannerService 
{
    /**
     * 查询首页轮播图
     * 
     * @param id 首页轮播图主键
     * @return 首页轮播图
     */
    public HomeBanner selectHomeBannerById(String id);

    /**
     * 查询首页轮播图列表
     * 
     * @param homeBanner 首页轮播图
     * @return 首页轮播图集合
     */
    public List<HomeBanner> selectHomeBannerList(HomeBanner homeBanner);

    public List<HomeBanner> selectHomeBannerApiList();

    /**
     * 新增首页轮播图
     * 
     * @param homeBanner 首页轮播图
     * @return 结果
     */
    public AjaxResult insertHomeBanner(HomeBanner homeBanner);

    /**
     * 修改首页轮播图
     * 
     * @param homeBanner 首页轮播图
     * @return 结果
     */
    public AjaxResult updateHomeBanner(HomeBanner homeBanner);

    /**
     * 批量删除首页轮播图
     * 
     * @param ids 需要删除的首页轮播图主键集合
     * @return 结果
     */
    public int deleteHomeBannerByIds(String[] ids);

    /**
     * 删除首页轮播图信息
     * 
     * @param id 首页轮播图主键
     * @return 结果
     */
    public int deleteHomeBannerById(String id);
}
