package com.zcty.pv.mapper;


import com.zcty.pv.domain.WeChatUser;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 微名用户 数据层
 * 
 * @author liuruibin
 * @date 2020-04-03
 */
public interface WeChatUserMapper 
{
	/**
     * 查询微名用户信息
     * 
     * @param id 微名用户ID
     * @return 微名用户信息
     */
	public WeChatUser selectWeChatUserById(String id);

	/**
	 * 查询微名用户信息用于做同步锁
	 *
	 * @param id 微名用户ID
	 * @return 微名用户信息
	 */
	public WeChatUser selectWeChatForUpdateUserById(String id);
	/**
	 * 查询微名用户信息
	 *
	 * @param openId 微名用户ID
	 * @return 微名用户信息
	 */
	public WeChatUser selectWeChatUserByOpenId(@Param("openId") String openId);
	/**
     * 查询微名用户列表
     * 
     * @param weChatUser 微名用户信息
     * @return 微名用户集合
     */
	public List<WeChatUser> selectWeChatUserList(WeChatUser weChatUser);
	
	/**
     * 新增微名用户
     * 
     * @param weChatUser 微名用户信息
     * @return 结果
     */
	public int insertWeChatUser(WeChatUser weChatUser);
	
	/**
     * 修改微名用户
     * 
     * @param weChatUser 微名用户信息
     * @return 结果
     */
	public int updateWeChatUser(WeChatUser weChatUser);

	/**
	 * 修改会员
	 *
	 * @param weChatUser 微名用户信息
	 * @return 结果
	 */
	public int updateVipWeChatUser(WeChatUser weChatUser);
	/**
	 * 更改微信用户的头像
	 * @param id
	 * @param fileName
	 * @return
	 */
	public int changeAvatar(@Param("id") String id, @Param("fileName") String fileName);

	/**
	 * 修改微信用户的绑定手机号码
	 * @param openid
	 * @return
	 */
	public int updateWeChatUserBindPhone(@Param("openid") String openid, @Param("bindPhone") String bindPhone);

	/**
	 * 更新用户的积分
	 * @return
	 */
	public int updatePoints(WeChatUser weChatUser);
	/**
	 * 新增vip用户
	 * @param weChatUser
	 * @return
	 */
	public int addVipUser(WeChatUser weChatUser);

	/**
	 * 查询会员列表
	 * @param weChatUser
	 * @return
	 */
	public List<WeChatUser> selectWeChatVipUserList(WeChatUser weChatUser);


	/**
	 * 删除会员
	 * @param id
	 * @return
	 */
	public int deleteWeChatUserByIds(String id);

	/**
	 * 根据用户id查询用户信息
	 * @param userId
	 * @return
	 */
	public WeChatUser selectWeChatUserByUserId(String userId);
}