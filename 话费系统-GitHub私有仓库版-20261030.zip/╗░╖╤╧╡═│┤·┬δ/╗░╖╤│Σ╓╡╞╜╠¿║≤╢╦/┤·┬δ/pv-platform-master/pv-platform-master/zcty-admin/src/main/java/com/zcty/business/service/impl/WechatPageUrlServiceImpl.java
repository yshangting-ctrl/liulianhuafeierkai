package com.zcty.business.service.impl;

import java.util.List;
import com.zcty.common.utils.DateUtils;
import com.zcty.web.utlis.IdGen;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zcty.business.mapper.WechatPageUrlMapper;
import com.zcty.business.domain.WechatPageUrl;
import com.zcty.business.service.IWechatPageUrlService;

/**
 * 微信公众号页面链接地址Service业务层处理
 * 
 * @author lsw
 * @date 2024-05-29
 */
@Service
public class WechatPageUrlServiceImpl implements IWechatPageUrlService 
{
    @Autowired
    private WechatPageUrlMapper wechatPageUrlMapper;

    /**
     * 查询微信公众号页面链接地址
     * 
     * @param id 微信公众号页面链接地址主键
     * @return 微信公众号页面链接地址
     */
    @Override
    public WechatPageUrl selectWechatPageUrlById(String id)
    {
        return wechatPageUrlMapper.selectWechatPageUrlById(id);
    }

    /**
     * 查询微信公众号页面链接地址列表
     * 
     * @param wechatPageUrl 微信公众号页面链接地址
     * @return 微信公众号页面链接地址
     */
    @Override
    public List<WechatPageUrl> selectWechatPageUrlList(WechatPageUrl wechatPageUrl)
    {
        return wechatPageUrlMapper.selectWechatPageUrlList(wechatPageUrl);
    }

    /**
     * 新增微信公众号页面链接地址
     * 
     * @param wechatPageUrl 微信公众号页面链接地址
     * @return 结果
     */
    @Override
    public int insertWechatPageUrl(WechatPageUrl wechatPageUrl)
    {
        String id = IdGen.uuid();
        wechatPageUrl.setId(id);
        wechatPageUrl.setDelFlag(0);
        wechatPageUrl.setCreateTime(DateUtils.getNowDate());
        return wechatPageUrlMapper.insertWechatPageUrl(wechatPageUrl);
    }

    /**
     * 修改微信公众号页面链接地址
     * 
     * @param wechatPageUrl 微信公众号页面链接地址
     * @return 结果
     */
    @Override
    public int updateWechatPageUrl(WechatPageUrl wechatPageUrl)
    {
        return wechatPageUrlMapper.updateWechatPageUrl(wechatPageUrl);
    }

    /**
     * 批量删除微信公众号页面链接地址
     * 
     * @param ids 需要删除的微信公众号页面链接地址主键
     * @return 结果
     */
    @Override
    public int deleteWechatPageUrlByIds(String[] ids)
    {
        return wechatPageUrlMapper.deleteWechatPageUrlByIds(ids);
    }

    /**
     * 删除微信公众号页面链接地址信息
     * 
     * @param id 微信公众号页面链接地址主键
     * @return 结果
     */
    @Override
    public int deleteWechatPageUrlById(String id)
    {
        return wechatPageUrlMapper.deleteWechatPageUrlById(id);
    }
}
