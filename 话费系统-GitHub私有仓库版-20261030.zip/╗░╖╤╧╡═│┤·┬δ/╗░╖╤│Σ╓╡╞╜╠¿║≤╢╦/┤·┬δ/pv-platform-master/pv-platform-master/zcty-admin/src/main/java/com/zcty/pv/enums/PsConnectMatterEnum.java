package com.zcty.pv.enums;

/**
 * 并网事项枚举类
 */
public enum PsConnectMatterEnum {
    /** 并网申请 */
    CONNECT_REQ("ConnectReq","并网申请"),
    /** 并网回执 */
    CONNECT_RECEIPT("ConnectReceipt","并网回执"),
    /** 并网方案 */
    CONNECT_SCHEME("ConnectScheme","并网方案"),
    /** 供电合同 */
    CONNECT_CONTRACT("ConnectContract","供电合同"),
    /** 安装电表 */
    CONNECT_METER("ConnectMeter","安装电表"),
    /** 其他 */
    CONNECT_OTHER("ConnectOther","其他") ;

    private String value;
    private String text;

    PsConnectMatterEnum(String value, String text) {
        this.value = value;
        this.text = text;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
