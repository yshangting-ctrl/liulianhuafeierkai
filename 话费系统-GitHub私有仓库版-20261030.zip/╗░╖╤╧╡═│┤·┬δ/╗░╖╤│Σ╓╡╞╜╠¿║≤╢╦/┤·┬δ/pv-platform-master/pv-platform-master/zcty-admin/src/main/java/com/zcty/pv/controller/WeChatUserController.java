package com.zcty.pv.controller;


import com.zcty.common.core.controller.BaseController;
import com.zcty.common.core.page.TableDataInfo;
import com.zcty.pv.domain.WeChatUser;
import com.zcty.pv.service.IWeChatUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/**
 * 微名用户 信息操作处理
 * 
 * @author liuruibin
 * @date 2020-04-03
 */
@Controller
@RequestMapping("/business/weChatUser")
public class WeChatUserController extends BaseController
{

	
	@Autowired
	private IWeChatUserService weChatUserService;

	
	/**
	 * 查询微名用户列表
	 */
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(WeChatUser weChatUser)
	{
		startPage();
        List<WeChatUser> list = weChatUserService.selectWeChatUserList(weChatUser);
		return getDataTable(list);
	}

	/**
	 * 查询微名用户列表
	 */
	@PostMapping("/generalList")
	@ResponseBody
	public TableDataInfo generalList(WeChatUser weChatUser)
	{
		startPage();

		List<WeChatUser> list = weChatUserService.selectWeChatUserList(weChatUser);

		return getDataTable(list);
	}
}
