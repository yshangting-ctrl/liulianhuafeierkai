package com.zcty.business.service.impl;

import java.util.List;
import com.zcty.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zcty.business.mapper.OrderSendProductMapper;
import com.zcty.business.domain.OrderSendProduct;
import com.zcty.business.service.IOrderSendProductService;

/**
 * 业务发货Service业务层处理
 * 
 * @author lsw
 * @date 2024-07-09
 */
@Service
public class OrderSendProductServiceImpl implements IOrderSendProductService 
{
    @Autowired
    private OrderSendProductMapper orderSendProductMapper;

    /**
     * 查询业务发货
     * 
     * @param id 业务发货主键
     * @return 业务发货
     */
    @Override
    public OrderSendProduct selectOrderSendProductById(String id)
    {
        return orderSendProductMapper.selectOrderSendProductById(id);
    }

    /**
     * 查询业务发货列表
     * 
     * @param orderSendProduct 业务发货
     * @return 业务发货
     */
    @Override
    public List<OrderSendProduct> selectOrderSendProductList(OrderSendProduct orderSendProduct)
    {
        return orderSendProductMapper.selectOrderSendProductList(orderSendProduct);
    }

    /**
     * 新增业务发货
     * 
     * @param orderSendProduct 业务发货
     * @return 结果
     */
    @Override
    public int insertOrderSendProduct(OrderSendProduct orderSendProduct)
    {
        orderSendProduct.setCreateTime(DateUtils.getNowDate());
        return orderSendProductMapper.insertOrderSendProduct(orderSendProduct);
    }

    /**
     * 修改业务发货
     * 
     * @param orderSendProduct 业务发货
     * @return 结果
     */
    @Override
    public int updateOrderSendProduct(OrderSendProduct orderSendProduct)
    {
        return orderSendProductMapper.updateOrderSendProduct(orderSendProduct);
    }

    /**
     * 批量删除业务发货
     * 
     * @param ids 需要删除的业务发货主键
     * @return 结果
     */
    @Override
    public int deleteOrderSendProductByIds(String[] ids)
    {
        return orderSendProductMapper.deleteOrderSendProductByIds(ids);
    }

    /**
     * 删除业务发货信息
     * 
     * @param id 业务发货主键
     * @return 结果
     */
    @Override
    public int deleteOrderSendProductById(String id)
    {
        return orderSendProductMapper.deleteOrderSendProductById(id);
    }

    @Override
    public OrderSendProduct selectOrderSendProductByParentOrderNo(String parentOrderNo) {
        return orderSendProductMapper.selectOrderSendProductByParentOrderNo(parentOrderNo);
    }
}
