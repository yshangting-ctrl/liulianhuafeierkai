package com.zcty.business.service.impl;

import java.util.List;

import com.zcty.business.domain.PlatformInfos;
import com.zcty.business.service.IPlatformInfosService;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.utils.DateUtils;
import com.zcty.web.utlis.IdGen;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zcty.business.mapper.ActivityProductMapper;
import com.zcty.business.domain.ActivityProduct;
import com.zcty.business.service.IActivityProductService;

/**
 * 第三方业务商品Service业务层处理
 * 
 * @author LSW
 * @date 2024-07-01
 */
@Service
public class ActivityProductServiceImpl implements IActivityProductService 
{
    @Autowired
    private ActivityProductMapper activityProductMapper;

    @Autowired
    private IPlatformInfosService platformInfosService;

    /**
     * 查询第三方业务商品
     * 
     * @param id 第三方业务商品主键
     * @return 第三方业务商品
     */
    @Override
    public ActivityProduct selectActivityProductById(String id)
    {
        return activityProductMapper.selectActivityProductById(id);
    }

    /**
     * 查询第三方业务商品列表
     * 
     * @param activityProduct 第三方业务商品
     * @return 第三方业务商品
     */
    @Override
    public List<ActivityProduct> selectActivityProductList(ActivityProduct activityProduct)
    {
        return activityProductMapper.selectActivityProductList(activityProduct);
    }

    /**
     * 新增第三方业务商品
     * 
     * @param activityProduct 第三方业务商品
     * @return 结果
     */
    @Override
    public AjaxResult insertActivityProduct(ActivityProduct activityProduct)
    {
        String id = IdGen.uuid();
        activityProduct.setId(id);
        activityProduct.setCreateTime(DateUtils.getNowDate());
        String platformKey =  activityProduct.getPlatformKey();
        PlatformInfos platformInfos = platformInfosService.selectPlatformInfosByKeyWord(platformKey);
        if(platformInfos == null ){
            return AjaxResult.error("未找到充值平台信息");
        }
        activityProduct.setPlatformInfosId(platformInfos.getId());
        return AjaxResult.switchOne(activityProductMapper.insertActivityProduct(activityProduct));
    }

    /**
     * 修改第三方业务商品
     * 
     * @param activityProduct 第三方业务商品
     * @return 结果
     */
    @Override
    public AjaxResult updateActivityProduct(ActivityProduct activityProduct)
    {
//        String platformKey =  activityProduct.getPlatformKey();
//        PlatformInfos platformInfos = platformInfosService.selectPlatformInfosByKeyWord(platformKey);
//        if(platformInfos == null ){
//            return AjaxResult.error("未找到充值平台信息");
//        }
//        activityProduct.setPlatformInfosId(platformInfos.getId());
//        activityProduct.setUpdateTime();
        return  AjaxResult.switchOne(activityProductMapper.updateActivityProduct(activityProduct));
    }

    /**
     * 批量删除第三方业务商品
     * 
     * @param ids 需要删除的第三方业务商品主键
     * @return 结果
     */
    @Override
    public int deleteActivityProductByIds(String[] ids)
    {
        return activityProductMapper.deleteActivityProductByIds(ids);
    }

    /**
     * 删除第三方业务商品信息
     * 
     * @param id 第三方业务商品主键
     * @return 结果
     */
    @Override
    public int deleteActivityProductById(String id)
    {
        return activityProductMapper.deleteActivityProductById(id);
    }

    @Override
    public List<ActivityProduct> selectActivityPlatProductList(ActivityProduct activityProduct) {
        return activityProductMapper.selectActivityPlatProductList(activityProduct);
    }
}
