package com.zcty.business.controller;


import com.zcty.business.domain.OnlineMessage;
import com.zcty.business.domain.OnlineMessageReply;
import com.zcty.business.service.IOnlineMessageReplyService;
import com.zcty.business.service.IOnlineMessageService;
import com.zcty.common.annotation.Log;
import com.zcty.common.core.controller.BaseController;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.core.page.TableDataInfo;
import com.zcty.common.enums.BusinessType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

/**
 * 在线留言 信息操作处理
 * 
 * @author liuruibin
 * @date 2022-11-28
 */
@Controller
@RequestMapping("/business/onlineMessage")
public class OnlineMessageController extends BaseController
{
    private String prefix = "business/onlineMessage";
	@Autowired
	private IOnlineMessageReplyService onlineMessageReplyService;
	@Autowired
	private IOnlineMessageService onlineMessageService;
	
	@GetMapping()
	public String onlineMessage()
	{
	    return prefix + "/onlineMessage";
	}
	
	/**
	 * 查询在线留言列表
	 */
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(OnlineMessage onlineMessage)
	{
		startPage();
        List<OnlineMessage> list = onlineMessageService.selectOnlineMessageShowList(onlineMessage);
		return getDataTable(list);
	}

	/**
	 * 留言详情
	 */
	@GetMapping("/edit/{id}")
	@ResponseBody
	public AjaxResult edit(@PathVariable("id") String id)
	{
		OnlineMessage onlineMessage = onlineMessageService.selectOnlineMessageById(id);

		List<OnlineMessageReply> onlineMessageReplies=new ArrayList<>();

        OnlineMessageReply onlineMessageReply = new OnlineMessageReply();
		if(onlineMessage!=null){
			onlineMessageReplies = onlineMessageReplyService.selectOnlineMessageReplyList(new OnlineMessageReply(){
				{
					this.setMessageId(onlineMessage.getId()) ;
				}
			});
		 if(!onlineMessageReplies.isEmpty()){
             onlineMessageReply = onlineMessageReplies.get(0);
         }
		}
	    return AjaxResult.success(onlineMessageReply);
	}
	
	/**
	 * 留言备注
	 */
	@Log(title = "在线留言", businessType = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(OnlineMessage onlineMessage)
	{		
		return toAjax(onlineMessageService.updateOnlineMessage(new OnlineMessage(){{
			setId(onlineMessage.getId());
			setRemarks(onlineMessage.getRemarks());
			setCheckRemarks(1);
		}}));
	}
	
	/**
	 * 删除在线留言
	 */
	@Log(title = "在线留言", businessType = BusinessType.DELETE)
	@PostMapping( "/remove/{ids}")
	@ResponseBody
	public AjaxResult remove(@PathVariable String ids)
	{		
		return toAjax(onlineMessageService.deleteOnlineMessageByIds(ids));
	}
	
}
