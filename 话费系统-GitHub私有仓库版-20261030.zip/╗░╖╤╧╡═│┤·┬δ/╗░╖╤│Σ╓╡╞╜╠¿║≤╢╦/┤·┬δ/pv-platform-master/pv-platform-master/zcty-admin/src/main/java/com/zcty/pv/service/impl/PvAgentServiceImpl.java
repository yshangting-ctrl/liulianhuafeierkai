package com.zcty.pv.service.impl;

import java.util.List;

import cn.hutool.core.util.IdUtil;
import com.zcty.common.annotation.DataScope;
import com.zcty.common.constant.UserConstants;
import com.zcty.common.core.domain.entity.SysDept;
import com.zcty.common.utils.DateUtils;
import com.zcty.common.utils.SecurityUtils;
import com.zcty.common.utils.StringUtils;
import com.zcty.pv.constants.PvConstants;
import com.zcty.system.service.ISysDeptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zcty.pv.mapper.PvAgentMapper;
import com.zcty.pv.domain.PvAgent;
import com.zcty.pv.service.IPvAgentService;

/**
 * 代理商Service业务层处理
 * 
 * @author luohui
 * @date 2022-11-20
 */
@Service
public class PvAgentServiceImpl implements IPvAgentService 
{
    @Autowired
    private PvAgentMapper pvAgentMapper;

    @Autowired
    private ISysDeptService sysDeptService;

    /**
     * 查询代理商
     * 
     * @param agentId 代理商主键
     * @return 代理商
     */
    @Override
    public PvAgent selectPvAgentByAgentId(Long agentId)
    {
        return pvAgentMapper.selectPvAgentByAgentId(agentId);
    }

    /**
     * 查询代理商列表
     * 
     * @param pvAgent 代理商
     * @return 代理商
     */
    @Override
    @DataScope(agentAlias = "a")
    public List<PvAgent> selectPvAgentList(PvAgent pvAgent)
    {
        return pvAgentMapper.selectPvAgentList(pvAgent);
    }

    /**
     * 检查代理商名称是否唯一
     *
     * @param pvAgent
     * @return
     */
    @Override
    public String checkAgentNameUnique(PvAgent pvAgent) {
        Long agentId = StringUtils.isNull(pvAgent.getAgentId()) ? -1L : pvAgent.getAgentId();
        PvAgent info = pvAgentMapper.checkAgentNameUnique(pvAgent.getAgentName());
        if(StringUtils.isNotNull(info) && info.getAgentId().longValue() != agentId.longValue()){
            return UserConstants.NOT_UNIQUE;
        }

        return UserConstants.UNIQUE;
    }

    /**
     * 新增代理商
     * 
     * @param pvAgent 代理商
     * @return 结果
     */
    @Override
    public int insertPvAgent(PvAgent pvAgent)
    {
        Long deptId = IdUtil.getSnowflakeNextId();
        SysDept sysDept = new SysDept();
        sysDept.setDeptId(deptId);
        sysDept.setDeptName(pvAgent.getAgentName());
        sysDept.setParentId(PvConstants.AGENT_PARENT_DEPT_ID);
        sysDept.setLeader(pvAgent.getContacts());
        sysDept.setPhone(pvAgent.getPhone());
        sysDeptService.insertDept(sysDept);

        pvAgent.setCreateBy(SecurityUtils.getNickname());
        pvAgent.setAgentId(deptId);
        pvAgent.setCreateTime(DateUtils.getNowDate());
        pvAgent.setDeptId(deptId);
        pvAgent.setDelFlag(PvConstants.DEL_FLAG_0);
        return pvAgentMapper.insertPvAgent(pvAgent);
    }

    /**
     * 修改代理商
     * 
     * @param pvAgent 代理商
     * @return 结果
     */
    @Override
    public int updatePvAgent(PvAgent pvAgent)
    {
        Long deptId = pvAgent.getDeptId();
        SysDept dept = new SysDept();
        dept.setDeptId(deptId);
        dept.setDeptName(pvAgent.getAgentName());
        sysDeptService.updateDept(dept);
        pvAgent.setUpdateBy(SecurityUtils.getNickname());
        pvAgent.setUpdateTime(DateUtils.getNowDate());
        return pvAgentMapper.updatePvAgent(pvAgent);
    }

    /**
     * 批量删除代理商
     * 
     * @param agentIds 需要删除的代理商主键
     * @return 结果
     */
    @Override
    public int deletePvAgentByAgentIds(Long[] agentIds)
    {
        return pvAgentMapper.deletePvAgentByAgentIds(agentIds);
    }

    /**
     * 删除代理商信息
     * 
     * @param agentId 代理商主键
     * @return 结果
     */
    @Override
    public int deletePvAgentByAgentId(Long agentId)
    {
        sysDeptService.deleteDeptById(agentId);
        return pvAgentMapper.deletePvAgentByAgentId(agentId);
    }
}
