package com.zcty.pv.service;

import java.util.List;
import com.zcty.pv.domain.PvAgent;

/**
 * 代理商Service接口
 * 
 * @author luohui
 * @date 2022-11-20
 */
public interface IPvAgentService 
{
    /**
     * 查询代理商
     * 
     * @param agentId 代理商主键
     * @return 代理商
     */
    public PvAgent selectPvAgentByAgentId(Long agentId);

    /**
     * 查询代理商列表
     * 
     * @param pvAgent 代理商
     * @return 代理商集合
     */
    public List<PvAgent> selectPvAgentList(PvAgent pvAgent);

    /**
     * 新增代理商
     * 
     * @param pvAgent 代理商
     * @return 结果
     */
    public int insertPvAgent(PvAgent pvAgent);

    /**
     * 修改代理商
     * 
     * @param pvAgent 代理商
     * @return 结果
     */
    public int updatePvAgent(PvAgent pvAgent);

    /**
     * 批量删除代理商
     * 
     * @param agentIds 需要删除的代理商主键集合
     * @return 结果
     */
    public int deletePvAgentByAgentIds(Long[] agentIds);

    /**
     * 删除代理商信息
     * 
     * @param agentId 代理商主键
     * @return 结果
     */
    public int deletePvAgentByAgentId(Long agentId);

    /**
     * 检查代理商名称是否唯一
     * @param pvAgent
     * @return
     */
    public String checkAgentNameUnique(PvAgent pvAgent);
}
