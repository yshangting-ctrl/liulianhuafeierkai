package com.zcty.pv.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.zcty.common.annotation.Excel;
import com.zcty.common.core.domain.BaseEntity;

/**
 * 通用文件对象 pub_file
 * 
 * @author luohui
 * @date 2022-11-29
 */
@ApiModel("通用文件对象")
public class PubFile extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 文件id */
    @JsonSerialize(using = ToStringSerializer.class)
    @ApiModelProperty("文件id")
    private Long id;

    /** 业务id */
    @JsonSerialize(using = ToStringSerializer.class)
    @ApiModelProperty("业务id")
    @Excel(name = "业务id")
    private Long bizId;

    /** 业务类型 */
    @ApiModelProperty("业务类型")
    @Excel(name = "业务类型")
    private String bizKey;

    /** 文件名 */
    @ApiModelProperty("文件名")
    @Excel(name = "文件名")
    private String fileName;

    /** 文件存储路径 */
    @ApiModelProperty("文件存储路径")
    @Excel(name = "文件存储路径")
    private String fileUrl;

    /** 文件类型 */
    @ApiModelProperty("文件类型")
    @Excel(name = "文件类型")
    private String fileType;

    /** 文件大小 */
    @JsonSerialize(using = ToStringSerializer.class)
    @ApiModelProperty("文件大小")
    @Excel(name = "文件大小")
    private Long size;

    /** 代理商id */
    @JsonSerialize(using = ToStringSerializer.class)
    @ApiModelProperty("代理商id")
    @Excel(name = "代理商id")
    private Long agentId;

    /** 审核时间 */
    @ApiModelProperty("审核时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Excel(name = "审核时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date auditTime;

    /** 审核意见 */
    @ApiModelProperty("审核意见")
    @Excel(name = "审核意见")
    private String auditRemark;

    /** 状态 */
    @ApiModelProperty("状态")
    @Excel(name = "状态")
    private Integer status;

    /** 审核人 */
    @ApiModelProperty("审核人")
    @Excel(name = "审核人")
    private String auditor;

    /** 序号 */
    @ApiModelProperty("序号")
    @Excel(name = "序号")
    private Integer sortNum;

    /** 删除标志（0代表存在 2代表删除） */
    @ApiModelProperty("删除标志（0代表存在 2代表删除）")
    private String delFlag;

    /** 补充文件路径 */
    @ApiModelProperty("补充文件路径")
    @Excel(name = "补充文件路径")
    private String otherFileUrl;

    /** 是否必须，T-是 F-否 */
    @ApiModelProperty("是否必须，T-是 F-否")
    @Excel(name = "是否必须，T-是 F-否")
    private String isNeed;


    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setBizId(Long bizId) 
    {
        this.bizId = bizId;
    }

    public Long getBizId() 
    {
        return bizId;
    }
    public void setBizKey(String bizKey) 
    {
        this.bizKey = bizKey;
    }

    public String getBizKey() 
    {
        return bizKey;
    }
    public void setFileName(String fileName) 
    {
        this.fileName = fileName;
    }

    public String getFileName() 
    {
        return fileName;
    }
    public void setFileUrl(String fileUrl) 
    {
        this.fileUrl = fileUrl;
    }

    public String getFileUrl() 
    {
        return fileUrl;
    }
    public void setFileType(String fileType) 
    {
        this.fileType = fileType;
    }

    public String getFileType() 
    {
        return fileType;
    }
    public void setSize(Long size) 
    {
        this.size = size;
    }

    public Long getSize() 
    {
        return size;
    }
    public void setAgentId(Long agentId) 
    {
        this.agentId = agentId;
    }

    public Long getAgentId() 
    {
        return agentId;
    }
    public void setAuditTime(Date auditTime) 
    {
        this.auditTime = auditTime;
    }

    public Date getAuditTime() 
    {
        return auditTime;
    }
    public void setAuditRemark(String auditRemark) 
    {
        this.auditRemark = auditRemark;
    }

    public String getAuditRemark() 
    {
        return auditRemark;
    }
    public void setStatus(Integer status) 
    {
        this.status = status;
    }

    public Integer getStatus() 
    {
        return status;
    }
    public void setAuditor(String auditor) 
    {
        this.auditor = auditor;
    }

    public String getAuditor() 
    {
        return auditor;
    }
    public void setSortNum(Integer sortNum) 
    {
        this.sortNum = sortNum;
    }

    public Integer getSortNum() 
    {
        return sortNum;
    }
    public void setDelFlag(String delFlag) 
    {
        this.delFlag = delFlag;
    }

    public String getDelFlag() 
    {
        return delFlag;
    }

    public String getOtherFileUrl() {
        return otherFileUrl;
    }

    public void setOtherFileUrl(String otherFileUrl) {
        this.otherFileUrl = otherFileUrl;
    }

    public String getIsNeed() {
        return isNeed;
    }

    public void setIsNeed(String isNeed) {
        this.isNeed = isNeed;
    }



    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
                .append("id", getId())
                .append("bizId", getBizId())
                .append("bizKey", getBizKey())
                .append("fileName", getFileName())
                .append("fileUrl", getFileUrl())
                .append("fileType", getFileType())
                .append("size", getSize())
                .append("otherFileUrl", getOtherFileUrl())
                .append("isNeed", getIsNeed())
                .append("agentId", getAgentId())
                .append("auditTime", getAuditTime())
                .append("auditRemark", getAuditRemark())
                .append("status", getStatus())
                .append("auditor", getAuditor())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("sortNum", getSortNum())
                .append("delFlag", getDelFlag())

                .toString();
    }
}
