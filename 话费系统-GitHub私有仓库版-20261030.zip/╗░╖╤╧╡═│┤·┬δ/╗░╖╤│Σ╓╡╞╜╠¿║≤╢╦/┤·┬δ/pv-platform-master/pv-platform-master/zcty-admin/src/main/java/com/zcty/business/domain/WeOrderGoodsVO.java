package com.zcty.business.domain;



import java.math.BigDecimal;

/**
 * @Author: chushengkun
 * @Date: 2022/7/27 17:10
 */
public class WeOrderGoodsVO {
    /** 商品ID */
    private String goodsId;
    /** 商品编号 */
    private String commonSn;
    /** 商品名称 */
    private String commonName;
    /** 商品副标题 */
    private String commonDes;
    /** 单价 */
    private BigDecimal goodsPrice;
    /** 商品数量 */
    private Integer goodsNum;

    private String totalPrice;

    private String productTitle;

    /**商品类型 1 话费商品 2 流量商品 */
    private Integer goodsType;

    public String getGoodsId() {
        return goodsId;
    }

    public void setGoodsId(String goodsId) {
        this.goodsId = goodsId;
    }

    public String getCommonSn() {
        return commonSn;
    }

    public void setCommonSn(String commonSn) {
        this.commonSn = commonSn;
    }

    public String getCommonName() {
        return commonName;
    }

    public void setCommonName(String commonName) {
        this.commonName = commonName;
    }

    public String getCommonDes() {
        return commonDes;
    }

    public void setCommonDes(String commonDes) {
        this.commonDes = commonDes;
    }


    public BigDecimal getGoodsPrice() {
        return goodsPrice;
    }

    public void setGoodsPrice(BigDecimal goodsPrice) {
        this.goodsPrice = goodsPrice;
    }

    public Integer getGoodsNum() {
        return goodsNum;
    }

    public void setGoodsNum(Integer goodsNum) {
        this.goodsNum = goodsNum;
    }


    public String getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(String totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getProductTitle() {
        return productTitle;
    }

    public void setProductTitle(String productTitle) {
        this.productTitle = productTitle;
    }

    public Integer getGoodsType() {
        return goodsType;
    }

    public void setGoodsType(Integer goodsType) {
        this.goodsType = goodsType;
    }
}
