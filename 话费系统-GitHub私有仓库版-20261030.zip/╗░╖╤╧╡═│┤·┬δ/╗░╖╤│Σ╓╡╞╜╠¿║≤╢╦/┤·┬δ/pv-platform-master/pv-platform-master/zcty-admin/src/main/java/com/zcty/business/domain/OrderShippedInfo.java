package com.zcty.business.domain;



import javax.validation.constraints.NotBlank;

/**
 * @Author: chushengkun
 * @Date: 2022/8/3 9:40
 */
public class OrderShippedInfo {
    // 订单编号
    @NotBlank(message = "数据异常，请刷新重试！")
    private String orderNo;
    // 快递备注
    private String sendRemark;
    // 快递单号
    @NotBlank(message = "请填写快递单号！")
    private String sendSn;

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getSendRemark() {
        return sendRemark;
    }

    public void setSendRemark(String sendRemark) {
        this.sendRemark = sendRemark;
    }

    public String getSendSn() {
        return sendSn;
    }

    public void setSendSn(String sendSn) {
        this.sendSn = sendSn;
    }
}
