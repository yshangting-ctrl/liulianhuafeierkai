package com.zcty.web.utlis;

import com.alibaba.fastjson2.JSONArray;
import com.alibaba.fastjson2.JSONObject;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
/**
 * fastjson工具类(需要引入fastjson和dom4j的pom依赖)
 */
public class FastJsonUtil {

    /**
     * xml转fastjson
     * @param xml 待转换数据xml字符串
     * @return JSONObject对象
     */
    public static JSONObject xmlToFastJson(String xml){
        JSONObject jsonObject = null;
        try {
            jsonObject = new JSONObject();
            Document document = DocumentHelper.parseText(xml);
            // 获取根节点元素对象
            Element root = document.getRootElement();
            iterateNodes(root, jsonObject);
        }catch (Exception e){
            return jsonObject;
        }
        return jsonObject;
    }


    public static void iterateNodes(Element node, JSONObject json) {
        // 获取当前元素的名称
        String nodeName = node.getName();
        // 判断已遍历的JSON中是否已经有了该元素的名称
        if (json.containsKey(nodeName)) {
            // 该元素在同级下有多个
            Object Object = json.get(nodeName);
            JSONArray array;
            if (Object instanceof JSONArray) {
                array = (JSONArray) Object;
            }
            else {
                array = new JSONArray();
                array.add(Object);
            }
            // 获取该元素下所有子元素
            List<Element> listElement = node.elements();
            if (listElement.isEmpty()) {
                // 该元素无子元素，获取元素的值
                String nodeValue = node.getTextTrim();
                array.add(nodeValue);
                json.put(nodeName, array);
                return;
            }
            // 有子元素
            JSONObject newJson = new JSONObject();
            // 遍历所有子元素
            for (Element e : listElement) {
                // 递归
                iterateNodes(e, newJson);
            }
            array.add(newJson);
            json.put(nodeName, array);
            return;
        }
        // 该元素同级下第一次遍历
        // 获取该元素下所有子元素
        List<Element> listElement = node.elements();
        if (listElement.isEmpty()) {
            // 该元素无子元素，获取元素的值
            String nodeValue = node.getTextTrim();
            json.put(nodeName, nodeValue);
            return;
        }
        // 有子节点，新建一个JSONObject来存储该节点下子节点的值
        JSONObject object = new JSONObject();
        // 遍历所有一级子节点
        for (Element e : listElement) {
            // 递归
            iterateNodes(e, object);
        }
        json.put(nodeName, object);
        return;
    }


    /**
     * 拼当前节点属性
     * @param json
     * @return
     */
    private static String getAttr(JSONObject json){
        StringBuilder sb = new StringBuilder();
        for(Map.Entry<String,Object> entity:json.entrySet()){
            if(entity.getKey().startsWith("-")){
                sb.append(" ").append(entity.getKey().substring(1)).append("=\"").append(entity.getValue().toString()).append("\"");
            }
        }
        return sb.toString();
    }

    /**
     * 特殊字符pattern
     */
    private static Pattern pattern = Pattern.compile("[<>&\"',]");

    /**
     * json转xml中遇到特殊字符对内容追加![CDATA[]]
     * @param string
     * @return
     */
    private static String escape(String string) {
        return pattern.matcher(string).find() ? "<![CDATA[" + string + "]]>" : string;
    }


    public static void main(String[] args) {
        String a = "<xml>\n" +
                "<AppId>some_appid</AppId>\n" +
                "<CreateTime>1413192605</CreateTime>\n" +
                "<InfoType>component_verify_ticket</InfoType>\n" +
                "<ComponentVerifyTicket>some_verify_ticket</ComponentVerifyTicket>\n" +
                "</xml>";
        JSONObject jsonObject = FastJsonUtil.xmlToFastJson(a);

        String appId = jsonObject.getString("AppId");
        System.out.println(appId);
        System.out.println(jsonObject);

        JSONObject jsonObject1 = jsonObject.getJSONObject("xml");
        System.out.println(jsonObject1);
        String appId1 = jsonObject1.getString("AppId");
        System.out.println(appId1);
    }
}
