package com.zcty.business.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.zcty.common.annotation.Excel;
import com.zcty.common.core.domain.BaseEntity;

/**
 * 微信公众号页面链接地址对象 t_wechat_page_url
 * 
 * @author lsw
 * @date 2024-05-29
 */
public class WechatPageUrl extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 主键id */
    private String id;

    /** 链接地址 */
    private String pageUrl;

    /** 页面名称 */
    private String pageName;

    /** 删除标识  0未删除 1已删除 */
    private Integer delFlag;
    /** 代理商链接地址 */
    private String pageShowUrl;

    public void setId(String id) 
    {
        this.id = id;
    }

    public String getId() 
    {
        return id;
    }
    public void setPageUrl(String pageUrl) 
    {
        this.pageUrl = pageUrl;
    }

    public String getPageUrl() 
    {
        return pageUrl;
    }
    public void setPageName(String pageName) 
    {
        this.pageName = pageName;
    }

    public String getPageName() 
    {
        return pageName;
    }
    public void setDelFlag(Integer delFlag) 
    {
        this.delFlag = delFlag;
    }

    public Integer getDelFlag() 
    {
        return delFlag;
    }

    public String getPageShowUrl() {
        return pageShowUrl;
    }

    public void setPageShowUrl(String pageShowUrl) {
        this.pageShowUrl = pageShowUrl;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("pageUrl", getPageUrl())
            .append("pageShowUrl", getPageShowUrl())
            .append("pageName", getPageName())
            .append("delFlag", getDelFlag())
            .append("createTime", getCreateTime())
            .toString();
    }
}
