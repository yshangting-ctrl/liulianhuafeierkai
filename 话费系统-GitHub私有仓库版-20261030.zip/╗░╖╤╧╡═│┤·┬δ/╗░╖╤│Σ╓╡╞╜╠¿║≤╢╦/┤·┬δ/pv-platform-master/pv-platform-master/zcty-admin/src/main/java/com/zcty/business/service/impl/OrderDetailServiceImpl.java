package com.zcty.business.service.impl;


import com.zcty.business.domain.OrderDetail;
import com.zcty.business.mapper.OrderDetailMapper;
import com.zcty.business.service.IOrderDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 订单详情 服务层实现
 * 
 * @author liuruibin
 * @date 2022-07-25
 */
@Service
public class OrderDetailServiceImpl implements IOrderDetailService
{
	@Autowired
	private OrderDetailMapper orderDetailMapper;
	
	/**
     * 查询订单详情列表
     * 
     * @param orderDetail 订单详情信息
     * @return 订单详情集合
     */
	@Override
	public List<OrderDetail> selectOrderDetailList(OrderDetail orderDetail)
	{
	    return orderDetailMapper.selectOrderDetailList(orderDetail);
	}

	/**
	 * 新增订单详情
	 *
	 * @param orderDetailList 订单详情信息
	 * @return 结果
	 */
	@Override
	public int insertOrderDetailList(List<OrderDetail> orderDetailList) {
		return orderDetailMapper.insertOrderDetailList(orderDetailList);
	}
	
}
