package com.zcty.business.service.impl;

import java.util.Date;
import java.util.List;

import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.utils.DateUtils;
import com.zcty.web.utlis.IdGen;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zcty.business.mapper.HomeBannerMapper;
import com.zcty.business.domain.HomeBanner;
import com.zcty.business.service.IHomeBannerService;

/**
 * 首页轮播图Service业务层处理
 * 
 * @author lsw
 * @date 2024-03-15
 */
@Service
public class HomeBannerServiceImpl implements IHomeBannerService 
{
    @Autowired
    private HomeBannerMapper homeBannerMapper;

    /**
     * 查询首页轮播图
     * 
     * @param id 首页轮播图主键
     * @return 首页轮播图
     */
    @Override
    public HomeBanner selectHomeBannerById(String id)
    {
        return homeBannerMapper.selectHomeBannerById(id);
    }

    /**
     * 查询首页轮播图列表
     * 
     * @param homeBanner 首页轮播图
     * @return 首页轮播图
     */
    @Override
    public List<HomeBanner> selectHomeBannerList(HomeBanner homeBanner)
    {
        return homeBannerMapper.selectHomeBannerList(homeBanner);
    }

    @Override
    public List<HomeBanner> selectHomeBannerApiList()
    {
        return homeBannerMapper.selectHomeBannerApiList();
    }



    /**
     * 新增首页轮播图
     * 
     * @param homeBanner 首页轮播图
     * @return 结果
     */
    @Override
    public AjaxResult insertHomeBanner(HomeBanner homeBanner)
    {
        //填充必要数据
        //主键
        String id = IdGen.uuid();
        homeBanner.setId(id);
        homeBanner.setDelFlag(0);
        homeBanner.setStatus(1);
        //创建时间
        homeBanner.setCreateTime(DateUtils.getNowDate());
        return AjaxResult.switchOne(homeBannerMapper.insertHomeBanner(homeBanner));
    }

    /**
     * 修改首页轮播图
     * 
     * @param homeBanner 首页轮播图
     * @return 结果
     */
    @Override
    public AjaxResult updateHomeBanner(HomeBanner homeBanner)
    {
        return AjaxResult.switchOne(homeBannerMapper.updateHomeBanner(homeBanner));
    }

    /**
     * 批量删除首页轮播图
     * 
     * @param ids 需要删除的首页轮播图主键
     * @return 结果
     */
    @Override
    public int deleteHomeBannerByIds(String[] ids)
    {
        return homeBannerMapper.deleteHomeBannerByIds(ids);
    }

    /**
     * 删除首页轮播图信息
     * 
     * @param id 首页轮播图主键
     * @return 结果
     */
    @Override
    public int deleteHomeBannerById(String id)
    {
        return homeBannerMapper.deleteHomeBannerById(id);
    }
}
