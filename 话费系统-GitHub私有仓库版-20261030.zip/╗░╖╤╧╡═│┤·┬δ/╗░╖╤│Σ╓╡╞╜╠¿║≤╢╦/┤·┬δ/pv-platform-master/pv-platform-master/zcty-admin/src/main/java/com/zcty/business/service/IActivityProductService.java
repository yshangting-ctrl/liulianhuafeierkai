package com.zcty.business.service;

import java.util.List;
import com.zcty.business.domain.ActivityProduct;
import com.zcty.common.core.domain.AjaxResult;

/**
 * 第三方业务商品Service接口
 * 
 * @author LSW
 * @date 2024-07-01
 */
public interface IActivityProductService 
{
    /**
     * 查询第三方业务商品
     * 
     * @param id 第三方业务商品主键
     * @return 第三方业务商品
     */
    public ActivityProduct selectActivityProductById(String id);

    /**
     * 查询第三方业务商品列表
     * 
     * @param activityProduct 第三方业务商品
     * @return 第三方业务商品集合
     */
    public List<ActivityProduct> selectActivityProductList(ActivityProduct activityProduct);

    public List<ActivityProduct> selectActivityPlatProductList(ActivityProduct activityProduct);

    /**
     * 新增第三方业务商品
     * 
     * @param activityProduct 第三方业务商品
     * @return 结果
     */
    public AjaxResult insertActivityProduct(ActivityProduct activityProduct);

    /**
     * 修改第三方业务商品
     * 
     * @param activityProduct 第三方业务商品
     * @return 结果
     */
    public AjaxResult updateActivityProduct(ActivityProduct activityProduct);

    /**
     * 批量删除第三方业务商品
     * 
     * @param ids 需要删除的第三方业务商品主键集合
     * @return 结果
     */
    public int deleteActivityProductByIds(String[] ids);

    /**
     * 删除第三方业务商品信息
     * 
     * @param id 第三方业务商品主键
     * @return 结果
     */
    public int deleteActivityProductById(String id);
}
