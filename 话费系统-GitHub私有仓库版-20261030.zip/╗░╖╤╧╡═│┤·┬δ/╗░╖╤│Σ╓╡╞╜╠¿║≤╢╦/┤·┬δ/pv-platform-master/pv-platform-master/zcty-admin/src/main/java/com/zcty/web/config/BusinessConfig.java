package com.zcty.web.config;


import com.zcty.web.interceptor.WechatInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * 业务拦截器配置
 */
@Configuration
public class BusinessConfig implements WebMvcConfigurer {


    /**
     * 由于拦截器里面需要注入service，所有要提前注册好拦截器的been
     * @return
     */
    @Bean
    public HandlerInterceptor getWechatInterceptor(){
        return new WechatInterceptor();
    }

    /**
     * 自定义拦截规则
     */
    @Override
    public void addInterceptors(InterceptorRegistry registry)
    {
        registry.addInterceptor(getWechatInterceptor()).addPathPatterns("/weChat/**")
                .excludePathPatterns("/weChat/weChatLogin/getSessionKey","/weChat/weChatRedirect/index","/weChat/weChatRedirect/user/index","/weChat/webRedirect/**"
                        ,"/weChat/wxPay/wxNotify"
                        ,"/weChat/wxPay/refundWxNotify"
                        ,"/weChat/weGoods/**"
                        ,"/weChat/siteGoods/**"
                        ,"/weChat/newProduct/list"
                        ,"/weChat/pay/**"
//                        ,"/weChat/pay/payNotifyUrl"
//                        ,"/weChat/pay/refundNotifyUrl"
                );
    }
}
