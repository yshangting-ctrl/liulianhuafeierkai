package com.zcty.business.service.impl;

import java.util.List;
import com.zcty.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zcty.business.mapper.OrderSendProductDetailMapper;
import com.zcty.business.domain.OrderSendProductDetail;
import com.zcty.business.service.IOrderSendProductDetailService;

/**
 * 业务发货详情Service业务层处理
 * 
 * @author lsw
 * @date 2024-07-09
 */
@Service
public class OrderSendProductDetailServiceImpl implements IOrderSendProductDetailService 
{
    @Autowired
    private OrderSendProductDetailMapper orderSendProductDetailMapper;

    /**
     * 查询业务发货详情
     * 
     * @param id 业务发货详情主键
     * @return 业务发货详情
     */
    @Override
    public OrderSendProductDetail selectOrderSendProductDetailById(String id)
    {
        return orderSendProductDetailMapper.selectOrderSendProductDetailById(id);
    }

    /**
     * 查询业务发货详情列表
     * 
     * @param orderSendProductDetail 业务发货详情
     * @return 业务发货详情
     */
    @Override
    public List<OrderSendProductDetail> selectOrderSendProductDetailList(OrderSendProductDetail orderSendProductDetail)
    {
        return orderSendProductDetailMapper.selectOrderSendProductDetailList(orderSendProductDetail);
    }

    /**
     * 新增业务发货详情
     * 
     * @param orderSendProductDetail 业务发货详情
     * @return 结果
     */
    @Override
    public int insertOrderSendProductDetail(OrderSendProductDetail orderSendProductDetail)
    {
        orderSendProductDetail.setCreateTime(DateUtils.getNowDate());
        return orderSendProductDetailMapper.insertOrderSendProductDetail(orderSendProductDetail);
    }

    /**
     * 修改业务发货详情
     * 
     * @param orderSendProductDetail 业务发货详情
     * @return 结果
     */
    @Override
    public int updateOrderSendProductDetail(OrderSendProductDetail orderSendProductDetail)
    {
        return orderSendProductDetailMapper.updateOrderSendProductDetail(orderSendProductDetail);
    }

    /**
     * 批量删除业务发货详情
     * 
     * @param ids 需要删除的业务发货详情主键
     * @return 结果
     */
    @Override
    public int deleteOrderSendProductDetailByIds(String[] ids)
    {
        return orderSendProductDetailMapper.deleteOrderSendProductDetailByIds(ids);
    }

    /**
     * 删除业务发货详情信息
     * 
     * @param id 业务发货详情主键
     * @return 结果
     */
    @Override
    public int deleteOrderSendProductDetailById(String id)
    {
        return orderSendProductDetailMapper.deleteOrderSendProductDetailById(id);
    }
}
