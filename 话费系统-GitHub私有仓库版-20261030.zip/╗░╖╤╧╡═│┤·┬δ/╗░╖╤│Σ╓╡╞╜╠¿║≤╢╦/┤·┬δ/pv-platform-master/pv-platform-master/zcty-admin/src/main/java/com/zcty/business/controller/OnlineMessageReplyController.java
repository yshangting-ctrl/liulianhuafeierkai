package com.zcty.business.controller;


import com.zcty.business.domain.OnlineMessageReply;
import com.zcty.business.service.IOnlineMessageReplyService;
import com.zcty.common.annotation.Log;
import com.zcty.common.core.controller.BaseController;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.core.page.TableDataInfo;
import com.zcty.common.enums.BusinessType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 留言回复 信息操作处理
 * 
 * @author liuruibin
 * @date 2023-03-10
 */
@Controller
@RequestMapping("/business/onlineMessageReply")
public class OnlineMessageReplyController extends BaseController
{

	@Autowired
	private IOnlineMessageReplyService onlineMessageReplyService;

	
	/**
	 * 查询留言回复列表
	 */
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(OnlineMessageReply onlineMessageReply)
	{
		startPage();
        List<OnlineMessageReply> list = onlineMessageReplyService.selectOnlineMessageReplyList(onlineMessageReply);
		return getDataTable(list);
	}

	
	/**
	 * 新增保存留言回复
	 */
	@Log(title = "留言回复", businessType = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(OnlineMessageReply onlineMessageReply)
	{		
		return onlineMessageReplyService.insertOnlineMessageReply(onlineMessageReply);
	}


	
	/**
	 * 修改保存留言回复
	 */
	@Log(title = "留言回复", businessType = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(@RequestBody OnlineMessageReply onlineMessageReply)
	{		
		return (onlineMessageReplyService.updateOnlineMessageReply(onlineMessageReply));
	}
	
	/**
	 * 删除留言回复
	 */
	@Log(title = "留言回复", businessType = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(onlineMessageReplyService.deleteOnlineMessageReplyByIds(ids));
	}
	
}
