package com.zcty.business.domain;


import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
/**
 * 订单详情
 * @Author: chushengkun
 * @Date: 2022/7/27 17:02
 */
public class WeOrderInfoVO {

    /** 订单ID */
    private String orderId;

    private String userId;
    /** 订单编号 */
    private String orderNo;
    /** 微信返回的订单号 */
    private String transactionId;
    /** 订单title */
    private String remarkBody;
    /** 订单备注 */
    private String remark;
    /** 联系电话 */
    private String phone;
    /** 联系人 */
    private String nickName;
    /** 订单金额 */
    private BigDecimal totalFee;
    /** 订单支付金额*/
    private BigDecimal payFee;
    /** 交易类型JSAPI */
    private String tradeType;
    /** 创建时间 */
    private Date createTime;
    /** 支付时间 */
    private Date payTime;
    /** 取消时间 */
    private Date cancelTime;
    /** 是否已经发货 0、未发货 1、已发货 */
    private Integer sendProduct;
    /** 发货时间 */
    private Date sendProductTime;
    /** 发货备注 */
    private String sendRemark;
    /** 订单状态 0、待付款 1、待发货 2、待收货 3、交易完成 4、交易关闭 5、退款 6、取消 */
    private Integer orderStatus;

    /**商品类型 1 话费商品 2 流量商品 */
    private Integer goodsType;

    private List<WeOrderGoodsVO> orderGoodsVOList;

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getRemarkBody() {
        return remarkBody;
    }

    public void setRemarkBody(String remarkBody) {
        this.remarkBody = remarkBody;
    }



    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public BigDecimal getTotalFee() {
        return totalFee;
    }

    public void setTotalFee(BigDecimal totalFee) {
        this.totalFee = totalFee;
    }


    public BigDecimal getPayFee() {
        return payFee;
    }

    public void setPayFee(BigDecimal payFee) {
        this.payFee = payFee;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getPayTime() {
        return payTime;
    }

    public void setPayTime(Date payTime) {
        this.payTime = payTime;
    }

    public Date getCancelTime() {
        return cancelTime;
    }

    public void setCancelTime(Date cancelTime) {
        this.cancelTime = cancelTime;
    }

    public Integer getSendProduct() {
        return sendProduct;
    }

    public void setSendProduct(Integer sendProduct) {
        this.sendProduct = sendProduct;
    }

    public Date getSendProductTime() {
        return sendProductTime;
    }

    public void setSendProductTime(Date sendProductTime) {
        this.sendProductTime = sendProductTime;
    }

    public String getSendRemark() {
        return sendRemark;
    }

    public void setSendRemark(String sendRemark) {
        this.sendRemark = sendRemark;
    }


    public Integer getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(Integer orderStatus) {
        this.orderStatus = orderStatus;
    }

    public List<WeOrderGoodsVO> getOrderGoodsVOList() {
        return orderGoodsVOList;
    }

    public void setOrderGoodsVOList(List<WeOrderGoodsVO> orderGoodsVOList) {
        this.orderGoodsVOList = orderGoodsVOList;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getTradeType() {
        return tradeType;
    }

    public void setTradeType(String tradeType) {
        this.tradeType = tradeType;
    }

    public Integer getGoodsType() {
        return goodsType;
    }

    public void setGoodsType(Integer goodsType) {
        this.goodsType = goodsType;
    }
}
