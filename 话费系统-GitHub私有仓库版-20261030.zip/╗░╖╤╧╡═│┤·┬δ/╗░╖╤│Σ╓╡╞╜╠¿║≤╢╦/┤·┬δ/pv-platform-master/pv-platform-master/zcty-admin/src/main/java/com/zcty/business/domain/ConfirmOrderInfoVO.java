package com.zcty.business.domain;

import java.util.List;
/**
 * 确认订单信息
 * @Author: chushengkun
 * @Date: 2022/7/28 15:14
 */
public class ConfirmOrderInfoVO {


    /** 订单商品信息 */
    private List<WeOrderGoodsVO> weOrderGoodsVOList;

    /** 订单金额 */
    private String totalFee;

    public List<WeOrderGoodsVO> getWeOrderGoodsVOList() {
        return weOrderGoodsVOList;
    }

    public void setWeOrderGoodsVOList(List<WeOrderGoodsVO> weOrderGoodsVOList) {
        this.weOrderGoodsVOList = weOrderGoodsVOList;
    }

    public String getTotalFee() {
        return totalFee;
    }

    public void setTotalFee(String totalFee) {
        this.totalFee = totalFee;
    }
}
