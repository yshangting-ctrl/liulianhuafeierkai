package com.zcty.business.domain;

import java.math.BigDecimal;
import com.zcty.common.annotation.Excel;
import com.zcty.common.core.domain.BaseEntity;

/**
 * 第三方业务商品对象 t_activity_product
 * 
 * @author LSW
 * @date 2024-07-01
 */
public class ActivityProduct extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 主键id */
    private String id;

    /** 第三放平台归属 */
    @Excel(name = "第三放平台归属")
    private String platformInfosId;

    /** 业务id */
    @Excel(name = "业务id")
    private String activityid;

    /** 业务商品名城 */
    @Excel(name = "业务商品名城")
    private String activityName;

    /** 商品类型 1 话费商品 2 流量商品 */
    @Excel(name = "商品类型 1 话费商品 2 流量商品")
    private Integer category;

    /** 业务商品描述 */
    @Excel(name = "业务商品描述")
    private String activityDescribes;

    /** 省份 */
    @Excel(name = "省份")
    private Integer province;

    /** 平台关键字 */
    private String platformKey;

    private String provinceName;

    /** 城市 */
    @Excel(name = "城市")
    private Integer city;

    private String cityName;

    /** 办理限制次数 */
    @Excel(name = "办理限制次数")
    private Integer handlelimit;

    /** 短信接收次数 */
    @Excel(name = "短信接收次数")
    private Integer smscodenum;

    /** 需要额外支付话费 */
    @Excel(name = "需要额外支付话费")
    private BigDecimal paycost;

    /**  运营商  1 、移动 2、联通 3、电信 */
    @Excel(name = " 运营商  1 、移动 2、联通 3、电信")
    private Integer yys;

    public void setId(String id) 
    {
        this.id = id;
    }

    public String getId() 
    {
        return id;
    }
    public void setPlatformInfosId(String platformInfosId) 
    {
        this.platformInfosId = platformInfosId;
    }

    public String getPlatformInfosId() 
    {
        return platformInfosId;
    }
    public void setActivityid(String activityid) 
    {
        this.activityid = activityid;
    }

    public String getActivityid() 
    {
        return activityid;
    }
    public void setActivityName(String activityName) 
    {
        this.activityName = activityName;
    }

    public String getActivityName() 
    {
        return activityName;
    }
    public void setCategory(Integer category) 
    {
        this.category = category;
    }

    public Integer getCategory() 
    {
        return category;
    }
    public void setActivityDescribes(String activityDescribes) 
    {
        this.activityDescribes = activityDescribes;
    }

    public String getActivityDescribes() 
    {
        return activityDescribes;
    }
    public void setProvince(Integer province) 
    {
        this.province = province;
    }

    public Integer getProvince() 
    {
        return province;
    }
    public void setCity(Integer city) 
    {
        this.city = city;
    }

    public Integer getCity() 
    {
        return city;
    }
    public void setHandlelimit(Integer handlelimit) 
    {
        this.handlelimit = handlelimit;
    }

    public Integer getHandlelimit() 
    {
        return handlelimit;
    }
    public void setSmscodenum(Integer smscodenum) 
    {
        this.smscodenum = smscodenum;
    }

    public Integer getSmscodenum() 
    {
        return smscodenum;
    }
    public void setPaycost(BigDecimal paycost) 
    {
        this.paycost = paycost;
    }

    public BigDecimal getPaycost() 
    {
        return paycost;
    }
    public void setYys(Integer yys) 
    {
        this.yys = yys;
    }

    public Integer getYys() 
    {
        return yys;
    }

    public String getProvinceName() {
        return provinceName;
    }

    public void setProvinceName(String provinceName) {
        this.provinceName = provinceName;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getPlatformKey() {
        return platformKey;
    }

    public void setPlatformKey(String platformKey) {
        this.platformKey = platformKey;
    }

    @Override
    public String toString() {
        return "ActivityProduct{" +
                "id='" + id + '\'' +
                ", platformInfosId='" + platformInfosId + '\'' +
                ", activityid='" + activityid + '\'' +
                ", activityName='" + activityName + '\'' +
                ", category=" + category +
                ", activityDescribes='" + activityDescribes + '\'' +
                ", province=" + province +
                ", provinceName='" + provinceName + '\'' +
                ", city=" + city +
                ", cityName='" + cityName + '\'' +
                ", handlelimit=" + handlelimit +
                ", smscodenum=" + smscodenum +
                ", paycost=" + paycost +
                ", yys=" + yys +
                '}';
    }
}
