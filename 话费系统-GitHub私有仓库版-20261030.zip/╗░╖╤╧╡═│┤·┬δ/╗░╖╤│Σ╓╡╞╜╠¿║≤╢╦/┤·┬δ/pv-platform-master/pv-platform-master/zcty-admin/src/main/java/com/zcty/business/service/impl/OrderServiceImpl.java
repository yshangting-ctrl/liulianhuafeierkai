package com.zcty.business.service.impl;


import com.zcty.business.domain.*;
import com.zcty.business.mapper.OrderMapper;
import com.zcty.business.placeAnOrder.AbstractPlaceAnOrder;
import com.zcty.business.placeAnOrder.PlaceAnOrderGoodsBase;
import com.zcty.business.platformUtils.AbstractPlacePlatformBusiness;
import com.zcty.business.platformUtils.AbstractPlacePlatformEliuliang;
import com.zcty.business.platformUtils.AbstractPlacePlatformJipu;
import com.zcty.business.service.*;
import com.zcty.common.config.LuckqunxinConfig;
import com.zcty.common.config.ParamNameConfig;
import com.zcty.common.constant.OrderConstants;
import com.zcty.common.constant.PayConstants;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.core.text.Convert;
import com.zcty.common.enums.OrderStatusEnums;
import com.zcty.common.exception.base.BaseException;
import com.zcty.common.utils.StringUtils;
import com.zcty.pv.domain.WeChatUser;
import com.zcty.pv.service.IWeChatUserService;
import com.zcty.web.utlis.delay.AccessTokenDeLay;

import com.zcty.web.utlis.delay.DelayType;
import com.zcty.web.utlis.payInfo.PayInfoParam;
import com.zcty.web.utlis.payInfo.SendWePayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import javax.servlet.ServletContext;
import java.util.*;
import java.util.concurrent.DelayQueue;
/**
 * 订单 服务层实现
 * 
 * @author liuruibin
 * @date 2022-07-25
 */
@Service
public class OrderServiceImpl implements IOrderService
{
	@Autowired
	private OrderMapper orderMapper;

	@Autowired
	private PlaceAnOrderGoodsBase placeAnOrderGoodsBase;

    @Autowired
    private ServletContext servletContext;

    @Autowired
    private IWeChatUserService weChatUserService;
    @Autowired
    private IWechartPayInfoService wechartPayInfoService;

    @Autowired
    private IOrderDetailService orderDetailService;

    @Autowired
    private IProductService productService;
    @Autowired
    private IFlowProductService flowProductService;
    @Autowired
    private IActivityProductService activityProductService;
    @Autowired
    private IPlatformInfosService platformInfosService;

    @Autowired
    private AbstractPlacePlatformJipu abstractPlacePlatformJipu;

    @Autowired
    private AbstractPlacePlatformEliuliang abstractPlacePlatformEliuliang;

    @Autowired
    private IOrderSendProductService orderSendProductService;

	/**
     * 查询订单信息
     * 
     * @param orderId 订单ID
     * @return 订单信息
     */
    @Override
	public Order selectOrderById(String orderId)
	{
	    return orderMapper.selectOrderById(orderId);
	}

    /**
     * 查询订单详情
     *
     * @param orderId 订单ID
     * @return 订单信息
     */
    @Override
    public OrderInfoVO selectOrderInfoVOById(String orderId)
    {
        OrderInfoVO orderInfoVO = orderMapper.selectOrderInfoVOById(orderId);
        if (orderInfoVO != null && orderInfoVO.getOrderStatus() != null){
            orderInfoVO.setOrderStatus(OrderStatusEnums.getByStatus(orderInfoVO.getOrderStatus()));
        }
        return orderInfoVO;
    }

//    /**
//     * 获取确认订单信息
//     * @param params 参数
//     * @return	结果
//     */
//    @Override
//    public ConfirmOrderInfoVO getConfirmOrderInfoVO(Map<String, Object> params) {
//
//        String openId = String.valueOf(params.get(OrderConstants.OPEN_ID));
//
//        ConfirmOrderInfoVO confirmOrderInfoVO = new ConfirmOrderInfoVO();
//
//        List<WeOrderGoodsVO> weOrderGoodsVOList = new ArrayList<>();
//
//        if (params.containsKey(OrderConstants.ORDER_GOODS_ID) ){
//
//            String goodsId = String.valueOf(params.get(OrderConstants.ORDER_GOODS_ID));
//
//            WeGoodsCommonInfoVO weGoodsCommonInfoVO
//                    = goodsCommonService.weChatQuery(goodsId);
//
//            WeOrderGoodsVO weOrderGoodsVO = new WeOrderGoodsVO();
//
//            if (weGoodsCommonInfoVO == null
//                    || StringUtils.isEmpty(weGoodsCommonInfoVO.getCommonId())
//                    || StringUtils.isEmpty(weGoodsCommonInfoVO.getGoodsBaseVOList())){
//                throw new BaseException("商品已下架！");
//            }
//
//            weOrderGoodsVO.setGoodsId(goodsId);
//            weOrderGoodsVO.setCommonName(weGoodsCommonInfoVO.getCommonName());
//            weOrderGoodsVO.setCommonDes(weGoodsCommonInfoVO.getCommonDes());
//            weOrderGoodsVO.setGoodsPic(weGoodsCommonInfoVO.getGoodsBaseVOList().get(0).getGoodsPic());
//            weOrderGoodsVO.setGoodsPrice(weGoodsCommonInfoVO.getGoodsBaseVOList().get(0).getGoodsRetailPrice());
//            weOrderGoodsVO.setGoodsSpec(weGoodsCommonInfoVO.getGoodsBaseVOList().get(0).getGoodsSpec());
//            weOrderGoodsVO.setGoodsNum(Integer.parseInt(String.valueOf(params.get(OrderConstants.ORDER_NUM))));
//            weOrderGoodsVOList.add(weOrderGoodsVO);
//        }
//
//
//
//        confirmOrderInfoVO.setWeOrderGoodsVOList(weOrderGoodsVOList);
//
//        BigDecimal totalFee = BigDecimal.ZERO;
//        for (WeOrderGoodsVO weOrderGoodsVO : weOrderGoodsVOList) {
//            totalFee = totalFee.add(
//                    weOrderGoodsVO.getGoodsPrice().multiply(
//                            new BigDecimal(weOrderGoodsVO.getGoodsNum())));
//        }
//        confirmOrderInfoVO.setTotalFee(totalFee.toString());
//
//        return confirmOrderInfoVO;
//    }

    /**
	 * 查询订单信息
	 *
	 * @param orderNo 订单编号
	 * @return 订单信息
	 */
	@Override
	public Order selectOrderByNo(String orderNo) {
		return orderMapper.selectOrderByNo(orderNo);
	}

    /**
     * 查询订单列表信息 待付款、待收货
     * @return
     */
    @Override
    public List<Order> selectOrderList() {
        return orderMapper.selectOrderListByStatus();
    }

    /**
	 * 查询订单信息
	 *
	 * @param orderId 订单ID
	 * @return 订单信息
	 */
	@Override
	public AjaxResult selectWeOrderInfoVOById(String orderId, String openId) {
		if (StringUtils.isEmpty(orderId)){
			return AjaxResult.error("请选择订单！");
		}
		WeOrderInfoVO weOrderInfoVO = orderMapper.selectWeOrderInfoVOById(orderId, openId);
		if (weOrderInfoVO == null){
			return AjaxResult.error("订单数据异常，请刷新重试！");
		}
		return AjaxResult.success("data", weOrderInfoVO);
	}

	/**
     * 查询订单列表
     * 
     * @param order 订单信息
     * @return 订单集合
     */
	@Override
	public List<OrderVO> selectOrderList(Order order)
	{
	    List<OrderVO> orderVOList = orderMapper.selectOrderList(order);
	    orderVOList.forEach(orderVO -> {
	        String status = orderVO.getOrderStatus();
            orderVO.setOrderStatus(OrderStatusEnums.getByStatus(status));
	    });
	    return orderVOList;
	}

    /**
     * 查询待发货订单列表
     *
     * @param order 筛选条件
     * @return 订单集合
     */
    @Override
    public List<OrderVO> selectOrderListByToBeDelivered(Order order) {
        List<OrderVO> orderVOList = orderMapper.selectOrderShippedList(order);
        orderVOList.forEach(orderVO ->
                orderVO.setOrderStatus(
                        OrderStatusEnums.getByStatus(orderVO.getOrderStatus())));
        return orderVOList;
    }

    /**
	 * 查询订单列表
	 *
	 * @param params 赛选条件
	 * @return 订单集合
	 */
	@Override
	public List<WeOrderVO> selectWeOrderVOList(Map<String, Object> params) {
		return orderMapper.selectWeOrderVOList(params);
	}

	/**
     * 新增订单
     * 
     * @param order 订单信息
     * @return 结果
     */
	@Override
	public int insertOrder(Order order)
	{
	    return orderMapper.insertOrder(order);
	}
	
	/**
     * 修改订单
     * 
     * @param order 订单信息
     * @return 结果
     */
	@Override
	public int updateOrder(Order order)
	{
	    return orderMapper.updateOrder(order);
	}

	/**
     * 删除订单对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteOrderByIds(String ids)
	{
		return orderMapper.deleteOrderByIds(Convert.toStrArray(ids));
	}


	/**
	 * 立即购买
	 * @param weOrderDTO 订单信息
	 * @return 结果
	 */
    @Transactional(rollbackFor = Exception.class)
	@Override
	public AjaxResult buyNow(WeOrderDTO weOrderDTO) {
		AbstractPlaceAnOrder placeAnOrder = placeAnOrderGoodsBase;
		return createOrder(placeAnOrder, weOrderDTO);
	}

	/**
	 * 取消订单接口
     * TODO 接口可以优化 参数orderId换成OrderNo
	 * @param orderId 订单ID
	 * @param openId 微信用户ID
	 * @return 结果
	 */
	@Transactional(rollbackFor = Exception.class)
	@Override
	public AjaxResult cancelOrder(String orderId, String openId) {

        WeChatUser weChatUser = weChatUserService.selectWeChatUserByOpenId(openId);

        if(weChatUser==null){
            return AjaxResult.error("未找到用户信息，请刷新重试");
        }
//        String supplierId = weChatUser.getSupplierId();

        PayInfoParam payInfoParam = new PayInfoParam();

	    Map<String, Object> params = getParams(orderId, openId);

        String orderNo = params.get(OrderConstants.ORDER_NO).toString();
        synchronized (orderNo.intern()){

            params = getParams(orderId, openId);
            Date nowDate = new Date();
            params.put(OrderConstants.ORDER_STATUS, OrderConstants.ORDER_STATUS_CANCEL);
            params.put(OrderConstants.CANCEL_TIME, nowDate);
            params.put(OrderConstants.UPDATE_TIME, nowDate);

            if (!checkOrderStatusByCancelOrPay(orderId)){
                return AjaxResult.error("当前订单不可以取消！");
            }

            Map<String, String> map = SendWePayUtils.checkTransactions(orderNo,payInfoParam);

            if (
                (map.containsKey(LuckqunxinConfig.RESULT_CODE)
                    && ("500".equals(map.get(LuckqunxinConfig.RESULT_CODE))
                        || !"200".equals(map.get(LuckqunxinConfig.RESULT_CODE))))
                ||
                (map.containsKey(PayConstants.PAY_NOTIFY_TRADE_STATE)
                    && !OrderConstants.PAY_STATUS_NOT_PAY.equals(map.get(PayConstants.PAY_NOTIFY_TRADE_STATE)))){
                return AjaxResult.error(orderNo + "订单不可以取消，请联系管理员！");
            }

            if (casUpdateOrderStatus(params)){
                WeOrderInfoVO weOrderInfoVO = orderMapper.selectWeOrderInfoVOById(orderId, openId);

                return AjaxResult.success();
            }

        }
        return AjaxResult.error();
	}

	/**
	 * 订单确认收货接口
     * TODO 接口可以优化 参数orderId换成OrderNo
	 * @param orderId 订单ID
	 * @param openId 微信用户ID
	 * @return 结果
	 */
	@Transactional(rollbackFor = Exception.class)
	@Override
	public AjaxResult confirmOrder(String orderId, String openId) {

        Map<String, Object> params = getParams(orderId, openId);
        String orderNo = params.get(OrderConstants.ORDER_NO).toString();

        synchronized (orderNo.intern()) {

            params = getParams(orderId, openId);
            Date nowDate = new Date();
            params.put(OrderConstants.ORDER_STATUS, OrderConstants.ORDER_STATUS_RECEIPT);
            params.put(OrderConstants.CONFIRM_TIME, nowDate);
            params.put(OrderConstants.UPDATE_TIME, nowDate);

            if (!checkOrderStatusByConfirm(orderId)) {
                return AjaxResult.error("当前订单不可以确认收货！");
            }

            if (casUpdateOrderStatus(params)) {
                addDelay(orderNo, nowDate.getTime() + OrderConstants.ORDER_AUTO_COMPLETE_TIME, DelayType.ORDER_RECEIPT);
                return AjaxResult.success();
            }
        }
		return AjaxResult.error();
	}

    /**
     * 订单交易完成
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public AjaxResult completeOrder(String orderNo) {
        synchronized (orderNo.intern()) {
            Order order = selectOrderByNo(orderNo);
            if (StringUtils.isEmpty(order.getOrderId())){
                throw new BaseException("数据异常！");
            }
            if (!OrderConstants.ORDER_STATUS_RECEIPT.equals(order.getOrderStatus())){
                throw new BaseException("当前订单不可执行交易完成！[" +order.toString()+ "]");
            }
            Map<String, Object> params = new HashMap<>();
            params.put(OrderConstants.OPEN_ID, order.getOpenId());
            params.put(OrderConstants.ORDER_ID, order.getOrderId());
            params.put(OrderConstants.ORDER_NO, order.getOrderNo());
            params.put(OrderConstants.SYS_VERSION_STR, order.getSysVersion());
            params.put(OrderConstants.ORDER_STATUS, OrderConstants.ORDER_STATUS_TRANSACTION_COMPLETE);
            params.put(OrderConstants.UPDATE_TIME, new Date());
            if (casUpdateOrderStatus(params)) {
                return AjaxResult.success();
            }
        }
        return AjaxResult.error();
    }

    /**
	 * 去支付，调用微信支付下单接口，并返回小程序唤起支付参数
     * TODO 接口可以优化 参数orderId换成OrderNo
	 * @param orderId	订单ID
	 * @param openId	微信用户ID
	 * @return	结果
	 */
	@Override
	public AjaxResult toPay(String orderId, String openId) {
        //防止异常订单支付，校验订单与用户信息是否一致
		WeOrderInfoVO weOrderInfoVO = orderMapper.selectWeOrderInfoVOById(orderId, openId);
		if(weOrderInfoVO==null){
		    return AjaxResult.error("订单不存在，或订单与用户信息不匹配");
        }
		String orderNo = weOrderInfoVO.getOrderNo();
        synchronized (orderNo.intern()) {

            weOrderInfoVO = orderMapper.selectWeOrderInfoVOById(orderId, openId);

            WeChatUser weChatUser = weChatUserService.selectWeChatUserByOpenId(openId);
            if(weChatUser==null){
                return AjaxResult.error("未找到用户信息，晴刷新重试");
            }


            WechartPayInfo wechartPayInfo = wechartPayInfoService.selectWechartPayInfoSupplierId(weChatUser.getSupplierId());
            if(wechartPayInfo == null){
                return AjaxResult.error("未设置支付信息，请联系管理员");
            }

            PayInfoParam payInfoParam = new PayInfoParam();

            payInfoParam.setWeixinAppId(wechartPayInfo.getWeixinAppId());
            payInfoParam.setMchid(wechartPayInfo.getMchid());
            payInfoParam.setPrivateKeyPath(LuckqunxinConfig.PayFile+wechartPayInfo.getPrivateKeyPath());
            payInfoParam.setPublicKeyPath(LuckqunxinConfig.PayFile+wechartPayInfo.getPublicKeyPath());
            payInfoParam.setSerialNo(wechartPayInfo.getSerialNo());
            payInfoParam.setPartnerKey(wechartPayInfo.getPartnerKey());
            payInfoParam.setSupplierId(wechartPayInfo.getSupplierId());


            Map<String, String> result = toTransactions(
                    weOrderInfoVO.getRemarkBody(),
                    weOrderInfoVO.getOrderNo(),
                    String.valueOf(weOrderInfoVO.getPayFee()),
                    openId,payInfoParam);

            if (result.containsKey(LuckqunxinConfig.RESULT_CODE)){
                return AjaxResult.error(
                        Integer.parseInt(result.get(LuckqunxinConfig.RESULT_CODE)),
                        result.get(LuckqunxinConfig.RESULT_MSG));
            }
            //公众号appid
            result.put("appId",wechartPayInfo.getWeixinAppId());
            return AjaxResult.success("data", result);
        }
	}

    /**
     * 添加订单延迟队列
     * @param orderNo
     * @param startTime
     * @param delayType
     */
	private void addDelay(String orderNo, long startTime, Integer delayType){
        DelayQueue<AccessTokenDeLay> accessTokenDeLays = (DelayQueue<AccessTokenDeLay>) servletContext.getAttribute(ParamNameConfig.DELAY_ORDER);
        if (accessTokenDeLays != null){
            AccessTokenDeLay accessTokenDeLay = new AccessTokenDeLay();
            accessTokenDeLay.setAccessTokenName(orderNo);
            accessTokenDeLay.setTimeStart(startTime);
            accessTokenDeLay.setDelayType(delayType);
            System.out.println("添加任务到订单延迟队列：[" + accessTokenDeLay+"]");
            accessTokenDeLays.add(accessTokenDeLay);
        }
    }

	/**
	 * 订单支付回调更改订单状态
	 * @param order	订单信息
	 * @return	结果
	 */
	@Override
	public int updateOrderByPay(Order order) {
		return orderMapper.updateOrderByPay(order);
	}

    /**
     * 删除订单
     * @param orderNo 订单编号
     * @param openId 微信用户ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public AjaxResult remove(String orderNo, String openId) {
        synchronized (orderNo.intern()){
            Order order = orderMapper.selectOrderByNo(orderNo);
            if (!openId.equals(order.getOpenId())){
                return AjaxResult.error("数据异常，请刷新重试！");
            }
            if (!OrderConstants.ORDER_STATUS_CANCEL.equals(order.getOrderStatus())){
                return AjaxResult.error("当前订单不可删除！");
            }
            Map<String, Object> params = new HashMap<>();
            params.put(OrderConstants.OPEN_ID, openId);
            params.put(OrderConstants.ORDER_ID, order.getOrderId());
            params.put(OrderConstants.ORDER_NO, orderNo);
            params.put(OrderConstants.CHECK_DELETE, OrderConstants.CHECK_DELETE_TRUE);
            params.put(OrderConstants.UPDATE_TIME, new Date());
            params.put(OrderConstants.SYS_VERSION_STR, order.getSysVersion());
            if (casUpdateOrderStatus(params)){
                return AjaxResult.success();
            }
            return AjaxResult.error();
        }
    }

    /**
     * 订单统计
     * @param openId 微信用户ID
     * @return
     */
    @Override
    public AjaxResult selectOrderCountByStatus(String openId) {
        return AjaxResult.success("data", orderMapper.selectOrderCountByStatus(openId));
    }

    /**
     * 编辑订单发货信息 -- 订单编号、快递单号、快递备注
     */
    @Transactional
    @Override
    public AjaxResult editOrderSend(OrderShippedInfo orderShippedInfo) {
        String orderNo = orderShippedInfo.getOrderNo();
        synchronized (orderNo.intern()){
            // 获取订单信息
            Order order = orderMapper.selectOrderByNo(orderNo);
            if (order == null){
                System.out.println("订单[" + orderNo + "]不存在！");
                return AjaxResult.error("订单[" + orderNo + "]不存在！");
            }
            if (!OrderConstants.ORDER_STATUS_TO_BE_DELIVERED.equals(order.getOrderStatus())){
                System.out.println("订单[" + orderNo + "]不可设置发货信息！");
                return AjaxResult.error("订单[" + orderNo + "]不可设置发货信息！");
            }
            Date nowDate = new Date();
            order.setSendRemark(orderShippedInfo.getSendRemark());
            order.setSendProduct(1);
            order.setSendProductTime(nowDate);
            order.setOrderStatus(OrderConstants.ORDER_STATUS_PENDING_RECEIPT);
            order.setUpdateTime(nowDate);

            if (orderMapper.editOrderSend(order) > 0){
                addDelay(orderNo, nowDate.getTime() + OrderConstants.ORDER_AUTO_CONFIRM_TIME, DelayType.ORDER_CONFIRM);
                return AjaxResult.success();
            }
            return AjaxResult.error();
        }
    }

    /**
     * 获取订单发信息
     * @param orderNo
     * @return
     */
    @Override
    public AjaxResult queryOrderShippedInfo(String orderNo) {
        if (StringUtils.isEmpty(orderNo)){
            return AjaxResult.error("请选择订单！");
        }
        OrderShippedInfoVO orderShippedInfoVO = orderMapper.queryOrderShippedInfo(orderNo);
        if (orderShippedInfoVO == null){
            return AjaxResult.error("订单[" +orderNo+ "]未发货");
        }
        return AjaxResult.success("data", orderShippedInfoVO);
    }

    private boolean checkOrderStatusByCancelOrPay(String orderId){
	    return orderMapper.checkOrderStatusByCancelOrPay(orderId) > 0;
    }

    private boolean checkOrderStatusByConfirm(String orderId){
        return orderMapper.checkOrderStatusByConfirm(orderId) > 0;
    }

    /**
     * 封装更新订单状态参数
     * @param orderId   订单ID
     * @param openId    微信用户ID
     * @return  结果
     */
	private Map<String, Object> getParams(String orderId, String openId){

        Map<String, Object> params = new HashMap<>();
        Order order = orderMapper.selectOrderById(orderId);
        if (!openId.equals(order.getOpenId())){
            throw new BaseException("数据异常，请刷新重试！");
        }
        params.put(OrderConstants.OPEN_ID, openId);
        params.put(OrderConstants.ORDER_ID, orderId);
        params.put(OrderConstants.ORDER_NO, order.getOrderNo());
        params.put(OrderConstants.SYS_VERSION_STR, order.getSysVersion());

        return params;
    }

    /**
     * 更新订单状态
     * @param params    参数 updateTime orderId openId sysVersion
     * @return  结果
     */
    @Override
	public boolean casUpdateOrderStatus(Map<String, Object> params){
        if (!params.containsKey(OrderConstants.ORDER_ID)){
            throw new BaseException(OrderConstants.ORDER_ID + "参数不能为空");
        }
        if (!params.containsKey(OrderConstants.OPEN_ID)){
            throw new BaseException(OrderConstants.OPEN_ID + "参数不能为空");
        }
        if (!params.containsKey(OrderConstants.SYS_VERSION_STR)){
            throw new BaseException(OrderConstants.SYS_VERSION_STR + "参数不能为空");
        }
        if (!params.containsKey(OrderConstants.UPDATE_TIME)){
            throw new BaseException(OrderConstants.UPDATE_TIME + "参数不能为空");
        }
	    return orderMapper.updateOrderStatus(params) > 0;
    }

    /**
     * 更新订单状态
     * @param params    参数
     * @return  结果
     */
	private boolean synUpdateOrderStatus(Map<String, Object> params){
	    String orderNo = String.valueOf(params.get("orderNo"));
	    synchronized (orderNo.intern()){
            return casUpdateOrderStatus(params);
        }
	}

	/**
	 * 创建订单，并创建微信支付订单
	 * @param placeAnOrder	创建订单方式
	 * @param weOrderDTO	订单信息
	 * @return	结果
	 */
	private AjaxResult createOrder(AbstractPlaceAnOrder placeAnOrder, WeOrderDTO weOrderDTO){
		Map<String, Object> objectMap = placeAnOrder.placeAnOrder(weOrderDTO);

		if ((boolean) objectMap.get(OrderConstants.CREATE_ORDER_FLAG)){

			Order order = (Order) objectMap.get(OrderConstants.CREATE_ORDER_INFO);

            addDelay(order.getOrderNo(), order.getCreateTime().getTime() + OrderConstants.ORDER_AUTO_CANCEL_TIME, DelayType.ORDER_CANCEL);
            System.out.println("本地订单信息：" + order.toString());
			return AjaxResult.success("data", order.getOrderId());
		}
		return AjaxResult.error("下单失败！");
	}

	/**
	 * 调用微信支付下单接口
	 */
	private Map<String, String> toTransactions(String desc, String orderNo, String payFee, String openId ,PayInfoParam payInfoParam ){

		Map<String,String> param = new HashMap<>();
		param.put(LuckqunxinConfig.PARAM_DESCRIPTION, desc);
		param.put(LuckqunxinConfig.PARAM_OUT_TRADE_NO, orderNo);
		param.put(LuckqunxinConfig.PARAM_TOTAL, payFee);
		param.put(LuckqunxinConfig.PARAM_OPEN_ID, openId);
        System.out.println("开始创建微信订单：" + param.toString());
		return SendWePayUtils.transactions(param,payInfoParam);
	}


    /**
     * 发送请求获取业务办理验证码
     * @param orderNo
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public synchronized AjaxResult sendFirstSmsCode(String orderNo, String openId) {

        synchronized (orderNo.intern()){
            // 获取订单信息
            Order order = orderMapper.selectOrderByNo(orderNo);
            if (order == null){
                System.out.println("订单[" + orderNo + "]不存在！");
                return AjaxResult.error("订单[" + orderNo + "]不存在！");
            }
            if (!OrderConstants.ORDER_STATUS_TO_BE_DELIVERED.equals(order.getOrderStatus())){
                System.out.println("订单[" + orderNo + "]不可设置充值信息！");
                return AjaxResult.error("订单[" + orderNo + "]不可设置充值信息！");
            }
            String phone = order.getPhone();
            if(StringUtils.isEmpty(phone)){
                System.out.println("订单未找到手机号码信息");
                return AjaxResult.error("订单未找到手机号码信息");
            }
            if(!openId.equals(order.getOpenId())){
                return AjaxResult.error("订单与用户信息不匹配！");
            }
            String third_order_no = orderNo;

            Date nowDate = new Date();
            order.setSendProduct(1);
            order.setSendProductTime(nowDate);
            order.setOrderStatus(OrderConstants.ORDER_STATUS_PENDING_RECEIPT);
            order.setUpdateTime(nowDate);


            OrderDetail orderDetail = new OrderDetail();
            orderDetail.setOrderId(order.getOrderId());
            List<OrderDetail> list = orderDetailService.selectOrderDetailList(orderDetail);
            //按照订单详情进行发货
            for(OrderDetail o:list){

                String productId = o.getGoodsId();
                Integer goodsType = o.getGoodsType();

                String activityProductId = null;
                if(goodsType.equals(1)){
                    //话费商品
                    Product product = productService.selectProductById(productId);
                    if(product == null ){
                        System.out.println("订单异常，未找到商品信息");
                        return AjaxResult.error("订单异常，未找到商品信息");
                    }
                    activityProductId = product.getActivityProductId();
                }else {
                    //流量商品
                    FlowProduct flowProduct =  flowProductService.selectFlowProductById(productId);
                    if(flowProduct == null ){
                        System.out.println("订单异常，未找到商品信息");
                        return AjaxResult.error("订单异常，未找到商品信息");
                    }
                    activityProductId = flowProduct.getActivityProductId();
                }

                if(StringUtils.isEmpty(activityProductId)){
                    System.out.println("订单异常，未找到充值商品id信息");
                    return AjaxResult.error("订单异常，未找到充值商品id信息");
                }

                ActivityProduct activityProduct = activityProductService.selectActivityProductById(activityProductId);
                if(activityProduct == null){
                    System.out.println("订单异常，未找到充值商品信息");
                    return AjaxResult.error("订单异常，未找到充值商品信息");
                }
                PlatformInfos platformInfos = platformInfosService.selectPlatformInfosById(activityProduct.getPlatformInfosId());
                if(platformInfos == null){
                    System.out.println("订单异常，未找到充值商品平台信息，请联系管理员");
                    return AjaxResult.error("订单异常，未找到充值商品平台信息，请联系管理员");
                }

                String platformKey  = platformInfos.getPlatformKey();
                if(StringUtils.isEmpty(platformKey)){
                    System.out.println("未找到平台关键字");
                    return AjaxResult.error("未找到平台关键字");
                }


                AbstractPlacePlatformBusiness abstractPlacePlatformBusiness = null;

                if(platformKey.equals("jipu")){
                    abstractPlacePlatformBusiness = abstractPlacePlatformJipu;
                }else if(platformKey.equals("eliuliang")){
                    abstractPlacePlatformBusiness = abstractPlacePlatformEliuliang;
                }else {
                    System.out.println("未匹配到平台接口信息");
                    return AjaxResult.error("未匹配到平台接口信息");
                }
                //发送短信验证码，并写入业务信息
                abstractPlacePlatformBusiness.sendFirstSmsCode(activityProductId,phone,"",third_order_no,order);
            }

            return AjaxResult.success();
        }
    }

    @Override
    public AjaxResult submitFirstSmsCode(String orderNo, String smsCode, String openId) {

        synchronized (orderNo.intern()){
            // 获取订单信息
            Order order = orderMapper.selectOrderByNo(orderNo);
            if (order == null){
                System.out.println("订单[" + orderNo + "]不存在！");
                return AjaxResult.error("订单[" + orderNo + "]不存在！");
            }
            if (!OrderConstants.ORDER_STATUS_PENDING_RECEIPT.equals(order.getOrderStatus())){
                System.out.println("订单[" + orderNo + "]不可设置提交验证码信息！");
                return AjaxResult.error("订单[" + orderNo + "]不可设置提交验证码信息！");
            }
            String phone = order.getPhone();
            if(StringUtils.isEmpty(phone)){
                System.out.println("订单未找到手机号码信息");
                return AjaxResult.error("订单未找到手机号码信息");
            }
            if(!openId.equals(order.getOrderId())){
                return AjaxResult.error("订单与用户信息不匹配！");
            }
            String third_order_no = orderNo;

            Date nowDate = new Date();
            order.setSendProduct(1);
            order.setSendProductTime(nowDate);
            order.setOrderStatus(OrderConstants.ORDER_STATUS_RECEIPT);
            order.setUpdateTime(nowDate);
            //发送到这个验证码就代表可以进行了发货
            int sendResult =  orderMapper.editOrderSend(order);

            //查询订单发货表
            OrderSendProduct orderSendProduct = orderSendProductService.selectOrderSendProductByParentOrderNo(third_order_no);
            if(orderSendProduct==null){
                return AjaxResult.error("未找到验证码信息");
            }

            String activityid = orderSendProduct.getActivityid();

            ActivityProduct activityProduct = activityProductService.selectActivityProductById(activityid);

            if(activityProduct == null ){
                return AjaxResult.error("未找到充值商品业务信息");
            }

            PlatformInfos platformInfos = platformInfosService.selectPlatformInfosById(activityProduct.getPlatformInfosId());
            if(platformInfos == null){
                System.out.println("订单异常，未找到充值商品平台信息，请联系管理员");
                return AjaxResult.error("订单异常，未找到充值商品平台信息，请联系管理员");
            }

            String platformKey  = platformInfos.getPlatformKey();
            if(StringUtils.isEmpty(platformKey)){
                System.out.println("未找到平台关键字");
                return AjaxResult.error("未找到平台关键字");
            }

            AbstractPlacePlatformBusiness abstractPlacePlatformBusiness = null;

            if(platformKey.equals("jipu")){
                abstractPlacePlatformBusiness = abstractPlacePlatformJipu;
            }else if(platformKey.equals("eliuliang")){
                abstractPlacePlatformBusiness = abstractPlacePlatformEliuliang;
            }else {
                System.out.println("未匹配到平台接口信息");
                return AjaxResult.error("未匹配到平台接口信息");
            }

            //发送短信验证码，并写入业务信息
            abstractPlacePlatformBusiness.submitFirstSmsCode(platformInfos,orderSendProduct,  activityProduct ,smsCode,phone,third_order_no,order);

            return AjaxResult.success();
        }
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public AjaxResult sendPreSmsCode(String orderNo, String openId) {
        synchronized (orderNo.intern()){
            // 获取订单信息
            Order order = orderMapper.selectOrderByNo(orderNo);
            if (order == null){
                System.out.println("订单[" + orderNo + "]不存在！");
                return AjaxResult.error("订单[" + orderNo + "]不存在！");
            }
            if (!OrderConstants.ORDER_STATUS_TO_BE_DELIVERED.equals(order.getOrderStatus())){
                System.out.println("订单[" + orderNo + "]不可设置充值前置码信息！");
                return AjaxResult.error("订单[" + orderNo + "]不可设置充值前置码信息！");
            }
            String phone = order.getPhone();
            if(StringUtils.isEmpty(phone)){
                System.out.println("订单未找到手机号码信息");
                return AjaxResult.error("订单未找到手机号码信息");
            }
            if(!openId.equals(order.getOpenId())){
                return AjaxResult.error("订单与用户信息不匹配！");
            }
            String third_order_no = orderNo;

//            Date nowDate = new Date();
//            order.setSendProduct(1);
//            order.setSendProductTime(nowDate);
//            order.setOrderStatus(OrderConstants.ORDER_STATUS_PENDING_RECEIPT);
//            order.setUpdateTime(nowDate);


            OrderDetail orderDetail = new OrderDetail();
            orderDetail.setOrderId(order.getOrderId());
            List<OrderDetail> list = orderDetailService.selectOrderDetailList(orderDetail);
            //按照订单详情进行发货
            for(OrderDetail o:list){

                String productId = o.getGoodsId();
                Integer goodsType = o.getGoodsType();

                String activityProductId = null;
                if(goodsType.equals(1)){
                    //话费商品
                    Product product = productService.selectProductById(productId);
                    if(product == null ){
                        System.out.println("订单异常，未找到商品信息");
                        return AjaxResult.error("订单异常，未找到商品信息");
                    }
                    activityProductId = product.getActivityProductId();
                }else {
                    //流量商品
                    FlowProduct flowProduct =  flowProductService.selectFlowProductById(productId);
                    if(flowProduct == null ){
                        System.out.println("订单异常，未找到商品信息");
                        return AjaxResult.error("订单异常，未找到商品信息");
                    }
                    activityProductId = flowProduct.getActivityProductId();
                }

                if(StringUtils.isEmpty(activityProductId)){
                    System.out.println("订单异常，未找到充值商品id信息");
                    return AjaxResult.error("订单异常，未找到充值商品id信息");
                }

                ActivityProduct activityProduct = activityProductService.selectActivityProductById(activityProductId);
                if(activityProduct == null){
                    System.out.println("订单异常，未找到充值商品信息");
                    return AjaxResult.error("订单异常，未找到充值商品信息");
                }
                PlatformInfos platformInfos = platformInfosService.selectPlatformInfosById(activityProduct.getPlatformInfosId());
                if(platformInfos == null){
                    System.out.println("订单异常，未找到充值商品平台信息，请联系管理员");
                    return AjaxResult.error("订单异常，未找到充值商品平台信息，请联系管理员");
                }

                String platformKey  = platformInfos.getPlatformKey();
                if(StringUtils.isEmpty(platformKey)){
                    System.out.println("未找到平台关键字");
                    return AjaxResult.error("未找到平台关键字");
                }


                AbstractPlacePlatformBusiness abstractPlacePlatformBusiness = null;

                if(platformKey.equals("jipu")){
                    abstractPlacePlatformBusiness = abstractPlacePlatformJipu;
                }else if(platformKey.equals("eliuliang")){
                    abstractPlacePlatformBusiness = abstractPlacePlatformEliuliang;
                }else {
                    System.out.println("未匹配到平台接口信息");
                    return AjaxResult.error("未匹配到平台接口信息");
                }
                //发送短信验证码，并写入业务信息
                abstractPlacePlatformBusiness.getPreSmsCode(activityProductId,phone,"",third_order_no,order);
            }

            return AjaxResult.success();
        }
    }

    @Override
    public AjaxResult submitPreSmsCode(String orderNo, String smsCode, String openId) {
        synchronized (orderNo.intern()){
            // 获取订单信息
            Order order = orderMapper.selectOrderByNo(orderNo);
            if (order == null){
                System.out.println("订单[" + orderNo + "]不存在！");
                return AjaxResult.error("订单[" + orderNo + "]不存在！");
            }
            if (!OrderConstants.ORDER_STATUS_PENDING_RECEIPT.equals(order.getOrderStatus())){
                System.out.println("订单[" + orderNo + "]不可设置提交验证码信息！");
                return AjaxResult.error("订单[" + orderNo + "]不可设置提交验证码信息！");
            }
            String phone = order.getPhone();
            if(StringUtils.isEmpty(phone)){
                System.out.println("订单未找到手机号码信息");
                return AjaxResult.error("订单未找到手机号码信息");
            }
            if(!openId.equals(order.getOrderId())){
                return AjaxResult.error("订单与用户信息不匹配！");
            }
            String third_order_no = orderNo;

//            Date nowDate = new Date();
//            order.setSendProduct(1);
//            order.setSendProductTime(nowDate);
//            order.setOrderStatus(OrderConstants.ORDER_STATUS_RECEIPT);
//            order.setUpdateTime(nowDate);
//            //发送到这个验证码就代表可以进行了发货
//            int sendResult =  orderMapper.editOrderSend(order);

            //查询订单发货表
            OrderSendProduct orderSendProduct = orderSendProductService.selectOrderSendProductByParentOrderNo(third_order_no);
            if(orderSendProduct==null){
                return AjaxResult.error("未找到验证码信息");
            }

            String activityid = orderSendProduct.getActivityid();

            ActivityProduct activityProduct = activityProductService.selectActivityProductById(activityid);

            if(activityProduct == null ){
                return AjaxResult.error("未找到充值商品业务信息");
            }

            PlatformInfos platformInfos = platformInfosService.selectPlatformInfosById(activityProduct.getPlatformInfosId());
            if(platformInfos == null){
                System.out.println("订单异常，未找到充值商品平台信息，请联系管理员");
                return AjaxResult.error("订单异常，未找到充值商品平台信息，请联系管理员");
            }

            String platformKey  = platformInfos.getPlatformKey();
            if(StringUtils.isEmpty(platformKey)){
                System.out.println("未找到平台关键字");
                return AjaxResult.error("未找到平台关键字");
            }

            AbstractPlacePlatformBusiness abstractPlacePlatformBusiness = null;

            if(platformKey.equals("jipu")){
                abstractPlacePlatformBusiness = abstractPlacePlatformJipu;
            }else if(platformKey.equals("eliuliang")){
                abstractPlacePlatformBusiness = abstractPlacePlatformEliuliang;
            }else {
                System.out.println("未匹配到平台接口信息");
                return AjaxResult.error("未匹配到平台接口信息");
            }

            //发送短信验证码，并写入业务信息
            abstractPlacePlatformBusiness.submitPreSmsCode(platformInfos,orderSendProduct,  activityProduct ,smsCode,phone,third_order_no,order);

            return AjaxResult.success();
        }
    }
}
