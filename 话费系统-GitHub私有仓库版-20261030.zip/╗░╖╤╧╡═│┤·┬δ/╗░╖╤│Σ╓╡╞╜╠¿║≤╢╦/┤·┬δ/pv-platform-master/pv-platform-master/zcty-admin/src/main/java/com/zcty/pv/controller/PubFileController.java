package com.zcty.pv.controller;

import com.zcty.common.annotation.Log;
import com.zcty.common.config.LuckqunxinConfig;
import com.zcty.common.config.RuoYiConfig;
import com.zcty.common.constant.Constants;
import com.zcty.common.core.controller.BaseController;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.core.page.TableDataInfo;
import com.zcty.common.enums.BusinessType;
import com.zcty.common.utils.StringUtils;
import com.zcty.common.utils.file.FileUploadUtils;
import com.zcty.common.utils.file.FileUtils;
import com.zcty.common.utils.poi.ExcelUtil;
import com.zcty.pv.domain.PubFile;
import com.zcty.pv.service.IPubFileService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * 通用文件Controller
 * 
 * @author luohui
 * @date 2022-11-20
 */
@Api(tags = "文件管理")
@RestController
@RequestMapping("/pv/pubfile")
public class PubFileController extends BaseController
{
    @Autowired
    private IPubFileService pubFileService;

    /**
     * 查询通用文件列表
     */
    @ApiOperation("查询通用文件列表")
//    @PreAuthorize("@ss.hasPermi('pv:pubfile:list')")
    @GetMapping("/list")
    public TableDataInfo list(PubFile pubFile)
    {
        startPage();
        List<PubFile> list = pubFileService.selectPubFileList(pubFile);
        return getDataTable(list);
    }

    /**
     * 导出通用文件列表
     */
    @ApiOperation("导出通用文件列表")
//    @PreAuthorize("@ss.hasPermi('pv:pubfile:export')")
    @Log(title = "通用文件", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, PubFile pubFile)
    {
        List<PubFile> list = pubFileService.selectPubFileList(pubFile);
        ExcelUtil<PubFile> util = new ExcelUtil<PubFile>(PubFile.class);
        util.exportExcel(response, list, "通用文件数据");
    }

    /**
     * 获取通用文件详细信息
     */
    @ApiOperation("获取通用文件详细信息")
//    @PreAuthorize("@ss.hasPermi('pv:pubfile:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(pubFileService.selectPubFileById(id));
    }

    /**
     * 新增通用文件
     */
    @ApiOperation("新增通用文件")
//    @PreAuthorize("@ss.hasPermi('pv:pubfile:add')")
    @Log(title = "通用文件", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody PubFile pubFile)
    {
        pubFile.setCreateBy(getNickname());
        return toAjax(pubFileService.insertPubFile(pubFile));
    }

    /**
     * 修改通用文件
     */
    @ApiOperation("修改通用文件")
//    @PreAuthorize("@ss.hasPermi('pv:pubfile:edit')")
    @Log(title = "通用文件", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody PubFile pubFile)
    {
        pubFile.setUpdateBy(getNickname());
        return toAjax(pubFileService.updatePubFile(pubFile));
    }

    /**
     * 删除通用文件
     */
    @ApiOperation("删除通用文件")
//    @PreAuthorize("@ss.hasPermi('pv:pubfile:remove')")
    @Log(title = "通用文件", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(pubFileService.deletePubFileByIds(ids));
    }

    @ApiOperation(value = "文件上传接口")
//    @PreAuthorize("@ss.hasPermi('pv:pubfile:add')")
    @Log(title = "通用文件", businessType = BusinessType.INSERT)
    @PostMapping("/uploadFile")
    public AjaxResult uploadFile(MultipartFile[] files, PubFile pubFile) {

        return success( pubFileService.uploadFiles(files,pubFile));
    }


    @Log(title = "通用文件", businessType = BusinessType.INSERT)
    @PostMapping("/uploadFileSingle")
    public AjaxResult uploadFileSingle(MultipartFile file) {
        return success( pubFileService.uploadFile(file));
    }


    /**
     * 本地资源通用下载
     */
    @ApiOperation(value = "文件下载接口")
    @GetMapping("/download/{fileId}")
    public void resourceDownload(@PathVariable Long fileId, HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {
        PubFile file = pubFileService.selectPubFileById(fileId);
        String resource = file.getFileUrl();
        try
        {
            if (!FileUtils.checkAllowDownload(resource))
            {
                throw new Exception(StringUtils.format("资源文件({})非法，不允许下载。 ", resource));
            }
            // 本地资源路径
            String localPath = RuoYiConfig.getProfile();
            // 数据库资源地址
            String downloadPath = localPath + StringUtils.substringAfter(resource, Constants.RESOURCE_PREFIX);
            // 下载名称
            String downloadName = file.getFileName();
            response.setContentType(MediaType.APPLICATION_OCTET_STREAM_VALUE);
            FileUtils.setAttachmentResponseHeader(response, downloadName);
            FileUtils.writeBytes(downloadPath, response.getOutputStream());
        }
        catch (Exception e)
        {
            logger.error("下载文件失败", e);
        }
    }

    /**
     * 通用上传请求（单个）
     */
    @RequestMapping("/upload")
    public AjaxResult uploadFile(MultipartFile file) throws Exception
    {
        try
        {
            // 上传文件路径
            String filePath = LuckqunxinConfig.PayFile;
            // 上传并返回新文件名称
            String fileName = FileUploadUtils.uploadPenFile(filePath, file);
            AjaxResult ajax = AjaxResult.success();
            ajax.put("fileName", fileName);
            ajax.put("newFileName", FileUtils.getName(fileName));
            ajax.put("originalFilename", file.getOriginalFilename());
            System.out.println("为什么回调有url？？？"+ajax);
            return ajax;
        }
        catch (Exception e)
        {
            return AjaxResult.error(e.getMessage());
        }
    }


}
