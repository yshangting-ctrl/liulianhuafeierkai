package com.zcty.api;

import com.zcty.business.domain.Product;
import com.zcty.business.service.IProductService;
import com.zcty.common.core.controller.BaseController;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.core.page.TableDataInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;
/**
 * 产品Controller
 *
 * @author lsw
 * @date 2024-03-13
 */
@RestController
@RequestMapping("/api/product")
public class ProductApiController extends BaseController {

    @Autowired
    private IProductService productService;


    /**
     * 查询话费商品信息分页列表
     * @param product
     * @return
     */
    @PostMapping("/list")
    public TableDataInfo list(Product product)
    {
        startPage();
        List<Product> list = productService.selectProductList(product);
        return getDataTable(list);
    }


    /**
     * 根据话费商品id查询话费商品详情
     * @param id
     * @return
     */
    @PostMapping("/selectInfo")
    public AjaxResult selectInfo(String id){
        Product flowProduct = productService.selectProductById(id);
        return AjaxResult.success(flowProduct);

    }



}
