package com.zcty.business.domain;


import com.zcty.common.annotation.Excel;
import com.zcty.common.core.domain.BaseEntity;

/**
 * 第三方充值平台管理对象 t_platform_infos
 * 
 * @author lsw
 * @date 2024-06-29
 */
public class PlatformInfos extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 主键id */
    private String id;

    /** 第三方平台名称 */
    @Excel(name = "第三方平台名称")
    private String platformName;

    /** 平台关键字 */
    @Excel(name = "平台关键字")
    private String platformKey;

    /** 平台链接地址 */
    @Excel(name = "平台链接地址")
    private String plaformUrl;

    /** 用户token */
    @Excel(name = "用户token")
    private String userToken;

    /** 用户秘钥 */
    @Excel(name = "用户秘钥")
    private String userSecrect;

    /** 删除标示 0未删除 1已删除 */
    private Integer delFlag;

    /** 使用状态 0 未开启 1已开启 */
    @Excel(name = "使用状态 0 未开启 1已开启")
    private Integer useStatus;

    public void setId(String id) 
    {
        this.id = id;
    }

    public String getId() 
    {
        return id;
    }
    public void setPlatformName(String platformName) 
    {
        this.platformName = platformName;
    }

    public String getPlatformName() 
    {
        return platformName;
    }
    public void setPlatformKey(String platformKey) 
    {
        this.platformKey = platformKey;
    }

    public String getPlatformKey() 
    {
        return platformKey;
    }
    public void setPlaformUrl(String plaformUrl) 
    {
        this.plaformUrl = plaformUrl;
    }

    public String getPlaformUrl() 
    {
        return plaformUrl;
    }
    public void setUserToken(String userToken) 
    {
        this.userToken = userToken;
    }

    public String getUserToken() 
    {
        return userToken;
    }
    public void setUserSecrect(String userSecrect) 
    {
        this.userSecrect = userSecrect;
    }

    public String getUserSecrect() 
    {
        return userSecrect;
    }
    public void setDelFlag(Integer delFlag) 
    {
        this.delFlag = delFlag;
    }

    public Integer getDelFlag() 
    {
        return delFlag;
    }
    public void setUseStatus(Integer useStatus) 
    {
        this.useStatus = useStatus;
    }

    public Integer getUseStatus() 
    {
        return useStatus;
    }

    @Override
    public String toString() {
        return "PlatformInfos{" +
                "id='" + id + '\'' +
                ", platformName='" + platformName + '\'' +
                ", platformKey='" + platformKey + '\'' +
                ", plaformUrl='" + plaformUrl + '\'' +
                ", userToken='" + userToken + '\'' +
                ", userSecrect='" + userSecrect + '\'' +
                ", delFlag=" + delFlag +
                ", useStatus=" + useStatus +
                '}';
    }
}
