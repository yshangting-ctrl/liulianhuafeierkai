package com.zcty.business.mapper;

import java.util.List;
import com.zcty.business.domain.PrivacyInfo;

/**
 * 隐私政策Mapper接口
 * 
 * @author lsw
 * @date 2024-03-22
 */
public interface PrivacyInfoMapper 
{
    /**
     * 查询隐私政策
     * 
     * @param id 隐私政策主键
     * @return 隐私政策
     */
    public PrivacyInfo selectPrivacyInfoById(String id);

    /**
     * 查询隐私政策列表
     * 
     * @param privacyInfo 隐私政策
     * @return 隐私政策集合
     */
    public List<PrivacyInfo> selectPrivacyInfoList(PrivacyInfo privacyInfo);

    /**
     * 新增隐私政策
     * 
     * @param privacyInfo 隐私政策
     * @return 结果
     */
    public int insertPrivacyInfo(PrivacyInfo privacyInfo);

    /**
     * 修改隐私政策
     * 
     * @param privacyInfo 隐私政策
     * @return 结果
     */
    public int updatePrivacyInfo(PrivacyInfo privacyInfo);

    /**
     * 删除隐私政策
     * 
     * @param id 隐私政策主键
     * @return 结果
     */
    public int deletePrivacyInfoById(String id);

    /**
     * 批量删除隐私政策
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deletePrivacyInfoByIds(String[] ids);
}
