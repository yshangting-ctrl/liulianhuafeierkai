package com.zcty.pv.enums;

/**
 * 订单状态枚举类
 */
public enum OrderStatusEnum {

    /** 待支付 */
    INITIAL(0, "待支付"),
    /** 已支付（待发货） */
    PAID(1, "已支付（待发货）"),
    /** 已发货 */
    DELIVERED(2, "已发货"),
    /** 已收货 */
    RECEIVED(3, "已收货"),
    /** 已作废 */
    CANCEL(4, "已作废");

    private Integer value;
    private String text;

    OrderStatusEnum(Integer value, String text) {
        this.value = value;
        this.text = text;
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
