package com.zcty.weChat.controller;


import com.zcty.common.constant.UserConstants;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.utils.StringUtils;
import com.zcty.weChat.service.WechatIndexService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * 获取用户授权（登录态） 控制层
 */
@Controller
@RequestMapping("/weChat/weChatRedirect")
public class WechatIndexController {
    @Autowired
    private WechatIndexService wechatIndexService;
    /**
     * 指定跳转菜单商城首页
     * @param code
     * @Param state 公众号id
     * @param request
     * @return
     */
    @RequestMapping(value = "/index",method = RequestMethod.GET)
    public String index(String code,String state, HttpServletRequest request){
       //校验进来的用户，若以及登记过，则绕过，否则新建一个
        String cookie=wechatIndexService.registeOrLogin(code,state,request);
        //若获取用户信息失败，则跳转获取授权失败页面，要求用户重新获取
        if (StringUtils.isEmpty(cookie)) {
            cookie="";
        }
        System.out.println("------cookie:"+cookie+"----------------");
        String redirectUrl = "redirect:http://ateli.soolds.com/?"+cookie+"&url=index";
        System.out.println("----------------redirectUrl------------------"+redirectUrl);
        return "redirect:http://ateli.soolds.com/?"+cookie+"&url=index";
    }

    /**
     * 指定跳转菜单我的中心
     * @param code
     * @Param state 公众号id
     * @param request
     * @return
     */
    @RequestMapping(value = "/user/index",method = RequestMethod.GET)
    public String userIndex(String code,String state, HttpServletRequest request){
        //校验进来的用户，若以及登记过，则绕过，否则新建一个
        String cookie=wechatIndexService.registeOrLogin(code,state,request);
        //若获取用户信息失败，则跳转获取授权失败页面，要求用户重新获取
        if (StringUtils.isEmpty(cookie)) {
            cookie="";
        }
        System.out.println("------cookie:"+cookie+"----------------");
        String redirectUrl = "redirect:http://ateli.soolds.com/?"+cookie+"&url=userIndex";
                System.out.println("----------------redirectUrl------------------"+redirectUrl);
        return redirectUrl;
    }



    /**
     * 获取网页使用微信js的参数
     * @param url
     * @return
     */
    @PostMapping("/getWxConfig")
    @ResponseBody
    public AjaxResult getWxConfig(String url, HttpServletRequest request){
        String openId = (String)request.getAttribute(UserConstants.OPENID);
        System.out.println("-----------------------------openId----------------"+openId);
        if(StringUtils.isEmpty(openId)){
            return AjaxResult.withOutUser();
        }
        return  wechatIndexService.getWxConfig(url,openId);
    }
}
