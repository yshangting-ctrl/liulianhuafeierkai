package com.zcty.pv.service;

import java.util.List;
import com.zcty.pv.domain.PvArea;

/**
 * 区域Service接口
 * 
 * @author luohui
 * @date 2022-11-12
 */
public interface IPvAreaService 
{
    /**
     * 查询区域
     * 
     * @param areaId 区域主键
     * @return 区域
     */
    public PvArea selectPvAreaByAreaId(String areaId);

    /**
     * 查询区域列表
     * 
     * @param pvArea 区域
     * @return 区域集合
     */
    public List<PvArea> selectPvAreaList(PvArea pvArea);

    /**
     * 新增区域
     * 
     * @param pvArea 区域
     * @return 结果
     */
    public int insertPvArea(PvArea pvArea);

    /**
     * 修改区域
     * 
     * @param pvArea 区域
     * @return 结果
     */
    public int updatePvArea(PvArea pvArea);

    /**
     * 批量删除区域
     * 
     * @param areaIds 需要删除的区域主键集合
     * @return 结果
     */
    public int deletePvAreaByAreaIds(String[] areaIds);

    /**
     * 删除区域信息
     * 
     * @param areaId 区域主键
     * @return 结果
     */
    public int deletePvAreaByAreaId(String areaId);
}
