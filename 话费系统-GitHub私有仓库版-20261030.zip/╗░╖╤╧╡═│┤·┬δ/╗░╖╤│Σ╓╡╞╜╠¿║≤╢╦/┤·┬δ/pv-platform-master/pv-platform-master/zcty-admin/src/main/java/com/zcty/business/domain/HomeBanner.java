package com.zcty.business.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.zcty.common.annotation.Excel;
import java.io.Serializable;
import java.util.Date;

/**
 * 首页轮播图对象 t_home_banner
 * 
 * @author lsw
 * @date 2024-03-15
 */
public class HomeBanner implements Serializable
{
    private static final long serialVersionUID = 1L;

    /** 主键id */
    private String id;

    /** 文件名称 */
    @Excel(name = "文件名称")
    private String fileName;

    /** 文件访问地址 */
    @Excel(name = "文件访问地址")
    private String fileUrl;

    /** 备注 */
    @Excel(name = "备注")
    private String remake;

    /** 排序 */
    @Excel(name = "排序")
    private Integer orderBy;

    /** 状态 0未开启  1已开启 */
    @Excel(name = "状态 0未开启  1已开启")
    private Integer status;

    /** 是否删除标识 0未删除  1已删除 */
    private Integer delFlag;

    /** 创建时间 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;

    public void setId(String id) 
    {
        this.id = id;
    }

    public String getId() 
    {
        return id;
    }
    public void setFileName(String fileName) 
    {
        this.fileName = fileName;
    }

    public String getFileName() 
    {
        return fileName;
    }
    public void setFileUrl(String fileUrl) 
    {
        this.fileUrl = fileUrl;
    }

    public String getFileUrl() 
    {
        return fileUrl;
    }
    public void setRemake(String remake) 
    {
        this.remake = remake;
    }

    public String getRemake() 
    {
        return remake;
    }
    public void setOrderBy(Integer orderBy) 
    {
        this.orderBy = orderBy;
    }

    public Integer getOrderBy() 
    {
        return orderBy;
    }
    public void setStatus(Integer status) 
    {
        this.status = status;
    }

    public Integer getStatus() 
    {
        return status;
    }
    public void setDelFlag(Integer delFlag) 
    {
        this.delFlag = delFlag;
    }

    public Integer getDelFlag() 
    {
        return delFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}
