package com.zcty.pv.service.impl;


import com.zcty.pv.domain.WeChatUser;
import com.zcty.pv.mapper.WeChatUserMapper;
import com.zcty.pv.service.IWeChatUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;


/**
 * 微名用户 服务层实现
 * 
 * @author liuruibin
 * @date 2020-04-03
 */
@Service
public class WeChatUserServiceImpl implements IWeChatUserService
{
	@Autowired
	private WeChatUserMapper weChatUserMapper;


	/**
     * 查询微名用户信息
     * 
     * @param id 微名用户ID
     * @return 微名用户信息
     */
    @Override
	public WeChatUser selectWeChatUserById(String id)
	{
	    return weChatUserMapper.selectWeChatUserById(id);
	}
	
	/**
     * 查询微名用户列表
     * 
     * @param weChatUser 微名用户信息
     * @return 微名用户集合
     */
	@Override
	public List<WeChatUser> selectWeChatUserList(WeChatUser weChatUser)
	{
	    return weChatUserMapper.selectWeChatUserList(weChatUser);
	}
    /**
     * 新增微名用户
     * 
     * @param weChatUser 微名用户信息
     * @return 结果
     */
	@Override
	public int insertWeChatUser(WeChatUser weChatUser)
	{
	    return weChatUserMapper.insertWeChatUser(weChatUser);
	}
	
	/**
     * 修改微名用户
     * 
     * @param weChatUser 微名用户信息
     * @return 结果
     */
	@Override
	public int updateWeChatUser(WeChatUser weChatUser)
	{
	    return weChatUserMapper.updateWeChatUser(weChatUser);
	}

	/**获取唯一的用户id
	 * @return
	 */
	@Override
	public String getUniqueUserId() {
		return "";
	}



	/**
	 * 删除会员
	 * @param id
	 * @return
	 */
	@Override
	public int deleteWeChatUserByIds(String id) {
		return weChatUserMapper.deleteWeChatUserByIds(id);
	}

	/**
	 * 根据openId查询用户信息
	 * @param openId
	 * @return
	 */
	@Override
	public WeChatUser selectWeChatUserByOpenId(String openId) {
		return weChatUserMapper.selectWeChatUserByOpenId(openId);
	}

	/**
	 * 根据用户id查询用户信息
	 * @param userId
	 * @return
	 */
	@Override
	public WeChatUser selectWeChatUserByUserId(String userId){
		return  weChatUserMapper.selectWeChatUserByUserId(userId);
	}
}
