package com.zcty.weChat.controller;


import com.zcty.business.domain.WeOrderDTO;
import com.zcty.business.domain.WeOrderVO;
import com.zcty.business.service.IOrderService;
import com.zcty.common.constant.UserConstants;
import com.zcty.common.core.controller.BaseController;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.core.page.TableDataInfo;
import com.zcty.common.exception.base.BaseException;
import com.zcty.common.utils.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;
/**
 * @Author: chushengkun
 * @Date: 2022/7/25 16:19
 */
@RestController
@RequestMapping("/weChat/order")
public class WeOrderController extends BaseController {

    @Autowired
    private IOrderService orderService;

//    /**
//     * 获取确认订单信息 - 收集号码、订单商品信息、订单总金额
//     * @return
//     */
//    @PostMapping("/confirmOrderInfo")
//    public AjaxResult confirmOrderInfo(@RequestParam Map<String, Object> params, HttpServletRequest request){
//        String openId = (String)request.getAttribute(UserConstants.OPENID);
//        if(StringUtils.isEmpty(openId)){
//            return AjaxResult.withOutUser();
//        }
//        params.put(OrderConstants.OPEN_ID, openId);
//        return AjaxResult.success("data", orderService.getConfirmOrderInfoVO(params));
//    }

//    /**
//     * 下单接口 >openId、、其他订单信息
//     * @param weOrderDTO
//     * @param request
//     * @return
//     */
//    @PostMapping("/settlement")
//    public AjaxResult settlement(@Validated(WeOrderDTO.B.class) WeOrderDTO weOrderDTO, HttpServletRequest request){
//        String openId = (String)request.getAttribute(UserConstants.OPENID);
//        if(StringUtils.isEmpty(openId)){
//            return AjaxResult.withOutUser();
//        }
//        weOrderDTO.setOpenId(openId);
//        return orderService.settlement(weOrderDTO);
//    }

    /**
     * 下单接口openId、其他订单信息
     * @param weOrderDTO
     * @param request
     * @return
     */
    @PostMapping("/buyNow")
    public AjaxResult buyNow(@Validated(WeOrderDTO.BuyNow.class) WeOrderDTO weOrderDTO, HttpServletRequest request){
        String openId = (String)request.getAttribute(UserConstants.OPENID);
        if(StringUtils.isEmpty(openId)){
            return AjaxResult.withOutUser();
        }
        weOrderDTO.setOpenId(openId);
        return orderService.buyNow(weOrderDTO);
    }

    /**
     * 去支付，调用微信支付下单接口，并返回小程序唤起支付参数
     * @param orderId	订单ID
     * @return	结果
     */
    @PostMapping("/toPay")
    public AjaxResult toPay(String orderId, HttpServletRequest request){
        String openId = (String)request.getAttribute(UserConstants.OPENID);
        if(StringUtils.isEmpty(openId)){
            return AjaxResult.withOutUser();
        }
        return orderService.toPay(orderId, openId);
    }

    /**
     * 订单信息列表接口 - 下单时间、订单状态、商品规格主图、商品名称、商品副标题、下单数量、商品单价、实付金额、优惠金额
     * @param params 查询类型 - 全部、待支付、待发货、待收货、已完成
     * @param request
     * @return
     */
    @PostMapping("/list")
    public TableDataInfo list(@RequestParam Map<String, Object> params, HttpServletRequest request){
        String openId = (String)request.getAttribute(UserConstants.OPENID);
        if(StringUtils.isEmpty(openId)){
            throw new BaseException("登录过期,请重新登录");
        }
        params.put("openId", openId);
        startPage();
        List<WeOrderVO> list = orderService.selectWeOrderVOList(params);
        return getDataTable(list);
    }

    /**
     * 订单详情接口
     * @param orderId 订单ID
     * @param request
     * @return -  商品名称、主图、单价、数量、支付金额 -- 订单编号、微信订单号、下单时间、取消时间、订单状态
     */
    @PostMapping("/query")
    public AjaxResult queryOrderInfo(String orderId, HttpServletRequest request){
        String openId = (String)request.getAttribute(UserConstants.OPENID);
        if(StringUtils.isEmpty(openId)){
            return AjaxResult.withOutUser();
        }
        return orderService.selectWeOrderInfoVOById(orderId, openId);
    }

    /**
     * 取消订单接口
     * @param orderId 订单ID
     * @param request
     * @return
     */
    @PostMapping("/cancel")
    public AjaxResult cancelOrder(String orderId, HttpServletRequest request){
        String openId = (String)request.getAttribute(UserConstants.OPENID);
        if(StringUtils.isEmpty(openId)){
            return AjaxResult.withOutUser();
        }
        return orderService.cancelOrder(orderId, openId);
    }

    /**
     * 订单确认收货接口
     * @param orderId 订单ID
     * @param request
     * @return
     */
    @PostMapping("/confirm")
    public AjaxResult confirmOrder(String orderId, HttpServletRequest request){
        String openId = (String)request.getAttribute(UserConstants.OPENID);
        if(StringUtils.isEmpty(openId)){
            return AjaxResult.withOutUser();
        }
        return orderService.confirmOrder(orderId, openId);
    }

    /**
     * 删除订单
     * @param orderNo 订单编号
     * @param request
     * @return
     */
    @PostMapping("/remove")
    public AjaxResult remove(String orderNo, HttpServletRequest request){
        String openId = (String)request.getAttribute(UserConstants.OPENID);
        if(StringUtils.isEmpty(openId)){
            return AjaxResult.withOutUser();
        }
        return orderService.remove(orderNo, openId);
    }

    /**
     * 订单统计
     * @param request
     * @return
     */
    @PostMapping("/selectCount")
    public AjaxResult selectOrderCountByStatus(HttpServletRequest request){
        String openId = (String)request.getAttribute(UserConstants.OPENID);
        if(StringUtils.isEmpty(openId)){
            return AjaxResult.withOutUser();
        }
        return orderService.selectOrderCountByStatus(openId);
    }


    /**
     * 发送请求获取业务办理验证码
     * @param orderNo
     * @return
     */
    @PostMapping("/sendFirstSmsCode")
    public AjaxResult sendFirstSmsCode(String orderNo,HttpServletRequest request){
        String openId = (String)request.getAttribute(UserConstants.OPENID);
        if(StringUtils.isEmpty(openId)){
            return AjaxResult.withOutUser();
        }
        System.out.println("--------openId--------"+openId);
        return orderService.sendFirstSmsCode(orderNo,openId);
    }


    /**
     * 提交请求业务办理验证码
     * @param orderNo
     * @return
     */
    @PostMapping("/submitFirstSmsCode")
    public AjaxResult submitFirstSmsCode(String orderNo,String smsCode,HttpServletRequest request){
        String openId = (String)request.getAttribute(UserConstants.OPENID);
        if(StringUtils.isEmpty(openId)){
            return AjaxResult.withOutUser();
        }
        return orderService.submitFirstSmsCode(orderNo,smsCode,openId);
    }

    /**
     * 发送请求获取业务前置验证码
     * @param orderNo
     * @return
     */
    @PostMapping("/sendPreSmsCode")
    public AjaxResult sendPreSmsCode(String orderNo,HttpServletRequest request){
        String openId = (String)request.getAttribute(UserConstants.OPENID);
        if(StringUtils.isEmpty(openId)){
            return AjaxResult.withOutUser();
        }
        System.out.println("--------openId--------"+openId);
        return orderService.sendPreSmsCode(orderNo,openId);
    }


    /**
     * 提交请求业务前置验证码
     * @param orderNo
     * @return
     */
    @PostMapping("/submitPreSmsCode")
    public AjaxResult submitPreSmsCode(String orderNo,String smsCode,HttpServletRequest request){
        String openId = (String)request.getAttribute(UserConstants.OPENID);
        if(StringUtils.isEmpty(openId)){
            return AjaxResult.withOutUser();
        }
        return orderService.submitPreSmsCode(orderNo,smsCode,openId);
    }


}
