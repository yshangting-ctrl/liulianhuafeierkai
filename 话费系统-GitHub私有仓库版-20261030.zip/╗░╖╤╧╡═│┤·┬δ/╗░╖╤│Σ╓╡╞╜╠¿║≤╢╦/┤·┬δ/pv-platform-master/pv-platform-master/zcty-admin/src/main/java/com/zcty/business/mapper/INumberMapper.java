package com.zcty.business.mapper;


import com.zcty.business.domain.INumber;
import org.apache.ibatis.annotations.Param;

/**
 * @authour:linxiaohan
 * @date:2018/12/13
 * @description:
 */
public interface INumberMapper {

    void save(INumber number);

    INumber selectByDateAndType(@Param("date") String date, @Param("type") Integer type);

    INumber selectByType(Integer type);

    void update(INumber number);
}
