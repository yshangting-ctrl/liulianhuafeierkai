package com.zcty.web.utlis.delay;


import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;


public class AccessTokenDeLay implements Delayed {

    //延迟队列名称
    private String accessTokenName;

    //到期执行的时间
    private long timeStart;

    //这个延迟队列的类型
    private Integer delayType;

    public String getAccessTokenName() {
        return accessTokenName;
    }

    public void setAccessTokenName(String accessTokenName) {
        this.accessTokenName = accessTokenName;
    }

    public long getTimeStart() {
        return timeStart;
    }

    public void setTimeStart(long timeStart) {
        this.timeStart = timeStart;
    }

    public Integer getDelayType() {
        return delayType;
    }

    public void setDelayType(Integer delayType) {
        this.delayType = delayType;
    }

    public AccessTokenDeLay(String accessTokenName, long timeStart, Integer delayType) {
        this.accessTokenName = accessTokenName;
        this.timeStart = timeStart;
        this.delayType = delayType;
    }

    //作为一个标准的javaBean这里可不能省略
    public AccessTokenDeLay() {

    }

    @Override
    public long getDelay(TimeUnit unit) {
        return timeStart-System.currentTimeMillis();
    }

    @Override
    public int compareTo(Delayed o) {
        AccessTokenDeLay accessTokenDeLay=(AccessTokenDeLay)o;

        long diff=this.timeStart-accessTokenDeLay.timeStart;

        if (diff <= 0) {// 改成>=会造成问题
            return -1;
        }else {
            return 1;
        }
    }

    @Override
    public String toString() {
        return "AccessTokenDeLay{" +
                "accessTokenName='" + accessTokenName + '\'' +
                ", timeStart=" + timeStart +
                ", delayType=" + delayType +
                '}';
    }
}
