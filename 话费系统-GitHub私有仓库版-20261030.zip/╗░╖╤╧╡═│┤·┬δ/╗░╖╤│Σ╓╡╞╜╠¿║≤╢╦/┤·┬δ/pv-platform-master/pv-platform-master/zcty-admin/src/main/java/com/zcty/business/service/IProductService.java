package com.zcty.business.service;

import java.util.List;
import com.zcty.business.domain.Product;
import com.zcty.common.core.domain.AjaxResult;

/**
 * 产品项目Service接口
 * 
 * @author lsw
 * @date 2024-03-13
 */
public interface IProductService 
{
    /**
     * 查询产品项目
     * 
     * @param id 产品项目主键
     * @return 产品项目
     */
    public Product selectProductById(String id);

    /**
     * 查询产品项目列表
     * 
     * @param product 产品项目
     * @return 产品项目集合
     */
    public List<Product> selectProductList(Product product);

    /**
     * 新增产品项目
     * 
     * @param product 产品项目
     * @return 结果
     */
    public AjaxResult insertProduct(Product product);

    /**
     * 修改产品项目
     * 
     * @param product 产品项目
     * @return 结果
     */
    public AjaxResult updateProduct(Product product);

    /**
     * 批量删除产品项目
     * 
     * @param ids 需要删除的产品项目主键集合
     * @return 结果
     */
    public int deleteProductByIds(String[] ids);

    /**
     * 删除产品项目信息
     * 
     * @param id 产品项目主键
     * @return 结果
     */
    public int deleteProductById(String id);

    /**
     * 添加销量
     * @return
     */
    public int addSales(String commonId, Integer num);


    public AjaxResult updateProductStatus(Product product);
}
