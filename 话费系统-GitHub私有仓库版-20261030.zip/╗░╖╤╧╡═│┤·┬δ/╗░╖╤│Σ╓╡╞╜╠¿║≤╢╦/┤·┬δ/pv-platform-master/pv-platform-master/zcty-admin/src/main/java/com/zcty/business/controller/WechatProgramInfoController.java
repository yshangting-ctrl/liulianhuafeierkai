package com.zcty.business.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.zcty.common.annotation.Log;
import com.zcty.common.core.controller.BaseController;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.enums.BusinessType;
import com.zcty.business.domain.WechatProgramInfo;
import com.zcty.business.service.IWechatProgramInfoService;
import com.zcty.common.utils.poi.ExcelUtil;
import com.zcty.common.core.page.TableDataInfo;

/**
 * 微信公众号授权信息Controller
 * 
 * @author ruoyi
 * @date 2024-05-16
 */
@RestController
@RequestMapping("/business/weChatProgramInfo")
public class WechatProgramInfoController extends BaseController
{
    @Autowired
    private IWechatProgramInfoService wechatProgramInfoService;

    /**
     * 查询微信公众号授权信息列表
     */
    @PreAuthorize("@ss.hasPermi('business:weChatProgramInfo:list')")
    @GetMapping("/list")
    public TableDataInfo list(WechatProgramInfo wechatProgramInfo)
    {
        startPage();
        List<WechatProgramInfo> list = wechatProgramInfoService.selectWechatProgramInfoList(wechatProgramInfo);
        return getDataTable(list);
    }

    /**
     * 导出微信公众号授权信息列表
     */
    @PreAuthorize("@ss.hasPermi('business:weChatProgramInfo:export')")
    @Log(title = "微信公众号授权信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, WechatProgramInfo wechatProgramInfo)
    {
        List<WechatProgramInfo> list = wechatProgramInfoService.selectWechatProgramInfoList(wechatProgramInfo);
        ExcelUtil<WechatProgramInfo> util = new ExcelUtil<WechatProgramInfo>(WechatProgramInfo.class);
        util.exportExcel(response, list, "微信公众号授权信息数据");
    }

    /**
     * 获取微信公众号授权信息详细信息
     */
    @PreAuthorize("@ss.hasPermi('business:weChatProgramInfo:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") String id)
    {
        return success(wechatProgramInfoService.selectWechatProgramInfoById(id));
    }

    /**
     * 新增微信公众号授权信息
     */
    @PreAuthorize("@ss.hasPermi('business:weChatProgramInfo:add')")
    @Log(title = "微信公众号授权信息", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody WechatProgramInfo wechatProgramInfo)
    {
        return toAjax(wechatProgramInfoService.insertWechatProgramInfo(wechatProgramInfo));
    }

    /**
     * 修改微信公众号授权信息
     */
    @PreAuthorize("@ss.hasPermi('business:weChatProgramInfo:edit')")
    @Log(title = "微信公众号授权信息", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody WechatProgramInfo wechatProgramInfo)
    {
        return toAjax(wechatProgramInfoService.updateWechatProgramInfo(wechatProgramInfo));
    }

    /**
     * 删除微信公众号授权信息
     */
    @PreAuthorize("@ss.hasPermi('business:weChatProgramInfo:remove')")
    @Log(title = "微信公众号授权信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable String[] ids)
    {
        return toAjax(wechatProgramInfoService.deleteWechatProgramInfoByIds(ids));
    }
}
