package com.zcty.business.service.impl;

import java.util.List;
import com.zcty.common.utils.DateUtils;
import com.zcty.web.utlis.IdGen;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zcty.business.mapper.WechartPayInfoMapper;
import com.zcty.business.domain.WechartPayInfo;
import com.zcty.business.service.IWechartPayInfoService;

/**
 * 微信支付信息Service业务层处理
 * 
 * @author lsw
 * @date 2024-05-30
 */
@Service
public class WechartPayInfoServiceImpl implements IWechartPayInfoService 
{
    @Autowired
    private WechartPayInfoMapper wechartPayInfoMapper;

    /**
     * 查询微信支付信息
     * 
     * @param id 微信支付信息主键
     * @return 微信支付信息
     */
    @Override
    public WechartPayInfo selectWechartPayInfoById(String id)
    {
        return wechartPayInfoMapper.selectWechartPayInfoById(id);
    }

    /**
     * 查询微信支付信息列表
     * 
     * @param wechartPayInfo 微信支付信息
     * @return 微信支付信息
     */
    @Override
    public List<WechartPayInfo> selectWechartPayInfoList(WechartPayInfo wechartPayInfo)
    {
        return wechartPayInfoMapper.selectWechartPayInfoList(wechartPayInfo);
    }

    /**
     * 新增微信支付信息
     * 
     * @param wechartPayInfo 微信支付信息
     * @return 结果
     */
    @Override
    public int insertWechartPayInfo(WechartPayInfo wechartPayInfo)
    {
        String id = IdGen.uuid();
        wechartPayInfo.setDelFlag(0);
        wechartPayInfo.setId(id);
        wechartPayInfo.setUseStatus(1);
        wechartPayInfo.setCreateTime(DateUtils.getNowDate());
        wechartPayInfo.setSupplierId("1");
        return wechartPayInfoMapper.insertWechartPayInfo(wechartPayInfo);
    }

    /**
     * 修改微信支付信息
     * 
     * @param wechartPayInfo 微信支付信息
     * @return 结果
     */
    @Override
    public int updateWechartPayInfo(WechartPayInfo wechartPayInfo)
    {
        return wechartPayInfoMapper.updateWechartPayInfo(wechartPayInfo);
    }

    /**
     * 批量删除微信支付信息
     * 
     * @param ids 需要删除的微信支付信息主键
     * @return 结果
     */
    @Override
    public int deleteWechartPayInfoByIds(String[] ids)
    {
        return wechartPayInfoMapper.deleteWechartPayInfoByIds(ids);
    }

    /**
     * 删除微信支付信息信息
     * 
     * @param id 微信支付信息主键
     * @return 结果
     */
    @Override
    public int deleteWechartPayInfoById(String id)
    {
        return wechartPayInfoMapper.deleteWechartPayInfoById(id);
    }

    @Override
    public WechartPayInfo selectWechartPayInfoSupplierId(String supplierId) {
        return wechartPayInfoMapper.selectWechartPayInfoSupplierId(supplierId);
    }
}
