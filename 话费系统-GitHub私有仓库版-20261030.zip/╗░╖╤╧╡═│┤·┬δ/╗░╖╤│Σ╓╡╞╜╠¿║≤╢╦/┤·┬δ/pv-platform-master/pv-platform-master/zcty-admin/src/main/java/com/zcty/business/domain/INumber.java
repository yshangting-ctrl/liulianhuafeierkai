package com.zcty.business.domain;

import java.io.Serializable;

/**
 * @authour:linxiaohan
 * @date:2018/12/13
 * @description:
 */
public class INumber implements Serializable{

    private static final long serialVersionUID = 7287948287440086612L;
    private String id;

    private Integer type;

    private String date;

    private Integer number;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public INumber(String id, Integer type, String date, Integer number) {
        this.id = id;
        this.type = type;
        this.date = date;
        this.number = number;
    }

    public INumber() {
    }
}
