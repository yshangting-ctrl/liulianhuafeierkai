package com.zcty.business.mapper;

import java.util.List;
import com.zcty.business.domain.OrderSendProduct;

/**
 * 业务发货Mapper接口
 * 
 * @author lsw
 * @date 2024-07-09
 */
public interface OrderSendProductMapper 
{
    /**
     * 查询业务发货
     * 
     * @param id 业务发货主键
     * @return 业务发货
     */
    public OrderSendProduct selectOrderSendProductById(String id);

    /**
     * 查询业务发货列表
     * 
     * @param orderSendProduct 业务发货
     * @return 业务发货集合
     */
    public List<OrderSendProduct> selectOrderSendProductList(OrderSendProduct orderSendProduct);

    /**
     * 新增业务发货
     * 
     * @param orderSendProduct 业务发货
     * @return 结果
     */
    public int insertOrderSendProduct(OrderSendProduct orderSendProduct);

    /**
     * 修改业务发货
     * 
     * @param orderSendProduct 业务发货
     * @return 结果
     */
    public int updateOrderSendProduct(OrderSendProduct orderSendProduct);

    /**
     * 删除业务发货
     * 
     * @param id 业务发货主键
     * @return 结果
     */
    public int deleteOrderSendProductById(String id);

    /**
     * 批量删除业务发货
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteOrderSendProductByIds(String[] ids);

    public OrderSendProduct selectOrderSendProductByParentOrderNo(String parentOrderNo);
}
