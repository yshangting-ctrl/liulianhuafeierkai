package com.zcty.pv.utils;

import com.zcty.common.utils.StringUtils;
import com.zcty.pv.domain.PvSerialNumber;
import com.zcty.pv.service.IPvSerialNumberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 编号序号生成工具类
 */
@Component
public class SerialNumberGeneralUtil {
    @Autowired
    private IPvSerialNumberService serialNumberService;

    /**
     * 默认序号长度
     */
    private static final Integer SERIAL_NUMBER_LENGTH = 6;

    private static final String SEP = ".";

    /**
     * 根据前缀获取序号，默认长度
     *
     * @param prefix
     * @return
     */
    public String getNext(String prefix) {
        return getNext(prefix, SEP, SERIAL_NUMBER_LENGTH);
    }

    /**
     * 根据前缀获取序号，指定长度
     *
     * @param prefix 前缀
     * @param len    序号长度
     * @return
     */
    public synchronized String getNext(String prefix, int len) {
        String sn = "";
        Integer index = 1;
        PvSerialNumber serialNumber = serialNumberService.getMaxSerialNo(prefix);
        if (StringUtils.isNotNull(serialNumber)) {
            Integer seqNo = serialNumber.getSeqNo();
            index = seqNo + 1;
        }
        sn = prefix + StringUtils.padl(index, len);
        PvSerialNumber newSerial = new PvSerialNumber();
        newSerial.setSerialNo(sn);
        newSerial.setSeqNo(index);
        newSerial.setPrefix(prefix);
        serialNumberService.insertPvSerialNumber(newSerial);
        return sn;
    }

    /**
     * 根据前缀获取序号，指定长度
     *
     * @param prefix 前缀
     * @param sep    分隔符
     * @param len    序号长度
     * @return
     */
    public synchronized String getNext(String prefix, String sep, int len) {
        String sn = "";
        Integer index = 1;
        PvSerialNumber serialNumber = serialNumberService.getMaxSerialNo(prefix);
        if (StringUtils.isNotNull(serialNumber)) {
            Integer seqNo = serialNumber.getSeqNo();
            index = seqNo + 1;
        }
        sn = prefix + sep + StringUtils.padl(index, len);
        PvSerialNumber newSerial = new PvSerialNumber();
        newSerial.setSerialNo(sn);
        newSerial.setSeqNo(index);
        newSerial.setPrefix(prefix);
        serialNumberService.insertPvSerialNumber(newSerial);
        return sn;
    }

}
