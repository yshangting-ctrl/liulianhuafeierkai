package com.zcty.business.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.zcty.common.utils.StringUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.zcty.common.annotation.Log;
import com.zcty.common.core.controller.BaseController;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.enums.BusinessType;
import com.zcty.business.domain.FlowProduct;
import com.zcty.business.service.IFlowProductService;
import com.zcty.common.utils.poi.ExcelUtil;
import com.zcty.common.core.page.TableDataInfo;

/**
 * 流量商品Controller
 * 
 * @author lsw
 * @date 2024-03-20
 */
@RestController
@RequestMapping("/business/flowProduct")
public class FlowProductController extends BaseController
{
    @Autowired
    private IFlowProductService flowProductService;

    /**
     * 查询流量商品列表
     */
    @PreAuthorize("@ss.hasPermi('business:product:list')")
    @GetMapping("/list")
    public TableDataInfo list(FlowProduct flowProduct)
    {
        startPage();
        List<FlowProduct> list = flowProductService.selectFlowProductList(flowProduct);
        return getDataTable(list);
    }

    /**
     * 导出流量商品列表
     */
    @PreAuthorize("@ss.hasPermi('business:product:export')")
    @Log(title = "流量商品", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, FlowProduct flowProduct)
    {
        List<FlowProduct> list = flowProductService.selectFlowProductList(flowProduct);
        ExcelUtil<FlowProduct> util = new ExcelUtil<FlowProduct>(FlowProduct.class);
        util.exportExcel(response, list, "流量商品数据");
    }

    /**
     * 获取流量商品详细信息
     */
    @PreAuthorize("@ss.hasPermi('business:product:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") String id)
    {
        return success(flowProductService.selectFlowProductById(id));
    }

    /**
     * 新增流量商品
     */
    @PreAuthorize("@ss.hasPermi('business:product:add')")
    @Log(title = "流量商品", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody FlowProduct flowProduct)
    {
        return (flowProductService.insertFlowProduct(flowProduct));
    }

    /**
     * 修改流量商品
     */
    @PreAuthorize("@ss.hasPermi('business:product:edit')")
    @Log(title = "流量商品", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody FlowProduct flowProduct)
    {
        return (flowProductService.updateFlowProduct(flowProduct));
    }

    /**
     * 删除流量商品
     */
    @PreAuthorize("@ss.hasPermi('business:product:remove')")
    @Log(title = "流量商品", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable String[] ids)
    {
        return toAjax(flowProductService.deleteFlowProductByIds(ids));
    }

    /**
     * 状态修改
     */
    @Log(title = "流量商品上下架", businessType = BusinessType.UPDATE)
    @PutMapping("/changeStatus")
    public AjaxResult changeStatus(@RequestBody FlowProduct flowProduct)
    {
        String id = flowProduct.getId();
        if(StringUtils.isEmpty(id)){
            return AjaxResult.error("未找到流量商品信息");
        }
        FlowProduct flowProductUpdate = flowProductService.selectFlowProductById(id);
        if(flowProductUpdate==null){
            return AjaxResult.error("未找到流量商品的信息");
        }
        flowProductUpdate.setStatus(flowProduct.getStatus());
        return (flowProductService.updateFlowProductStatus(flowProductUpdate));
    }

}
