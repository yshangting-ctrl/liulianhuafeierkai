package com.zcty.business.service;

import java.util.List;
import com.zcty.business.domain.WechatProgramInfo;

/**
 * 微信公众号授权信息Service接口
 * 
 * @author ruoyi
 * @date 2024-05-16
 */
public interface IWechatProgramInfoService 
{
    /**
     * 查询微信公众号授权信息
     * 
     * @param id 微信公众号授权信息主键
     * @return 微信公众号授权信息
     */
    public WechatProgramInfo selectWechatProgramInfoById(String id);

    /**
     * 查询微信公众号授权信息列表
     * 
     * @param wechatProgramInfo 微信公众号授权信息
     * @return 微信公众号授权信息集合
     */
    public List<WechatProgramInfo> selectWechatProgramInfoList(WechatProgramInfo wechatProgramInfo);

    /**
     * 新增微信公众号授权信息
     * 
     * @param wechatProgramInfo 微信公众号授权信息
     * @return 结果
     */
    public int insertWechatProgramInfo(WechatProgramInfo wechatProgramInfo);

    /**
     * 修改微信公众号授权信息
     * 
     * @param wechatProgramInfo 微信公众号授权信息
     * @return 结果
     */
    public int updateWechatProgramInfo(WechatProgramInfo wechatProgramInfo);

    /**
     * 批量删除微信公众号授权信息
     * 
     * @param ids 需要删除的微信公众号授权信息主键集合
     * @return 结果
     */
    public int deleteWechatProgramInfoByIds(String[] ids);

    /**
     * 删除微信公众号授权信息信息
     * 
     * @param id 微信公众号授权信息主键
     * @return 结果
     */
    public int deleteWechatProgramInfoById(String id);

    /**
     * 删除微信公众号授权信息
     *
     * @param authorizerAppid 微信公众号授权公众号appId
     * @return 结果
     */
    public int  deleteWechatProgramInfoByAuthorizerAppid(String authorizerAppid);
}
