package com.zcty.business.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.zcty.common.annotation.Log;
import com.zcty.common.core.controller.BaseController;
import com.zcty.common.core.domain.AjaxResult;
import com.zcty.common.enums.BusinessType;
import com.zcty.business.domain.OrderSendProduct;
import com.zcty.business.service.IOrderSendProductService;
import com.zcty.common.utils.poi.ExcelUtil;
import com.zcty.common.core.page.TableDataInfo;

/**
 * 业务发货Controller
 * 
 * @author lsw
 * @date 2024-07-09
 */
@RestController
@RequestMapping("/business/orderSendProduct")
public class OrderSendProductController extends BaseController
{
    @Autowired
    private IOrderSendProductService orderSendProductService;

    /**
     * 查询业务发货列表
     */
    @PreAuthorize("@ss.hasPermi('business:orderSendProduct:list')")
    @GetMapping("/list")
    public TableDataInfo list(OrderSendProduct orderSendProduct)
    {
        startPage();
        List<OrderSendProduct> list = orderSendProductService.selectOrderSendProductList(orderSendProduct);
        return getDataTable(list);
    }

    /**
     * 导出业务发货列表
     */
    @PreAuthorize("@ss.hasPermi('business:orderSendProduct:export')")
    @Log(title = "业务发货", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, OrderSendProduct orderSendProduct)
    {
        List<OrderSendProduct> list = orderSendProductService.selectOrderSendProductList(orderSendProduct);
        ExcelUtil<OrderSendProduct> util = new ExcelUtil<OrderSendProduct>(OrderSendProduct.class);
        util.exportExcel(response, list, "业务发货数据");
    }

    /**
     * 获取业务发货详细信息
     */
    @PreAuthorize("@ss.hasPermi('business:orderSendProduct:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") String id)
    {
        return success(orderSendProductService.selectOrderSendProductById(id));
    }

    /**
     * 新增业务发货
     */
    @PreAuthorize("@ss.hasPermi('business:orderSendProduct:add')")
    @Log(title = "业务发货", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody OrderSendProduct orderSendProduct)
    {
        return toAjax(orderSendProductService.insertOrderSendProduct(orderSendProduct));
    }

    /**
     * 修改业务发货
     */
    @PreAuthorize("@ss.hasPermi('business:orderSendProduct:edit')")
    @Log(title = "业务发货", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody OrderSendProduct orderSendProduct)
    {
        return toAjax(orderSendProductService.updateOrderSendProduct(orderSendProduct));
    }

    /**
     * 删除业务发货
     */
    @PreAuthorize("@ss.hasPermi('business:orderSendProduct:remove')")
    @Log(title = "业务发货", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable String[] ids)
    {
        return toAjax(orderSendProductService.deleteOrderSendProductByIds(ids));
    }
}
