package com.zcty.business.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.zcty.common.annotation.Excel;
import java.io.Serializable;
import java.util.Date;

/**
 * 隐私政策对象 t_privacy_info
 * 
 * @author lsw
 * @date 2024-03-22
 */
public class PrivacyInfo implements Serializable
{
    private static final long serialVersionUID = 1L;

    /** 主键id */
    private String id;

    /** 隐私正常内容 */
    @Excel(name = "隐私正常内容")
    private String contentInfo;

    /** 隐私名称 */
    @Excel(name = "隐私名称")
    private String privacyName;

    /** 隐私标题 */
    @Excel(name = "隐私标题")
    private String privacyTitle;

    /** 创建时间 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;

    public void setId(String id) 
    {
        this.id = id;
    }

    public String getId() 
    {
        return id;
    }


    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getContentInfo() {
        return contentInfo;
    }

    public void setContentInfo(String contentInfo) {
        this.contentInfo = contentInfo;
    }

    public String getPrivacyName() {
        return privacyName;
    }

    public void setPrivacyName(String privacyName) {
        this.privacyName = privacyName;
    }

    public String getPrivacyTitle() {
        return privacyTitle;
    }

    public void setPrivacyTitle(String privacyTitle) {
        this.privacyTitle = privacyTitle;
    }
}
