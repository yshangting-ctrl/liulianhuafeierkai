package com.zcty.business.domain;

import com.zcty.common.core.domain.BaseEntity;
import java.math.BigDecimal;
import java.util.Date;
/**
 * 订单表 t_order
 * 
 * @author liuruibin
 * @date 2022-07-25
 */
public class Order extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** 订单ID */
	private String orderId;
	/** 订单编号 */
	private String orderNo;
	/** 微信的用户ID */
	private String openId;
	/** 订单title */
	private String remarkBody;
	/** 标价币种，默认人民币：CNY */
	private String feeType;
	/** 订单金额 */
	private BigDecimal totalFee;
	/** 订单支付金额*/
	private BigDecimal payFee;
	/** 交易类型JSAPI -JSAPI支付 NATIVE -Native支付 APP -APP支付 */
	private String tradeType;
	/** 支付时间 */
	private Date payTime;
	/** 订单备注 */
	private String remark;
	/** 联系电话 */
	private String phone;
	/** 联系人 */
	private String nickName;
	/** 订单状态 0、待付款 1、待发货 2、待收货 3、交易完成 4、交易关闭 5、退款 6、取消 */
	private Integer orderStatus;
	/** 微信返回的订单号 */
	private String transactionId;
	/** 订单支付状态 SUCCESS—支付成功 NOTPAY—未支付 CLOSED—已关闭 */
	private String payStatus;
	/** 第三方支付状态 SUCCESS—支付成功 REFUND—转入退款 NOTPAY—未支付 CLOSED—已关闭 REVOKED—已撤销（付款码支付） USERPAYING--用户支付中（付款码支付） PAYERROR--支付失败(其他原因，如银行返回失败) */
	private String thirdPayStatus;
	/** 是否已经发货 0、未发货 1、已发货 */
	private Integer sendProduct;
	/** 发货时间 */
	private Date sendProductTime;
	/** 发货备注 */
	private String sendRemark;
	/** 确认收货时间 */
	private Date confirmTime;
	/** 取消时间 */
	private Date cancelTime;
	/** 创建时间 */
	private Date createTime;
	/** 更新时间 */
	private Date updateTime;
	/** 版本号 */
	private Integer sysVersion;

	/**
	 * 代理商id
	 */
	private String supplierId;


	/**商品类型 1 话费商品 2 流量商品 */
	private Integer goodsType;


	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public String getOpenId() {
		return openId;
	}

	public void setOpenId(String openId) {
		this.openId = openId;
	}

	public String getRemarkBody() {
		return remarkBody;
	}

	public void setRemarkBody(String remarkBody) {
		this.remarkBody = remarkBody;
	}

	public String getFeeType() {
		return feeType;
	}

	public void setFeeType(String feeType) {
		this.feeType = feeType;
	}

	public BigDecimal getTotalFee() {
		return totalFee;
	}

	public void setTotalFee(BigDecimal totalFee) {
		this.totalFee = totalFee;
	}

	public BigDecimal getPayFee() {
		return payFee;
	}

	public void setPayFee(BigDecimal payFee) {
		this.payFee = payFee;
	}

	public String getTradeType() {
		return tradeType;
	}

	public void setTradeType(String tradeType) {
		this.tradeType = tradeType;
	}

	public Date getPayTime() {
		return payTime;
	}

	public void setPayTime(Date payTime) {
		this.payTime = payTime;
	}

	@Override
	public String getRemark() {
		return remark;
	}

	@Override
	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	public Integer getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(Integer orderStatus) {
		this.orderStatus = orderStatus;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getPayStatus() {
		return payStatus;
	}

	public void setPayStatus(String payStatus) {
		this.payStatus = payStatus;
	}

	public String getThirdPayStatus() {
		return thirdPayStatus;
	}

	public void setThirdPayStatus(String thirdPayStatus) {
		this.thirdPayStatus = thirdPayStatus;
	}

	public Integer getSendProduct() {
		return sendProduct;
	}

	public void setSendProduct(Integer sendProduct) {
		this.sendProduct = sendProduct;
	}

	public Date getSendProductTime() {
		return sendProductTime;
	}

	public void setSendProductTime(Date sendProductTime) {
		this.sendProductTime = sendProductTime;
	}

	public String getSendRemark() {
		return sendRemark;
	}

	public void setSendRemark(String sendRemark) {
		this.sendRemark = sendRemark;
	}

	public Date getConfirmTime() {
		return confirmTime;
	}

	public void setConfirmTime(Date confirmTime) {
		this.confirmTime = confirmTime;
	}

	public Date getCancelTime() {
		return cancelTime;
	}

	public void setCancelTime(Date cancelTime) {
		this.cancelTime = cancelTime;
	}

	@Override
	public Date getCreateTime() {
		return createTime;
	}

	@Override
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	@Override
	public Date getUpdateTime() {
		return updateTime;
	}

	@Override
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Integer getSysVersion() {
		return sysVersion;
	}

	public void setSysVersion(Integer sysVersion) {
		this.sysVersion = sysVersion;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public Integer getGoodsType() {
		return goodsType;
	}

	public void setGoodsType(Integer goodsType) {
		this.goodsType = goodsType;
	}


	@Override
	public String toString() {
		return "Order{" +
				"orderId='" + orderId + '\'' +
				", orderNo='" + orderNo + '\'' +
				", openId='" + openId + '\'' +
				", remarkBody='" + remarkBody + '\'' +
				", feeType='" + feeType + '\'' +
				", totalFee=" + totalFee +
				", payFee=" + payFee +
				", tradeType='" + tradeType + '\'' +
				", payTime=" + payTime +
				", remark='" + remark + '\'' +
				", phone='" + phone + '\'' +
				", nickName='" + nickName + '\'' +
				", orderStatus=" + orderStatus +
				", transactionId='" + transactionId + '\'' +
				", payStatus='" + payStatus + '\'' +
				", thirdPayStatus='" + thirdPayStatus + '\'' +
				", sendProduct=" + sendProduct +
				", sendProductTime=" + sendProductTime +
				", sendRemark='" + sendRemark + '\'' +
				", confirmTime=" + confirmTime +
				", cancelTime=" + cancelTime +
				", createTime=" + createTime +
				", updateTime=" + updateTime +
				", sysVersion=" + sysVersion +
				", supplierId='" + supplierId + '\'' +
				", goodsType=" + goodsType +
				'}';
	}
}
