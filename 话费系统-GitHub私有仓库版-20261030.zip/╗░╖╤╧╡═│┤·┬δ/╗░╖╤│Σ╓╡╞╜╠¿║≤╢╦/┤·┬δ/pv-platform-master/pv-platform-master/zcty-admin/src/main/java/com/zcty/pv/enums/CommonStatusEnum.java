package com.zcty.pv.enums;

public enum CommonStatusEnum {
    /** 正常 */
    OK(0, "通过"),
    /** 作废（异常） */
    FAIL(1, "不通过");

    private Integer value;
    private String text;

    CommonStatusEnum(Integer value, String text) {
        this.value = value;
        this.text = text;
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
