package com.zcty.web.utlis;


import com.zcty.common.config.InterceptorConfig;
import com.zcty.common.config.LuckqunxinConfig;
import org.apache.commons.lang3.StringUtils;

import javax.servlet.http.HttpServletRequest;
import java.util.Base64;
import java.util.Enumeration;

/**
 * 微信用户信息工具类
 */
public class WeChatUserUtils {

    public static  String getWeChatOpenId(HttpServletRequest request){

        //做自带表头兼容，由于浏览器通讯协议的问题，导致前端传递的表头参数accessToken和timeStamps会大小写出现无法和定义的时候一致大小写
        //注意：本次处理只是针对大小写问题，后续浏览器对关键字定义开放问题的，需要后续观察，已知的有token无法作为自定义参数传递
        //循环遍历表头，全做小写equals判断
        Enumeration<String> headerNames = request.getHeaderNames();
        //定义变量
        String timeStamps= null;
        String accessToken= null;
        System.out.println(headerNames);
        while (headerNames.hasMoreElements()) {
            String headerName = headerNames.nextElement();
            System.out.println("-------headerNames--------"+headerName);
            String headerValue =  request.getHeader(headerName);
            System.out.println("-------headerValue--------"+headerValue);
            //判断accesstoken
            if(InterceptorConfig.accessToken.toLowerCase().equals(headerName.toLowerCase())){
                // 在这里可以处理头部的值，例如打印出来或者进行其他操作
                accessToken = request.getHeader(headerName);
            }
            //判断timeStamps
            if(InterceptorConfig.timeStamps.toLowerCase().equals(headerName.toLowerCase())){
                // 在这里可以处理头部的值，例如打印出来或者进行其他操作
                timeStamps = headerValue;
            }
        }

        //获取时间的表头数据
//        String timeStamps= request.getHeader("timeStamps");
        //获取加密的accessToken的表头数据
//        String accessToken=request.getHeader("accessToken");

        if(StringUtils.isEmpty(timeStamps)){
//            log.info("未传入时间表头信息");
            return null;
        }
        if(StringUtils.isEmpty(accessToken)){
//            log.info("未传入accessToken信息");
            return null;
        }
        //前面把斜杆换成%%%，现在换回来
        accessToken=accessToken.replaceAll("-ss-","/");
        //将字符串的+化为-jj-
        accessToken=accessToken.replaceAll("-jj-","\\+");
        //讲字符串=化为-kk-
        accessToken=accessToken.replaceAll("-kk-","=");
        //对数据进行解密，最终会获取到一个用户的openId
        try {

            //accessToken是一个经过base64编码后的一个bytep[]数据
            byte[] accessTokenByte= Base64.getDecoder().decode(accessToken);

            //把这个byte数组给解码成字符串
            String originAccessToken=new String(EncrypAES.DecryptorNew(accessTokenByte));

            //这样得到原始的未加密之前的数据， 数据由三部分组成，服务器的私钥+时间字符串（yyyyMMdd）+openId
            //截取时间秘钥字符串和时间字符串，共xxx.length()+13个字符串长度，在来和服务器的私钥+时间字符串拼接的字符串进行equals比较
            //截取字符串长度为这个
            int size= LuckqunxinConfig.aeskey.length()+13;

            //反正字符串截取方法的异常
            if(originAccessToken==null||originAccessToken.length()<size){
//                log.info("解密后，获取的字符串长度异常！");
                return null;
            }

            //服务器拼接的字符串数据
            String serverString= LuckqunxinConfig.aeskey+timeStamps;
            //解析客户端的字符串拼接
            String customString=originAccessToken.substring(0,size);

            //equals比较两边是否一致
            if(!serverString.equals(customString)){
                //解析用户的登录信息失败
//                log.info("解析用户的登录信息失败！是个伪造的数据！");
                return null;
            }

            String openId=originAccessToken.substring(size);
//            log.info(openId);
            return openId;
        }catch (Exception e){
//            log.info("解密失败！可能是错误的数据，或者是服务器重启，重置了加解密的对象信息！");
        }

        return null;
    }

    public static void main(String[] args) {
        String accessToken = System.getenv().getOrDefault("WX_DEBUG_ACCESS_TOKEN", "");
        //前面把斜杆换成%%%，现在换回来
        accessToken=accessToken.replaceAll("-ss-","/");
        //将字符串的+化为-jj-
        accessToken=accessToken.replaceAll("-jj-","\\+");
        //讲字符串=化为-kk-
        accessToken=accessToken.replaceAll("-kk-","=");
        System.out.println(accessToken);

        //将字符串的斜杆转化为-ss-
        accessToken=accessToken.replaceAll("/","-ss-");
        //将字符串的+化为-jj-
        accessToken=accessToken.replaceAll("\\+","-jj-");
        //讲字符串=化为-kk-
        accessToken=accessToken.replaceAll("=","-kk-");

        System.out.println(accessToken);

    }
}
