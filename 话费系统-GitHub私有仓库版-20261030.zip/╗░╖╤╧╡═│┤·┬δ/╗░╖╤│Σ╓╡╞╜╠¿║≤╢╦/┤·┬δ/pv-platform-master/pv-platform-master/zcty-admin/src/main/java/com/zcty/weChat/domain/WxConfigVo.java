package com.zcty.weChat.domain;

import java.io.Serializable;

/**
 * 微信js-sdk使用的config接口注入权限验证配置
 */
public class WxConfigVo implements Serializable {

   //公众号appId
   private String appId;
   //时间戳
   private Long timestamp;
   //随机数
   private String  nonceStr;
   //签名
   private String signature;

   public String getAppId() {
      return appId;
   }

   public void setAppId(String appId) {
      this.appId = appId;
   }

   public Long getTimestamp() {
      return timestamp;
   }

   public void setTimestamp(Long timestamp) {
      this.timestamp = timestamp;
   }

   public String getNonceStr() {
      return nonceStr;
   }

   public void setNonceStr(String nonceStr) {
      this.nonceStr = nonceStr;
   }

   public String getSignature() {
      return signature;
   }

   public void setSignature(String signature) {
      this.signature = signature;
   }
}
