package com.zcty.business.service;



import com.zcty.business.domain.*;
import com.zcty.common.core.domain.AjaxResult;

import java.util.List;
import java.util.Map;

/**
 * 订单 服务层
 * 
 * @author liuruibin
 * @date 2022-07-25
 */
public interface IOrderService 
{
	/**
     * 查询订单信息
     * 
     * @param orderId 订单ID
     * @return 订单信息
     */
	public Order selectOrderById(String orderId);

    /**
     * 查询订单详情
     *
     * @param orderId 订单ID
     * @return 订单信息
     */
    public OrderInfoVO selectOrderInfoVOById(String orderId);

//	/**
//	 * 获取确认订单信息
//	 * @param params 参数
//	 * @return	结果
//	 */
//	public ConfirmOrderInfoVO getConfirmOrderInfoVO(Map<String, Object> params);

	/**
	 * 查询订单信息
	 *
	 * @param orderNo 订单编号
	 * @return 订单信息
	 */
	public Order selectOrderByNo(String orderNo);

    /**
     * 查询订单列表信息 待付款、待收货、去支付
     * @return
     */
	public List<Order> selectOrderList();

	/**
	 * 查询订单信息
	 *
	 * @param orderId 订单ID
	 * @return 订单信息
	 */
	public AjaxResult selectWeOrderInfoVOById(String orderId, String openId);
	
	/**
     * 查询订单列表
     * 
     * @param order 订单信息
     * @return 订单集合
     */
	public List<OrderVO> selectOrderList(Order order);

	/**
	 * 查询待发货订单列表
	 *
	 * @param order 筛选条件
	 * @return 订单集合
	 */
	public List<OrderVO> selectOrderListByToBeDelivered(Order order);

	/**
	 * 查询订单列表
	 *
	 * @param params 赛选条件
	 * @return 订单集合
	 */
	public List<WeOrderVO> selectWeOrderVOList(Map<String, Object> params);
	
	/**
     * 新增订单
     * 
     * @param order 订单信息
     * @return 结果
     */
	public int insertOrder(Order order);
	
	/**
     * 修改订单
     * 
     * @param order 订单信息
     * @return 结果
     */
	public int updateOrder(Order order);
		
	/**
     * 删除订单信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteOrderByIds(String ids);

	/**
	 * 立即购买
	 * @param weOrderDTO
	 * @return
	 */
	public AjaxResult buyNow(WeOrderDTO weOrderDTO);

	/**
	 * 取消订单接口
	 * @param orderId 订单ID
	 * @param openId 微信用户ID
	 * @return
	 */
	public AjaxResult cancelOrder(String orderId, String openId);

	/**
	 * 订单确认收货接口
	 * @param orderId 订单ID
	 * @param openId 微信用户ID
	 * @return
	 */
	public AjaxResult confirmOrder(String orderId, String openId);

	/**
	 * 订单交易完成
	 * @return
	 */
	public AjaxResult completeOrder(String orderNo);

	/**
	 * 去支付，调用微信支付下单接口，并返回小程序唤起支付参数
	 * @param orderId	订单ID
	 * @param openId	微信用户ID
	 * @return	结果
	 */
	public AjaxResult toPay(String orderId, String openId);

	/**
	 * 订单支付回调更改订单状态
	 * @param order	订单信息
	 * @return	结果
	 */
	public int updateOrderByPay(Order order);

	/**
	 * 更新订单状态
	 * @param params    参数
	 * @return  结果
	 */
	public boolean casUpdateOrderStatus(Map<String, Object> params);

	/**
	 * 删除订单
	 * @param orderNo 订单编号
	 * @param openId 微信用户ID
	 * @return 结果
	 */
	public AjaxResult remove(String orderNo, String openId);

	/**
	 * 订单统计
	 * @param openId 微信用户ID
	 * @return
	 */
	public AjaxResult selectOrderCountByStatus(String openId);

	/**
	 * 编辑订单发货信息 -- 订单编号、快递单号、快递备注
	 */
	public AjaxResult editOrderSend(OrderShippedInfo orderShippedInfo);

	public AjaxResult queryOrderShippedInfo(String orderNo);

	/**
	 * 发送请求获取业务办理验证码
	 * @param orderNo
	 * @return
	 */
	public AjaxResult sendFirstSmsCode(String orderNo,String openId);
	/**
	 * 提交请求业务办理验证码
	 * @param orderNo
	 * @return
	 */
	public AjaxResult submitFirstSmsCode(String orderNo,String smsCode,String openId);


	/**
	 * 发送请求获取业务前置验证码
	 * @param orderNo
	 * @return
	 */
	public AjaxResult sendPreSmsCode(String orderNo,String openId);
	/**
	 * 提交请求业务前置验证码
	 * @param orderNo
	 * @return
	 */
	public AjaxResult submitPreSmsCode(String orderNo,String smsCode,String openId);

}
