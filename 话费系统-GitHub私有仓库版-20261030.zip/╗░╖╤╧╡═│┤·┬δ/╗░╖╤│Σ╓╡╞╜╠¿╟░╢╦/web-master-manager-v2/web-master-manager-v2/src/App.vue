<template>
  <div id="app">
    <router-view />
    <theme-picker />
  </div>
</template>

<script>
import ThemePicker from "@/components/ThemePicker";

export default {
  name: "App",
  components: { ThemePicker },
    metaInfo() {
        return {
            title: this.$store.state.settings.dynamicTitle && this.$store.state.settings.title,
            titleTemplate: title => {
                return title ? `${title} - ${process.env.VUE_APP_TITLE}` : process.env.VUE_APP_TITLE
            }
        }
    }
};
</script>
<style lang="scss">
#app .theme-picker {
  display: none;
}

.parseritem {
  display: inline-block;
  cursor: pointer;
  padding: 0 15px;
  font-size: 12px;
  font-weight: 500;
  border-radius: 5px;
  color: #fff;
  border: 1px solid transparent;
}

.parseritem.info{
  background-color: #b7d8ca;
}

.parseritem.primary{
  background-color: #178a68;
}

.parseritem.success{
  background-color: #67C23A;
}

.parseritem.error{
  background-color: #ed4014 !important;
}
.parseritem.errorNo{
  color: #ed4014;
  border-color: #ed4014;
}

.parseritem.successNo{
  background-color: #ed4014;
}

.parseritem.pass{
  background-color: #19be6b;
}

.parseritem.passNo{
  color: #19be6b;
  border-color: #19be6b;
}

.formstyle {
  display: flex;
  flex-wrap: wrap;
  background-color: #f1f1f1;
  border: 1px solid #ccc;
  margin-bottom: 10px;
  box-shadow: 0 3px 3px rgb(0 0 0 / 10%);
  border-radius: 4px;
  padding: 5px;
}
@for $i from 9 to 40 {
  .u-font-#{$i} {
    font-size: $i + px;
  }
}

// 定义内外边距，历遍1-80
@for $i from 0 through 80 {
  // 只要双数和能被5除尽的数
  @if $i % 2 == 0 or $i % 5 == 0 {
    // 得出：u-margin-30或者u-m-30
    .u-margin-#{$i},
    .u-m-#{$i} {
      margin: $i + px !important;
    }

    // 得出：u-padding-30或者u-p-30
    .u-padding-#{$i},
    .u-p-#{$i} {
      padding: $i + px !important;
    }

    @each $short, $long in l left, t top, r right, b bottom {
      // 缩写版，结果如： u-m-l-30
      // 定义外边距
      .u-m-#{$short}-#{$i} {
        margin-#{$long}: $i + px !important;
      }

      // 定义内边距
      .u-p-#{$short}-#{$i} {
        padding-#{$long}: $i + px !important;
      }

      // 完整版，结果如：u-margin-left-30
      // 定义外边距
      .u-margin-#{$long}-#{$i} {
        margin-#{$long}: $i + px !important;
      }

      // 定义内边距
      .u-padding-#{$long}-#{$i} {
        padding-#{$long}: $i + px !important;
      }
    }
  }
}

@for $i from 400 through 600 {
  .fw-#{$i} {
    font-weight: $i;
  }
}

.u-font-xl {
  font-size: 34rpx;
}

.u-flex {
  display: flex;
  flex-direction: row;
  align-items: right;
}

.u-flex-wrap {
  flex-wrap: wrap;
}

.u-flex-nowrap {
  flex-wrap: nowrap;
}

.u-col-center {
  align-items: center;
}

.u-col-top {
  align-items: flex-start;
}

.u-col-bottom {
  align-items: flex-end;
}

.u-row-center {
  justify-content: center;
}

.u-row-left {
  justify-content: flex-start;
}

.u-row-right {
  justify-content: flex-end;
}

.u-row-between {
  justify-content: space-between;
}

.u-row-around {
  justify-content: space-around;
}

.u-text-left {
  text-align: left;
}

.u-text-center {
  text-align: center;
}

.u-text-right {
  text-align: right;
}

.u-flex-col {
  flex-direction: column;
}

.backfroun-f5{
  background-color: #f5f5f5;
}
.background-f{
  background-color: #fff;
}

.boderR-10{
  border-radius: 10px;
}

.w-100{
  width: 100% !important;
}
.w-50{
  width: 50% !important;
}
.cursorP{
  cursor: pointer;
}
</style>
