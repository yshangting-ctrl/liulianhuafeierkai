<template>
  <div class="dashboard-page" v-loading="loading">
    <header class="dashboard-header">
      <div>
        <p class="header-kicker">OPERATIONS OVERVIEW</p>
        <h1>{{ greeting }}，{{ displayName }}</h1>
        <p class="header-desc">这是今天的话费充值业务概览，祝你工作顺利。</p>
      </div>
      <div class="header-date">
        <span class="date-icon"><i></i></span>
        <div><small>今天</small><strong>{{ currentDate }}</strong></div>
      </div>
    </header>

    <section class="metric-grid">
      <article v-for="item in primaryMetrics" :key="item.key" class="metric-card" :class="item.tone">
        <div class="metric-top">
          <span class="metric-label">{{ item.label }}</span>
          <span class="metric-icon" :class="item.icon"><i></i></span>
        </div>
        <div class="metric-value">{{ formatNumber(item.value) }}</div>
        <div class="metric-foot">
          <span class="metric-dot"></span>
          <span>{{ item.note }}</span>
        </div>
      </article>
    </section>

    <section class="dashboard-grid">
      <article class="panel trend-panel">
        <div class="panel-heading">
          <div><h2>订单趋势</h2><p>最近 7 天订单数量变化</p></div>
          <span class="panel-chip">近 7 天</span>
        </div>
        <div class="chart-summary">
          <div><small>近七日订单</small><strong>{{ weeklyTotal }}</strong></div>
          <div class="summary-divider"></div>
          <div><small>日均订单</small><strong>{{ weeklyAverage }}</strong></div>
        </div>
        <div class="bar-chart">
          <div v-for="day in weeklyTrend" :key="day.date" class="bar-column">
            <div class="bar-track">
              <div class="bar-fill" :style="{ height: barHeight(day.value) }"><span>{{ day.value }}</span></div>
            </div>
            <span class="bar-label">{{ day.label }}</span>
          </div>
        </div>
      </article>

      <article class="panel status-panel">
        <div class="panel-heading">
          <div><h2>订单状态</h2><p>当前全部订单构成</p></div>
          <span class="live-state"><i></i> 实时</span>
        </div>
        <div class="status-body">
          <div class="donut" :style="donutStyle">
            <div class="donut-center"><strong>{{ formatNumber(stats.totalOrders) }}</strong><span>总订单</span></div>
          </div>
          <div class="status-legend">
            <div v-for="item in statusItems" :key="item.label" class="legend-row">
              <span class="legend-color" :style="{ background: item.color }"></span>
              <span class="legend-name">{{ item.label }}</span>
              <strong>{{ formatNumber(item.value) }}</strong>
              <small>{{ percent(item.value) }}%</small>
            </div>
          </div>
        </div>
      </article>
    </section>

    <section class="dashboard-grid lower-grid">
      <article class="panel recent-panel">
        <div class="panel-heading">
          <div><h2>最近订单</h2><p>最新提交的充值订单</p></div>
          <button class="text-button" @click="goTo('/order/order')">查看全部 <span>→</span></button>
        </div>
        <div class="order-table" v-if="recentOrders.length">
          <div class="table-head"><span>订单编号</span><span>充值号码</span><span>金额</span><span>状态</span><span>下单时间</span></div>
          <div class="table-row" v-for="order in recentOrders" :key="order.orderId || order.orderNo">
            <span class="order-no">{{ order.orderNo || '--' }}</span>
            <span>{{ maskPhone(order.phone) }}</span>
            <span class="money">¥{{ money(order.payFee || order.totalFee) }}</span>
            <span><b class="status-tag" :class="statusClass(order.orderStatus)">{{ statusText(order.orderStatus) }}</b></span>
            <span class="order-time">{{ shortTime(order.createTime) }}</span>
          </div>
        </div>
        <div class="empty-orders" v-else><span>⌁</span><p>暂无订单记录</p></div>
      </article>

      <article class="panel quick-panel">
        <div class="panel-heading"><div><h2>快捷入口</h2><p>常用业务快速处理</p></div></div>
        <div class="quick-grid">
          <button v-for="item in quickEntries" :key="item.label" class="quick-item" @click="goTo(item.path)">
            <span class="quick-icon" :class="item.icon"><i></i></span>
            <span><strong>{{ item.label }}</strong><small>{{ item.desc }}</small></span>
            <b>›</b>
          </button>
        </div>
        <div class="system-card">
          <div class="system-check">✓</div>
          <div><strong>系统运行正常</strong><span>接口服务与数据连接均已就绪</span></div>
          <i class="pulse-dot"></i>
        </div>
      </article>
    </section>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { listOrder } from '@/api/business/order'
import { listSupplier } from '@/api/business/supplier'
import { listProduct } from '@/api/business/product'
import { listOnlineMessage } from '@/api/business/onlineMessage'

export default {
  name: 'Index',
  computed: {
    ...mapGetters(['name', 'nickName']),
    displayName() {
      return this.nickName || this.name || '管理员'
    },
    greeting() {
      const hour = new Date().getHours()
      if (hour < 6) return '夜深了'
      if (hour < 11) return '早上好'
      if (hour < 14) return '中午好'
      if (hour < 18) return '下午好'
      return '晚上好'
    },
    currentDate() {
      const now = new Date()
      const weekdays = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六']
      return `${now.getFullYear()}年${now.getMonth() + 1}月${now.getDate()}日 · ${weekdays[now.getDay()]}`
    },
    primaryMetrics() {
      return [
        { key: 'orders', label: '总订单数', value: this.stats.totalOrders, note: '累计充值订单', tone: 'emerald', icon: 'orders-icon' },
        { key: 'success', label: '成功订单', value: this.stats.successOrders, note: `成功率 ${this.percent(this.stats.successOrders)}%`, tone: 'gold', icon: 'success-icon' },
        { key: 'processing', label: '处理中订单', value: this.stats.processingOrders, note: '需要持续关注', tone: 'clay', icon: 'process-icon' },
        { key: 'agents', label: '代理商数量', value: this.stats.suppliers, note: '已接入合作渠道', tone: 'forest', icon: 'agent-icon' }
      ]
    },
    statusItems() {
      return [
        { label: '充值成功', value: this.stats.successOrders, color: '#178a68' },
        { label: '处理中', value: this.stats.processingOrders, color: '#d5a854' },
        { label: '关闭 / 取消', value: this.stats.closedOrders, color: '#d46c5c' },
        { label: '其他', value: Math.max(0, this.stats.totalOrders - this.stats.successOrders - this.stats.processingOrders - this.stats.closedOrders), color: '#c8cec9' }
      ]
    },
    donutStyle() {
      const total = this.stats.totalOrders || 1
      const success = this.stats.successOrders / total * 100
      const processing = this.stats.processingOrders / total * 100
      const closed = this.stats.closedOrders / total * 100
      return { background: `conic-gradient(#178a68 0 ${success}%, #d5a854 ${success}% ${success + processing}%, #d46c5c ${success + processing}% ${success + processing + closed}%, #e2e5e1 ${success + processing + closed}% 100%)` }
    },
    weeklyTotal() {
      return this.weeklyTrend.reduce((sum, day) => sum + day.value, 0)
    },
    weeklyAverage() {
      return Math.round(this.weeklyTotal / 7)
    }
  },
  data() {
    return {
      loading: false,
      stats: { totalOrders: 0, successOrders: 0, processingOrders: 0, closedOrders: 0, suppliers: 0, products: 0, messages: 0 },
      recentOrders: [],
      rawOrders: [],
      weeklyTrend: [],
      quickEntries: [
        { label: '订单管理', desc: '查询充值进度', path: '/order/order', icon: 'quick-order' },
        { label: '代理商管理', desc: '维护渠道资料', path: '/supplier/supplier', icon: 'quick-agent' },
        { label: '商品管理', desc: '配置充值产品', path: '/product/product', icon: 'quick-product' },
        { label: '投诉建议', desc: '处理用户反馈', path: '/onlineMessage/onlineMessage', icon: 'quick-message' }
      ]
    }
  },
  created() {
    this.buildWeeklyTrend([])
    this.loadDashboard()
  },
  methods: {
    safe(promise) {
      return promise.catch(() => ({ rows: [], total: 0 }))
    },
    async loadDashboard() {
      this.loading = true
      const query = (extra = {}) => ({ pageNum: 1, pageSize: 100, ...extra })
      try {
        const results = await Promise.all([
          this.safe(listOrder(query())),
          this.safe(listOrder(query({ pageSize: 1, orderStatus: 3 }))),
          this.safe(listOrder(query({ pageSize: 1, orderStatus: 7 }))),
          this.safe(listOrder(query({ pageSize: 1, orderStatus: 1 }))),
          this.safe(listOrder(query({ pageSize: 1, orderStatus: 2 }))),
          this.safe(listOrder(query({ pageSize: 1, orderStatus: 4 }))),
          this.safe(listOrder(query({ pageSize: 1, orderStatus: 6 }))),
          this.safe(listSupplier({ pageNum: 1, pageSize: 1 })),
          this.safe(listProduct({ pageNum: 1, pageSize: 1 })),
          this.safe(listOnlineMessage({ pageNum: 1, pageSize: 1 }))
        ])
        const [all, successA, successB, processingA, processingB, closedA, closedB, suppliers, products, messages] = results
        this.rawOrders = all.rows || []
        this.recentOrders = this.rawOrders.slice(0, 5)
        this.stats = {
          totalOrders: Number(all.total || 0),
          successOrders: Number(successA.total || 0) + Number(successB.total || 0),
          processingOrders: Number(processingA.total || 0) + Number(processingB.total || 0),
          closedOrders: Number(closedA.total || 0) + Number(closedB.total || 0),
          suppliers: Number(suppliers.total || 0),
          products: Number(products.total || 0),
          messages: Number(messages.total || 0)
        }
        this.buildWeeklyTrend(this.rawOrders)
      } finally {
        this.loading = false
      }
    },
    buildWeeklyTrend(orders) {
      const values = []
      for (let offset = 6; offset >= 0; offset--) {
        const date = new Date()
        date.setHours(0, 0, 0, 0)
        date.setDate(date.getDate() - offset)
        const dateKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`
        values.push({ date: dateKey, label: offset === 0 ? '今天' : `${date.getMonth() + 1}/${date.getDate()}`, value: orders.filter(item => String(item.createTime || '').slice(0, 10) === dateKey).length })
      }
      this.weeklyTrend = values
    },
    barHeight(value) {
      const max = Math.max(1, ...this.weeklyTrend.map(item => item.value))
      return `${Math.max(value ? 14 : 3, value / max * 100)}%`
    },
    formatNumber(value) {
      return Number(value || 0).toLocaleString('zh-CN')
    },
    percent(value) {
      if (!this.stats.totalOrders) return 0
      return Math.round(Number(value || 0) / this.stats.totalOrders * 100)
    },
    money(value) {
      const amount = Number(value || 0)
      return amount.toFixed(2).replace(/\.00$/, '')
    },
    maskPhone(phone) {
      const value = String(phone || '')
      return value.length === 11 ? `${value.slice(0, 3)}****${value.slice(-4)}` : value || '--'
    },
    shortTime(value) {
      return value ? String(value).replace(/-/g, '/').slice(5, 16) : '--'
    },
    statusText(status) {
      const map = { '0': '待支付', '1': '充值中', '2': '处理中', '3': '已完成', '4': '已关闭', '5': '退款中', '6': '已取消', '7': '已完成' }
      const value = String(status || '')
      return map[value] || value || '未知'
    },
    statusClass(status) {
      const value = String(status || '')
      if (['3', '7', '已收货', '已完成', '交易完成'].includes(value)) return 'success'
      if (['1', '2', '待发货', '待收货', '充值中', '处理中'].includes(value)) return 'processing'
      if (['0', '待付款', '待支付', '5', '退款中'].includes(value)) return 'pending'
      return 'closed'
    },
    goTo(path) {
      this.$router.push(path).catch(() => {})
    }
  }
}
</script>

<style lang="scss" scoped>
.dashboard-page { min-height: calc(100vh - 84px); padding: 26px 28px 34px; background: #f5f3ed; color: #263a33; }
.dashboard-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 22px; }
.header-kicker { margin: 0 0 7px; font-size: 10px; letter-spacing: 2.2px; font-weight: 700; color: #178a68; }
.dashboard-header h1 { margin: 0; font-size: 27px; line-height: 1.3; color: #20352d; }
.header-desc { margin: 8px 0 0; font-size: 13px; color: #87928d; }
.header-date { display: flex; align-items: center; gap: 11px; padding: 12px 16px; border: 1px solid #e3ded3; border-radius: 13px; background: #fffdf9; }
.header-date small, .header-date strong { display: block; }
.header-date small { margin-bottom: 3px; font-size: 10px; color: #9a9f9b; }
.header-date strong { font-size: 12px; color: #3d5048; }
.date-icon { position: relative; width: 34px; height: 34px; border-radius: 10px; background: #e6f2ed; }
.date-icon::before { content: ''; position: absolute; left: 8px; right: 8px; top: 10px; bottom: 7px; border: 2px solid #178a68; border-radius: 4px; }
.date-icon::after { content: ''; position: absolute; left: 8px; right: 8px; top: 15px; height: 2px; background: #178a68; }
.metric-grid { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 16px; margin-bottom: 18px; }
.metric-card { position: relative; overflow: hidden; min-height: 148px; padding: 20px 21px; border: 1px solid #e4e0d8; border-radius: 17px; background: #fffdf9; box-shadow: 0 8px 24px rgba(48,64,56,.045); }
.metric-card::after { content: ''; position: absolute; width: 78px; height: 78px; right: -28px; bottom: -32px; border-radius: 50%; background: currentColor; opacity: .06; }
.metric-card.emerald { color: #178a68; }
.metric-card.gold { color: #bc8a35; }
.metric-card.clay { color: #c66a58; }
.metric-card.forest { color: #516f62; }
.metric-top { display: flex; align-items: center; justify-content: space-between; }
.metric-label { font-size: 12px; color: #748079; }
.metric-icon { position: relative; width: 34px; height: 34px; border-radius: 10px; background: currentColor; }
.metric-icon::after { content: ''; position: absolute; inset: 8px; border: 2px solid #fff; border-radius: 4px; }
.success-icon::after { border-radius: 50%; }
.success-icon::before { content: ''; position: absolute; z-index: 1; left: 11px; top: 11px; width: 9px; height: 5px; transform: rotate(-45deg); border-left: 2px solid #fff; border-bottom: 2px solid #fff; }
.process-icon::after { border-radius: 50%; border-left-color: transparent; }
.agent-icon::after { border-radius: 50% 50% 5px 5px; }
.metric-value { margin-top: 14px; font-size: 31px; line-height: 1; font-weight: 700; letter-spacing: -.5px; color: #24372f; }
.metric-foot { display: flex; align-items: center; gap: 7px; margin-top: 14px; font-size: 10px; color: #9a9f9c; }
.metric-dot { width: 6px; height: 6px; border-radius: 50%; background: currentColor; }
.dashboard-grid { display: grid; grid-template-columns: minmax(0, 1.45fr) minmax(340px, .85fr); gap: 18px; margin-bottom: 18px; }
.lower-grid { grid-template-columns: minmax(0, 1.6fr) minmax(330px, .7fr); }
.panel { border: 1px solid #e4e0d8; border-radius: 17px; background: #fffdf9; box-shadow: 0 8px 24px rgba(48,64,56,.04); }
.panel-heading { display: flex; align-items: flex-start; justify-content: space-between; padding: 20px 22px 0; }
.panel-heading h2 { margin: 0; font-size: 16px; color: #263a33; }
.panel-heading p { margin: 6px 0 0; font-size: 10px; color: #9ca39f; }
.panel-chip { padding: 6px 10px; border-radius: 8px; background: #edf4f0; font-size: 10px; color: #547468; }
.chart-summary { display: flex; align-items: center; gap: 20px; padding: 20px 22px 0; }
.chart-summary small, .chart-summary strong { display: block; }
.chart-summary small { font-size: 10px; color: #9ca39f; }
.chart-summary strong { margin-top: 4px; font-size: 18px; color: #31473d; }
.summary-divider { width: 1px; height: 32px; background: #ebe7df; }
.bar-chart { height: 155px; display: flex; align-items: flex-end; justify-content: space-between; gap: 18px; padding: 22px 28px 20px; }
.bar-column { flex: 1; height: 100%; display: flex; flex-direction: column; align-items: center; justify-content: flex-end; }
.bar-track { width: 100%; max-width: 32px; height: 112px; display: flex; align-items: flex-end; border-radius: 8px; background: #f0eee8; }
.bar-fill { position: relative; width: 100%; min-height: 3px; border-radius: 8px; background: linear-gradient(180deg, #38a782, #178a68); transition: height .5s ease; }
.bar-fill span { position: absolute; left: 50%; top: -17px; transform: translateX(-50%); font-size: 9px; color: #77827c; }
.bar-label { margin-top: 9px; font-size: 9px; color: #949d98; }
.live-state { display: flex; align-items: center; gap: 6px; font-size: 10px; color: #75827c; }
.live-state i { width: 7px; height: 7px; border-radius: 50%; background: #32a477; box-shadow: 0 0 0 5px rgba(50,164,119,.1); }
.status-body { min-height: 230px; display: flex; align-items: center; justify-content: center; gap: 35px; padding: 18px 24px 24px; }
.donut { width: 136px; height: 136px; display: flex; align-items: center; justify-content: center; border-radius: 50%; }
.donut-center { width: 86px; height: 86px; display: flex; flex-direction: column; align-items: center; justify-content: center; border-radius: 50%; background: #fffdf9; box-shadow: 0 0 0 6px rgba(255,255,255,.46); }
.donut-center strong { font-size: 21px; color: #2c4037; }
.donut-center span { margin-top: 4px; font-size: 9px; color: #9ca39f; }
.status-legend { flex: 1; max-width: 180px; }
.legend-row { display: grid; grid-template-columns: 8px 1fr auto 32px; align-items: center; gap: 7px; padding: 8px 0; border-bottom: 1px dashed #ebe8e1; font-size: 10px; }
.legend-color { width: 7px; height: 7px; border-radius: 50%; }
.legend-name { color: #68756f; }
.legend-row strong { color: #33483e; }
.legend-row small { text-align: right; color: #9ca39f; }
.text-button { border: 0; background: transparent; font-size: 10px; color: #178a68; cursor: pointer; }
.text-button span { margin-left: 4px; }
.order-table { padding: 15px 22px 22px; }
.table-head, .table-row { display: grid; grid-template-columns: 1.45fr 1fr .72fr .72fr .85fr; align-items: center; gap: 12px; }
.table-head { height: 34px; padding: 0 12px; border-radius: 8px; background: #f5f3ed; font-size: 9px; color: #929b96; }
.table-row { min-height: 50px; padding: 0 12px; border-bottom: 1px solid #f0ede7; font-size: 10px; color: #5c6c65; }
.order-no { overflow: hidden; white-space: nowrap; text-overflow: ellipsis; font-weight: 600; color: #354b41; }
.money { font-weight: 600; color: #9a6d25; }
.order-time { color: #8f9994; }
.status-tag { display: inline-block; padding: 4px 7px; border-radius: 6px; font-size: 9px; font-weight: 500; }
.status-tag.success { background: #e8f4ef; color: #178a68; }
.status-tag.processing { background: #faf1de; color: #a7772d; }
.status-tag.pending { background: #f4eee1; color: #93764a; }
.status-tag.closed { background: #f8e9e6; color: #bd6556; }
.empty-orders { min-height: 210px; display: flex; flex-direction: column; align-items: center; justify-content: center; color: #a6ada9; }
.empty-orders span { font-size: 30px; color: #c8cec9; }
.empty-orders p { margin: 7px 0 0; font-size: 11px; }
.quick-panel { padding-bottom: 18px; }
.quick-grid { display: grid; gap: 8px; padding: 16px 18px 10px; }
.quick-item { width: 100%; min-height: 56px; display: grid; grid-template-columns: 38px 1fr 12px; align-items: center; gap: 11px; padding: 8px 10px; border: 1px solid transparent; border-radius: 11px; background: #f7f5ef; text-align: left; cursor: pointer; transition: .2s; }
.quick-item:hover { transform: translateX(3px); border-color: #d9e4de; background: #f0f6f2; }
.quick-item > span:nth-child(2) { min-width: 0; }
.quick-item strong, .quick-item small { display: block; }
.quick-item strong { font-size: 11px; color: #344a40; }
.quick-item small { margin-top: 3px; font-size: 9px; color: #9ca49f; }
.quick-item > b { font-size: 20px; font-weight: 400; color: #9da7a2; }
.quick-icon { position: relative; width: 36px; height: 36px; border-radius: 10px; background: #e6f1ec; color: #178a68; }
.quick-icon::before { content: ''; position: absolute; inset: 10px; border: 2px solid currentColor; border-radius: 4px; }
.quick-agent { background: #f5ecd9; color: #ae7a27; }
.quick-agent::before { border-radius: 50% 50% 4px 4px; }
.quick-product { background: #eee9e0; color: #6f6554; }
.quick-message { background: #f5e8e4; color: #b66657; }
.system-card { display: grid; grid-template-columns: 34px 1fr 8px; align-items: center; gap: 10px; margin: 8px 18px 0; padding: 12px; border-radius: 11px; background: #22372f; color: #fff; }
.system-check { width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; border-radius: 9px; background: rgba(213,168,84,.17); color: #e1bd75; }
.system-card strong, .system-card span { display: block; }
.system-card strong { font-size: 10px; }
.system-card span { margin-top: 4px; font-size: 8px; color: #9eb0a8; }
.pulse-dot { width: 7px; height: 7px; border-radius: 50%; background: #4ed29d; box-shadow: 0 0 0 5px rgba(78,210,157,.1); }
@media (max-width: 1180px) { .metric-grid { grid-template-columns: repeat(2, 1fr); } .dashboard-grid, .lower-grid { grid-template-columns: 1fr; } }
@media (max-width: 680px) { .dashboard-page { padding: 18px 14px 28px; } .dashboard-header { align-items: flex-start; } .header-date { display: none; } .metric-grid { grid-template-columns: 1fr; } .status-body { flex-direction: column; } .table-head { display: none; } .table-row { grid-template-columns: 1fr 1fr; padding: 10px; } .order-time { display: none; } }
</style>
