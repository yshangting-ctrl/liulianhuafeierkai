<template>
  <div class="login-page">
    <div class="ambient ambient-one"></div>
    <div class="ambient ambient-two"></div>
    <div class="grid-texture"></div>

    <main class="login-layout">
      <section class="brand-panel">
        <div class="brand-top">
          <div class="brand-mark" aria-hidden="true">
            <span class="signal signal-one"></span>
            <span class="signal signal-two"></span>
            <span class="signal signal-three"></span>
          </div>
          <div class="brand-name">
            <strong>话费充值</strong>
            <span>运营管理中心</span>
          </div>
        </div>

        <div class="brand-content">
          <div class="eyebrow"><span></span> RECHARGE OPERATIONS</div>
          <h1>让每一笔充值<br><em>清晰、高效、可控</em></h1>
          <p>聚合订单、产品、渠道与财务数据，为平台运营提供稳定可靠的管理能力。</p>

          <div class="feature-list">
            <div class="feature-item">
              <div class="feature-icon order-feature"><i></i></div>
              <div><strong>订单管理</strong><span>全流程状态追踪</span></div>
            </div>
            <div class="feature-item">
              <div class="feature-icon data-feature"><i></i></div>
              <div><strong>经营数据</strong><span>核心指标集中呈现</span></div>
            </div>
            <div class="feature-item">
              <div class="feature-icon safe-feature"><i></i></div>
              <div><strong>安全稳定</strong><span>权限与风控双重保障</span></div>
            </div>
          </div>
        </div>

        <div class="brand-status">
          <span class="status-dot"></span>
          <span>系统服务运行正常</span>
          <i></i>
          <span>安全连接</span>
        </div>
      </section>

      <section class="form-panel">
        <div class="mobile-brand">
          <div class="brand-mark small-mark" aria-hidden="true">
            <span class="signal signal-one"></span>
            <span class="signal signal-two"></span>
            <span class="signal signal-three"></span>
          </div>
          <strong>话费充值管理平台</strong>
        </div>

        <div class="form-heading">
          <span class="heading-badge">MANAGEMENT CONSOLE</span>
          <h2>欢迎登录</h2>
          <p>请输入管理账号，进入运营工作台</p>
        </div>

        <el-form ref="loginForm" :model="loginForm" :rules="loginRules" class="login-form">
          <div class="field-label">账号</div>
          <el-form-item prop="username">
            <el-input v-model="loginForm.username" type="text" autocomplete="username" placeholder="请输入管理账号">
              <svg-icon slot="prefix" icon-class="user" class="input-icon" />
            </el-input>
          </el-form-item>

          <div class="field-label">密码</div>
          <el-form-item prop="password">
            <el-input v-model="loginForm.password" type="password" autocomplete="current-password"
              placeholder="请输入登录密码" show-password @keyup.enter.native="handleLogin">
              <svg-icon slot="prefix" icon-class="password" class="input-icon" />
            </el-input>
          </el-form-item>

          <template v-if="captchaEnabled">
            <div class="field-label">验证码</div>
            <el-form-item prop="code" class="captcha-form-item">
              <div class="captcha-row">
                <el-input v-model="loginForm.code" autocomplete="off" placeholder="请输入验证码"
                  @keyup.enter.native="handleLogin">
                  <svg-icon slot="prefix" icon-class="validCode" class="input-icon" />
                </el-input>
                <button type="button" class="captcha-box" title="点击刷新验证码" @click="getCode">
                  <img v-if="codeUrl" :src="codeUrl" alt="验证码">
                  <span v-else>加载中...</span>
                  <i class="refresh-icon">↻</i>
                </button>
              </div>
            </el-form-item>
          </template>

          <div class="form-options">
            <el-checkbox v-model="loginForm.rememberMe">记住登录信息</el-checkbox>
            <span class="secure-label"><i></i> 数据加密传输</span>
          </div>

          <el-button class="login-button" :loading="loading" type="primary" @click.native.prevent="handleLogin">
            <span v-if="!loading">登录管理平台 <b>→</b></span>
            <span v-else>正在安全登录...</span>
          </el-button>
        </el-form>

        <div class="login-help">
          <span class="help-icon">?</span>
          <span>登录遇到问题，请联系系统管理员</span>
        </div>
      </section>
    </main>

    <footer class="login-footer">
      <span>© {{ currentYear }} 话费充值管理平台</span>
      <i></i>
      <a href="https://beian.miit.gov.cn" target="_blank" rel="noopener noreferrer">粤ICP备17106363号</a>
    </footer>
  </div>
</template>

<script>
import { getCodeImg } from '@/api/login'
import Cookies from 'js-cookie'
import { encrypt, decrypt } from '@/utils/jsencrypt'

export default {
  name: 'Login',
  data() {
    return {
      currentYear: new Date().getFullYear(),
      codeUrl: '',
      loginForm: {
        username: '',
        password: '',
        rememberMe: false,
        code: '',
        uuid: ''
      },
      loginRules: {
        username: [{ required: true, trigger: 'blur', message: '请输入您的账号' }],
        password: [{ required: true, trigger: 'blur', message: '请输入您的密码' }],
        code: [{ required: true, trigger: 'change', message: '请输入验证码' }]
      },
      loading: false,
      captchaEnabled: true,
      redirect: undefined
    }
  },
  watch: {
    $route: {
      handler(route) {
        this.redirect = route.query && route.query.redirect
      },
      immediate: true
    }
  },
  created() {
    this.getCode()
    this.getCookie()
  },
  methods: {
    getCode() {
      getCodeImg().then(res => {
        this.captchaEnabled = res.captchaEnabled === undefined ? true : res.captchaEnabled
        if (this.captchaEnabled) {
          this.codeUrl = 'data:image/jpeg;base64,' + res.img
          this.loginForm.uuid = res.uuid
        }
      })
    },
    getCookie() {
      const username = Cookies.get('username')
      const password = Cookies.get('password')
      const rememberMe = Cookies.get('rememberMe')
      this.loginForm.username = username === undefined ? '' : username
      this.loginForm.password = password === undefined ? '' : decrypt(password)
      this.loginForm.rememberMe = rememberMe === undefined ? false : rememberMe === 'true'
    },
    handleLogin() {
      this.$refs.loginForm.validate(valid => {
        if (!valid) return
        this.loading = true
        if (this.loginForm.rememberMe) {
          Cookies.set('username', this.loginForm.username, { expires: 30 })
          Cookies.set('password', encrypt(this.loginForm.password), { expires: 30 })
          Cookies.set('rememberMe', this.loginForm.rememberMe, { expires: 30 })
        } else {
          Cookies.remove('username')
          Cookies.remove('password')
          Cookies.remove('rememberMe')
        }
        this.$store.dispatch('Login', this.loginForm).then(() => {
          this.$router.push({ path: this.redirect || '/' }).catch(() => {})
        }).catch(() => {
          this.loading = false
          if (this.captchaEnabled) this.getCode()
        })
      })
    }
  }
}
</script>

<style lang="scss">
$blue: #178a68;
$navy: #263a33;
$cyan: #d5a854;

.login-page {
  position: relative;
  min-height: 100vh;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
  padding: 48px 48px 70px;
  background: linear-gradient(145deg, #eee9de 0%, #faf8f2 46%, #edf3ed 100%);
  color: #263a33;
  font-family: "PingFang SC", "Microsoft YaHei", Arial, sans-serif;
}

.grid-texture {
  position: absolute;
  inset: 0;
  opacity: .42;
  background-image: linear-gradient(rgba(38, 58, 51, .045) 1px, transparent 1px),
    linear-gradient(90deg, rgba(38, 58, 51, .045) 1px, transparent 1px);
  background-size: 32px 32px;
  mask-image: linear-gradient(to right, #000, transparent 72%);
}

.ambient {
  position: absolute;
  border-radius: 50%;
  filter: blur(4px);
  pointer-events: none;
}
.ambient-one {
  width: 520px;
  height: 520px;
  top: -250px;
  left: -150px;
  background: radial-gradient(circle, rgba(213, 168, 84, .22), rgba(213, 168, 84, 0) 70%);
}
.ambient-two {
  width: 640px;
  height: 640px;
  right: -300px;
  bottom: -330px;
  background: radial-gradient(circle, rgba(23, 138, 104, .17), rgba(23, 138, 104, 0) 70%);
}

.login-layout {
  position: relative;
  z-index: 2;
  width: min(1100px, 94vw);
  min-height: 650px;
  display: grid;
  grid-template-columns: 1.08fr .92fr;
  overflow: hidden;
  border: 1px solid rgba(91, 116, 105, .18);
  border-radius: 28px;
  background: rgba(255, 255, 255, .92);
  box-shadow: 0 35px 90px rgba(38, 58, 51, .18), 0 4px 16px rgba(38, 58, 51, .08);
  backdrop-filter: blur(18px);
}

.brand-panel {
  position: relative;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  padding: 48px 54px 38px;
  background: linear-gradient(150deg, #1b2f29 0%, #174c3d 52%, #1f7a5a 100%);
  color: #fff;
}
.brand-panel::before {
  content: '';
  position: absolute;
  width: 460px;
  height: 460px;
  right: -270px;
  top: -210px;
  border: 70px solid rgba(255, 255, 255, .07);
  border-radius: 50%;
}
.brand-panel::after {
  content: '';
  position: absolute;
  left: -80px;
  right: -80px;
  bottom: -142px;
  height: 310px;
  transform: rotate(-6deg);
  border-radius: 50% 50% 0 0;
  background: linear-gradient(90deg, rgba(213, 168, 84, .26), rgba(255, 255, 255, .05));
}

.brand-top,
.brand-content,
.brand-status { position: relative; z-index: 2; }
.brand-top { display: flex; align-items: center; gap: 14px; }
.brand-mark {
  position: relative;
  width: 48px;
  height: 48px;
  border: 1px solid rgba(255, 255, 255, .4);
  border-radius: 15px;
  background: linear-gradient(145deg, rgba(255,255,255,.24), rgba(255,255,255,.1));
  box-shadow: inset 0 1px 0 rgba(255,255,255,.3), 0 10px 24px rgba(8, 35, 27, .22);
}
.signal {
  position: absolute;
  left: 12px;
  bottom: 11px;
  width: 6px;
  border-radius: 5px 5px 2px 2px;
  background: #fff;
}
.signal-one { height: 12px; }
.signal-two { left: 21px; height: 20px; background: #e1bd75; }
.signal-three { left: 30px; height: 28px; background: #fff; }
.brand-name { display: flex; flex-direction: column; }
.brand-name strong { font-size: 20px; letter-spacing: 1px; }
.brand-name span { margin-top: 3px; font-size: 11px; letter-spacing: 3px; color: rgba(255,255,255,.63); }

.brand-content { margin: auto 0; padding: 34px 0; }
.eyebrow { display: flex; align-items: center; gap: 9px; font-size: 11px; letter-spacing: 2.5px; color: #e1bd75; }
.eyebrow span { width: 28px; height: 2px; border-radius: 2px; background: #d5a854; }
.brand-content h1 { margin: 22px 0 18px; font-size: 39px; line-height: 1.42; font-weight: 700; letter-spacing: 1px; }
.brand-content h1 em { font-style: normal; color: #e8ca8d; }
.brand-content > p { max-width: 440px; margin: 0; font-size: 14px; line-height: 1.9; color: rgba(235, 246, 255, .76); }
.feature-list { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-top: 38px; }
.feature-item {
  min-width: 0;
  padding: 16px 12px;
  border: 1px solid rgba(255, 255, 255, .14);
  border-radius: 14px;
  background: rgba(255, 255, 255, .075);
  backdrop-filter: blur(8px);
}
.feature-icon { position: relative; width: 28px; height: 28px; margin-bottom: 12px; color: #e1bd75; }
.feature-item strong, .feature-item span { display: block; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
.feature-item strong { font-size: 13px; color: #fff; }
.feature-item span { margin-top: 5px; font-size: 10px; color: rgba(255,255,255,.58); }
.order-feature { border: 2px solid currentColor; border-radius: 6px; }
.order-feature::before, .order-feature::after, .order-feature i { content: ''; position: absolute; left: 6px; width: 13px; height: 2px; border-radius: 2px; background: currentColor; }
.order-feature::before { top: 7px; }
.order-feature i { top: 12px; }
.order-feature::after { top: 17px; }
.data-feature::before { content: ''; position: absolute; inset: 2px 1px; border-left: 2px solid currentColor; border-bottom: 2px solid currentColor; border-radius: 0 0 0 4px; }
.data-feature::after { content: ''; position: absolute; left: 6px; top: 13px; width: 17px; height: 10px; border-left: 3px solid currentColor; border-top: 3px solid currentColor; transform: skewY(-30deg) rotate(8deg); }
.safe-feature { border: 2px solid currentColor; border-radius: 50% 50% 55% 55%; transform: scale(.85); }
.safe-feature::after { content: ''; position: absolute; left: 8px; top: 6px; width: 8px; height: 4px; transform: rotate(-45deg); border-left: 3px solid currentColor; border-bottom: 3px solid currentColor; }
.brand-status { display: flex; align-items: center; gap: 9px; font-size: 11px; color: rgba(255,255,255,.65); }
.brand-status i { width: 1px; height: 12px; margin: 0 6px; background: rgba(255,255,255,.22); }
.status-dot { width: 7px; height: 7px; border-radius: 50%; background: #5df0ad; box-shadow: 0 0 0 5px rgba(93,240,173,.12); }

.form-panel {
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding: 56px 66px;
  background: linear-gradient(155deg, rgba(255,255,255,.98), rgba(249,247,241,.94));
}
.mobile-brand { display: none; }
.heading-badge { display: inline-block; margin-bottom: 14px; font-size: 10px; font-weight: 700; letter-spacing: 2px; color: $blue; }
.form-heading h2 { margin: 0; font-size: 30px; line-height: 1.25; font-weight: 700; color: $navy; }
.form-heading p { margin: 10px 0 32px; font-size: 13px; color: #89968f; }
.field-label { margin: 0 0 8px 2px; font-size: 12px; font-weight: 600; color: #52675e; }
.login-form .el-form-item { margin-bottom: 22px; }
.login-form .el-input__inner {
  height: 49px;
  padding-left: 45px;
  border: 1px solid #dfe7e1;
  border-radius: 11px;
  background: #fafbf8;
  font-size: 13px;
  color: #263a33;
  transition: all .2s ease;
}
.login-form .el-input__inner:hover { border-color: #a9c8ba; }
.login-form .el-input__inner:focus { border-color: #178a68; background: #fff; box-shadow: 0 0 0 4px rgba(23,138,104,.1); }
.login-form .el-input__prefix { left: 15px; display: flex; align-items: center; color: #78958a; }
.login-form .input-icon { width: 17px; height: 17px; }
.captcha-row { display: grid; grid-template-columns: 1fr 128px; gap: 12px; }
.captcha-box {
  position: relative;
  height: 49px;
  overflow: hidden;
  padding: 0;
  border: 1px solid #dfe7e1;
  border-radius: 11px;
  background: #f7f8f3;
  cursor: pointer;
  color: #829188;
}
.captcha-box img { width: 100%; height: 100%; object-fit: cover; }
.captcha-box span { font-size: 11px; }
.refresh-icon {
  position: absolute;
  right: 4px;
  bottom: 3px;
  width: 18px;
  height: 18px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  background: rgba(38, 58, 51, .82);
  font-size: 13px;
  font-style: normal;
  color: #fff;
}
.form-options { display: flex; align-items: center; justify-content: space-between; margin: -2px 0 25px; }
.form-options .el-checkbox__label { padding-left: 7px; font-size: 12px; color: #687970; }
.secure-label { display: flex; align-items: center; gap: 6px; font-size: 11px; color: #91a099; }
.secure-label i { width: 7px; height: 7px; border-radius: 50%; background: #20b879; box-shadow: 0 0 0 4px rgba(32,184,121,.1); }
.login-button.el-button {
  width: 100%;
  height: 50px;
  border: 0;
  border-radius: 11px;
  background: linear-gradient(100deg, #176f56, #1d9a72);
  box-shadow: 0 13px 28px rgba(23,138,104,.24);
  font-size: 14px;
  font-weight: 600;
  letter-spacing: 1px;
  transition: all .2s ease;
}
.login-button.el-button:hover { transform: translateY(-1px); box-shadow: 0 16px 30px rgba(23,138,104,.3); background: linear-gradient(100deg, #125f49, #178a68); }
.login-button b { display: inline-block; margin-left: 10px; font-size: 18px; font-weight: 400; transition: transform .2s; }
.login-button:hover b { transform: translateX(3px); }
.login-help { display: flex; align-items: center; justify-content: center; gap: 7px; margin-top: 24px; font-size: 11px; color: #9aa69f; }
.help-icon { width: 16px; height: 16px; display: inline-flex; align-items: center; justify-content: center; border: 1px solid #b8c5be; border-radius: 50%; font-size: 10px; }

.login-footer {
  position: absolute;
  z-index: 2;
  left: 0;
  right: 0;
  bottom: 22px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 13px;
  font-size: 11px;
  color: #8d9a93;
}
.login-footer i { width: 1px; height: 11px; background: #c7d1ca; }
.login-footer a { color: #71877c; text-decoration: none; }
.login-footer a:hover { color: $blue; }

@media (max-width: 900px) {
  .login-page { padding: 28px 22px 65px; }
  .login-layout { width: min(460px, 100%); min-height: auto; display: block; border-radius: 22px; }
  .brand-panel { display: none; }
  .form-panel { padding: 42px 38px; }
  .mobile-brand { display: flex; align-items: center; gap: 11px; margin-bottom: 34px; color: $navy; }
  .mobile-brand .brand-mark { flex: 0 0 auto; background: linear-gradient(145deg, #174c3d, #1f8f69); }
  .mobile-brand strong { font-size: 17px; }
  .small-mark { transform: scale(.86); transform-origin: left center; margin-right: -5px; }
}

@media (max-width: 520px) {
  .login-page { align-items: flex-start; padding: 18px 14px 68px; overflow-y: auto; }
  .login-layout { margin-top: 3vh; }
  .form-panel { padding: 32px 24px 30px; }
  .mobile-brand { margin-bottom: 27px; }
  .form-heading h2 { font-size: 27px; }
  .form-heading p { margin-bottom: 27px; }
  .captcha-row { grid-template-columns: 1fr 112px; gap: 9px; }
  .secure-label { display: none; }
  .login-footer { bottom: 14px; font-size: 10px; }
  .login-footer span { display: none; }
  .login-footer i { display: none; }
}
</style>
