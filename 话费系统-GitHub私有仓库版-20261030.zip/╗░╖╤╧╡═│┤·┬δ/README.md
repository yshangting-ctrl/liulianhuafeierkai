# 话费充值系统

该仓库包含管理端、代理端、公众号 H5、两个 Spring Boot 后端及数据库结构。

## 目录

- `话费充值平台前端`：管理端 Vue 2
- `话费充值代理商前端`：代理端 Vue 2
- `话费充值公众号前端代码`：uni-app H5
- `话费充值平台后端`：管理/H5 Spring Boot 后端，默认端口 8980
- `话费充值代理商后端`：代理端 Spring Boot 后端，默认端口 8981

## 环境

- JDK 8、Maven 3.8+
- Node.js、npm
- MySQL 5.7/8.0
- Redis
- HBuilderX（H5 推荐）

## 安全配置

仓库包已经移除数据库业务数据、前端私钥及已发现的硬编码密钥。启动前请通过环境变量配置：

- `DB_URL`、`DB_USERNAME`、`DB_PASSWORD`
- `REDIS_HOST`、`REDIS_PASSWORD`
- `JWT_SECRET`
- `APP_RSA_PRIVATE_KEY`
- `WX_OPEN_APP_ID`、`WX_OPEN_APP_SECRET`、`WX_OPEN_TOKEN`、`WX_OPEN_AES_KEY`
- `WX_APP_ID`、`WX_APP_SECRET`、`WX_AES_KEY`
- `WX_JSAPI_ACCESS_TOKEN`、`WX_DEBUG_ACCESS_TOKEN`
- `WX_KEY_FILE`、`WX_PAY_FILE`
- `JIPU_API_SECRET`、`JIPU_API_TOKEN`、`JIPU_ACTIVITY_ID`
- `PUBLIC_FILE_URL`、`PUBLIC_API_URL`

严禁把真实密码、支付证书、公众号密钥或生产数据库备份提交到仓库，即使仓库设置为私有。

## 安装

前端进入对应目录执行：

```bash
npm install
npm run dev
```

旧 Vue CLI 在新版本 Node.js 下如遇 OpenSSL 错误，可临时设置 `NODE_OPTIONS=--openssl-legacy-provider`。

后端进入对应 Maven 根目录执行：

```bash
mvn clean package -DskipTests
```

数据库结构位于 `话费充值平台后端/数据库文件/swrecharge.sql`，GitHub 包仅保留结构，业务数据请从本地安全备份恢复。
